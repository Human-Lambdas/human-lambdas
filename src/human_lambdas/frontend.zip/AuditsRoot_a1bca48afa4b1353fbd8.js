(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["AuditsRoot"],{

/***/ "./src/client/components/EmptyPage.tsx":
/*!*********************************************!*\
  !*** ./src/client/components/EmptyPage.tsx ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styles_typography__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styles/typography */ "./src/client/styles/typography.ts");
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/EmptyPage.tsx";




const Wrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1mrkvlm0"
})({
  backgroundColor: '#fff',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  height: '100%',
  width: '100%',
  fontFamily: styles_typography__WEBPACK_IMPORTED_MODULE_2__["FONT_FAMILY"].SANS_SERIF
});

const Title = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1mrkvlm1"
})({
  color: styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_MAIN,
  fontSize: 24,
  fontWeight: 500,
  margin: '20px 0 15px'
});

const SubTitle = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1mrkvlm2"
})({
  color: styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_MAIN,
  fontSize: 16,
  fontWeight: 400,
  margin: '0px 0 20px',
  '> div > a': {
    color: styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].PRIMARY_MAIN
  }
});

const EmptyPage = ({
  svg,
  header,
  subHeader,
  button
}) => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Wrapper, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    }
  }, svg, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Title, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }, header), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(SubTitle, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    }
  }, subHeader), button);
};

/* harmony default export */ __webpack_exports__["default"] = (EmptyPage);

/***/ }),

/***/ "./src/client/components/IconButtonWrapper.tsx":
/*!*****************************************************!*\
  !*** ./src/client/components/IconButtonWrapper.tsx ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
/* harmony import */ var components_PlainButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! components/PlainButton */ "./src/client/components/PlainButton.tsx");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/IconButtonWrapper.tsx"; // TODO replace IconButton





const Container = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(components_PlainButton__WEBPACK_IMPORTED_MODULE_3__["default"], {
  target: "e110poak0"
})({
  cursor: 'pointer',
  backgroundColor: 'inherit',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: 50,
  width: 25,
  height: 25,
  padding: 0,
  margin: 0,
  transition: 'all 200ms ease-in',
  ':hover': {
    backgroundColor: styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].BACKGROUND_HOVER
  }
});

const IconButton = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["forwardRef"])((props, ref) => {
  const {
    onClick,
    type,
    children
  } = props;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Container, {
    ref: ref,
    onClick: onClick,
    type: type,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }, children);
});
/* harmony default export */ __webpack_exports__["default"] = (IconButton);

/***/ }),

/***/ "./src/client/components/Icons/ArrowLeftSVG.tsx":
/*!******************************************************!*\
  !*** ./src/client/components/Icons/ArrowLeftSVG.tsx ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Icons/ArrowLeftSVG.tsx";


const ArrowLeftSVG = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(() => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', {
    height: "13",
    viewBox: "0 0 515.555 515.555",
    width: "13",
    xmlns: "http://www.w3.org/2000/svg",
    fill: styles_palette__WEBPACK_IMPORTED_MODULE_1__["PALETTE"].TEXT_MAIN,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M143.492 221.863L336.226 29.129c6.663-6.664 6.663-17.468 0-24.132-6.665-6.662-17.468-6.662-24.132 0l-204.8 204.8c-6.662 6.664-6.662 17.468 0 24.132l204.8 204.8c6.78 6.548 17.584 6.36 24.132-.42 6.387-6.614 6.387-17.099 0-23.712L143.492 221.863z",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }));
});
/* harmony default export */ __webpack_exports__["default"] = (ArrowLeftSVG);

/***/ }),

/***/ "./src/client/components/Icons/ArrowRightSVG.tsx":
/*!*******************************************************!*\
  !*** ./src/client/components/Icons/ArrowRightSVG.tsx ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Icons/ArrowRightSVG.tsx";


const ArrowRightSVG = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(() => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', {
    height: "13",
    viewBox: "0 0 515.555 515.555",
    width: "13",
    xmlns: "http://www.w3.org/2000/svg",
    fill: styles_palette__WEBPACK_IMPORTED_MODULE_1__["PALETTE"].TEXT_MAIN,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M336.226 209.591l-204.8-204.8c-6.78-6.548-17.584-6.36-24.132.42-6.388 6.614-6.388 17.099 0 23.712l192.734 192.734-192.734 192.734c-6.663 6.664-6.663 17.468 0 24.132 6.665 6.663 17.468 6.663 24.132 0l204.8-204.8c6.663-6.665 6.663-17.468 0-24.132z",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }));
});
/* harmony default export */ __webpack_exports__["default"] = (ArrowRightSVG);

/***/ }),

/***/ "./src/client/components/Icons/EmptyAuditsSVG.tsx":
/*!********************************************************!*\
  !*** ./src/client/components/Icons/EmptyAuditsSVG.tsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Icons/EmptyAuditsSVG.tsx";


const EmptyAuditsSVG = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(() => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', {
    fill: styles_palette__WEBPACK_IMPORTED_MODULE_1__["PALETTE"].BACKGROUND_GRAY_MID,
    height: 100,
    width: 100,
    viewBox: "0 0 24 24",
    xmlns: "http://www.w3.org/2000/svg",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M0 0h24v24H0z",
    fill: "none",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-6 15h-2v-2h2v2zm0-4h-2V8h2v6zm-1-9c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    }
  }));
});
/* harmony default export */ __webpack_exports__["default"] = (EmptyAuditsSVG);

/***/ }),

/***/ "./src/client/components/Icons/FilterSVG.tsx":
/*!***************************************************!*\
  !*** ./src/client/components/Icons/FilterSVG.tsx ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Icons/FilterSVG.tsx";


const FilterSVG = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(props => {
  const {
    color
  } = props;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', {
    height: "15",
    viewBox: "0 0 515.555 515.555",
    width: "15",
    xmlns: "http://www.w3.org/2000/svg",
    fill: color || styles_palette__WEBPACK_IMPORTED_MODULE_1__["PALETTE"].TEXT_MAIN,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M178.5 382.5h102v-51h-102v51zM0 76.5v51h459v-51H0zM76.5 255h306v-51h-306v51z",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 18
    }
  }));
});
/* harmony default export */ __webpack_exports__["default"] = (FilterSVG);

/***/ }),

/***/ "./src/client/components/StandardMenu.tsx":
/*!************************************************!*\
  !*** ./src/client/components/StandardMenu.tsx ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Menu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Menu */ "./src/client/components/Menu.tsx");
/* harmony import */ var _MenuItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./MenuItem */ "./src/client/components/MenuItem.tsx");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/StandardMenu.tsx";




const StandardMenu = props => {
  const {
    menuProps,
    menuItems
  } = props;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Menu__WEBPACK_IMPORTED_MODULE_1__["default"], _objectSpread(_objectSpread({
    ariaLabel: 'Standard dropdown menu'
  }, menuProps), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    }
  }), menuItems.map(({
    label,
    onClick
  }, idx) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_MenuItem__WEBPACK_IMPORTED_MODULE_2__["default"], {
    key: idx,
    label: label,
    onClick: onClick,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 16
    }
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (StandardMenu);

/***/ }),

/***/ "./src/universal/modules/audits/AuditsRoot.tsx":
/*!*****************************************************!*\
  !*** ./src/universal/modules/audits/AuditsRoot.tsx ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _components_Audits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/Audits */ "./src/universal/modules/audits/components/Audits.tsx");
/* harmony import */ var client_hooks_useNetworker__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! client/hooks/useNetworker */ "./src/client/hooks/useNetworker.ts");
/* harmony import */ var client_components_LoadingPage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! client/components/LoadingPage */ "./src/client/components/LoadingPage.tsx");
/* harmony import */ var client_redux_filtersReducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! client/redux/filtersReducer */ "./src/client/redux/filtersReducer.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/modules/audits/AuditsRoot.tsx";







const AuditsRoot = props => {
  const {
    user,
    users,
    auditFilters,
    setUserId,
    setQueueId
  } = props || {};
  const [audits, setAudits] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [queues, setQueues] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [offset, setOffset] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(0);
  const [loading, setLoading] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const {
    queue_id: queueId,
    worker_id: userId
  } = auditFilters;
  const networker = Object(client_hooks_useNetworker__WEBPACK_IMPORTED_MODULE_3__["default"])();
  const orgId = user.current_organization_id;
  const {
    tasks,
    count
  } = audits || {};
  const PAGE_LIMIT = 50;
  const onNext = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => {
    if (offset < Math.abs(count - PAGE_LIMIT)) {
      setOffset(offset + PAGE_LIMIT);
    }
  }, [count, offset]);
  const onBack = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => {
    if (offset >= PAGE_LIMIT) {
      setOffset(offset - PAGE_LIMIT);
    }
  }, [count, offset]);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    async function fetchAudits() {
      setLoading(true);
      const payload = {
        method: 'GET',
        params: _objectSpread(_objectSpread({}, auditFilters), {}, {
          limit: PAGE_LIMIT,
          offset
        })
      };
      const {
        data
      } = await networker.httpHandler(`/orgs/${orgId}/queues/tasks/completed`, payload);
      const {
        data: queues
      } = await networker.httpHandler(`/orgs/${orgId}/queues`, {
        method: 'GET',
        params: {
          task_status: 'completed'
        }
      });
      setAudits(data);
      setQueues(queues);
      setLoading(false);
    }

    fetchAudits();
  }, [queueId, userId, offset, user]);
  if (loading) return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(client_components_LoadingPage__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 68
    }
  });
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_Audits__WEBPACK_IMPORTED_MODULE_2__["default"], {
    tasks: tasks || [],
    count: count,
    onNext: onNext,
    onBack: onBack,
    limit: PAGE_LIMIT,
    offset: offset,
    queues: queues,
    setQueueId: setQueueId,
    queueId: queueId,
    users: users,
    setUserId: setUserId,
    userId: userId,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    }
  });
};

const mapStateToProps = state => ({
  users: state.users,
  auditFilters: state.filters.auditFilters
});

const mapDispatchToProps = dispatch => ({
  setQueueId: arg => dispatch(client_redux_filtersReducer__WEBPACK_IMPORTED_MODULE_5__["filterActions"].setAuditsQueue(arg)),
  setUserId: arg => dispatch(client_redux_filtersReducer__WEBPACK_IMPORTED_MODULE_5__["filterActions"].setAuditsUser(arg))
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_1__["connect"])(mapStateToProps, mapDispatchToProps)(AuditsRoot));

/***/ }),

/***/ "./src/universal/modules/audits/components/Audits.tsx":
/*!************************************************************!*\
  !*** ./src/universal/modules/audits/components/Audits.tsx ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! dayjs */ "./node_modules/dayjs/dayjs.min.js");
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var client_styles_palette__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! client/styles/palette */ "./src/client/styles/palette.ts");
/* harmony import */ var client_components_ListPage_ListPage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! client/components/ListPage/ListPage */ "./src/client/components/ListPage/ListPage.tsx");
/* harmony import */ var client_components_PlainButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! client/components/PlainButton */ "./src/client/components/PlainButton.tsx");
/* harmony import */ var client_components_Icons_ArrowLeftSVG__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! client/components/Icons/ArrowLeftSVG */ "./src/client/components/Icons/ArrowLeftSVG.tsx");
/* harmony import */ var client_components_Icons_ArrowRightSVG__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! client/components/Icons/ArrowRightSVG */ "./src/client/components/Icons/ArrowRightSVG.tsx");
/* harmony import */ var universal_components_Avatar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! universal/components/Avatar */ "./src/universal/components/Avatar.tsx");
/* harmony import */ var universal_utils_getInitials__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! universal/utils/getInitials */ "./src/universal/utils/getInitials.ts");
/* harmony import */ var universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! universal/styles/helpers/textOverflow */ "./src/universal/styles/helpers/textOverflow.ts");
/* harmony import */ var client_hooks_useMenu__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! client/hooks/useMenu */ "./src/client/hooks/useMenu.ts");
/* harmony import */ var client_hooks_useCoords__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! client/hooks/useCoords */ "./src/client/hooks/useCoords.ts");
/* harmony import */ var client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! client/components/ListPage/ListTitle */ "./src/client/components/ListPage/ListTitle.tsx");
/* harmony import */ var client_components_StandardMenu__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! client/components/StandardMenu */ "./src/client/components/StandardMenu.tsx");
/* harmony import */ var client_components_Icons_FilterSVG__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! client/components/Icons/FilterSVG */ "./src/client/components/Icons/FilterSVG.tsx");
/* harmony import */ var client_components_EmptyPage__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! client/components/EmptyPage */ "./src/client/components/EmptyPage.tsx");
/* harmony import */ var client_components_Icons_EmptyAuditsSVG__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! client/components/Icons/EmptyAuditsSVG */ "./src/client/components/Icons/EmptyAuditsSVG.tsx");
/* harmony import */ var client_components_IconButtonWrapper__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! client/components/IconButtonWrapper */ "./src/client/components/IconButtonWrapper.tsx");
/* harmony import */ var universal_utils_getColor__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! universal/utils/getColor */ "./src/universal/utils/getColor.ts");
/* harmony import */ var universal_modules_task_components_Sidebar__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! universal/modules/task/components/Sidebar */ "./src/universal/modules/task/components/Sidebar.tsx");
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var universal_components_Icon__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! universal/components/Icon */ "./src/universal/components/Icon.tsx");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/modules/audits/components/Audits.tsx";
























const ColumnContainer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16d2yob0"
})({
  name: "i6hear",
  styles: "line-height:40px;height:40px;display:grid;grid-template-columns:100px 1fr 180px 100px 100px 80px 100px;grid-column-gap:15px;"
});

const Footer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16d2yob1"
})({
  name: "y8ru05",
  styles: "height:45px;display:grid;max-width:80%;grid-template-columns:200px 200px;justify-content:space-between;align-items:center;"
});

const Paginator = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16d2yob2"
})({
  name: "192qrng",
  styles: "display:flex;align-items:center;justify-content:flex-end;"
});

const Label = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "e16d2yob3"
})(_objectSpread({
  marginLeft: 7,
  width: '100%'
}, universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_11__["default"]));

const Spacer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16d2yob4"
})({
  name: "jgwfcl",
  styles: "margin-right:7px;display:flex;align-items:center;"
});

const LineItem = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16d2yob5"
})(_objectSpread({
  flexDirection: 'row',
  alignItems: 'center',
  cursor: 'pointer !important',
  display: 'block'
}, universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_11__["default"]));

const SmallText = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "e16d2yob6"
})({
  textAlign: 'left',
  color: client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_MAIN,
  fontSize: 14,
  userSelect: 'none'
});

const AvatarBlock = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16d2yob7"
})({
  name: "70qvj9",
  styles: "display:flex;align-items:center;"
});

const PageCount = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(client_components_PlainButton__WEBPACK_IMPORTED_MODULE_6__["default"], {
  target: "e16d2yob8"
})({
  color: client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_MAIN,
  fontSize: 14,
  fontWeight: 400,
  userSelect: 'none',
  backgroundColor: client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BACKGROUND_HOVER,
  marginLeft: 2,
  marginRight: 2,
  width: 'auto',
  borderRadius: 0,
  height: 25,
  lineHeight: '25px'
});

const PaginateBtn = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(client_components_PlainButton__WEBPACK_IMPORTED_MODULE_6__["default"], {
  target: "e16d2yob9"
})(({
  left
}) => {
  return {
    height: 25,
    lineHeight: '25px',
    width: 30,
    padding: 0,
    margin: 0,
    background: client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BACKGROUND_HOVER,
    borderTopRightRadius: left ? 0 : 4,
    borderBottomRightRadius: left ? 0 : 4,
    borderBottomLeftRadius: left ? 4 : 0,
    borderTopLeftRadius: left ? 4 : 0
  };
});

const StyledEl = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16d2yob10"
})(_objectSpread({
  margin: '0 15px',
  padding: '7px 0',
  fontWeight: 500,
  maxWidth: 350
}, universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_11__["default"]));

const HR = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16d2yob11"
})({
  height: 1,
  width: '100%',
  backgroundColor: client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BORDER_MAIN_GRAY
});

const StyledCommentsIcon = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_Icon__WEBPACK_IMPORTED_MODULE_23__["default"], {
  target: "e16d2yob12"
})({
  display: 'block',
  color: client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_GRAY,
  marginRight: 15,
  marginLeft: 4,
  fontSize: 17
});

const Audits = props => {
  const {
    tasks,
    count,
    onNext,
    onBack,
    limit,
    offset,
    queues,
    setQueueId,
    setUserId,
    queueId,
    userId,
    users
  } = props;
  const history = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["useHistory"])();
  const separator = {
    label: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(HR, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 166
      }
    })
  };
  const wMenuItems = queues.map(w => ({
    label: queueId === w.id ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledEl, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 169
      }
    }, w.name) : w.name,
    onClick: () => setQueueId(w.id)
  }));

  if (queueId) {
    wMenuItems.unshift(separator);
    wMenuItems.unshift({
      label: 'Clear filter',
      onClick: () => setQueueId(undefined)
    });
  }

  const cbMenuItems = users.map(u => ({
    label: userId === u.id ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledEl, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 178
      }
    }, u.name) : u.name,
    onClick: () => setUserId(u.id)
  }));

  if (userId) {
    cbMenuItems.unshift(separator);
    cbMenuItems.unshift({
      label: 'Clear filter',
      onClick: () => setUserId(undefined)
    });
  }

  const {
    menuPortal: menuPortalQueue,
    originRef: originRefQueue,
    menuProps: menuPropsQueue,
    togglePortal: togglePortalQueue
  } = Object(client_hooks_useMenu__WEBPACK_IMPORTED_MODULE_12__["default"])(client_hooks_useCoords__WEBPACK_IMPORTED_MODULE_13__["MenuPosition"].UPPER_RIGHT, {
    isDropdown: true,
    menuContentStyles: {
      width: 350
    }
  });
  const {
    menuPortal: menuPortalCb,
    originRef: originRefCb,
    menuProps: menuPropsCb,
    togglePortal: togglePortalCb
  } = Object(client_hooks_useMenu__WEBPACK_IMPORTED_MODULE_12__["default"])(client_hooks_useCoords__WEBPACK_IMPORTED_MODULE_13__["MenuPosition"].UPPER_RIGHT, {
    isDropdown: true,
    menuContentStyles: {
      width: 350
    }
  });
  const pageHeader = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ColumnContainer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 207
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_14__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 208
    }
  }, "Task ID"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_14__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 209
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Spacer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 211
    }
  }, "Queue Name"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_IconButtonWrapper__WEBPACK_IMPORTED_MODULE_19__["default"], {
    ref: originRefQueue,
    onClick: togglePortalQueue,
    type: "button",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 212
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_FilterSVG__WEBPACK_IMPORTED_MODULE_16__["default"], {
    color: queueId ? client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_MAIN : client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_GRAY,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 213
    }
  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_14__["default"], {
    align: "left",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 217
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Spacer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 219
    }
  }, "Completed By"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_IconButtonWrapper__WEBPACK_IMPORTED_MODULE_19__["default"], {
    ref: originRefCb,
    onClick: togglePortalCb,
    type: "button",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 220
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_FilterSVG__WEBPACK_IMPORTED_MODULE_16__["default"], {
    color: userId ? client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_MAIN : client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_GRAY,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 221
    }
  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_14__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 225
    }
  }, "Completed At"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_14__["default"], {
    align: "center",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 226
    }
  }, "Source"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_14__["default"], {
    align: "center",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 227
    }
  }, "Comments"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_14__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 228
    }
  }, "Audit"));
  const pageFooter = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Footer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 233
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(SmallText, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 234
    }
  }, count, " Completed tasks"), count > limit && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Paginator, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 236
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(PaginateBtn, {
    left: true,
    onClick: onBack,
    disabled: offset < limit,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 237
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_ArrowLeftSVG__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 238
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(PageCount, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 240
    }
  }, `${(offset / limit + 1).toFixed()} / ${Math.ceil(count / limit)}`), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(PaginateBtn, {
    onClick: onNext,
    disabled: offset >= Math.abs(count - limit),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 241
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_ArrowRightSVG__WEBPACK_IMPORTED_MODULE_8__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 242
    }
  }))));
  const auditDecisionIcon = {
    null: null,
    false: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_modules_task_components_Sidebar__WEBPACK_IMPORTED_MODULE_21__["AuditDecisionIcon"], {
      color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_22__["STATUS_PALETTE"].IN_PROGRESS,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 251
      }
    }, "cancel"),
    true: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_modules_task_components_Sidebar__WEBPACK_IMPORTED_MODULE_21__["AuditDecisionIcon"], {
      color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_22__["STATUS_PALETTE"].COMPLETED,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 252
      }
    }, "check_circle")
  };
  const itemList = tasks.map(({
    id: taskId,
    completed_by: completedBy,
    completed_at: completedAt,
    correct,
    queue: name,
    source,
    n_comments
  }) => {
    let sourceTextStyle = 'none';
    sourceTextStyle = ['manual', 'zapier'].includes(source) ? 'capitalize' : sourceTextStyle;
    sourceTextStyle = ['api'].includes(source) ? 'uppercase' : sourceTextStyle;
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ColumnContainer, {
      key: taskId,
      onClick: () => history.push({
        pathname: `/queues/tasks/${taskId}/audit`,
        state: {
          isAudits: true
        }
      }),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 269
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LineItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 278
      }
    }, taskId), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LineItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 279
      }
    }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LineItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 280
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(AvatarBlock, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 281
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_Avatar__WEBPACK_IMPORTED_MODULE_9__["default"], {
      initials: Object(universal_utils_getInitials__WEBPACK_IMPORTED_MODULE_10__["default"])(completedBy),
      color: Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_20__["colorFromString"])(completedBy),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 282
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 283
      }
    }, completedBy))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LineItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 286
      }
    }, dayjs__WEBPACK_IMPORTED_MODULE_3___default()(completedAt).format('DD-MM-YYYY')), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LineItem, {
      style: {
        textTransform: sourceTextStyle,
        display: 'inline-block',
        justifySelf: 'center',
        width: '100%'
      },
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 287
      }
    }, source), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LineItem, {
      style: {
        display: 'flex',
        justifySelf: 'center',
        color: client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_GRAY
      },
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 297
      }
    }, n_comments > 0 && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, n_comments, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledCommentsIcon, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 307
      }
    }, "comment"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LineItem, {
      style: {
        display: 'flex',
        justifySelf: 'flex-start'
      },
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 311
      }
    }, auditDecisionIcon[correct]));
  });
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListPage__WEBPACK_IMPORTED_MODULE_5__["default"], {
    pageHeader: pageHeader,
    itemList: itemList,
    pageFooter: pageFooter,
    emptyList: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_EmptyPage__WEBPACK_IMPORTED_MODULE_17__["default"], {
      svg: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_EmptyAuditsSVG__WEBPACK_IMPORTED_MODULE_18__["default"], {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 332
        }
      }),
      header: 'No tasks here…',
      subHeader: 'Try using different filters.',
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 331
      }
    }),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 326
    }
  }), menuPortalQueue( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_StandardMenu__WEBPACK_IMPORTED_MODULE_15__["default"], {
    menuProps: menuPropsQueue,
    menuItems: wMenuItems,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 338
    }
  })), menuPortalCb( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_StandardMenu__WEBPACK_IMPORTED_MODULE_15__["default"], {
    menuProps: menuPropsCb,
    menuItems: cbMenuItems,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 339
    }
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (Audits);

/***/ }),

/***/ "./src/universal/modules/outstanding/OutstandingRoot.tsx":
/*!***************************************************************!*\
  !*** ./src/universal/modules/outstanding/OutstandingRoot.tsx ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _components_Outstanding__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/Outstanding */ "./src/universal/modules/outstanding/components/Outstanding.tsx");
/* harmony import */ var client_hooks_useNetworker__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! client/hooks/useNetworker */ "./src/client/hooks/useNetworker.ts");
/* harmony import */ var client_components_LoadingPage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! client/components/LoadingPage */ "./src/client/components/LoadingPage.tsx");
/* harmony import */ var client_hooks_useDocumentTitle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! client/hooks/useDocumentTitle */ "./src/client/hooks/useDocumentTitle.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/modules/outstanding/OutstandingRoot.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}








const OutstandingRoot = props => {
  const {
    user,
    users
  } = props || {};
  const [queues, setQueues] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [offset, setOffset] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(0);
  const [count, setCount] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(0);
  const [loading, setLoading] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const [queueId, setQueueId] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(undefined);
  const [userId, setUserId] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(undefined);
  const networker = Object(client_hooks_useNetworker__WEBPACK_IMPORTED_MODULE_3__["default"])();
  const orgId = user.current_organization_id;
  const PAGE_LIMIT = 50;
  const onNext = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => {
    if (offset < Math.abs(count - PAGE_LIMIT)) {
      setOffset(offset + PAGE_LIMIT);
    }
  }, [count, offset]);
  const onBack = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => {
    if (offset >= PAGE_LIMIT) {
      setOffset(offset - PAGE_LIMIT);
    }
  }, [count, offset]);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    async function fetchQueues() {
      setLoading(true);
      const {
        errors,
        data: queues
      } = await _optionalChain([networker, 'optionalAccess', _ => _.httpHandler, 'call', _2 => _2(`/orgs/${orgId}/queues`, {
        method: 'GET'
      })]);

      if (errors) {
        console.error('Error fetching queues!', JSON.stringify(errors));
      } else {
        if (queues) {
          setCount(queues.length);
          setQueues(queues);
          setLoading(false);
        }
      }
    }

    fetchQueues();
  }, [queueId, userId, offset, user]);
  Object(client_hooks_useDocumentTitle__WEBPACK_IMPORTED_MODULE_5__["default"])('Outstanding Queues | Human Lambdas');
  if (loading) return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(client_components_LoadingPage__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    }
  });
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_Outstanding__WEBPACK_IMPORTED_MODULE_2__["default"], {
    count: count,
    onNext: onNext,
    onBack: onBack,
    limit: PAGE_LIMIT,
    offset: offset,
    queues: queues,
    setQueueId: setQueueId,
    queueId: queueId,
    users: users,
    setUserId: setUserId,
    userId: userId,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    }
  });
};

const mapStateToProps = state => ({
  users: state.users
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_1__["connect"])(mapStateToProps, null)(OutstandingRoot));

/***/ }),

/***/ "./src/universal/modules/outstanding/components/Outstanding.tsx":
/*!**********************************************************************!*\
  !*** ./src/universal/modules/outstanding/components/Outstanding.tsx ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var client_styles_palette__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! client/styles/palette */ "./src/client/styles/palette.ts");
/* harmony import */ var client_components_ListPage_ListPage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! client/components/ListPage/ListPage */ "./src/client/components/ListPage/ListPage.tsx");
/* harmony import */ var client_components_PlainButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! client/components/PlainButton */ "./src/client/components/PlainButton.tsx");
/* harmony import */ var client_components_Icons_ArrowLeftSVG__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! client/components/Icons/ArrowLeftSVG */ "./src/client/components/Icons/ArrowLeftSVG.tsx");
/* harmony import */ var client_components_Icons_ArrowRightSVG__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! client/components/Icons/ArrowRightSVG */ "./src/client/components/Icons/ArrowRightSVG.tsx");
/* harmony import */ var universal_components_Avatar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/components/Avatar */ "./src/universal/components/Avatar.tsx");
/* harmony import */ var universal_utils_getInitials__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! universal/utils/getInitials */ "./src/universal/utils/getInitials.ts");
/* harmony import */ var universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! universal/styles/helpers/textOverflow */ "./src/universal/styles/helpers/textOverflow.ts");
/* harmony import */ var client_hooks_useMenu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! client/hooks/useMenu */ "./src/client/hooks/useMenu.ts");
/* harmony import */ var client_hooks_useCoords__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! client/hooks/useCoords */ "./src/client/hooks/useCoords.ts");
/* harmony import */ var client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! client/components/ListPage/ListTitle */ "./src/client/components/ListPage/ListTitle.tsx");
/* harmony import */ var client_components_StandardMenu__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! client/components/StandardMenu */ "./src/client/components/StandardMenu.tsx");
/* harmony import */ var client_components_Icons_FilterSVG__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! client/components/Icons/FilterSVG */ "./src/client/components/Icons/FilterSVG.tsx");
/* harmony import */ var client_components_EmptyPage__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! client/components/EmptyPage */ "./src/client/components/EmptyPage.tsx");
/* harmony import */ var client_components_Icons_EmptyAuditsSVG__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! client/components/Icons/EmptyAuditsSVG */ "./src/client/components/Icons/EmptyAuditsSVG.tsx");
/* harmony import */ var client_components_IconButtonWrapper__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! client/components/IconButtonWrapper */ "./src/client/components/IconButtonWrapper.tsx");
/* harmony import */ var universal_utils_getColor__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! universal/utils/getColor */ "./src/universal/utils/getColor.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/modules/outstanding/components/Outstanding.tsx";




















const ColumnContainer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16vkno50"
})({
  name: "19b2y6p",
  styles: "line-height:40px;height:40px;display:grid;grid-template-columns:80px 100px 1fr 180px 150px;grid-column-gap:15px;"
});

const Footer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16vkno51"
})({
  name: "y8ru05",
  styles: "height:45px;display:grid;max-width:80%;grid-template-columns:200px 200px;justify-content:space-between;align-items:center;"
});

const Paginator = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16vkno52"
})({
  name: "192qrng",
  styles: "display:flex;align-items:center;justify-content:flex-end;"
});

const Label = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "e16vkno53"
})(_objectSpread({
  marginLeft: 7,
  width: '100%'
}, universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_10__["default"]));

const Spacer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16vkno54"
})({
  name: "jgwfcl",
  styles: "margin-right:7px;display:flex;align-items:center;"
});

const LineItem = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16vkno55"
})(_objectSpread({
  flexDirection: 'row',
  alignItems: 'center',
  cursor: 'pointer !important',
  display: 'block'
}, universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_10__["default"]));

const SmallText = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "e16vkno56"
})({
  textAlign: 'left',
  color: client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_MAIN,
  fontSize: 14,
  userSelect: 'none'
});

const AvatarBlock = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16vkno57"
})({
  name: "70qvj9",
  styles: "display:flex;align-items:center;"
});

const PageCount = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(client_components_PlainButton__WEBPACK_IMPORTED_MODULE_5__["default"], {
  target: "e16vkno58"
})({
  color: client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_MAIN,
  fontSize: 14,
  fontWeight: 400,
  userSelect: 'none',
  backgroundColor: client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].BACKGROUND_HOVER,
  marginLeft: 2,
  marginRight: 2,
  width: 'auto',
  borderRadius: 0,
  height: 25,
  lineHeight: '25px'
});

const PaginateBtn = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(client_components_PlainButton__WEBPACK_IMPORTED_MODULE_5__["default"], {
  target: "e16vkno59"
})(({
  left
}) => {
  return {
    height: 25,
    lineHeight: '25px',
    width: 30,
    padding: 0,
    margin: 0,
    background: client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].BACKGROUND_HOVER,
    borderTopRightRadius: left ? 0 : 4,
    borderBottomRightRadius: left ? 0 : 4,
    borderBottomLeftRadius: left ? 4 : 0,
    borderTopLeftRadius: left ? 4 : 0
  };
});

const StyledEl = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16vkno510"
})(_objectSpread({
  margin: '0 15px',
  padding: '7px 0',
  fontWeight: 500,
  maxWidth: 350
}, universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_10__["default"]));

const HR = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e16vkno511"
})({
  height: 1,
  width: '100%',
  backgroundColor: client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].BORDER_MAIN_GRAY
});

const Outstanding = props => {
  const {
    count,
    onNext,
    onBack,
    limit,
    offset,
    queues,
    setQueueId,
    setUserId,
    queueId,
    userId,
    users
  } = props;
  const history = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["useHistory"])();
  const separator = {
    label: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(HR, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 152
      }
    })
  };
  const wMenuItems = queues.map(w => ({
    label: queueId === w.id ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledEl, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 155
      }
    }, w.name) : w.name,
    onClick: () => setQueueId(prev => prev === w.id ? undefined : w.id)
  }));

  if (queueId) {
    wMenuItems.unshift(separator);
    wMenuItems.unshift({
      label: 'Clear filter',
      onClick: () => setQueueId(undefined)
    });
  }

  const cbMenuItems = users.map(u => ({
    label: userId === u.id ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledEl, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 164
      }
    }, u.name) : u.name,
    onClick: () => setUserId(prev => prev === u.id ? undefined : u.id)
  }));

  if (userId) {
    cbMenuItems.unshift(separator);
    cbMenuItems.unshift({
      label: 'Clear filter',
      onClick: () => setUserId(undefined)
    });
  }

  const {
    menuPortal: menuPortalQueue,
    originRef: originRefQueue,
    menuProps: menuPropsQueue,
    togglePortal: togglePortalQueue
  } = Object(client_hooks_useMenu__WEBPACK_IMPORTED_MODULE_11__["default"])(client_hooks_useCoords__WEBPACK_IMPORTED_MODULE_12__["MenuPosition"].UPPER_RIGHT, {
    isDropdown: true,
    menuContentStyles: {
      width: 350
    }
  });
  const {
    menuPortal: menuPortalCb,
    originRef: originRefCb,
    menuProps: menuPropsCb,
    togglePortal: togglePortalCb
  } = Object(client_hooks_useMenu__WEBPACK_IMPORTED_MODULE_11__["default"])(client_hooks_useCoords__WEBPACK_IMPORTED_MODULE_12__["MenuPosition"].UPPER_RIGHT, {
    isDropdown: true,
    menuContentStyles: {
      width: 350
    }
  });
  const pageHeader = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ColumnContainer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 193
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_13__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 194
    }
  }, "Queue ID"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_13__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 195
    }
  }, "Org ID"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_13__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 196
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Spacer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 198
    }
  }, "Queue Name"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_IconButtonWrapper__WEBPACK_IMPORTED_MODULE_18__["default"], {
    ref: originRefQueue,
    onClick: togglePortalQueue,
    type: "button",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 199
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_FilterSVG__WEBPACK_IMPORTED_MODULE_15__["default"], {
    color: queueId ? client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_MAIN : client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_GRAY,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 200
    }
  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_13__["default"], {
    align: "center",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 204
    }
  }, "Created At"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListTitle__WEBPACK_IMPORTED_MODULE_13__["default"], {
    align: "center",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 205
    }
  }, "Pending Tasks"));
  const pageFooter = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Footer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 210
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(SmallText, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 211
    }
  }, count, " Completed tasks"), count > limit && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Paginator, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 213
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(PaginateBtn, {
    left: true,
    onClick: onBack,
    disabled: offset < limit,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 214
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_ArrowLeftSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 215
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(PageCount, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 217
    }
  }, `${(offset / limit + 1).toFixed()} / ${Math.ceil(count / limit)}`), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(PaginateBtn, {
    onClick: onNext,
    disabled: offset >= Math.abs(count - limit),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 218
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_ArrowRightSVG__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 219
    }
  }))));
  const itemList = queues.map(({
    id,
    created_at,
    org_id,
    n_tasks,
    name
  }) => {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ColumnContainer, {
      key: id,
      onClick: () => history.push(`/queues/${id}`),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 228
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LineItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 234
      }
    }, id), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LineItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 235
      }
    }, org_id), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LineItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 236
      }
    }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LineItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 237
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(AvatarBlock, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 238
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_Avatar__WEBPACK_IMPORTED_MODULE_8__["default"], {
      initials: Object(universal_utils_getInitials__WEBPACK_IMPORTED_MODULE_9__["default"])(name),
      color: Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_19__["colorFromString"])(name),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 239
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 240
      }
    }, created_at))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LineItem, {
      style: {
        display: 'flex',
        justifySelf: 'center',
        color: client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_GRAY
      },
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 243
      }
    }, n_tasks));
  });
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListPage_ListPage__WEBPACK_IMPORTED_MODULE_4__["default"], {
    pageHeader: pageHeader,
    itemList: itemList,
    pageFooter: pageFooter,
    emptyList: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_EmptyPage__WEBPACK_IMPORTED_MODULE_16__["default"], {
      svg: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_EmptyAuditsSVG__WEBPACK_IMPORTED_MODULE_17__["default"], {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 264
        }
      }),
      header: 'No tasks here…',
      subHeader: 'Try using different filters.',
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 263
      }
    }),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 258
    }
  }), menuPortalQueue( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_StandardMenu__WEBPACK_IMPORTED_MODULE_14__["default"], {
    menuProps: menuPropsQueue,
    menuItems: wMenuItems,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 270
    }
  })), menuPortalCb( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_StandardMenu__WEBPACK_IMPORTED_MODULE_14__["default"], {
    menuProps: menuPropsCb,
    menuItems: cbMenuItems,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 271
    }
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (Outstanding);

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY2xpZW50L2NvbXBvbmVudHMvRW1wdHlQYWdlLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY2xpZW50L2NvbXBvbmVudHMvSWNvbkJ1dHRvbldyYXBwZXIudHN4Iiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvY29tcG9uZW50cy9JY29ucy9BcnJvd0xlZnRTVkcudHN4Iiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvY29tcG9uZW50cy9JY29ucy9BcnJvd1JpZ2h0U1ZHLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY2xpZW50L2NvbXBvbmVudHMvSWNvbnMvRW1wdHlBdWRpdHNTVkcudHN4Iiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvY29tcG9uZW50cy9JY29ucy9GaWx0ZXJTVkcudHN4Iiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvY29tcG9uZW50cy9TdGFuZGFyZE1lbnUudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvbW9kdWxlcy9hdWRpdHMvQXVkaXRzUm9vdC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9tb2R1bGVzL2F1ZGl0cy9jb21wb25lbnRzL0F1ZGl0cy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9tb2R1bGVzL291dHN0YW5kaW5nL091dHN0YW5kaW5nUm9vdC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9tb2R1bGVzL291dHN0YW5kaW5nL2NvbXBvbmVudHMvT3V0c3RhbmRpbmcudHN4Il0sIm5hbWVzIjpbIl9qc3hGaWxlTmFtZSIsIldyYXBwZXIiLCJiYWNrZ3JvdW5kQ29sb3IiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsImhlaWdodCIsIndpZHRoIiwiZm9udEZhbWlseSIsIkZPTlRfRkFNSUxZIiwiU0FOU19TRVJJRiIsIlRpdGxlIiwiY29sb3IiLCJQQUxFVFRFIiwiVEVYVF9NQUlOIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwibWFyZ2luIiwiU3ViVGl0bGUiLCJQUklNQVJZX01BSU4iLCJFbXB0eVBhZ2UiLCJzdmciLCJoZWFkZXIiLCJzdWJIZWFkZXIiLCJidXR0b24iLCJSZWFjdCIsImNyZWF0ZUVsZW1lbnQiLCJfX3NlbGYiLCJfX3NvdXJjZSIsImZpbGVOYW1lIiwibGluZU51bWJlciIsIkNvbnRhaW5lciIsIlBsYWluQnV0dG9uIiwiY3Vyc29yIiwiYm9yZGVyUmFkaXVzIiwicGFkZGluZyIsInRyYW5zaXRpb24iLCJCQUNLR1JPVU5EX0hPVkVSIiwiSWNvbkJ1dHRvbiIsImZvcndhcmRSZWYiLCJwcm9wcyIsInJlZiIsIm9uQ2xpY2siLCJ0eXBlIiwiY2hpbGRyZW4iLCJBcnJvd0xlZnRTVkciLCJtZW1vIiwidmlld0JveCIsInhtbG5zIiwiZmlsbCIsImQiLCJBcnJvd1JpZ2h0U1ZHIiwiRW1wdHlBdWRpdHNTVkciLCJCQUNLR1JPVU5EX0dSQVlfTUlEIiwiRmlsdGVyU1ZHIiwiU3RhbmRhcmRNZW51IiwibWVudVByb3BzIiwibWVudUl0ZW1zIiwiTWVudSIsImFyaWFMYWJlbCIsIm1hcCIsImxhYmVsIiwiaWR4IiwiTWVudUl0ZW0iLCJrZXkiLCJBdWRpdHNSb290IiwidXNlciIsInVzZXJzIiwiYXVkaXRGaWx0ZXJzIiwic2V0VXNlcklkIiwic2V0UXVldWVJZCIsImF1ZGl0cyIsInNldEF1ZGl0cyIsInVzZVN0YXRlIiwicXVldWVzIiwic2V0UXVldWVzIiwib2Zmc2V0Iiwic2V0T2Zmc2V0IiwibG9hZGluZyIsInNldExvYWRpbmciLCJxdWV1ZV9pZCIsInF1ZXVlSWQiLCJ3b3JrZXJfaWQiLCJ1c2VySWQiLCJuZXR3b3JrZXIiLCJ1c2VOZXR3b3JrZXIiLCJvcmdJZCIsImN1cnJlbnRfb3JnYW5pemF0aW9uX2lkIiwidGFza3MiLCJjb3VudCIsIlBBR0VfTElNSVQiLCJvbk5leHQiLCJ1c2VDYWxsYmFjayIsIk1hdGgiLCJhYnMiLCJvbkJhY2siLCJ1c2VFZmZlY3QiLCJmZXRjaEF1ZGl0cyIsInBheWxvYWQiLCJtZXRob2QiLCJwYXJhbXMiLCJsaW1pdCIsImRhdGEiLCJodHRwSGFuZGxlciIsInRhc2tfc3RhdHVzIiwiTG9hZGluZ1BhZ2UiLCJBdWRpdHMiLCJtYXBTdGF0ZVRvUHJvcHMiLCJzdGF0ZSIsImZpbHRlcnMiLCJtYXBEaXNwYXRjaFRvUHJvcHMiLCJkaXNwYXRjaCIsImFyZyIsImZpbHRlckFjdGlvbnMiLCJzZXRBdWRpdHNRdWV1ZSIsInNldEF1ZGl0c1VzZXIiLCJjb25uZWN0IiwiQ29sdW1uQ29udGFpbmVyIiwiRm9vdGVyIiwiUGFnaW5hdG9yIiwiTGFiZWwiLCJtYXJnaW5MZWZ0IiwidGV4dE92ZXJmbG93IiwiU3BhY2VyIiwiTGluZUl0ZW0iLCJTbWFsbFRleHQiLCJ0ZXh0QWxpZ24iLCJ1c2VyU2VsZWN0IiwiQXZhdGFyQmxvY2siLCJQYWdlQ291bnQiLCJtYXJnaW5SaWdodCIsImxpbmVIZWlnaHQiLCJQYWdpbmF0ZUJ0biIsImxlZnQiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyVG9wUmlnaHRSYWRpdXMiLCJib3JkZXJCb3R0b21SaWdodFJhZGl1cyIsImJvcmRlckJvdHRvbUxlZnRSYWRpdXMiLCJib3JkZXJUb3BMZWZ0UmFkaXVzIiwiU3R5bGVkRWwiLCJtYXhXaWR0aCIsIkhSIiwiQk9SREVSX01BSU5fR1JBWSIsIlN0eWxlZENvbW1lbnRzSWNvbiIsIkljb24iLCJURVhUX0dSQVkiLCJoaXN0b3J5IiwidXNlSGlzdG9yeSIsInNlcGFyYXRvciIsIndNZW51SXRlbXMiLCJ3IiwiaWQiLCJuYW1lIiwidW5zaGlmdCIsInVuZGVmaW5lZCIsImNiTWVudUl0ZW1zIiwidSIsIm1lbnVQb3J0YWwiLCJtZW51UG9ydGFsUXVldWUiLCJvcmlnaW5SZWYiLCJvcmlnaW5SZWZRdWV1ZSIsIm1lbnVQcm9wc1F1ZXVlIiwidG9nZ2xlUG9ydGFsIiwidG9nZ2xlUG9ydGFsUXVldWUiLCJ1c2VNZW51IiwiTWVudVBvc2l0aW9uIiwiVVBQRVJfUklHSFQiLCJpc0Ryb3Bkb3duIiwibWVudUNvbnRlbnRTdHlsZXMiLCJtZW51UG9ydGFsQ2IiLCJvcmlnaW5SZWZDYiIsIm1lbnVQcm9wc0NiIiwidG9nZ2xlUG9ydGFsQ2IiLCJwYWdlSGVhZGVyIiwiTGlzdFRpdGxlIiwiRnJhZ21lbnQiLCJJY29uQnV0dG9uV3JhcHBlciIsIkZpbHRlckljb24iLCJhbGlnbiIsInBhZ2VGb290ZXIiLCJkaXNhYmxlZCIsIkFycm93TGVmdEljb24iLCJ0b0ZpeGVkIiwiY2VpbCIsIkFycm93UmlnaHRJY29uIiwiYXVkaXREZWNpc2lvbkljb24iLCJudWxsIiwiZmFsc2UiLCJBdWRpdERlY2lzaW9uSWNvbiIsIlNUQVRVU19QQUxFVFRFIiwiSU5fUFJPR1JFU1MiLCJ0cnVlIiwiQ09NUExFVEVEIiwiaXRlbUxpc3QiLCJ0YXNrSWQiLCJjb21wbGV0ZWRfYnkiLCJjb21wbGV0ZWRCeSIsImNvbXBsZXRlZF9hdCIsImNvbXBsZXRlZEF0IiwiY29ycmVjdCIsInF1ZXVlIiwic291cmNlIiwibl9jb21tZW50cyIsInNvdXJjZVRleHRTdHlsZSIsImluY2x1ZGVzIiwicHVzaCIsInBhdGhuYW1lIiwiaXNBdWRpdHMiLCJBdmF0YXIiLCJpbml0aWFscyIsImdldEluaXRpYWxzIiwiY29sb3JGcm9tU3RyaW5nIiwiZGF5anMiLCJmb3JtYXQiLCJzdHlsZSIsInRleHRUcmFuc2Zvcm0iLCJqdXN0aWZ5U2VsZiIsIkxpc3RQYWdlIiwiZW1wdHlMaXN0IiwiRW1wdHlBdWRpdHNJY29uIiwiX29wdGlvbmFsQ2hhaW4iLCJvcHMiLCJsYXN0QWNjZXNzTEhTIiwidmFsdWUiLCJpIiwibGVuZ3RoIiwib3AiLCJmbiIsImFyZ3MiLCJjYWxsIiwiT3V0c3RhbmRpbmdSb290Iiwic2V0Q291bnQiLCJmZXRjaFF1ZXVlcyIsImVycm9ycyIsIl8iLCJfMiIsImNvbnNvbGUiLCJlcnJvciIsIkpTT04iLCJzdHJpbmdpZnkiLCJ1c2VEb2N1bWVudFRpdGxlIiwiT3V0c3RhbmRpbmciLCJwcmV2IiwiY3JlYXRlZF9hdCIsIm9yZ19pZCIsIm5fdGFza3MiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsTUFBTUEsWUFBWSxHQUFHLHVFQUFyQjtBQUE2RjtBQUU3RjtBQUNBOztBQVNBLE1BQU1DLE9BQU8sR0FBRztBQUFBO0FBQUEsR0FBVztBQUN6QkMsaUJBQWUsRUFBRSxNQURRO0FBRXpCQyxTQUFPLEVBQUUsTUFGZ0I7QUFHekJDLGVBQWEsRUFBRSxRQUhVO0FBSXpCQyxZQUFVLEVBQUUsUUFKYTtBQUt6QkMsZ0JBQWMsRUFBRSxRQUxTO0FBTXpCQyxRQUFNLEVBQUUsTUFOaUI7QUFPekJDLE9BQUssRUFBRSxNQVBrQjtBQVF6QkMsWUFBVSxFQUFFQyw2REFBVyxDQUFDQztBQVJDLENBQVgsQ0FBaEI7O0FBV0EsTUFBTUMsS0FBSyxHQUFHO0FBQUE7QUFBQSxHQUFXO0FBQ3ZCQyxPQUFLLEVBQUVDLHNEQUFPLENBQUNDLFNBRFE7QUFFdkJDLFVBQVEsRUFBRSxFQUZhO0FBR3ZCQyxZQUFVLEVBQUUsR0FIVztBQUl2QkMsUUFBTSxFQUFFO0FBSmUsQ0FBWCxDQUFkOztBQU9BLE1BQU1DLFFBQVEsR0FBRztBQUFBO0FBQUEsR0FBVztBQUMxQk4sT0FBSyxFQUFFQyxzREFBTyxDQUFDQyxTQURXO0FBRTFCQyxVQUFRLEVBQUUsRUFGZ0I7QUFHMUJDLFlBQVUsRUFBRSxHQUhjO0FBSTFCQyxRQUFNLEVBQUUsWUFKa0I7QUFLMUIsZUFBYTtBQUNYTCxTQUFLLEVBQUVDLHNEQUFPLENBQUNNO0FBREo7QUFMYSxDQUFYLENBQWpCOztBQVVBLE1BQU1DLFNBQVMsR0FBRyxDQUFDO0FBQUNDLEtBQUQ7QUFBTUMsUUFBTjtBQUFjQyxXQUFkO0FBQXlCQztBQUF6QixDQUFELEtBQXNDO0FBQ3RELHNCQUNFQyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMUIsT0FBcEIsRUFBNkI7QUFBQzJCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUE3QixFQUNJVCxHQURKLGVBRUlJLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JmLEtBQXBCLEVBQTJCO0FBQUNnQixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBM0IsRUFBK0ZSLE1BQS9GLENBRkosZUFHSUcsNENBQUssQ0FBQ0MsYUFBTixDQUFvQlIsUUFBcEIsRUFBOEI7QUFBQ1MsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTlCLEVBQWtHUCxTQUFsRyxDQUhKLEVBSUlDLE1BSkosQ0FERjtBQVFELENBVEQ7O0FBV2VKLHdFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuREEsTUFBTXJCLFlBQVksR0FBRywrRUFBckIsQyxDQUFxRzs7QUFDckc7QUFFQTtBQUNBOztBQVFBLE1BQU1nQyxTQUFTLEdBQUcsa0ZBQU9DLDhEQUFQO0FBQUE7QUFBQSxHQUFvQjtBQUNwQ0MsUUFBTSxFQUFFLFNBRDRCO0FBRXBDaEMsaUJBQWUsRUFBRSxTQUZtQjtBQUdwQ0MsU0FBTyxFQUFFLE1BSDJCO0FBSXBDRSxZQUFVLEVBQUUsUUFKd0I7QUFLcENDLGdCQUFjLEVBQUUsUUFMb0I7QUFNcEM2QixjQUFZLEVBQUUsRUFOc0I7QUFPcEMzQixPQUFLLEVBQUUsRUFQNkI7QUFRcENELFFBQU0sRUFBRSxFQVI0QjtBQVNwQzZCLFNBQU8sRUFBRSxDQVQyQjtBQVVwQ2xCLFFBQU0sRUFBRSxDQVY0QjtBQVdwQ21CLFlBQVUsRUFBRSxtQkFYd0I7QUFZcEMsWUFBVTtBQUNSbkMsbUJBQWUsRUFBRVksc0RBQU8sQ0FBQ3dCO0FBRGpCO0FBWjBCLENBQXBCLENBQWxCOztBQWlCQSxNQUFNQyxVQUFVLGdCQUFHQyx3REFBVSxDQUFDLENBQUNDLEtBQUQsRUFBUUMsR0FBUixLQUFnQjtBQUM1QyxRQUFNO0FBQUNDLFdBQUQ7QUFBVUMsUUFBVjtBQUFnQkM7QUFBaEIsTUFBNEJKLEtBQWxDO0FBQ0Esc0JBQ0VmLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JLLFNBQXBCLEVBQStCO0FBQUVVLE9BQUcsRUFBRUEsR0FBUDtBQUFZQyxXQUFPLEVBQUVBLE9BQXJCO0FBQThCQyxRQUFJLEVBQUVBLElBQXBDO0FBQTBDaEIsVUFBTSxFQUFFLFNBQWxEO0FBQXdEQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBbEUsR0FBL0IsRUFDSWMsUUFESixDQURGO0FBS0QsQ0FQNEIsQ0FBN0I7QUFTZU4seUVBQWYsRTs7Ozs7Ozs7Ozs7O0FDdENBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBTXZDLFlBQVksR0FBRyxnRkFBckI7QUFBc0c7QUFDdEc7QUFFQSxNQUFNOEMsWUFBWSxnQkFBR0Msa0RBQUksQ0FBQyxNQUFNO0FBQzlCLHNCQUNFckIsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixLQUFwQixFQUEyQjtBQUN6QnBCLFVBQU0sRUFBRSxJQURpQjtBQUV6QnlDLFdBQU8sRUFBRSxxQkFGZ0I7QUFHekJ4QyxTQUFLLEVBQUUsSUFIa0I7QUFJekJ5QyxTQUFLLEVBQUUsNEJBSmtCO0FBS3pCQyxRQUFJLEVBQUVwQyxzREFBTyxDQUFDQyxTQUxXO0FBS0FhLFVBQU0sRUFBRSxTQUxSO0FBS2NDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUx4QixHQUEzQixlQU9JTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLE1BQXBCLEVBQTRCO0FBQUV3QixLQUFDLEVBQUUsc1BBQUw7QUFBZ1J2QixVQUFNLEVBQUUsU0FBeFI7QUFBOFJDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF4UyxHQUE1QixDQVBKLENBREY7QUFXRCxDQVp3QixDQUF6QjtBQWNlZSwyRUFBZixFOzs7Ozs7Ozs7Ozs7QUNqQkE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUFNOUMsWUFBWSxHQUFHLGlGQUFyQjtBQUF1RztBQUN2RztBQUVBLE1BQU1vRCxhQUFhLGdCQUFHTCxrREFBSSxDQUFDLE1BQU07QUFDL0Isc0JBQ0VyQiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLEtBQXBCLEVBQTJCO0FBQ3pCcEIsVUFBTSxFQUFFLElBRGlCO0FBRXpCeUMsV0FBTyxFQUFFLHFCQUZnQjtBQUd6QnhDLFNBQUssRUFBRSxJQUhrQjtBQUl6QnlDLFNBQUssRUFBRSw0QkFKa0I7QUFLekJDLFFBQUksRUFBRXBDLHNEQUFPLENBQUNDLFNBTFc7QUFLQWEsVUFBTSxFQUFFLFNBTFI7QUFLY0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBTHhCLEdBQTNCLGVBT0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsTUFBcEIsRUFBNEI7QUFBRXdCLEtBQUMsRUFBRSx1UEFBTDtBQUFpUnZCLFVBQU0sRUFBRSxTQUF6UjtBQUErUkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpTLEdBQTVCLENBUEosQ0FERjtBQVdELENBWnlCLENBQTFCO0FBY2VxQiw0RUFBZixFOzs7Ozs7Ozs7Ozs7QUNqQkE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUFNcEQsWUFBWSxHQUFHLGtGQUFyQjtBQUF3RztBQUN4RztBQUVBLE1BQU1xRCxjQUFjLGdCQUFHTixrREFBSSxDQUFDLE1BQU07QUFDaEMsc0JBQ0VyQiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLEtBQXBCLEVBQTJCO0FBQ3pCdUIsUUFBSSxFQUFFcEMsc0RBQU8sQ0FBQ3dDLG1CQURXO0FBRXpCL0MsVUFBTSxFQUFFLEdBRmlCO0FBR3pCQyxTQUFLLEVBQUUsR0FIa0I7QUFJekJ3QyxXQUFPLEVBQUUsV0FKZ0I7QUFLekJDLFNBQUssRUFBRSw0QkFMa0I7QUFLWXJCLFVBQU0sRUFBRSxTQUxwQjtBQUswQkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBTHBDLEdBQTNCLGVBT0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsTUFBcEIsRUFBNEI7QUFBRXdCLEtBQUMsRUFBRSxlQUFMO0FBQXVCRCxRQUFJLEVBQUUsTUFBN0I7QUFBcUN0QixVQUFNLEVBQUUsU0FBN0M7QUFBbURDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUE3RCxHQUE1QixDQVBKLGVBUUlMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsTUFBcEIsRUFBNEI7QUFBRXdCLEtBQUMsRUFBRSxtTkFBTDtBQUFxUHZCLFVBQU0sRUFBRSxTQUE3UDtBQUFtUUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQTdRLEdBQTVCLENBUkosQ0FERjtBQVlELENBYjBCLENBQTNCO0FBZWVzQiw2RUFBZixFOzs7Ozs7Ozs7Ozs7QUNsQkE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUFNckQsWUFBWSxHQUFHLDZFQUFyQjtBQUFtRztBQUNuRztBQU1BLE1BQU11RCxTQUFTLGdCQUFHUixrREFBSSxDQUFFTixLQUFELElBQVc7QUFDaEMsUUFBTTtBQUFDNUI7QUFBRCxNQUFVNEIsS0FBaEI7QUFDQSxzQkFDRWYsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixLQUFwQixFQUEyQjtBQUN6QnBCLFVBQU0sRUFBRSxJQURpQjtBQUV6QnlDLFdBQU8sRUFBRSxxQkFGZ0I7QUFHekJ4QyxTQUFLLEVBQUUsSUFIa0I7QUFJekJ5QyxTQUFLLEVBQUUsNEJBSmtCO0FBS3pCQyxRQUFJLEVBQUVyQyxLQUFLLElBQUlDLHNEQUFPLENBQUNDLFNBTEU7QUFLU2EsVUFBTSxFQUFFLFNBTGpCO0FBS3VCQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFMakMsR0FBM0IsZUFPSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixNQUFwQixFQUE0QjtBQUFFd0IsS0FBQyxFQUFFLDhFQUFMO0FBQXdGdkIsVUFBTSxFQUFFLFNBQWhHO0FBQXNHQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBaEgsR0FBNUIsQ0FQSixDQURGO0FBV0QsQ0FicUIsQ0FBdEI7QUFlZXdCLHdFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEJBLE1BQU12RCxZQUFZLEdBQUcsMEVBQXJCO0FBQWdHO0FBQ2hHO0FBRUE7O0FBT0EsTUFBTXdELFlBQVksR0FBSWYsS0FBRCxJQUFXO0FBQzlCLFFBQU07QUFBQ2dCLGFBQUQ7QUFBWUM7QUFBWixNQUF5QmpCLEtBQS9CO0FBQ0Esc0JBQ0VmLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JnQyw2Q0FBcEI7QUFBNEJDLGFBQVMsRUFBRTtBQUF2QyxLQUFvRUgsU0FBcEU7QUFBK0U3QixVQUFNLEVBQUUsU0FBdkY7QUFBNkZDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF2RyxNQUNJMkIsU0FBUyxDQUFDRyxHQUFWLENBQWMsQ0FBQztBQUFDQyxTQUFEO0FBQVFuQjtBQUFSLEdBQUQsRUFBbUJvQixHQUFuQixrQkFDZHJDLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JxQyxpREFBcEIsRUFBOEI7QUFBRUMsT0FBRyxFQUFFRixHQUFQO0FBQVlELFNBQUssRUFBRUEsS0FBbkI7QUFBMEJuQixXQUFPLEVBQUVBLE9BQW5DO0FBQTRDZixVQUFNLEVBQUUsU0FBcEQ7QUFBMERDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUFwRSxHQUE5QixDQURBLENBREosQ0FERjtBQU9ELENBVEQ7O0FBV2V5QiwyRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JCQSxNQUFNeEQsWUFBWSxHQUFHLCtFQUFyQjtBQUFxRztBQUNyRztBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQVVBLE1BQU1rRSxVQUFVLEdBQUl6QixLQUFELElBQVc7QUFDNUIsUUFBTTtBQUFDMEIsUUFBRDtBQUFPQyxTQUFQO0FBQWNDLGdCQUFkO0FBQTRCQyxhQUE1QjtBQUF1Q0M7QUFBdkMsTUFBcUQ5QixLQUFLLElBQUksRUFBcEU7QUFDQSxRQUFNLENBQUMrQixNQUFELEVBQVNDLFNBQVQsSUFBc0JDLHNEQUFRLENBQUMsRUFBRCxDQUFwQztBQUNBLFFBQU0sQ0FBQ0MsTUFBRCxFQUFTQyxTQUFULElBQXNCRixzREFBUSxDQUFDLEVBQUQsQ0FBcEM7QUFDQSxRQUFNLENBQUNHLE1BQUQsRUFBU0MsU0FBVCxJQUFzQkosc0RBQVEsQ0FBQyxDQUFELENBQXBDO0FBQ0EsUUFBTSxDQUFDSyxPQUFELEVBQVVDLFVBQVYsSUFBd0JOLHNEQUFRLENBQUMsS0FBRCxDQUF0QztBQUNBLFFBQU07QUFBQ08sWUFBUSxFQUFFQyxPQUFYO0FBQW9CQyxhQUFTLEVBQUVDO0FBQS9CLE1BQXlDZixZQUEvQztBQUNBLFFBQU1nQixTQUFTLEdBQUdDLHlFQUFZLEVBQTlCO0FBQ0EsUUFBTUMsS0FBSyxHQUFHcEIsSUFBSSxDQUFDcUIsdUJBQW5CO0FBQ0EsUUFBTTtBQUFDQyxTQUFEO0FBQVFDO0FBQVIsTUFBaUJsQixNQUFNLElBQUksRUFBakM7QUFDQSxRQUFNbUIsVUFBVSxHQUFHLEVBQW5CO0FBRUEsUUFBTUMsTUFBTSxHQUFHQyx5REFBVyxDQUFDLE1BQU07QUFDL0IsUUFBSWhCLE1BQU0sR0FBR2lCLElBQUksQ0FBQ0MsR0FBTCxDQUFTTCxLQUFLLEdBQUdDLFVBQWpCLENBQWIsRUFBMkM7QUFDekNiLGVBQVMsQ0FBQ0QsTUFBTSxHQUFHYyxVQUFWLENBQVQ7QUFDRDtBQUNGLEdBSnlCLEVBSXZCLENBQUNELEtBQUQsRUFBUWIsTUFBUixDQUp1QixDQUExQjtBQU1BLFFBQU1tQixNQUFNLEdBQUdILHlEQUFXLENBQUMsTUFBTTtBQUMvQixRQUFJaEIsTUFBTSxJQUFJYyxVQUFkLEVBQTBCO0FBQ3hCYixlQUFTLENBQUNELE1BQU0sR0FBR2MsVUFBVixDQUFUO0FBQ0Q7QUFDRixHQUp5QixFQUl2QixDQUFDRCxLQUFELEVBQVFiLE1BQVIsQ0FKdUIsQ0FBMUI7QUFNQW9CLHlEQUFTLENBQUMsTUFBTTtBQUNkLG1CQUFlQyxXQUFmLEdBQTZCO0FBQzNCbEIsZ0JBQVUsQ0FBQyxJQUFELENBQVY7QUFDQSxZQUFNbUIsT0FBTyxHQUFHO0FBQ2RDLGNBQU0sRUFBRSxLQURNO0FBRWRDLGNBQU0sa0NBQ0RoQyxZQURDO0FBRUppQyxlQUFLLEVBQUVYLFVBRkg7QUFHSmQ7QUFISTtBQUZRLE9BQWhCO0FBUUEsWUFBTTtBQUFDMEI7QUFBRCxVQUFTLE1BQU1sQixTQUFTLENBQUNtQixXQUFWLENBQXVCLFNBQVFqQixLQUFNLHlCQUFyQyxFQUErRFksT0FBL0QsQ0FBckI7QUFDQSxZQUFNO0FBQUNJLFlBQUksRUFBRTVCO0FBQVAsVUFBaUIsTUFBTVUsU0FBUyxDQUFDbUIsV0FBVixDQUF1QixTQUFRakIsS0FBTSxTQUFyQyxFQUErQztBQUMxRWEsY0FBTSxFQUFFLEtBRGtFO0FBRTFFQyxjQUFNLEVBQUU7QUFDTkkscUJBQVcsRUFBRTtBQURQO0FBRmtFLE9BQS9DLENBQTdCO0FBT0FoQyxlQUFTLENBQUM4QixJQUFELENBQVQ7QUFDQTNCLGVBQVMsQ0FBQ0QsTUFBRCxDQUFUO0FBQ0FLLGdCQUFVLENBQUMsS0FBRCxDQUFWO0FBQ0Q7O0FBRURrQixlQUFXO0FBQ1osR0F6QlEsRUF5Qk4sQ0FBQ2hCLE9BQUQsRUFBVUUsTUFBVixFQUFrQlAsTUFBbEIsRUFBMEJWLElBQTFCLENBekJNLENBQVQ7QUEyQkEsTUFBSVksT0FBSixFQUFhLG9CQUFPckQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQitFLHFFQUFwQixFQUFpQztBQUFDOUUsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQWpDLENBQVA7QUFFYixzQkFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmdGLDBEQUFwQixFQUE0QjtBQUMxQmxCLFNBQUssRUFBRUEsS0FBSyxJQUFJLEVBRFU7QUFFMUJDLFNBQUssRUFBRUEsS0FGbUI7QUFHMUJFLFVBQU0sRUFBRUEsTUFIa0I7QUFJMUJJLFVBQU0sRUFBRUEsTUFKa0I7QUFLMUJNLFNBQUssRUFBRVgsVUFMbUI7QUFNMUJkLFVBQU0sRUFBRUEsTUFOa0I7QUFPMUJGLFVBQU0sRUFBRUEsTUFQa0I7QUFRMUJKLGNBQVUsRUFBRUEsVUFSYztBQVMxQlcsV0FBTyxFQUFFQSxPQVRpQjtBQVUxQmQsU0FBSyxFQUFFQSxLQVZtQjtBQVcxQkUsYUFBUyxFQUFFQSxTQVhlO0FBWTFCYyxVQUFNLEVBQUVBLE1BWmtCO0FBWVZ4RCxVQUFNLEVBQUUsU0FaRTtBQVlJQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFaZCxHQUE1QixDQURGO0FBZ0JELENBckVEOztBQXVFQSxNQUFNNkUsZUFBZSxHQUFJQyxLQUFELEtBQVk7QUFDbEN6QyxPQUFLLEVBQUV5QyxLQUFLLENBQUN6QyxLQURxQjtBQUVsQ0MsY0FBWSxFQUFFd0MsS0FBSyxDQUFDQyxPQUFOLENBQWN6QztBQUZNLENBQVosQ0FBeEI7O0FBS0EsTUFBTTBDLGtCQUFrQixHQUFJQyxRQUFELEtBQWU7QUFDeEN6QyxZQUFVLEVBQUcwQyxHQUFELElBQVNELFFBQVEsQ0FBQ0UseUVBQWEsQ0FBQ0MsY0FBZCxDQUE2QkYsR0FBN0IsQ0FBRCxDQURXO0FBRXhDM0MsV0FBUyxFQUFHMkMsR0FBRCxJQUFTRCxRQUFRLENBQUNFLHlFQUFhLENBQUNFLGFBQWQsQ0FBNEJILEdBQTVCLENBQUQ7QUFGWSxDQUFmLENBQTNCOztBQUtlSSwwSEFBTyxDQUFDVCxlQUFELEVBQWtCRyxrQkFBbEIsQ0FBUCxDQUE2QzdDLFVBQTdDLENBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqR0EsTUFBTWxFLFlBQVksR0FBRyxzRkFBckI7QUFBNEc7QUFDNUc7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBa0JBLE1BQU1zSCxlQUFlLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXhCOztBQVFBLE1BQU1DLE1BQU0sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBZjs7QUFTQSxNQUFNQyxTQUFTLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQWxCOztBQU1BLE1BQU1DLEtBQUssR0FBRztBQUFBO0FBQUE7QUFDWkMsWUFBVSxFQUFFLENBREE7QUFFWmxILE9BQUssRUFBRTtBQUZLLEdBR1RtSCw4RUFIUyxFQUFkOztBQU1BLE1BQU1DLE1BQU0sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBZjs7QUFNQSxNQUFNQyxRQUFRLEdBQUc7QUFBQTtBQUFBO0FBQ2Z6SCxlQUFhLEVBQUUsS0FEQTtBQUVmQyxZQUFVLEVBQUUsUUFGRztBQUdmNkIsUUFBTSxFQUFFLG9CQUhPO0FBSWYvQixTQUFPLEVBQUU7QUFKTSxHQUtad0gsOEVBTFksRUFBakI7O0FBUUEsTUFBTUcsU0FBUyxHQUFHO0FBQUE7QUFBQSxHQUFZO0FBQzVCQyxXQUFTLEVBQUUsTUFEaUI7QUFFNUJsSCxPQUFLLEVBQUVDLDZEQUFPLENBQUNDLFNBRmE7QUFHNUJDLFVBQVEsRUFBRSxFQUhrQjtBQUk1QmdILFlBQVUsRUFBRTtBQUpnQixDQUFaLENBQWxCOztBQU9BLE1BQU1DLFdBQVcsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBcEI7O0FBS0EsTUFBTUMsU0FBUyxHQUFHLGtGQUFPakcscUVBQVA7QUFBQTtBQUFBLEdBQW9CO0FBQ3BDcEIsT0FBSyxFQUFFQyw2REFBTyxDQUFDQyxTQURxQjtBQUVwQ0MsVUFBUSxFQUFFLEVBRjBCO0FBR3BDQyxZQUFVLEVBQUUsR0FId0I7QUFJcEMrRyxZQUFVLEVBQUUsTUFKd0I7QUFLcEM5SCxpQkFBZSxFQUFFWSw2REFBTyxDQUFDd0IsZ0JBTFc7QUFNcENvRixZQUFVLEVBQUUsQ0FOd0I7QUFPcENTLGFBQVcsRUFBRSxDQVB1QjtBQVFwQzNILE9BQUssRUFBRSxNQVI2QjtBQVNwQzJCLGNBQVksRUFBRSxDQVRzQjtBQVVwQzVCLFFBQU0sRUFBRSxFQVY0QjtBQVdwQzZILFlBQVUsRUFBRTtBQVh3QixDQUFwQixDQUFsQjs7QUFjQSxNQUFNQyxXQUFXLEdBQUcsa0ZBQU9wRyxxRUFBUDtBQUFBO0FBQUEsR0FBb0IsQ0FBQztBQUFDcUc7QUFBRCxDQUFELEtBQVk7QUFDbEQsU0FBTztBQUNML0gsVUFBTSxFQUFFLEVBREg7QUFFTDZILGNBQVUsRUFBRSxNQUZQO0FBR0w1SCxTQUFLLEVBQUUsRUFIRjtBQUlMNEIsV0FBTyxFQUFFLENBSko7QUFLTGxCLFVBQU0sRUFBRSxDQUxIO0FBTUxxSCxjQUFVLEVBQUV6SCw2REFBTyxDQUFDd0IsZ0JBTmY7QUFPTGtHLHdCQUFvQixFQUFFRixJQUFJLEdBQUcsQ0FBSCxHQUFPLENBUDVCO0FBUUxHLDJCQUF1QixFQUFFSCxJQUFJLEdBQUcsQ0FBSCxHQUFPLENBUi9CO0FBU0xJLDBCQUFzQixFQUFFSixJQUFJLEdBQUcsQ0FBSCxHQUFPLENBVDlCO0FBVUxLLHVCQUFtQixFQUFFTCxJQUFJLEdBQUcsQ0FBSCxHQUFPO0FBVjNCLEdBQVA7QUFZRCxDQWJtQixDQUFwQjs7QUFlQSxNQUFNTSxRQUFRLEdBQUc7QUFBQTtBQUFBO0FBQ2YxSCxRQUFNLEVBQUUsUUFETztBQUVma0IsU0FBTyxFQUFFLE9BRk07QUFHZm5CLFlBQVUsRUFBRSxHQUhHO0FBSWY0SCxVQUFRLEVBQUU7QUFKSyxHQUtabEIsOEVBTFksRUFBakI7O0FBUUEsTUFBTW1CLEVBQUUsR0FBRztBQUFBO0FBQUEsR0FBVztBQUNwQnZJLFFBQU0sRUFBRSxDQURZO0FBRXBCQyxPQUFLLEVBQUUsTUFGYTtBQUdwQk4saUJBQWUsRUFBRVksNkRBQU8sQ0FBQ2lJO0FBSEwsQ0FBWCxDQUFYOztBQU1BLE1BQU1DLGtCQUFrQixHQUFHLGtGQUFPQyxrRUFBUDtBQUFBO0FBQUEsR0FBYTtBQUN0QzlJLFNBQU8sRUFBRSxPQUQ2QjtBQUV0Q1UsT0FBSyxFQUFFQyw2REFBTyxDQUFDb0ksU0FGdUI7QUFHdENmLGFBQVcsRUFBRSxFQUh5QjtBQUl0Q1QsWUFBVSxFQUFFLENBSjBCO0FBS3RDMUcsVUFBUSxFQUFFO0FBTDRCLENBQWIsQ0FBM0I7O0FBUUEsTUFBTTJGLE1BQU0sR0FBSWxFLEtBQUQsSUFBVztBQUN4QixRQUFNO0FBQ0pnRCxTQURJO0FBRUpDLFNBRkk7QUFHSkUsVUFISTtBQUlKSSxVQUpJO0FBS0pNLFNBTEk7QUFNSnpCLFVBTkk7QUFPSkYsVUFQSTtBQVFKSixjQVJJO0FBU0pELGFBVEk7QUFVSlksV0FWSTtBQVdKRSxVQVhJO0FBWUpoQjtBQVpJLE1BYUYzQixLQWJKO0FBY0EsUUFBTTBHLE9BQU8sR0FBR0MsbUVBQVUsRUFBMUI7QUFFQSxRQUFNQyxTQUFTLEdBQUc7QUFBQ3ZGLFNBQUssZUFBRXBDLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JtSCxFQUFwQixFQUF3QjtBQUFDbEgsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU5QixZQUFYO0FBQXlCK0Isa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUF4QjtBQUFSLEdBQWxCO0FBRUEsUUFBTXVILFVBQVUsR0FBRzNFLE1BQU0sQ0FBQ2QsR0FBUCxDQUFZMEYsQ0FBRCxLQUFRO0FBQ3BDekYsU0FBSyxFQUFFb0IsT0FBTyxLQUFLcUUsQ0FBQyxDQUFDQyxFQUFkLGdCQUFtQjlILDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JpSCxRQUFwQixFQUE4QjtBQUFDaEgsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU5QixZQUFYO0FBQXlCK0Isa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUE5QixFQUFtR3dILENBQUMsQ0FBQ0UsSUFBckcsQ0FBbkIsR0FBZ0lGLENBQUMsQ0FBQ0UsSUFEckc7QUFFcEM5RyxXQUFPLEVBQUUsTUFBTTRCLFVBQVUsQ0FBQ2dGLENBQUMsQ0FBQ0MsRUFBSDtBQUZXLEdBQVIsQ0FBWCxDQUFuQjs7QUFJQSxNQUFJdEUsT0FBSixFQUFhO0FBQ1hvRSxjQUFVLENBQUNJLE9BQVgsQ0FBbUJMLFNBQW5CO0FBQ0FDLGNBQVUsQ0FBQ0ksT0FBWCxDQUFtQjtBQUFDNUYsV0FBSyxFQUFFLGNBQVI7QUFBd0JuQixhQUFPLEVBQUUsTUFBTTRCLFVBQVUsQ0FBQ29GLFNBQUQ7QUFBakQsS0FBbkI7QUFDRDs7QUFFRCxRQUFNQyxXQUFXLEdBQUd4RixLQUFLLENBQUNQLEdBQU4sQ0FBV2dHLENBQUQsS0FBUTtBQUNwQy9GLFNBQUssRUFBRXNCLE1BQU0sS0FBS3lFLENBQUMsQ0FBQ0wsRUFBYixnQkFBa0I5SCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CaUgsUUFBcEIsRUFBOEI7QUFBQ2hILFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBOUIsRUFBbUc4SCxDQUFDLENBQUNKLElBQXJHLENBQWxCLEdBQStISSxDQUFDLENBQUNKLElBRHBHO0FBRXBDOUcsV0FBTyxFQUFFLE1BQU0yQixTQUFTLENBQUN1RixDQUFDLENBQUNMLEVBQUg7QUFGWSxHQUFSLENBQVYsQ0FBcEI7O0FBSUEsTUFBSXBFLE1BQUosRUFBWTtBQUNWd0UsZUFBVyxDQUFDRixPQUFaLENBQW9CTCxTQUFwQjtBQUNBTyxlQUFXLENBQUNGLE9BQVosQ0FBb0I7QUFBQzVGLFdBQUssRUFBRSxjQUFSO0FBQXdCbkIsYUFBTyxFQUFFLE1BQU0yQixTQUFTLENBQUNxRixTQUFEO0FBQWhELEtBQXBCO0FBQ0Q7O0FBRUQsUUFBTTtBQUNKRyxjQUFVLEVBQUVDLGVBRFI7QUFFSkMsYUFBUyxFQUFFQyxjQUZQO0FBR0p4RyxhQUFTLEVBQUV5RyxjQUhQO0FBSUpDLGdCQUFZLEVBQUVDO0FBSlYsTUFLRkMscUVBQU8sQ0FBQ0Msb0VBQVksQ0FBQ0MsV0FBZCxFQUEyQjtBQUNwQ0MsY0FBVSxFQUFFLElBRHdCO0FBRXBDQyxxQkFBaUIsRUFBRTtBQUFDakssV0FBSyxFQUFFO0FBQVI7QUFGaUIsR0FBM0IsQ0FMWDtBQVVBLFFBQU07QUFDSnNKLGNBQVUsRUFBRVksWUFEUjtBQUVKVixhQUFTLEVBQUVXLFdBRlA7QUFHSmxILGFBQVMsRUFBRW1ILFdBSFA7QUFJSlQsZ0JBQVksRUFBRVU7QUFKVixNQUtGUixxRUFBTyxDQUFDQyxvRUFBWSxDQUFDQyxXQUFkLEVBQTJCO0FBQ3BDQyxjQUFVLEVBQUUsSUFEd0I7QUFFcENDLHFCQUFpQixFQUFFO0FBQUNqSyxXQUFLLEVBQUU7QUFBUjtBQUZpQixHQUEzQixDQUxYO0FBVUEsUUFBTXNLLFVBQVUsZ0JBQ2RwSiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMkYsZUFBcEIsRUFBcUM7QUFBQzFGLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFyQyxlQUNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cb0osNkVBQXBCLEVBQStCO0FBQUNuSixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBL0IsRUFBb0csU0FBcEcsQ0FESixlQUVJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cb0osNkVBQXBCLEVBQStCO0FBQUNuSixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBL0IsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQkQsNENBQUssQ0FBQ3NKLFFBQTFCLEVBQW9DLElBQXBDLGVBQ0V0Siw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CaUcsTUFBcEIsRUFBNEI7QUFBQ2hHLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUE1QixFQUFpRyxZQUFqRyxDQURGLGVBRUVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JzSiw0RUFBcEIsRUFBdUM7QUFBRXZJLE9BQUcsRUFBRXVILGNBQVA7QUFBdUJ0SCxXQUFPLEVBQUV5SCxpQkFBaEM7QUFBbUR4SCxRQUFJLEVBQUUsUUFBekQ7QUFBbUVoQixVQUFNLEVBQUUsU0FBM0U7QUFBaUZDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUEzRixHQUF2QyxlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CdUosMEVBQXBCLEVBQWdDO0FBQUVySyxTQUFLLEVBQUVxRSxPQUFPLEdBQUdwRSw2REFBTyxDQUFDQyxTQUFYLEdBQXVCRCw2REFBTyxDQUFDb0ksU0FBL0M7QUFBMER0SCxVQUFNLEVBQUUsU0FBbEU7QUFBd0VDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUFsRixHQUFoQyxDQURGLENBRkYsQ0FERixDQUZKLGVBVUlMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvSiw2RUFBcEIsRUFBK0I7QUFBRUksU0FBSyxFQUFFLE1BQVQ7QUFBaUJ2SixVQUFNLEVBQUUsU0FBekI7QUFBK0JDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QyxHQUEvQixlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CRCw0Q0FBSyxDQUFDc0osUUFBMUIsRUFBb0MsSUFBcEMsZUFDRXRKLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JpRyxNQUFwQixFQUE0QjtBQUFDaEcsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTVCLEVBQWlHLGNBQWpHLENBREYsZUFFRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnNKLDRFQUFwQixFQUF1QztBQUFFdkksT0FBRyxFQUFFaUksV0FBUDtBQUFvQmhJLFdBQU8sRUFBRWtJLGNBQTdCO0FBQTZDakksUUFBSSxFQUFFLFFBQW5EO0FBQTZEaEIsVUFBTSxFQUFFLFNBQXJFO0FBQTJFQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBckYsR0FBdkMsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnVKLDBFQUFwQixFQUFnQztBQUFFckssU0FBSyxFQUFFdUUsTUFBTSxHQUFHdEUsNkRBQU8sQ0FBQ0MsU0FBWCxHQUF1QkQsNkRBQU8sQ0FBQ29JLFNBQTlDO0FBQXlEdEgsVUFBTSxFQUFFLFNBQWpFO0FBQXVFQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBakYsR0FBaEMsQ0FERixDQUZGLENBREYsQ0FWSixlQWtCSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm9KLDZFQUFwQixFQUErQjtBQUFDbkosVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQS9CLEVBQW9HLGNBQXBHLENBbEJKLGVBbUJJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cb0osNkVBQXBCLEVBQStCO0FBQUVJLFNBQUssRUFBRSxRQUFUO0FBQW1CdkosVUFBTSxFQUFFLFNBQTNCO0FBQWlDQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBM0MsR0FBL0IsRUFBc0gsUUFBdEgsQ0FuQkosZUFvQklMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvSiw2RUFBcEIsRUFBK0I7QUFBRUksU0FBSyxFQUFFLFFBQVQ7QUFBbUJ2SixVQUFNLEVBQUUsU0FBM0I7QUFBaUNDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUEzQyxHQUEvQixFQUFzSCxVQUF0SCxDQXBCSixlQXFCSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm9KLDZFQUFwQixFQUErQjtBQUFDbkosVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQS9CLEVBQW9HLE9BQXBHLENBckJKLENBREY7QUEwQkEsUUFBTXFKLFVBQVUsZ0JBQ2QxSiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CNEYsTUFBcEIsRUFBNEI7QUFBQzNGLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUE1QixlQUNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CbUcsU0FBcEIsRUFBK0I7QUFBQ2xHLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEvQixFQUFvRzJELEtBQXBHLEVBQTJHLGtCQUEzRyxDQURKLEVBRUlBLEtBQUssR0FBR1ksS0FBUixpQkFDQTVFLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I2RixTQUFwQixFQUErQjtBQUFDNUYsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQS9CLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IwRyxXQUFwQixFQUFpQztBQUFFQyxRQUFJLEVBQUUsSUFBUjtBQUFjM0YsV0FBTyxFQUFFcUQsTUFBdkI7QUFBK0JxRixZQUFRLEVBQUV4RyxNQUFNLEdBQUd5QixLQUFsRDtBQUF5RDFFLFVBQU0sRUFBRSxTQUFqRTtBQUF1RUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQWpGLEdBQWpDLGVBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IySiw0RUFBcEIsRUFBbUM7QUFBQzFKLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFuQyxDQURGLENBREosZUFJSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnVHLFNBQXBCLEVBQStCO0FBQUN0RyxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBL0IsRUFBcUcsR0FBRSxDQUFDOEMsTUFBTSxHQUFHeUIsS0FBVCxHQUFpQixDQUFsQixFQUFxQmlGLE9BQXJCLEVBQStCLE1BQUt6RixJQUFJLENBQUMwRixJQUFMLENBQVU5RixLQUFLLEdBQUdZLEtBQWxCLENBQXlCLEVBQXBLLENBSkosZUFLSTVFLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IwRyxXQUFwQixFQUFpQztBQUFFMUYsV0FBTyxFQUFFaUQsTUFBWDtBQUFtQnlGLFlBQVEsRUFBRXhHLE1BQU0sSUFBSWlCLElBQUksQ0FBQ0MsR0FBTCxDQUFTTCxLQUFLLEdBQUdZLEtBQWpCLENBQXZDO0FBQWdFMUUsVUFBTSxFQUFFLFNBQXhFO0FBQThFQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBeEYsR0FBakMsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhKLDZFQUFwQixFQUFvQztBQUFDN0osVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQXBDLENBREYsQ0FMSixDQUhKLENBREY7QUFpQkEsUUFBTTJKLGlCQUFpQixHQUFHO0FBQ3hCQyxRQUFJLEVBQUUsSUFEa0I7QUFFeEJDLFNBQUssZUFBRWxLLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JrSyw0RkFBcEIsRUFBdUM7QUFBRWhMLFdBQUssRUFBRWlMLHdFQUFjLENBQUNDLFdBQXhCO0FBQXFDbkssWUFBTSxFQUFFLFNBQTdDO0FBQW1EQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixrQkFBVSxFQUFFO0FBQXJDO0FBQTdELEtBQXZDLEVBQWdKLFFBQWhKLENBRmlCO0FBR3hCaUssUUFBSSxlQUFFdEssNENBQUssQ0FBQ0MsYUFBTixDQUFvQmtLLDRGQUFwQixFQUF1QztBQUFFaEwsV0FBSyxFQUFFaUwsd0VBQWMsQ0FBQ0csU0FBeEI7QUFBbUNySyxZQUFNLEVBQUUsU0FBM0M7QUFBaURDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGtCQUFVLEVBQUU7QUFBckM7QUFBM0QsS0FBdkMsRUFBOEksY0FBOUk7QUFIa0IsR0FBMUI7QUFNQSxRQUFNbUssUUFBUSxHQUFHekcsS0FBSyxDQUFDNUIsR0FBTixDQUNmLENBQUM7QUFDQzJGLE1BQUUsRUFBRTJDLE1BREw7QUFFQ0MsZ0JBQVksRUFBRUMsV0FGZjtBQUdDQyxnQkFBWSxFQUFFQyxXQUhmO0FBSUNDLFdBSkQ7QUFLQ0MsU0FBSyxFQUFFaEQsSUFMUjtBQU1DaUQsVUFORDtBQU9DQztBQVBELEdBQUQsS0FRTTtBQUNKLFFBQUlDLGVBQWUsR0FBRyxNQUF0QjtBQUNBQSxtQkFBZSxHQUFHLENBQUMsUUFBRCxFQUFXLFFBQVgsRUFBcUJDLFFBQXJCLENBQThCSCxNQUE5QixJQUF3QyxZQUF4QyxHQUF1REUsZUFBekU7QUFDQUEsbUJBQWUsR0FBRyxDQUFDLEtBQUQsRUFBUUMsUUFBUixDQUFpQkgsTUFBakIsSUFBMkIsV0FBM0IsR0FBeUNFLGVBQTNEO0FBQ0Esd0JBQ0VsTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMkYsZUFBcEIsRUFBcUM7QUFDbkNyRCxTQUFHLEVBQUVrSSxNQUQ4QjtBQUVuQ3hKLGFBQU8sRUFBRSxNQUNQd0csT0FBTyxDQUFDMkQsSUFBUixDQUFhO0FBQ1hDLGdCQUFRLEVBQUcsaUJBQWdCWixNQUFPLFFBRHZCO0FBRVh0RixhQUFLLEVBQUU7QUFBQ21HLGtCQUFRLEVBQUU7QUFBWDtBQUZJLE9BQWIsQ0FIaUM7QUFPakNwTCxZQUFNLEVBQUUsU0FQeUI7QUFPbkJDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGtCQUFVLEVBQUU7QUFBckM7QUFQUyxLQUFyQyxlQVNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0csUUFBcEIsRUFBOEI7QUFBQ2pHLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBOUIsRUFBbUdvSyxNQUFuRyxDQVRKLGVBVUl6Syw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0csUUFBcEIsRUFBOEI7QUFBQ2pHLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBOUIsRUFBbUcwSCxJQUFuRyxDQVZKLGVBV0kvSCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0csUUFBcEIsRUFBOEI7QUFBQ2pHLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBOUIsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnNHLFdBQXBCLEVBQWlDO0FBQUNyRyxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQWpDLGVBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JzTCxtRUFBcEIsRUFBNEI7QUFBRUMsY0FBUSxFQUFFQyw0RUFBVyxDQUFDZCxXQUFELENBQXZCO0FBQXNDeEwsV0FBSyxFQUFFdU0saUZBQWUsQ0FBQ2YsV0FBRCxDQUE1RDtBQUEyRXpLLFlBQU0sRUFBRSxTQUFuRjtBQUF5RkMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU5QixZQUFYO0FBQXlCK0Isa0JBQVUsRUFBRTtBQUFyQztBQUFuRyxLQUE1QixDQURGLGVBRUVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I4RixLQUFwQixFQUEyQjtBQUFDN0YsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU5QixZQUFYO0FBQXlCK0Isa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUEzQixFQUFnR3NLLFdBQWhHLENBRkYsQ0FERixDQVhKLGVBaUJJM0ssNENBQUssQ0FBQ0MsYUFBTixDQUFvQmtHLFFBQXBCLEVBQThCO0FBQUNqRyxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTlCLEVBQW1Hc0wsNENBQUssQ0FBQ2QsV0FBRCxDQUFMLENBQW1CZSxNQUFuQixDQUEwQixZQUExQixDQUFuRyxDQWpCSixlQWtCSTVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JrRyxRQUFwQixFQUE4QjtBQUM5QjBGLFdBQUssRUFBRTtBQUNMQyxxQkFBYSxFQUFFWixlQURWO0FBRUx6TSxlQUFPLEVBQUUsY0FGSjtBQUdMc04sbUJBQVcsRUFBRSxRQUhSO0FBSUxqTixhQUFLLEVBQUU7QUFKRixPQUR1QjtBQU0zQm9CLFlBQU0sRUFBRSxTQU5tQjtBQU1iQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixrQkFBVSxFQUFFO0FBQXJDO0FBTkcsS0FBOUIsRUFRRTJLLE1BUkYsQ0FsQkosZUE0QkloTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0csUUFBcEIsRUFBOEI7QUFDOUIwRixXQUFLLEVBQUU7QUFDTHBOLGVBQU8sRUFBRSxNQURKO0FBRUxzTixtQkFBVyxFQUFFLFFBRlI7QUFHTDVNLGFBQUssRUFBRUMsNkRBQU8sQ0FBQ29JO0FBSFYsT0FEdUI7QUFLM0J0SCxZQUFNLEVBQUUsU0FMbUI7QUFLYkMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU5QixZQUFYO0FBQXlCK0Isa0JBQVUsRUFBRTtBQUFyQztBQUxHLEtBQTlCLEVBT0U0SyxVQUFVLEdBQUcsQ0FBYixpQkFDQWpMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JELDRDQUFLLENBQUNzSixRQUExQixFQUFvQyxJQUFwQyxFQUNJMkIsVUFESixlQUVJakwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnFILGtCQUFwQixFQUF3QztBQUFDcEgsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU5QixZQUFYO0FBQXlCK0Isa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUF4QyxFQUE2RyxTQUE3RyxDQUZKLENBUkYsQ0E1QkosZUEwQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JrRyxRQUFwQixFQUE4QjtBQUM5QjBGLFdBQUssRUFBRTtBQUNMcE4sZUFBTyxFQUFFLE1BREo7QUFFTHNOLG1CQUFXLEVBQUU7QUFGUixPQUR1QjtBQUkzQjdMLFlBQU0sRUFBRSxTQUptQjtBQUliQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixrQkFBVSxFQUFFO0FBQXJDO0FBSkcsS0FBOUIsRUFNRTJKLGlCQUFpQixDQUFDYyxPQUFELENBTm5CLENBMUNKLENBREY7QUFxREQsR0FsRWMsQ0FBakI7QUFxRUEsc0JBQ0U5Syw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CRCw0Q0FBSyxDQUFDc0osUUFBMUIsRUFBb0MsSUFBcEMsZUFDSXRKLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IrTCwyRUFBcEIsRUFBOEI7QUFDOUI1QyxjQUFVLEVBQUVBLFVBRGtCO0FBRTlCb0IsWUFBUSxFQUFFQSxRQUZvQjtBQUc5QmQsY0FBVSxFQUFFQSxVQUhrQjtBQUk5QnVDLGFBQVMsZUFDUGpNLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JOLG9FQUFwQixFQUErQjtBQUM3QkMsU0FBRyxlQUFFSSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CaU0sK0VBQXBCLEVBQXFDO0FBQUNoTSxjQUFNLEVBQUUsU0FBVDtBQUFlQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUU5QixZQUFYO0FBQXlCK0Isb0JBQVUsRUFBRTtBQUFyQztBQUF6QixPQUFyQyxDQUR3QjtBQUU3QlIsWUFBTSxFQUFFLGdCQUZxQjtBQUc3QkMsZUFBUyxFQUFFLDhCQUhrQjtBQUdjSSxZQUFNLEVBQUUsU0FIdEI7QUFHNEJDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGtCQUFVLEVBQUU7QUFBckM7QUFIdEMsS0FBL0IsQ0FMNEI7QUFVNUJILFVBQU0sRUFBRSxTQVZvQjtBQVVkQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFWSSxHQUE5QixDQURKLEVBYUlnSSxlQUFlLGVBQUNySSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CNkIsdUVBQXBCLEVBQWtDO0FBQUVDLGFBQVMsRUFBRXlHLGNBQWI7QUFBNkJ4RyxhQUFTLEVBQUU0RixVQUF4QztBQUFvRDFILFVBQU0sRUFBRSxTQUE1RDtBQUFrRUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQTVFLEdBQWxDLENBQUQsQ0FibkIsRUFjSTJJLFlBQVksZUFBQ2hKLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I2Qix1RUFBcEIsRUFBa0M7QUFBRUMsYUFBUyxFQUFFbUgsV0FBYjtBQUEwQmxILGFBQVMsRUFBRWtHLFdBQXJDO0FBQWtEaEksVUFBTSxFQUFFLFNBQTFEO0FBQWdFQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBMUUsR0FBbEMsQ0FBRCxDQWRoQixDQURGO0FBa0JELENBak1EOztBQW1NZTRFLHFFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3ZWQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBTTNHLFlBQVksR0FBRyx5RkFBckI7O0FBQWdILFNBQVM2TixjQUFULENBQXdCQyxHQUF4QixFQUE2QjtBQUFFLE1BQUlDLGFBQWEsR0FBR3BFLFNBQXBCO0FBQStCLE1BQUlxRSxLQUFLLEdBQUdGLEdBQUcsQ0FBQyxDQUFELENBQWY7QUFBb0IsTUFBSUcsQ0FBQyxHQUFHLENBQVI7O0FBQVcsU0FBT0EsQ0FBQyxHQUFHSCxHQUFHLENBQUNJLE1BQWYsRUFBdUI7QUFBRSxVQUFNQyxFQUFFLEdBQUdMLEdBQUcsQ0FBQ0csQ0FBRCxDQUFkO0FBQW1CLFVBQU1HLEVBQUUsR0FBR04sR0FBRyxDQUFDRyxDQUFDLEdBQUcsQ0FBTCxDQUFkO0FBQXVCQSxLQUFDLElBQUksQ0FBTDs7QUFBUSxRQUFJLENBQUNFLEVBQUUsS0FBSyxnQkFBUCxJQUEyQkEsRUFBRSxLQUFLLGNBQW5DLEtBQXNESCxLQUFLLElBQUksSUFBbkUsRUFBeUU7QUFBRSxhQUFPckUsU0FBUDtBQUFtQjs7QUFBQyxRQUFJd0UsRUFBRSxLQUFLLFFBQVAsSUFBbUJBLEVBQUUsS0FBSyxnQkFBOUIsRUFBZ0Q7QUFBRUosbUJBQWEsR0FBR0MsS0FBaEI7QUFBdUJBLFdBQUssR0FBR0ksRUFBRSxDQUFDSixLQUFELENBQVY7QUFBb0IsS0FBN0YsTUFBbUcsSUFBSUcsRUFBRSxLQUFLLE1BQVAsSUFBaUJBLEVBQUUsS0FBSyxjQUE1QixFQUE0QztBQUFFSCxXQUFLLEdBQUdJLEVBQUUsQ0FBQyxDQUFDLEdBQUdDLElBQUosS0FBYUwsS0FBSyxDQUFDTSxJQUFOLENBQVdQLGFBQVgsRUFBMEIsR0FBR00sSUFBN0IsQ0FBZCxDQUFWO0FBQTZETixtQkFBYSxHQUFHcEUsU0FBaEI7QUFBNEI7QUFBRTs7QUFBQyxTQUFPcUUsS0FBUDtBQUFlOztBQUFBO0FBQ25uQjtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQU9BLE1BQU1PLGVBQWUsR0FBSTlMLEtBQUQsSUFBVztBQUNqQyxRQUFNO0FBQUMwQixRQUFEO0FBQU9DO0FBQVAsTUFBZ0IzQixLQUFLLElBQUksRUFBL0I7QUFDQSxRQUFNLENBQUNrQyxNQUFELEVBQVNDLFNBQVQsSUFBc0JGLHNEQUFRLENBQUMsRUFBRCxDQUFwQztBQUNBLFFBQU0sQ0FBQ0csTUFBRCxFQUFTQyxTQUFULElBQXNCSixzREFBUSxDQUFDLENBQUQsQ0FBcEM7QUFDQSxRQUFNLENBQUNnQixLQUFELEVBQVE4SSxRQUFSLElBQW9COUosc0RBQVEsQ0FBQyxDQUFELENBQWxDO0FBQ0EsUUFBTSxDQUFDSyxPQUFELEVBQVVDLFVBQVYsSUFBd0JOLHNEQUFRLENBQUMsS0FBRCxDQUF0QztBQUNBLFFBQU0sQ0FBQ1EsT0FBRCxFQUFVWCxVQUFWLElBQXdCRyxzREFBUSxDQUFDaUYsU0FBRCxDQUF0QztBQUNBLFFBQU0sQ0FBQ3ZFLE1BQUQsRUFBU2QsU0FBVCxJQUFzQkksc0RBQVEsQ0FBQ2lGLFNBQUQsQ0FBcEM7QUFDQSxRQUFNdEUsU0FBUyxHQUFHQyx5RUFBWSxFQUE5QjtBQUNBLFFBQU1DLEtBQUssR0FBR3BCLElBQUksQ0FBQ3FCLHVCQUFuQjtBQUNBLFFBQU1HLFVBQVUsR0FBRyxFQUFuQjtBQUVBLFFBQU1DLE1BQU0sR0FBR0MseURBQVcsQ0FBQyxNQUFNO0FBQy9CLFFBQUloQixNQUFNLEdBQUdpQixJQUFJLENBQUNDLEdBQUwsQ0FBU0wsS0FBSyxHQUFHQyxVQUFqQixDQUFiLEVBQTJDO0FBQ3pDYixlQUFTLENBQUNELE1BQU0sR0FBR2MsVUFBVixDQUFUO0FBQ0Q7QUFDRixHQUp5QixFQUl2QixDQUFDRCxLQUFELEVBQVFiLE1BQVIsQ0FKdUIsQ0FBMUI7QUFNQSxRQUFNbUIsTUFBTSxHQUFHSCx5REFBVyxDQUFDLE1BQU07QUFDL0IsUUFBSWhCLE1BQU0sSUFBSWMsVUFBZCxFQUEwQjtBQUN4QmIsZUFBUyxDQUFDRCxNQUFNLEdBQUdjLFVBQVYsQ0FBVDtBQUNEO0FBQ0YsR0FKeUIsRUFJdkIsQ0FBQ0QsS0FBRCxFQUFRYixNQUFSLENBSnVCLENBQTFCO0FBTUFvQix5REFBUyxDQUFDLE1BQU07QUFDZCxtQkFBZXdJLFdBQWYsR0FBNkI7QUFDM0J6SixnQkFBVSxDQUFDLElBQUQsQ0FBVjtBQUVBLFlBQU07QUFBQzBKLGNBQUQ7QUFBU25JLFlBQUksRUFBRTVCO0FBQWYsVUFBeUIsTUFBTWtKLGNBQWMsQ0FBQyxDQUFDeEksU0FBRCxFQUFZLGdCQUFaLEVBQThCc0osQ0FBQyxJQUFJQSxDQUFDLENBQUNuSSxXQUFyQyxFQUFrRCxNQUFsRCxFQUEwRG9JLEVBQUUsSUFBSUEsRUFBRSxDQUFFLFNBQVFySixLQUFNLFNBQWhCLEVBQTBCO0FBQzlJYSxjQUFNLEVBQUU7QUFEc0ksT0FBMUIsQ0FBbEUsQ0FBRCxDQUFuRDs7QUFJQSxVQUFJc0ksTUFBSixFQUFZO0FBQ1ZHLGVBQU8sQ0FBQ0MsS0FBUixDQUFjLHdCQUFkLEVBQXdDQyxJQUFJLENBQUNDLFNBQUwsQ0FBZU4sTUFBZixDQUF4QztBQUNELE9BRkQsTUFFTztBQUNMLFlBQUkvSixNQUFKLEVBQVk7QUFDVjZKLGtCQUFRLENBQUM3SixNQUFNLENBQUN1SixNQUFSLENBQVI7QUFDQXRKLG1CQUFTLENBQUNELE1BQUQsQ0FBVDtBQUNBSyxvQkFBVSxDQUFDLEtBQUQsQ0FBVjtBQUNEO0FBQ0Y7QUFDRjs7QUFFRHlKLGVBQVc7QUFDWixHQXBCUSxFQW9CTixDQUFDdkosT0FBRCxFQUFVRSxNQUFWLEVBQWtCUCxNQUFsQixFQUEwQlYsSUFBMUIsQ0FwQk0sQ0FBVDtBQXNCQThLLCtFQUFnQixDQUFDLG9DQUFELENBQWhCO0FBRUEsTUFBSWxLLE9BQUosRUFBYSxvQkFBT3JELDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IrRSxxRUFBcEIsRUFBaUM7QUFBQzlFLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFqQyxDQUFQO0FBRWIsc0JBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1TiwrREFBcEIsRUFBaUM7QUFDL0J4SixTQUFLLEVBQUVBLEtBRHdCO0FBRS9CRSxVQUFNLEVBQUVBLE1BRnVCO0FBRy9CSSxVQUFNLEVBQUVBLE1BSHVCO0FBSS9CTSxTQUFLLEVBQUVYLFVBSndCO0FBSy9CZCxVQUFNLEVBQUVBLE1BTHVCO0FBTS9CRixVQUFNLEVBQUVBLE1BTnVCO0FBTy9CSixjQUFVLEVBQUVBLFVBUG1CO0FBUS9CVyxXQUFPLEVBQUVBLE9BUnNCO0FBUy9CZCxTQUFLLEVBQUVBLEtBVHdCO0FBVS9CRSxhQUFTLEVBQUVBLFNBVm9CO0FBVy9CYyxVQUFNLEVBQUVBLE1BWHVCO0FBV2Z4RCxVQUFNLEVBQUUsU0FYTztBQVdEQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFYVCxHQUFqQyxDQURGO0FBZUQsQ0FqRUQ7O0FBbUVBLE1BQU02RSxlQUFlLEdBQUlDLEtBQUQsS0FBWTtBQUNsQ3pDLE9BQUssRUFBRXlDLEtBQUssQ0FBQ3pDO0FBRHFCLENBQVosQ0FBeEI7O0FBSWVpRCwwSEFBTyxDQUFDVCxlQUFELEVBQWtCLElBQWxCLENBQVAsQ0FBK0IySCxlQUEvQixDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BGQSxNQUFNdk8sWUFBWSxHQUFHLGdHQUFyQjtBQUFzSDtBQUN0SDtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7O0FBaUJBLE1BQU1zSCxlQUFlLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXhCOztBQVFBLE1BQU1DLE1BQU0sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBZjs7QUFTQSxNQUFNQyxTQUFTLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQWxCOztBQU1BLE1BQU1DLEtBQUssR0FBRztBQUFBO0FBQUE7QUFDWkMsWUFBVSxFQUFFLENBREE7QUFFWmxILE9BQUssRUFBRTtBQUZLLEdBR1RtSCw4RUFIUyxFQUFkOztBQU1BLE1BQU1DLE1BQU0sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBZjs7QUFNQSxNQUFNQyxRQUFRLEdBQUc7QUFBQTtBQUFBO0FBQ2Z6SCxlQUFhLEVBQUUsS0FEQTtBQUVmQyxZQUFVLEVBQUUsUUFGRztBQUdmNkIsUUFBTSxFQUFFLG9CQUhPO0FBSWYvQixTQUFPLEVBQUU7QUFKTSxHQUtad0gsOEVBTFksRUFBakI7O0FBUUEsTUFBTUcsU0FBUyxHQUFHO0FBQUE7QUFBQSxHQUFZO0FBQzVCQyxXQUFTLEVBQUUsTUFEaUI7QUFFNUJsSCxPQUFLLEVBQUVDLDZEQUFPLENBQUNDLFNBRmE7QUFHNUJDLFVBQVEsRUFBRSxFQUhrQjtBQUk1QmdILFlBQVUsRUFBRTtBQUpnQixDQUFaLENBQWxCOztBQU9BLE1BQU1DLFdBQVcsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBcEI7O0FBS0EsTUFBTUMsU0FBUyxHQUFHLGtGQUFPakcscUVBQVA7QUFBQTtBQUFBLEdBQW9CO0FBQ3BDcEIsT0FBSyxFQUFFQyw2REFBTyxDQUFDQyxTQURxQjtBQUVwQ0MsVUFBUSxFQUFFLEVBRjBCO0FBR3BDQyxZQUFVLEVBQUUsR0FId0I7QUFJcEMrRyxZQUFVLEVBQUUsTUFKd0I7QUFLcEM5SCxpQkFBZSxFQUFFWSw2REFBTyxDQUFDd0IsZ0JBTFc7QUFNcENvRixZQUFVLEVBQUUsQ0FOd0I7QUFPcENTLGFBQVcsRUFBRSxDQVB1QjtBQVFwQzNILE9BQUssRUFBRSxNQVI2QjtBQVNwQzJCLGNBQVksRUFBRSxDQVRzQjtBQVVwQzVCLFFBQU0sRUFBRSxFQVY0QjtBQVdwQzZILFlBQVUsRUFBRTtBQVh3QixDQUFwQixDQUFsQjs7QUFjQSxNQUFNQyxXQUFXLEdBQUcsa0ZBQU9wRyxxRUFBUDtBQUFBO0FBQUEsR0FBb0IsQ0FBQztBQUFDcUc7QUFBRCxDQUFELEtBQVk7QUFDbEQsU0FBTztBQUNML0gsVUFBTSxFQUFFLEVBREg7QUFFTDZILGNBQVUsRUFBRSxNQUZQO0FBR0w1SCxTQUFLLEVBQUUsRUFIRjtBQUlMNEIsV0FBTyxFQUFFLENBSko7QUFLTGxCLFVBQU0sRUFBRSxDQUxIO0FBTUxxSCxjQUFVLEVBQUV6SCw2REFBTyxDQUFDd0IsZ0JBTmY7QUFPTGtHLHdCQUFvQixFQUFFRixJQUFJLEdBQUcsQ0FBSCxHQUFPLENBUDVCO0FBUUxHLDJCQUF1QixFQUFFSCxJQUFJLEdBQUcsQ0FBSCxHQUFPLENBUi9CO0FBU0xJLDBCQUFzQixFQUFFSixJQUFJLEdBQUcsQ0FBSCxHQUFPLENBVDlCO0FBVUxLLHVCQUFtQixFQUFFTCxJQUFJLEdBQUcsQ0FBSCxHQUFPO0FBVjNCLEdBQVA7QUFZRCxDQWJtQixDQUFwQjs7QUFlQSxNQUFNTSxRQUFRLEdBQUc7QUFBQTtBQUFBO0FBQ2YxSCxRQUFNLEVBQUUsUUFETztBQUVma0IsU0FBTyxFQUFFLE9BRk07QUFHZm5CLFlBQVUsRUFBRSxHQUhHO0FBSWY0SCxVQUFRLEVBQUU7QUFKSyxHQUtabEIsOEVBTFksRUFBakI7O0FBUUEsTUFBTW1CLEVBQUUsR0FBRztBQUFBO0FBQUEsR0FBVztBQUNwQnZJLFFBQU0sRUFBRSxDQURZO0FBRXBCQyxPQUFLLEVBQUUsTUFGYTtBQUdwQk4saUJBQWUsRUFBRVksNkRBQU8sQ0FBQ2lJO0FBSEwsQ0FBWCxDQUFYOztBQU1BLE1BQU1tRyxXQUFXLEdBQUl6TSxLQUFELElBQVc7QUFDN0IsUUFBTTtBQUNKaUQsU0FESTtBQUVKRSxVQUZJO0FBR0pJLFVBSEk7QUFJSk0sU0FKSTtBQUtKekIsVUFMSTtBQU1KRixVQU5JO0FBT0pKLGNBUEk7QUFRSkQsYUFSSTtBQVNKWSxXQVRJO0FBVUpFLFVBVkk7QUFXSmhCO0FBWEksTUFZRjNCLEtBWko7QUFhQSxRQUFNMEcsT0FBTyxHQUFHQyxtRUFBVSxFQUExQjtBQUVBLFFBQU1DLFNBQVMsR0FBRztBQUFDdkYsU0FBSyxlQUFFcEMsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm1ILEVBQXBCLEVBQXdCO0FBQUNsSCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQXhCO0FBQVIsR0FBbEI7QUFFQSxRQUFNdUgsVUFBVSxHQUFHM0UsTUFBTSxDQUFDZCxHQUFQLENBQVkwRixDQUFELEtBQVE7QUFDcEN6RixTQUFLLEVBQUVvQixPQUFPLEtBQUtxRSxDQUFDLENBQUNDLEVBQWQsZ0JBQW1COUgsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmlILFFBQXBCLEVBQThCO0FBQUNoSCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTlCLEVBQW1Hd0gsQ0FBQyxDQUFDRSxJQUFyRyxDQUFuQixHQUFnSUYsQ0FBQyxDQUFDRSxJQURyRztBQUVwQzlHLFdBQU8sRUFBRSxNQUFNNEIsVUFBVSxDQUFFNEssSUFBRCxJQUFXQSxJQUFJLEtBQUs1RixDQUFDLENBQUNDLEVBQVgsR0FBZ0JHLFNBQWhCLEdBQTRCSixDQUFDLENBQUNDLEVBQTFDO0FBRlcsR0FBUixDQUFYLENBQW5COztBQUlBLE1BQUl0RSxPQUFKLEVBQWE7QUFDWG9FLGNBQVUsQ0FBQ0ksT0FBWCxDQUFtQkwsU0FBbkI7QUFDQUMsY0FBVSxDQUFDSSxPQUFYLENBQW1CO0FBQUM1RixXQUFLLEVBQUUsY0FBUjtBQUF3Qm5CLGFBQU8sRUFBRSxNQUFNNEIsVUFBVSxDQUFDb0YsU0FBRDtBQUFqRCxLQUFuQjtBQUNEOztBQUVELFFBQU1DLFdBQVcsR0FBR3hGLEtBQUssQ0FBQ1AsR0FBTixDQUFXZ0csQ0FBRCxLQUFRO0FBQ3BDL0YsU0FBSyxFQUFFc0IsTUFBTSxLQUFLeUUsQ0FBQyxDQUFDTCxFQUFiLGdCQUFrQjlILDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JpSCxRQUFwQixFQUE4QjtBQUFDaEgsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU5QixZQUFYO0FBQXlCK0Isa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUE5QixFQUFtRzhILENBQUMsQ0FBQ0osSUFBckcsQ0FBbEIsR0FBK0hJLENBQUMsQ0FBQ0osSUFEcEc7QUFFcEM5RyxXQUFPLEVBQUUsTUFBTTJCLFNBQVMsQ0FBRTZLLElBQUQsSUFBV0EsSUFBSSxLQUFLdEYsQ0FBQyxDQUFDTCxFQUFYLEdBQWdCRyxTQUFoQixHQUE0QkUsQ0FBQyxDQUFDTCxFQUExQztBQUZZLEdBQVIsQ0FBVixDQUFwQjs7QUFJQSxNQUFJcEUsTUFBSixFQUFZO0FBQ1Z3RSxlQUFXLENBQUNGLE9BQVosQ0FBb0JMLFNBQXBCO0FBQ0FPLGVBQVcsQ0FBQ0YsT0FBWixDQUFvQjtBQUFDNUYsV0FBSyxFQUFFLGNBQVI7QUFBd0JuQixhQUFPLEVBQUUsTUFBTTJCLFNBQVMsQ0FBQ3FGLFNBQUQ7QUFBaEQsS0FBcEI7QUFDRDs7QUFFRCxRQUFNO0FBQ0pHLGNBQVUsRUFBRUMsZUFEUjtBQUVKQyxhQUFTLEVBQUVDLGNBRlA7QUFHSnhHLGFBQVMsRUFBRXlHLGNBSFA7QUFJSkMsZ0JBQVksRUFBRUM7QUFKVixNQUtGQyxxRUFBTyxDQUFDQyxvRUFBWSxDQUFDQyxXQUFkLEVBQTJCO0FBQ3BDQyxjQUFVLEVBQUUsSUFEd0I7QUFFcENDLHFCQUFpQixFQUFFO0FBQUNqSyxXQUFLLEVBQUU7QUFBUjtBQUZpQixHQUEzQixDQUxYO0FBVUEsUUFBTTtBQUNKc0osY0FBVSxFQUFFWSxZQURSO0FBRUpWLGFBQVMsRUFBRVcsV0FGUDtBQUdKbEgsYUFBUyxFQUFFbUgsV0FIUDtBQUlKVCxnQkFBWSxFQUFFVTtBQUpWLE1BS0ZSLHFFQUFPLENBQUNDLG9FQUFZLENBQUNDLFdBQWQsRUFBMkI7QUFDcENDLGNBQVUsRUFBRSxJQUR3QjtBQUVwQ0MscUJBQWlCLEVBQUU7QUFBQ2pLLFdBQUssRUFBRTtBQUFSO0FBRmlCLEdBQTNCLENBTFg7QUFVQSxRQUFNc0ssVUFBVSxnQkFDZHBKLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IyRixlQUFwQixFQUFxQztBQUFDMUYsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQXJDLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvSiw2RUFBcEIsRUFBK0I7QUFBQ25KLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEvQixFQUFvRyxVQUFwRyxDQURKLGVBRUlMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvSiw2RUFBcEIsRUFBK0I7QUFBQ25KLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEvQixFQUFvRyxRQUFwRyxDQUZKLGVBR0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvSiw2RUFBcEIsRUFBK0I7QUFBQ25KLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEvQixlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CRCw0Q0FBSyxDQUFDc0osUUFBMUIsRUFBb0MsSUFBcEMsZUFDRXRKLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JpRyxNQUFwQixFQUE0QjtBQUFDaEcsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTVCLEVBQWlHLFlBQWpHLENBREYsZUFFRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnNKLDRFQUFwQixFQUF1QztBQUFFdkksT0FBRyxFQUFFdUgsY0FBUDtBQUF1QnRILFdBQU8sRUFBRXlILGlCQUFoQztBQUFtRHhILFFBQUksRUFBRSxRQUF6RDtBQUFtRWhCLFVBQU0sRUFBRSxTQUEzRTtBQUFpRkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQTNGLEdBQXZDLGVBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1SiwwRUFBcEIsRUFBZ0M7QUFBRXJLLFNBQUssRUFBRXFFLE9BQU8sR0FBR3BFLDZEQUFPLENBQUNDLFNBQVgsR0FBdUJELDZEQUFPLENBQUNvSSxTQUEvQztBQUEwRHRILFVBQU0sRUFBRSxTQUFsRTtBQUF3RUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQWxGLEdBQWhDLENBREYsQ0FGRixDQURGLENBSEosZUFXSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm9KLDZFQUFwQixFQUErQjtBQUFFSSxTQUFLLEVBQUUsUUFBVDtBQUFtQnZKLFVBQU0sRUFBRSxTQUEzQjtBQUFpQ0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQTNDLEdBQS9CLEVBQXNILFlBQXRILENBWEosZUFZSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm9KLDZFQUFwQixFQUErQjtBQUFFSSxTQUFLLEVBQUUsUUFBVDtBQUFtQnZKLFVBQU0sRUFBRSxTQUEzQjtBQUFpQ0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQTNDLEdBQS9CLEVBQXNILGVBQXRILENBWkosQ0FERjtBQWlCQSxRQUFNcUosVUFBVSxnQkFDZDFKLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I0RixNQUFwQixFQUE0QjtBQUFDM0YsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTVCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JtRyxTQUFwQixFQUErQjtBQUFDbEcsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQS9CLEVBQW9HMkQsS0FBcEcsRUFBMkcsa0JBQTNHLENBREosRUFFSUEsS0FBSyxHQUFHWSxLQUFSLGlCQUNBNUUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjZGLFNBQXBCLEVBQStCO0FBQUM1RixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBL0IsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjBHLFdBQXBCLEVBQWlDO0FBQUVDLFFBQUksRUFBRSxJQUFSO0FBQWMzRixXQUFPLEVBQUVxRCxNQUF2QjtBQUErQnFGLFlBQVEsRUFBRXhHLE1BQU0sR0FBR3lCLEtBQWxEO0FBQXlEMUUsVUFBTSxFQUFFLFNBQWpFO0FBQXVFQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBakYsR0FBakMsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjJKLDRFQUFwQixFQUFtQztBQUFDMUosVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQW5DLENBREYsQ0FESixlQUlJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CdUcsU0FBcEIsRUFBK0I7QUFBQ3RHLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEvQixFQUFxRyxHQUFFLENBQUM4QyxNQUFNLEdBQUd5QixLQUFULEdBQWlCLENBQWxCLEVBQXFCaUYsT0FBckIsRUFBK0IsTUFBS3pGLElBQUksQ0FBQzBGLElBQUwsQ0FBVTlGLEtBQUssR0FBR1ksS0FBbEIsQ0FBeUIsRUFBcEssQ0FKSixlQUtJNUUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjBHLFdBQXBCLEVBQWlDO0FBQUUxRixXQUFPLEVBQUVpRCxNQUFYO0FBQW1CeUYsWUFBUSxFQUFFeEcsTUFBTSxJQUFJaUIsSUFBSSxDQUFDQyxHQUFMLENBQVNMLEtBQUssR0FBR1ksS0FBakIsQ0FBdkM7QUFBZ0UxRSxVQUFNLEVBQUUsU0FBeEU7QUFBOEVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF4RixHQUFqQyxlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9COEosNkVBQXBCLEVBQW9DO0FBQUM3SixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBcEMsQ0FERixDQUxKLENBSEosQ0FERjtBQWlCQSxRQUFNbUssUUFBUSxHQUFHdkgsTUFBTSxDQUFDZCxHQUFQLENBQVcsQ0FBQztBQUFDMkYsTUFBRDtBQUFLNEYsY0FBTDtBQUFpQkMsVUFBakI7QUFBeUJDLFdBQXpCO0FBQWtDN0Y7QUFBbEMsR0FBRCxLQUE2QztBQUN2RSx3QkFDRS9ILDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IyRixlQUFwQixFQUFxQztBQUNuQ3JELFNBQUcsRUFBRXVGLEVBRDhCO0FBRW5DN0csYUFBTyxFQUFFLE1BQ1B3RyxPQUFPLENBQUMyRCxJQUFSLENBQWMsV0FBVXRELEVBQUcsRUFBM0IsQ0FIaUM7QUFJakM1SCxZQUFNLEVBQUUsU0FKeUI7QUFJbkJDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGtCQUFVLEVBQUU7QUFBckM7QUFKUyxLQUFyQyxlQU1JTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0csUUFBcEIsRUFBOEI7QUFBQ2pHLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBOUIsRUFBbUd5SCxFQUFuRyxDQU5KLGVBT0k5SCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0csUUFBcEIsRUFBOEI7QUFBQ2pHLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBOUIsRUFBbUdzTixNQUFuRyxDQVBKLGVBUUkzTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0csUUFBcEIsRUFBOEI7QUFBQ2pHLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBOUIsRUFBbUcwSCxJQUFuRyxDQVJKLGVBU0kvSCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0csUUFBcEIsRUFBOEI7QUFBQ2pHLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBOUIsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnNHLFdBQXBCLEVBQWlDO0FBQUNyRyxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQWpDLGVBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JzTCxtRUFBcEIsRUFBNEI7QUFBRUMsY0FBUSxFQUFFQywyRUFBVyxDQUFDMUQsSUFBRCxDQUF2QjtBQUErQjVJLFdBQUssRUFBRXVNLGlGQUFlLENBQUMzRCxJQUFELENBQXJEO0FBQTZEN0gsWUFBTSxFQUFFLFNBQXJFO0FBQTJFQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixrQkFBVSxFQUFFO0FBQXJDO0FBQXJGLEtBQTVCLENBREYsZUFFRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhGLEtBQXBCLEVBQTJCO0FBQUM3RixZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTNCLEVBQWdHcU4sVUFBaEcsQ0FGRixDQURGLENBVEosZUFlSTFOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JrRyxRQUFwQixFQUE4QjtBQUM5QjBGLFdBQUssRUFBRTtBQUNMcE4sZUFBTyxFQUFFLE1BREo7QUFFTHNOLG1CQUFXLEVBQUUsUUFGUjtBQUdMNU0sYUFBSyxFQUFFQyw2REFBTyxDQUFDb0k7QUFIVixPQUR1QjtBQUszQnRILFlBQU0sRUFBRSxTQUxtQjtBQUtiQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixrQkFBVSxFQUFFO0FBQXJDO0FBTEcsS0FBOUIsRUFPRXVOLE9BUEYsQ0FmSixDQURGO0FBMkJELEdBNUJnQixDQUFqQjtBQThCQSxzQkFDRTVOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JELDRDQUFLLENBQUNzSixRQUExQixFQUFvQyxJQUFwQyxlQUNJdEosNENBQUssQ0FBQ0MsYUFBTixDQUFvQitMLDJFQUFwQixFQUE4QjtBQUM5QjVDLGNBQVUsRUFBRUEsVUFEa0I7QUFFOUJvQixZQUFRLEVBQUVBLFFBRm9CO0FBRzlCZCxjQUFVLEVBQUVBLFVBSGtCO0FBSTlCdUMsYUFBUyxlQUNQak0sNENBQUssQ0FBQ0MsYUFBTixDQUFvQk4sb0VBQXBCLEVBQStCO0FBQzdCQyxTQUFHLGVBQUVJLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JpTSwrRUFBcEIsRUFBcUM7QUFBQ2hNLGNBQU0sRUFBRSxTQUFUO0FBQWVDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRTlCLFlBQVg7QUFBeUIrQixvQkFBVSxFQUFFO0FBQXJDO0FBQXpCLE9BQXJDLENBRHdCO0FBRTdCUixZQUFNLEVBQUUsZ0JBRnFCO0FBRzdCQyxlQUFTLEVBQUUsOEJBSGtCO0FBR2NJLFlBQU0sRUFBRSxTQUh0QjtBQUc0QkMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU5QixZQUFYO0FBQXlCK0Isa0JBQVUsRUFBRTtBQUFyQztBQUh0QyxLQUEvQixDQUw0QjtBQVU1QkgsVUFBTSxFQUFFLFNBVm9CO0FBVWRDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQVZJLEdBQTlCLENBREosRUFhSWdJLGVBQWUsZUFBQ3JJLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I2Qix1RUFBcEIsRUFBa0M7QUFBRUMsYUFBUyxFQUFFeUcsY0FBYjtBQUE2QnhHLGFBQVMsRUFBRTRGLFVBQXhDO0FBQW9EMUgsVUFBTSxFQUFFLFNBQTVEO0FBQWtFQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFOUIsWUFBWDtBQUF5QitCLGdCQUFVLEVBQUU7QUFBckM7QUFBNUUsR0FBbEMsQ0FBRCxDQWJuQixFQWNJMkksWUFBWSxlQUFDaEosNENBQUssQ0FBQ0MsYUFBTixDQUFvQjZCLHVFQUFwQixFQUFrQztBQUFFQyxhQUFTLEVBQUVtSCxXQUFiO0FBQTBCbEgsYUFBUyxFQUFFa0csV0FBckM7QUFBa0RoSSxVQUFNLEVBQUUsU0FBMUQ7QUFBZ0VDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU5QixZQUFYO0FBQXlCK0IsZ0JBQVUsRUFBRTtBQUFyQztBQUExRSxHQUFsQyxDQUFELENBZGhCLENBREY7QUFrQkQsQ0ExSUQ7O0FBNEllbU4sMEVBQWYsRSIsImZpbGUiOiJBdWRpdHNSb290X2ExYmNhNDhhZmE0YjEzNTNmYmQ4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL2NsaWVudC9jb21wb25lbnRzL0VtcHR5UGFnZS50c3hcIjtpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcbmltcG9ydCB7Rk9OVF9GQU1JTFl9IGZyb20gJ3N0eWxlcy90eXBvZ3JhcGh5J1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICdzdHlsZXMvcGFsZXR0ZSdcblxuXG5cblxuXG5cblxuXG5jb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdih7XG4gIGJhY2tncm91bmRDb2xvcjogJyNmZmYnLFxuICBkaXNwbGF5OiAnZmxleCcsXG4gIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxuICBoZWlnaHQ6ICcxMDAlJyxcbiAgd2lkdGg6ICcxMDAlJyxcbiAgZm9udEZhbWlseTogRk9OVF9GQU1JTFkuU0FOU19TRVJJRlxufSlcblxuY29uc3QgVGl0bGUgPSBzdHlsZWQuZGl2KHtcbiAgY29sb3I6IFBBTEVUVEUuVEVYVF9NQUlOLFxuICBmb250U2l6ZTogMjQsXG4gIGZvbnRXZWlnaHQ6IDUwMCxcbiAgbWFyZ2luOiAnMjBweCAwIDE1cHgnXG59KVxuXG5jb25zdCBTdWJUaXRsZSA9IHN0eWxlZC5kaXYoe1xuICBjb2xvcjogUEFMRVRURS5URVhUX01BSU4sXG4gIGZvbnRTaXplOiAxNixcbiAgZm9udFdlaWdodDogNDAwLFxuICBtYXJnaW46ICcwcHggMCAyMHB4JyxcbiAgJz4gZGl2ID4gYSc6IHtcbiAgICBjb2xvcjogUEFMRVRURS5QUklNQVJZX01BSU5cbiAgfVxufSlcblxuY29uc3QgRW1wdHlQYWdlID0gKHtzdmcsIGhlYWRlciwgc3ViSGVhZGVyLCBidXR0b259KSA9PiB7XG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChXcmFwcGVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQzfX1cbiAgICAgICwgc3ZnXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGl0bGUsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDV9fSwgaGVhZGVyKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFN1YlRpdGxlLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ2fX0sIHN1YkhlYWRlcilcbiAgICAgICwgYnV0dG9uXG4gICAgKVxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEVtcHR5UGFnZVxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL2NsaWVudC9jb21wb25lbnRzL0ljb25CdXR0b25XcmFwcGVyLnRzeFwiOy8vIFRPRE8gcmVwbGFjZSBJY29uQnV0dG9uXG5pbXBvcnQgUmVhY3QsIHtmb3J3YXJkUmVmLH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcbmltcG9ydCB7UEFMRVRURX0gZnJvbSAnc3R5bGVzL3BhbGV0dGUnXG5pbXBvcnQgUGxhaW5CdXR0b24gZnJvbSAnY29tcG9uZW50cy9QbGFpbkJ1dHRvbidcblxuXG5cblxuXG5cblxuY29uc3QgQ29udGFpbmVyID0gc3R5bGVkKFBsYWluQnV0dG9uKSh7XG4gIGN1cnNvcjogJ3BvaW50ZXInLFxuICBiYWNrZ3JvdW5kQ29sb3I6ICdpbmhlcml0JyxcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxuICBib3JkZXJSYWRpdXM6IDUwLFxuICB3aWR0aDogMjUsXG4gIGhlaWdodDogMjUsXG4gIHBhZGRpbmc6IDAsXG4gIG1hcmdpbjogMCxcbiAgdHJhbnNpdGlvbjogJ2FsbCAyMDBtcyBlYXNlLWluJyxcbiAgJzpob3Zlcic6IHtcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IFBBTEVUVEUuQkFDS0dST1VORF9IT1ZFUlxuICB9XG59KVxuXG5jb25zdCBJY29uQnV0dG9uID0gZm9yd2FyZFJlZigocHJvcHMsIHJlZikgPT4ge1xuICBjb25zdCB7b25DbGljaywgdHlwZSwgY2hpbGRyZW59ID0gcHJvcHNcbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KENvbnRhaW5lciwgeyByZWY6IHJlZiwgb25DbGljazogb25DbGljaywgdHlwZTogdHlwZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDMzfX1cbiAgICAgICwgY2hpbGRyZW5cbiAgICApXG4gIClcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IEljb25CdXR0b25cbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy9jbGllbnQvY29tcG9uZW50cy9JY29ucy9BcnJvd0xlZnRTVkcudHN4XCI7aW1wb3J0IFJlYWN0LCB7bWVtb30gZnJvbSAncmVhY3QnXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3N0eWxlcy9wYWxldHRlJ1xuXG5jb25zdCBBcnJvd0xlZnRTVkcgPSBtZW1vKCgpID0+IHtcbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KCdzdmcnLCB7XG4gICAgICBoZWlnaHQ6IFwiMTNcIixcbiAgICAgIHZpZXdCb3g6IFwiMCAwIDUxNS41NTUgNTE1LjU1NVwiICAgLFxuICAgICAgd2lkdGg6IFwiMTNcIixcbiAgICAgIHhtbG5zOiBcImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIsXG4gICAgICBmaWxsOiBQQUxFVFRFLlRFWFRfTUFJTiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDZ9fVxuICAgIFxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdwYXRoJywgeyBkOiBcIk0xNDMuNDkyIDIyMS44NjNMMzM2LjIyNiAyOS4xMjljNi42NjMtNi42NjQgNi42NjMtMTcuNDY4IDAtMjQuMTMyLTYuNjY1LTYuNjYyLTE3LjQ2OC02LjY2Mi0yNC4xMzIgMGwtMjA0LjggMjA0LjhjLTYuNjYyIDYuNjY0LTYuNjYyIDE3LjQ2OCAwIDI0LjEzMmwyMDQuOCAyMDQuOGM2Ljc4IDYuNTQ4IDE3LjU4NCA2LjM2IDI0LjEzMi0uNDIgNi4zODctNi42MTQgNi4zODctMTcuMDk5IDAtMjMuNzEyTDE0My40OTIgMjIxLjg2M3pcIiAgICAgICAgICAgICAgICAgICAsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxM319IClcbiAgICApXG4gIClcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IEFycm93TGVmdFNWR1xuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL2NsaWVudC9jb21wb25lbnRzL0ljb25zL0Fycm93UmlnaHRTVkcudHN4XCI7aW1wb3J0IFJlYWN0LCB7bWVtb30gZnJvbSAncmVhY3QnXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3N0eWxlcy9wYWxldHRlJ1xuXG5jb25zdCBBcnJvd1JpZ2h0U1ZHID0gbWVtbygoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudCgnc3ZnJywge1xuICAgICAgaGVpZ2h0OiBcIjEzXCIsXG4gICAgICB2aWV3Qm94OiBcIjAgMCA1MTUuNTU1IDUxNS41NTVcIiAgICxcbiAgICAgIHdpZHRoOiBcIjEzXCIsXG4gICAgICB4bWxuczogXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiLFxuICAgICAgZmlsbDogUEFMRVRURS5URVhUX01BSU4sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2fX1cbiAgICBcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgncGF0aCcsIHsgZDogXCJNMzM2LjIyNiAyMDkuNTkxbC0yMDQuOC0yMDQuOGMtNi43OC02LjU0OC0xNy41ODQtNi4zNi0yNC4xMzIuNDItNi4zODggNi42MTQtNi4zODggMTcuMDk5IDAgMjMuNzEybDE5Mi43MzQgMTkyLjczNC0xOTIuNzM0IDE5Mi43MzRjLTYuNjYzIDYuNjY0LTYuNjYzIDE3LjQ2OCAwIDI0LjEzMiA2LjY2NSA2LjY2MyAxNy40NjggNi42NjMgMjQuMTMyIDBsMjA0LjgtMjA0LjhjNi42NjMtNi42NjUgNi42NjMtMTcuNDY4IDAtMjQuMTMyelwiICAgICAgICAgICAgICAgICAgICwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEzfX0gKVxuICAgIClcbiAgKVxufSlcblxuZXhwb3J0IGRlZmF1bHQgQXJyb3dSaWdodFNWR1xuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL2NsaWVudC9jb21wb25lbnRzL0ljb25zL0VtcHR5QXVkaXRzU1ZHLnRzeFwiO2ltcG9ydCBSZWFjdCwge21lbW99IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICdzdHlsZXMvcGFsZXR0ZSdcblxuY29uc3QgRW1wdHlBdWRpdHNTVkcgPSBtZW1vKCgpID0+IHtcbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KCdzdmcnLCB7XG4gICAgICBmaWxsOiBQQUxFVFRFLkJBQ0tHUk9VTkRfR1JBWV9NSUQsXG4gICAgICBoZWlnaHQ6IDEwMCxcbiAgICAgIHdpZHRoOiAxMDAsXG4gICAgICB2aWV3Qm94OiBcIjAgMCAyNCAyNFwiICAgLFxuICAgICAgeG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDZ9fVxuICAgIFxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdwYXRoJywgeyBkOiBcIk0wIDBoMjR2MjRIMHpcIiAsIGZpbGw6IFwibm9uZVwiLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTN9fSApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3BhdGgnLCB7IGQ6IFwiTTE5IDNoLTQuMThDMTQuNCAxLjg0IDEzLjMgMSAxMiAxYy0xLjMgMC0yLjQuODQtMi44MiAySDVjLTEuMSAwLTIgLjktMiAydjE0YzAgMS4xLjkgMiAyIDJoMTRjMS4xIDAgMi0uOSAyLTJWNWMwLTEuMS0uOS0yLTItMnptLTYgMTVoLTJ2LTJoMnYyem0wLTRoLTJWOGgydjZ6bS0xLTljLS41NSAwLTEtLjQ1LTEtMXMuNDUtMSAxLTEgMSAuNDUgMSAxLS40NSAxLTEgMXpcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE0fX0gKVxuICAgIClcbiAgKVxufSlcblxuZXhwb3J0IGRlZmF1bHQgRW1wdHlBdWRpdHNTVkdcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy9jbGllbnQvY29tcG9uZW50cy9JY29ucy9GaWx0ZXJTVkcudHN4XCI7aW1wb3J0IFJlYWN0LCB7bWVtb30gZnJvbSAncmVhY3QnXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3N0eWxlcy9wYWxldHRlJ1xuXG5cblxuXG5cbmNvbnN0IEZpbHRlclNWRyA9IG1lbW8oKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtjb2xvcn0gPSBwcm9wc1xuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3N2ZycsIHtcbiAgICAgIGhlaWdodDogXCIxNVwiLFxuICAgICAgdmlld0JveDogXCIwIDAgNTE1LjU1NSA1MTUuNTU1XCIgICAsXG4gICAgICB3aWR0aDogXCIxNVwiLFxuICAgICAgeG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIixcbiAgICAgIGZpbGw6IGNvbG9yIHx8IFBBTEVUVEUuVEVYVF9NQUlOLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTF9fVxuICAgIFxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdwYXRoJywgeyBkOiBcIk0xNzguNSAzODIuNWgxMDJ2LTUxaC0xMDJ2NTF6TTAgNzYuNXY1MWg0NTl2LTUxSDB6TTc2LjUgMjU1aDMwNnYtNTFoLTMwNnY1MXpcIiAgICwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE4fX0gKVxuICAgIClcbiAgKVxufSlcblxuZXhwb3J0IGRlZmF1bHQgRmlsdGVyU1ZHXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvY2xpZW50L2NvbXBvbmVudHMvU3RhbmRhcmRNZW51LnRzeFwiO2ltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBNZW51IGZyb20gJy4vTWVudSdcblxuaW1wb3J0IE1lbnVJdGVtIGZyb20gJy4vTWVudUl0ZW0nXG5cblxuXG5cblxuXG5jb25zdCBTdGFuZGFyZE1lbnUgPSAocHJvcHMpID0+IHtcbiAgY29uc3Qge21lbnVQcm9wcywgbWVudUl0ZW1zfSA9IHByb3BzXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChNZW51LCB7IGFyaWFMYWJlbDogJ1N0YW5kYXJkIGRyb3Bkb3duIG1lbnUnLCAuLi5tZW51UHJvcHMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNH19XG4gICAgICAsIG1lbnVJdGVtcy5tYXAoKHtsYWJlbCwgb25DbGlja30sIGlkeCkgPT4gKFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KE1lbnVJdGVtLCB7IGtleTogaWR4LCBsYWJlbDogbGFiZWwsIG9uQ2xpY2s6IG9uQ2xpY2ssIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNn19IClcbiAgICAgICkpXG4gICAgKVxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFN0YW5kYXJkTWVudVxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9tb2R1bGVzL2F1ZGl0cy9BdWRpdHNSb290LnRzeFwiO2ltcG9ydCBSZWFjdCwge3VzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZUNhbGxiYWNrfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7Y29ubmVjdH0gZnJvbSAncmVhY3QtcmVkdXgnXG5pbXBvcnQgQXVkaXRzIGZyb20gJy4vY29tcG9uZW50cy9BdWRpdHMnXG5pbXBvcnQgdXNlTmV0d29ya2VyIGZyb20gJ2NsaWVudC9ob29rcy91c2VOZXR3b3JrZXInXG5cbmltcG9ydCBMb2FkaW5nUGFnZSBmcm9tICdjbGllbnQvY29tcG9uZW50cy9Mb2FkaW5nUGFnZSdcbmltcG9ydCB7ZmlsdGVyQWN0aW9uc30gZnJvbSAnY2xpZW50L3JlZHV4L2ZpbHRlcnNSZWR1Y2VyJ1xuXG5cblxuXG5cblxuXG5cblxuY29uc3QgQXVkaXRzUm9vdCA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7dXNlciwgdXNlcnMsIGF1ZGl0RmlsdGVycywgc2V0VXNlcklkLCBzZXRRdWV1ZUlkfSA9IHByb3BzIHx8IHt9XG4gIGNvbnN0IFthdWRpdHMsIHNldEF1ZGl0c10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3F1ZXVlcywgc2V0UXVldWVzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbb2Zmc2V0LCBzZXRPZmZzZXRdID0gdXNlU3RhdGUoMClcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IHtxdWV1ZV9pZDogcXVldWVJZCwgd29ya2VyX2lkOiB1c2VySWR9ID0gYXVkaXRGaWx0ZXJzXG4gIGNvbnN0IG5ldHdvcmtlciA9IHVzZU5ldHdvcmtlcigpXG4gIGNvbnN0IG9yZ0lkID0gdXNlci5jdXJyZW50X29yZ2FuaXphdGlvbl9pZFxuICBjb25zdCB7dGFza3MsIGNvdW50fSA9IGF1ZGl0cyB8fCB7fVxuICBjb25zdCBQQUdFX0xJTUlUID0gNTBcblxuICBjb25zdCBvbk5leHQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKG9mZnNldCA8IE1hdGguYWJzKGNvdW50IC0gUEFHRV9MSU1JVCkpIHtcbiAgICAgIHNldE9mZnNldChvZmZzZXQgKyBQQUdFX0xJTUlUKVxuICAgIH1cbiAgfSwgW2NvdW50LCBvZmZzZXRdKVxuXG4gIGNvbnN0IG9uQmFjayA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAob2Zmc2V0ID49IFBBR0VfTElNSVQpIHtcbiAgICAgIHNldE9mZnNldChvZmZzZXQgLSBQQUdFX0xJTUlUKVxuICAgIH1cbiAgfSwgW2NvdW50LCBvZmZzZXRdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYXN5bmMgZnVuY3Rpb24gZmV0Y2hBdWRpdHMoKSB7XG4gICAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xuICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAuLi5hdWRpdEZpbHRlcnMsXG4gICAgICAgICAgbGltaXQ6IFBBR0VfTElNSVQsXG4gICAgICAgICAgb2Zmc2V0XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGNvbnN0IHtkYXRhfSA9IGF3YWl0IG5ldHdvcmtlci5odHRwSGFuZGxlcihgL29yZ3MvJHtvcmdJZH0vcXVldWVzL3Rhc2tzL2NvbXBsZXRlZGAsIHBheWxvYWQpXG4gICAgICBjb25zdCB7ZGF0YTogcXVldWVzfSA9IGF3YWl0IG5ldHdvcmtlci5odHRwSGFuZGxlcihgL29yZ3MvJHtvcmdJZH0vcXVldWVzYCwge1xuICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0YXNrX3N0YXR1czogJ2NvbXBsZXRlZCdcbiAgICAgICAgfVxuICAgICAgfSlcblxuICAgICAgc2V0QXVkaXRzKGRhdGEpXG4gICAgICBzZXRRdWV1ZXMocXVldWVzKVxuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcbiAgICB9XG5cbiAgICBmZXRjaEF1ZGl0cygpXG4gIH0sIFtxdWV1ZUlkLCB1c2VySWQsIG9mZnNldCwgdXNlcl0pXG5cbiAgaWYgKGxvYWRpbmcpIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KExvYWRpbmdQYWdlLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDY4fX0gKVxuXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChBdWRpdHMsIHtcbiAgICAgIHRhc2tzOiB0YXNrcyB8fCBbXSxcbiAgICAgIGNvdW50OiBjb3VudCxcbiAgICAgIG9uTmV4dDogb25OZXh0LFxuICAgICAgb25CYWNrOiBvbkJhY2ssXG4gICAgICBsaW1pdDogUEFHRV9MSU1JVCxcbiAgICAgIG9mZnNldDogb2Zmc2V0LFxuICAgICAgcXVldWVzOiBxdWV1ZXMsXG4gICAgICBzZXRRdWV1ZUlkOiBzZXRRdWV1ZUlkLFxuICAgICAgcXVldWVJZDogcXVldWVJZCxcbiAgICAgIHVzZXJzOiB1c2VycyxcbiAgICAgIHNldFVzZXJJZDogc2V0VXNlcklkLFxuICAgICAgdXNlcklkOiB1c2VySWQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA3MX19XG4gICAgKVxuICApXG59XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IChzdGF0ZSkgPT4gKHtcbiAgdXNlcnM6IHN0YXRlLnVzZXJzLFxuICBhdWRpdEZpbHRlcnM6IHN0YXRlLmZpbHRlcnMuYXVkaXRGaWx0ZXJzXG59KVxuXG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSAoZGlzcGF0Y2gpID0+ICh7XG4gIHNldFF1ZXVlSWQ6IChhcmcpID0+IGRpc3BhdGNoKGZpbHRlckFjdGlvbnMuc2V0QXVkaXRzUXVldWUoYXJnKSksXG4gIHNldFVzZXJJZDogKGFyZykgPT4gZGlzcGF0Y2goZmlsdGVyQWN0aW9ucy5zZXRBdWRpdHNVc2VyKGFyZykpXG59KVxuXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KG1hcFN0YXRlVG9Qcm9wcywgbWFwRGlzcGF0Y2hUb1Byb3BzKShBdWRpdHNSb290KVxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9tb2R1bGVzL2F1ZGl0cy9jb21wb25lbnRzL0F1ZGl0cy50c3hcIjtpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQge3VzZUhpc3Rvcnl9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgZGF5anMgZnJvbSAnZGF5anMnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcbmltcG9ydCB7UEFMRVRURX0gZnJvbSAnY2xpZW50L3N0eWxlcy9wYWxldHRlJ1xuaW1wb3J0IExpc3RQYWdlIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0xpc3RQYWdlL0xpc3RQYWdlJ1xuaW1wb3J0IFBsYWluQnV0dG9uLCB7fSBmcm9tICdjbGllbnQvY29tcG9uZW50cy9QbGFpbkJ1dHRvbidcbmltcG9ydCBBcnJvd0xlZnRJY29uIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0ljb25zL0Fycm93TGVmdFNWRydcbmltcG9ydCBBcnJvd1JpZ2h0SWNvbiBmcm9tICdjbGllbnQvY29tcG9uZW50cy9JY29ucy9BcnJvd1JpZ2h0U1ZHJ1xuaW1wb3J0IEF2YXRhciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9BdmF0YXInXG5pbXBvcnQgZ2V0SW5pdGlhbHMgZnJvbSAndW5pdmVyc2FsL3V0aWxzL2dldEluaXRpYWxzJ1xuaW1wb3J0IHRleHRPdmVyZmxvdyBmcm9tICd1bml2ZXJzYWwvc3R5bGVzL2hlbHBlcnMvdGV4dE92ZXJmbG93J1xuaW1wb3J0IHVzZU1lbnUgZnJvbSAnY2xpZW50L2hvb2tzL3VzZU1lbnUnXG5pbXBvcnQge01lbnVQb3NpdGlvbn0gZnJvbSAnY2xpZW50L2hvb2tzL3VzZUNvb3JkcydcbmltcG9ydCBMaXN0VGl0bGUgZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvTGlzdFBhZ2UvTGlzdFRpdGxlJ1xuaW1wb3J0IFN0YW5kYXJkTWVudSBmcm9tICdjbGllbnQvY29tcG9uZW50cy9TdGFuZGFyZE1lbnUnXG5pbXBvcnQgRmlsdGVySWNvbiBmcm9tICdjbGllbnQvY29tcG9uZW50cy9JY29ucy9GaWx0ZXJTVkcnXG5pbXBvcnQgRW1wdHlQYWdlIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0VtcHR5UGFnZSdcbmltcG9ydCBFbXB0eUF1ZGl0c0ljb24gZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvSWNvbnMvRW1wdHlBdWRpdHNTVkcnXG5pbXBvcnQgSWNvbkJ1dHRvbldyYXBwZXIgZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvSWNvbkJ1dHRvbldyYXBwZXInXG5cbmltcG9ydCB7Y29sb3JGcm9tU3RyaW5nfSBmcm9tICd1bml2ZXJzYWwvdXRpbHMvZ2V0Q29sb3InXG5pbXBvcnQge0F1ZGl0RGVjaXNpb25JY29ufSBmcm9tICd1bml2ZXJzYWwvbW9kdWxlcy90YXNrL2NvbXBvbmVudHMvU2lkZWJhcidcbmltcG9ydCB7U1RBVFVTX1BBTEVUVEV9IGZyb20gJ3VuaXZlcnNhbC9zdHlsZXMvcGFsZXR0ZSdcbmltcG9ydCBJY29uIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0ljb24nXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuY29uc3QgQ29sdW1uQ29udGFpbmVyID0gc3R5bGVkLmRpdih7XG4gIGxpbmVIZWlnaHQ6ICc0MHB4JyxcbiAgaGVpZ2h0OiA0MCxcbiAgZGlzcGxheTogJ2dyaWQnLFxuICBncmlkVGVtcGxhdGVDb2x1bW5zOiAnMTAwcHggMWZyIDE4MHB4IDEwMHB4IDEwMHB4IDgwcHggMTAwcHgnLFxuICBncmlkQ29sdW1uR2FwOiAxNVxufSlcblxuY29uc3QgRm9vdGVyID0gc3R5bGVkLmRpdih7XG4gIGhlaWdodDogNDUsXG4gIGRpc3BsYXk6ICdncmlkJyxcbiAgbWF4V2lkdGg6ICc4MCUnLFxuICBncmlkVGVtcGxhdGVDb2x1bW5zOiAnMjAwcHggMjAwcHgnLFxuICBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJ1xufSlcblxuY29uc3QgUGFnaW5hdG9yID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gIGp1c3RpZnlDb250ZW50OiAnZmxleC1lbmQnXG59KVxuXG5jb25zdCBMYWJlbCA9IHN0eWxlZC5zcGFuKHtcbiAgbWFyZ2luTGVmdDogNyxcbiAgd2lkdGg6ICcxMDAlJyxcbiAgLi4udGV4dE92ZXJmbG93XG59KVxuXG5jb25zdCBTcGFjZXIgPSBzdHlsZWQuZGl2KHtcbiAgbWFyZ2luUmlnaHQ6IDcsXG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgYWxpZ25JdGVtczogJ2NlbnRlcidcbn0pXG5cbmNvbnN0IExpbmVJdGVtID0gc3R5bGVkLmRpdih7XG4gIGZsZXhEaXJlY3Rpb246ICdyb3cnLFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgY3Vyc29yOiAncG9pbnRlciAhaW1wb3J0YW50JyxcbiAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgLi4udGV4dE92ZXJmbG93XG59KVxuXG5jb25zdCBTbWFsbFRleHQgPSBzdHlsZWQuc3Bhbih7XG4gIHRleHRBbGlnbjogJ2xlZnQnLFxuICBjb2xvcjogUEFMRVRURS5URVhUX01BSU4sXG4gIGZvbnRTaXplOiAxNCxcbiAgdXNlclNlbGVjdDogJ25vbmUnXG59KVxuXG5jb25zdCBBdmF0YXJCbG9jayA9IHN0eWxlZC5kaXYoe1xuICBkaXNwbGF5OiAnZmxleCcsXG4gIGFsaWduSXRlbXM6ICdjZW50ZXInXG59KVxuXG5jb25zdCBQYWdlQ291bnQgPSBzdHlsZWQoUGxhaW5CdXR0b24pKHtcbiAgY29sb3I6IFBBTEVUVEUuVEVYVF9NQUlOLFxuICBmb250U2l6ZTogMTQsXG4gIGZvbnRXZWlnaHQ6IDQwMCxcbiAgdXNlclNlbGVjdDogJ25vbmUnLFxuICBiYWNrZ3JvdW5kQ29sb3I6IFBBTEVUVEUuQkFDS0dST1VORF9IT1ZFUixcbiAgbWFyZ2luTGVmdDogMixcbiAgbWFyZ2luUmlnaHQ6IDIsXG4gIHdpZHRoOiAnYXV0bycsXG4gIGJvcmRlclJhZGl1czogMCxcbiAgaGVpZ2h0OiAyNSxcbiAgbGluZUhlaWdodDogJzI1cHgnXG59KVxuXG5jb25zdCBQYWdpbmF0ZUJ0biA9IHN0eWxlZChQbGFpbkJ1dHRvbikoKHtsZWZ0fSkgPT4ge1xuICByZXR1cm4ge1xuICAgIGhlaWdodDogMjUsXG4gICAgbGluZUhlaWdodDogJzI1cHgnLFxuICAgIHdpZHRoOiAzMCxcbiAgICBwYWRkaW5nOiAwLFxuICAgIG1hcmdpbjogMCxcbiAgICBiYWNrZ3JvdW5kOiBQQUxFVFRFLkJBQ0tHUk9VTkRfSE9WRVIsXG4gICAgYm9yZGVyVG9wUmlnaHRSYWRpdXM6IGxlZnQgPyAwIDogNCxcbiAgICBib3JkZXJCb3R0b21SaWdodFJhZGl1czogbGVmdCA/IDAgOiA0LFxuICAgIGJvcmRlckJvdHRvbUxlZnRSYWRpdXM6IGxlZnQgPyA0IDogMCxcbiAgICBib3JkZXJUb3BMZWZ0UmFkaXVzOiBsZWZ0ID8gNCA6IDBcbiAgfVxufSlcblxuY29uc3QgU3R5bGVkRWwgPSBzdHlsZWQuZGl2KHtcbiAgbWFyZ2luOiAnMCAxNXB4JyxcbiAgcGFkZGluZzogJzdweCAwJyxcbiAgZm9udFdlaWdodDogNTAwLFxuICBtYXhXaWR0aDogMzUwLFxuICAuLi50ZXh0T3ZlcmZsb3dcbn0pXG5cbmNvbnN0IEhSID0gc3R5bGVkLmRpdih7XG4gIGhlaWdodDogMSxcbiAgd2lkdGg6ICcxMDAlJyxcbiAgYmFja2dyb3VuZENvbG9yOiBQQUxFVFRFLkJPUkRFUl9NQUlOX0dSQVlcbn0pXG5cbmNvbnN0IFN0eWxlZENvbW1lbnRzSWNvbiA9IHN0eWxlZChJY29uKSh7XG4gIGRpc3BsYXk6ICdibG9jaycsXG4gIGNvbG9yOiBQQUxFVFRFLlRFWFRfR1JBWSxcbiAgbWFyZ2luUmlnaHQ6IDE1LFxuICBtYXJnaW5MZWZ0OiA0LFxuICBmb250U2l6ZTogMTdcbn0pXG5cbmNvbnN0IEF1ZGl0cyA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7XG4gICAgdGFza3MsXG4gICAgY291bnQsXG4gICAgb25OZXh0LFxuICAgIG9uQmFjayxcbiAgICBsaW1pdCxcbiAgICBvZmZzZXQsXG4gICAgcXVldWVzLFxuICAgIHNldFF1ZXVlSWQsXG4gICAgc2V0VXNlcklkLFxuICAgIHF1ZXVlSWQsXG4gICAgdXNlcklkLFxuICAgIHVzZXJzXG4gIH0gPSBwcm9wc1xuICBjb25zdCBoaXN0b3J5ID0gdXNlSGlzdG9yeSgpXG5cbiAgY29uc3Qgc2VwYXJhdG9yID0ge2xhYmVsOiBSZWFjdC5jcmVhdGVFbGVtZW50KEhSLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE2Nn19ICl9XG5cbiAgY29uc3Qgd01lbnVJdGVtcyA9IHF1ZXVlcy5tYXAoKHcpID0+ICh7XG4gICAgbGFiZWw6IHF1ZXVlSWQgPT09IHcuaWQgPyBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZEVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE2OX19LCB3Lm5hbWUpIDogdy5uYW1lLFxuICAgIG9uQ2xpY2s6ICgpID0+IHNldFF1ZXVlSWQody5pZClcbiAgfSkpXG4gIGlmIChxdWV1ZUlkKSB7XG4gICAgd01lbnVJdGVtcy51bnNoaWZ0KHNlcGFyYXRvcilcbiAgICB3TWVudUl0ZW1zLnVuc2hpZnQoe2xhYmVsOiAnQ2xlYXIgZmlsdGVyJywgb25DbGljazogKCkgPT4gc2V0UXVldWVJZCh1bmRlZmluZWQpfSlcbiAgfVxuXG4gIGNvbnN0IGNiTWVudUl0ZW1zID0gdXNlcnMubWFwKCh1KSA9PiAoe1xuICAgIGxhYmVsOiB1c2VySWQgPT09IHUuaWQgPyBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZEVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE3OH19LCB1Lm5hbWUpIDogdS5uYW1lLFxuICAgIG9uQ2xpY2s6ICgpID0+IHNldFVzZXJJZCh1LmlkKVxuICB9KSlcbiAgaWYgKHVzZXJJZCkge1xuICAgIGNiTWVudUl0ZW1zLnVuc2hpZnQoc2VwYXJhdG9yKVxuICAgIGNiTWVudUl0ZW1zLnVuc2hpZnQoe2xhYmVsOiAnQ2xlYXIgZmlsdGVyJywgb25DbGljazogKCkgPT4gc2V0VXNlcklkKHVuZGVmaW5lZCl9KVxuICB9XG5cbiAgY29uc3Qge1xuICAgIG1lbnVQb3J0YWw6IG1lbnVQb3J0YWxRdWV1ZSxcbiAgICBvcmlnaW5SZWY6IG9yaWdpblJlZlF1ZXVlLFxuICAgIG1lbnVQcm9wczogbWVudVByb3BzUXVldWUsXG4gICAgdG9nZ2xlUG9ydGFsOiB0b2dnbGVQb3J0YWxRdWV1ZVxuICB9ID0gdXNlTWVudShNZW51UG9zaXRpb24uVVBQRVJfUklHSFQsIHtcbiAgICBpc0Ryb3Bkb3duOiB0cnVlLFxuICAgIG1lbnVDb250ZW50U3R5bGVzOiB7d2lkdGg6IDM1MH1cbiAgfSlcblxuICBjb25zdCB7XG4gICAgbWVudVBvcnRhbDogbWVudVBvcnRhbENiLFxuICAgIG9yaWdpblJlZjogb3JpZ2luUmVmQ2IsXG4gICAgbWVudVByb3BzOiBtZW51UHJvcHNDYixcbiAgICB0b2dnbGVQb3J0YWw6IHRvZ2dsZVBvcnRhbENiXG4gIH0gPSB1c2VNZW51KE1lbnVQb3NpdGlvbi5VUFBFUl9SSUdIVCwge1xuICAgIGlzRHJvcGRvd246IHRydWUsXG4gICAgbWVudUNvbnRlbnRTdHlsZXM6IHt3aWR0aDogMzUwfVxuICB9KVxuXG4gIGNvbnN0IHBhZ2VIZWFkZXIgPSAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb2x1bW5Db250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjA3fX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMaXN0VGl0bGUsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjA4fX0sIFwiVGFzayBJRFwiIClcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMaXN0VGl0bGUsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjA5fX1cbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFJlYWN0LkZyYWdtZW50LCBudWxsXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFNwYWNlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMTF9fSwgXCJRdWV1ZSBOYW1lXCIgKVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChJY29uQnV0dG9uV3JhcHBlciwgeyByZWY6IG9yaWdpblJlZlF1ZXVlLCBvbkNsaWNrOiB0b2dnbGVQb3J0YWxRdWV1ZSwgdHlwZTogXCJidXR0b25cIiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIxMn19XG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRmlsdGVySWNvbiwgeyBjb2xvcjogcXVldWVJZCA/IFBBTEVUVEUuVEVYVF9NQUlOIDogUEFMRVRURS5URVhUX0dSQVksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMTN9fSApXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGlzdFRpdGxlLCB7IGFsaWduOiBcImxlZnRcIiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIxN319XG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwgbnVsbFxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTcGFjZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjE5fX0sIFwiQ29tcGxldGVkIEJ5XCIgKVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChJY29uQnV0dG9uV3JhcHBlciwgeyByZWY6IG9yaWdpblJlZkNiLCBvbkNsaWNrOiB0b2dnbGVQb3J0YWxDYiwgdHlwZTogXCJidXR0b25cIiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIyMH19XG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRmlsdGVySWNvbiwgeyBjb2xvcjogdXNlcklkID8gUEFMRVRURS5URVhUX01BSU4gOiBQQUxFVFRFLlRFWFRfR1JBWSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIyMX19IClcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgIClcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMaXN0VGl0bGUsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjI1fX0sIFwiQ29tcGxldGVkIEF0XCIgKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExpc3RUaXRsZSwgeyBhbGlnbjogXCJjZW50ZXJcIiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIyNn19LCBcIlNvdXJjZVwiKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExpc3RUaXRsZSwgeyBhbGlnbjogXCJjZW50ZXJcIiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIyN319LCBcIkNvbW1lbnRzXCIpXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGlzdFRpdGxlLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIyOH19LCBcIkF1ZGl0XCIpXG4gICAgKVxuICApXG5cbiAgY29uc3QgcGFnZUZvb3RlciA9IChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEZvb3Rlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzN9fVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFNtYWxsVGV4dCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzR9fSwgY291bnQsIFwiIENvbXBsZXRlZCB0YXNrc1wiICApXG4gICAgICAsIGNvdW50ID4gbGltaXQgJiYgKFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFBhZ2luYXRvciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzZ9fVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChQYWdpbmF0ZUJ0biwgeyBsZWZ0OiB0cnVlLCBvbkNsaWNrOiBvbkJhY2ssIGRpc2FibGVkOiBvZmZzZXQgPCBsaW1pdCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIzN319XG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQXJyb3dMZWZ0SWNvbiwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzh9fSApXG4gICAgICAgICAgKVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChQYWdlQ291bnQsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjQwfX0sIGAkeyhvZmZzZXQgLyBsaW1pdCArIDEpLnRvRml4ZWQoKX0gLyAke01hdGguY2VpbChjb3VudCAvIGxpbWl0KX1gKVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChQYWdpbmF0ZUJ0biwgeyBvbkNsaWNrOiBvbk5leHQsIGRpc2FibGVkOiBvZmZzZXQgPj0gTWF0aC5hYnMoY291bnQgLSBsaW1pdCksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNDF9fVxuICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEFycm93UmlnaHRJY29uLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI0Mn19IClcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgIClcbiAgICApXG4gIClcblxuICBjb25zdCBhdWRpdERlY2lzaW9uSWNvbiA9IHtcbiAgICBudWxsOiBudWxsLFxuICAgIGZhbHNlOiBSZWFjdC5jcmVhdGVFbGVtZW50KEF1ZGl0RGVjaXNpb25JY29uLCB7IGNvbG9yOiBTVEFUVVNfUEFMRVRURS5JTl9QUk9HUkVTUywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI1MX19LCBcImNhbmNlbFwiKSxcbiAgICB0cnVlOiBSZWFjdC5jcmVhdGVFbGVtZW50KEF1ZGl0RGVjaXNpb25JY29uLCB7IGNvbG9yOiBTVEFUVVNfUEFMRVRURS5DT01QTEVURUQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNTJ9fSwgXCJjaGVja19jaXJjbGVcIilcbiAgfVxuXG4gIGNvbnN0IGl0ZW1MaXN0ID0gdGFza3MubWFwKFxuICAgICh7XG4gICAgICBpZDogdGFza0lkLFxuICAgICAgY29tcGxldGVkX2J5OiBjb21wbGV0ZWRCeSxcbiAgICAgIGNvbXBsZXRlZF9hdDogY29tcGxldGVkQXQsXG4gICAgICBjb3JyZWN0LFxuICAgICAgcXVldWU6IG5hbWUsXG4gICAgICBzb3VyY2UsXG4gICAgICBuX2NvbW1lbnRzXG4gICAgfSkgPT4ge1xuICAgICAgbGV0IHNvdXJjZVRleHRTdHlsZSA9ICdub25lJ1xuICAgICAgc291cmNlVGV4dFN0eWxlID0gWydtYW51YWwnLCAnemFwaWVyJ10uaW5jbHVkZXMoc291cmNlKSA/ICdjYXBpdGFsaXplJyA6IHNvdXJjZVRleHRTdHlsZVxuICAgICAgc291cmNlVGV4dFN0eWxlID0gWydhcGknXS5pbmNsdWRlcyhzb3VyY2UpID8gJ3VwcGVyY2FzZScgOiBzb3VyY2VUZXh0U3R5bGVcbiAgICAgIHJldHVybiAoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29sdW1uQ29udGFpbmVyLCB7XG4gICAgICAgICAga2V5OiB0YXNrSWQsXG4gICAgICAgICAgb25DbGljazogKCkgPT5cbiAgICAgICAgICAgIGhpc3RvcnkucHVzaCh7XG4gICAgICAgICAgICAgIHBhdGhuYW1lOiBgL3F1ZXVlcy90YXNrcy8ke3Rhc2tJZH0vYXVkaXRgLFxuICAgICAgICAgICAgICBzdGF0ZToge2lzQXVkaXRzOiB0cnVlfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNjl9fVxuICAgICAgICBcbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGluZUl0ZW0sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjc4fX0sIHRhc2tJZClcbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGluZUl0ZW0sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjc5fX0sIG5hbWUpXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExpbmVJdGVtLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI4MH19XG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQXZhdGFyQmxvY2ssIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjgxfX1cbiAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEF2YXRhciwgeyBpbml0aWFsczogZ2V0SW5pdGlhbHMoY29tcGxldGVkQnkpLCBjb2xvcjogY29sb3JGcm9tU3RyaW5nKGNvbXBsZXRlZEJ5KSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI4Mn19IClcbiAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI4M319LCBjb21wbGV0ZWRCeSlcbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExpbmVJdGVtLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI4Nn19LCBkYXlqcyhjb21wbGV0ZWRBdCkuZm9ybWF0KCdERC1NTS1ZWVlZJykpXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExpbmVJdGVtLCB7XG4gICAgICAgICAgICBzdHlsZToge1xuICAgICAgICAgICAgICB0ZXh0VHJhbnNmb3JtOiBzb3VyY2VUZXh0U3R5bGUsXG4gICAgICAgICAgICAgIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLFxuICAgICAgICAgICAgICBqdXN0aWZ5U2VsZjogJ2NlbnRlcicsXG4gICAgICAgICAgICAgIHdpZHRoOiAnMTAwJSdcbiAgICAgICAgICAgIH0sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyODd9fVxuICAgICAgICAgIFxuICAgICAgICAgICAgLCBzb3VyY2VcbiAgICAgICAgICApXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExpbmVJdGVtLCB7XG4gICAgICAgICAgICBzdHlsZToge1xuICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICAgICAgIGp1c3RpZnlTZWxmOiAnY2VudGVyJyxcbiAgICAgICAgICAgICAgY29sb3I6IFBBTEVUVEUuVEVYVF9HUkFZXG4gICAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjk3fX1cbiAgICAgICAgICBcbiAgICAgICAgICAgICwgbl9jb21tZW50cyA+IDAgJiYgKFxuICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFJlYWN0LkZyYWdtZW50LCBudWxsXG4gICAgICAgICAgICAgICAgLCBuX2NvbW1lbnRzXG4gICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZENvbW1lbnRzSWNvbiwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzMDd9fSwgXCJjb21tZW50XCIpXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExpbmVJdGVtLCB7XG4gICAgICAgICAgICBzdHlsZToge1xuICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICAgICAgIGp1c3RpZnlTZWxmOiAnZmxleC1zdGFydCdcbiAgICAgICAgICAgIH0sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzMTF9fVxuICAgICAgICAgIFxuICAgICAgICAgICAgLCBhdWRpdERlY2lzaW9uSWNvbltjb3JyZWN0XVxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgKVxuICAgIH1cbiAgKVxuXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwgbnVsbFxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExpc3RQYWdlLCB7XG4gICAgICAgIHBhZ2VIZWFkZXI6IHBhZ2VIZWFkZXIsXG4gICAgICAgIGl0ZW1MaXN0OiBpdGVtTGlzdCxcbiAgICAgICAgcGFnZUZvb3RlcjogcGFnZUZvb3RlcixcbiAgICAgICAgZW1wdHlMaXN0OiBcbiAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEVtcHR5UGFnZSwge1xuICAgICAgICAgICAgc3ZnOiBSZWFjdC5jcmVhdGVFbGVtZW50KEVtcHR5QXVkaXRzSWNvbiwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzMzJ9fSApLFxuICAgICAgICAgICAgaGVhZGVyOiAnTm8gdGFza3MgaGVyZeKApicsXG4gICAgICAgICAgICBzdWJIZWFkZXI6ICdUcnkgdXNpbmcgZGlmZmVyZW50IGZpbHRlcnMuJywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDMzMX19XG4gICAgICAgICAgKVxuICAgICAgICAsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzMjZ9fVxuICAgICAgKVxuICAgICAgLCBtZW51UG9ydGFsUXVldWUoUmVhY3QuY3JlYXRlRWxlbWVudChTdGFuZGFyZE1lbnUsIHsgbWVudVByb3BzOiBtZW51UHJvcHNRdWV1ZSwgbWVudUl0ZW1zOiB3TWVudUl0ZW1zLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzM4fX0gKSlcbiAgICAgICwgbWVudVBvcnRhbENiKFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3RhbmRhcmRNZW51LCB7IG1lbnVQcm9wczogbWVudVByb3BzQ2IsIG1lbnVJdGVtczogY2JNZW51SXRlbXMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzMzl9fSApKVxuICAgIClcbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBdWRpdHNcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy91bml2ZXJzYWwvbW9kdWxlcy9vdXRzdGFuZGluZy9PdXRzdGFuZGluZ1Jvb3QudHN4XCI7IGZ1bmN0aW9uIF9vcHRpb25hbENoYWluKG9wcykgeyBsZXQgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgbGV0IHZhbHVlID0gb3BzWzBdOyBsZXQgaSA9IDE7IHdoaWxlIChpIDwgb3BzLmxlbmd0aCkgeyBjb25zdCBvcCA9IG9wc1tpXTsgY29uc3QgZm4gPSBvcHNbaSArIDFdOyBpICs9IDI7IGlmICgob3AgPT09ICdvcHRpb25hbEFjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSAmJiB2YWx1ZSA9PSBudWxsKSB7IHJldHVybiB1bmRlZmluZWQ7IH0gaWYgKG9wID09PSAnYWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJykgeyBsYXN0QWNjZXNzTEhTID0gdmFsdWU7IHZhbHVlID0gZm4odmFsdWUpOyB9IGVsc2UgaWYgKG9wID09PSAnY2FsbCcgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSB7IHZhbHVlID0gZm4oKC4uLmFyZ3MpID0+IHZhbHVlLmNhbGwobGFzdEFjY2Vzc0xIUywgLi4uYXJncykpOyBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyB9IH0gcmV0dXJuIHZhbHVlOyB9aW1wb3J0IFJlYWN0LCB7dXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlQ2FsbGJhY2t9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtjb25uZWN0fSBmcm9tICdyZWFjdC1yZWR1eCdcbmltcG9ydCBPdXRzdGFuZGluZyBmcm9tICcuL2NvbXBvbmVudHMvT3V0c3RhbmRpbmcnXG5pbXBvcnQgdXNlTmV0d29ya2VyIGZyb20gJ2NsaWVudC9ob29rcy91c2VOZXR3b3JrZXInXG5cbmltcG9ydCBMb2FkaW5nUGFnZSBmcm9tICdjbGllbnQvY29tcG9uZW50cy9Mb2FkaW5nUGFnZSdcbmltcG9ydCB1c2VEb2N1bWVudFRpdGxlIGZyb20gJ2NsaWVudC9ob29rcy91c2VEb2N1bWVudFRpdGxlJ1xuXG5cblxuXG5cblxuY29uc3QgT3V0c3RhbmRpbmdSb290ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHt1c2VyLCB1c2Vyc30gPSBwcm9wcyB8fCB7fVxuICBjb25zdCBbcXVldWVzLCBzZXRRdWV1ZXNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtvZmZzZXQsIHNldE9mZnNldF0gPSB1c2VTdGF0ZSgwKVxuICBjb25zdCBbY291bnQsIHNldENvdW50XSA9IHVzZVN0YXRlKDApXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbcXVldWVJZCwgc2V0UXVldWVJZF0gPSB1c2VTdGF0ZSh1bmRlZmluZWQpXG4gIGNvbnN0IFt1c2VySWQsIHNldFVzZXJJZF0gPSB1c2VTdGF0ZSh1bmRlZmluZWQpXG4gIGNvbnN0IG5ldHdvcmtlciA9IHVzZU5ldHdvcmtlcigpXG4gIGNvbnN0IG9yZ0lkID0gdXNlci5jdXJyZW50X29yZ2FuaXphdGlvbl9pZFxuICBjb25zdCBQQUdFX0xJTUlUID0gNTBcblxuICBjb25zdCBvbk5leHQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKG9mZnNldCA8IE1hdGguYWJzKGNvdW50IC0gUEFHRV9MSU1JVCkpIHtcbiAgICAgIHNldE9mZnNldChvZmZzZXQgKyBQQUdFX0xJTUlUKVxuICAgIH1cbiAgfSwgW2NvdW50LCBvZmZzZXRdKVxuXG4gIGNvbnN0IG9uQmFjayA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAob2Zmc2V0ID49IFBBR0VfTElNSVQpIHtcbiAgICAgIHNldE9mZnNldChvZmZzZXQgLSBQQUdFX0xJTUlUKVxuICAgIH1cbiAgfSwgW2NvdW50LCBvZmZzZXRdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYXN5bmMgZnVuY3Rpb24gZmV0Y2hRdWV1ZXMoKSB7XG4gICAgICBzZXRMb2FkaW5nKHRydWUpXG5cbiAgICAgIGNvbnN0IHtlcnJvcnMsIGRhdGE6IHF1ZXVlc30gPSBhd2FpdCBfb3B0aW9uYWxDaGFpbihbbmV0d29ya2VyLCAnb3B0aW9uYWxBY2Nlc3MnLCBfID0+IF8uaHR0cEhhbmRsZXIsICdjYWxsJywgXzIgPT4gXzIoYC9vcmdzLyR7b3JnSWR9L3F1ZXVlc2AsIHtcbiAgICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgICAgfSldKVxuXG4gICAgICBpZiAoZXJyb3JzKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGZldGNoaW5nIHF1ZXVlcyEnLCBKU09OLnN0cmluZ2lmeShlcnJvcnMpKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHF1ZXVlcykge1xuICAgICAgICAgIHNldENvdW50KHF1ZXVlcy5sZW5ndGgpXG4gICAgICAgICAgc2V0UXVldWVzKHF1ZXVlcylcbiAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgZmV0Y2hRdWV1ZXMoKVxuICB9LCBbcXVldWVJZCwgdXNlcklkLCBvZmZzZXQsIHVzZXJdKVxuXG4gIHVzZURvY3VtZW50VGl0bGUoJ091dHN0YW5kaW5nIFF1ZXVlcyB8IEh1bWFuIExhbWJkYXMnKVxuXG4gIGlmIChsb2FkaW5nKSByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChMb2FkaW5nUGFnZSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2Mn19IClcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoT3V0c3RhbmRpbmcsIHtcbiAgICAgIGNvdW50OiBjb3VudCxcbiAgICAgIG9uTmV4dDogb25OZXh0LFxuICAgICAgb25CYWNrOiBvbkJhY2ssXG4gICAgICBsaW1pdDogUEFHRV9MSU1JVCxcbiAgICAgIG9mZnNldDogb2Zmc2V0LFxuICAgICAgcXVldWVzOiBxdWV1ZXMsXG4gICAgICBzZXRRdWV1ZUlkOiBzZXRRdWV1ZUlkLFxuICAgICAgcXVldWVJZDogcXVldWVJZCxcbiAgICAgIHVzZXJzOiB1c2VycyxcbiAgICAgIHNldFVzZXJJZDogc2V0VXNlcklkLFxuICAgICAgdXNlcklkOiB1c2VySWQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2NX19XG4gICAgKVxuICApXG59XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IChzdGF0ZSkgPT4gKHtcbiAgdXNlcnM6IHN0YXRlLnVzZXJzXG59KVxuXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KG1hcFN0YXRlVG9Qcm9wcywgbnVsbCkoT3V0c3RhbmRpbmdSb290KVxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9tb2R1bGVzL291dHN0YW5kaW5nL2NvbXBvbmVudHMvT3V0c3RhbmRpbmcudHN4XCI7aW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHt1c2VIaXN0b3J5fSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ2NsaWVudC9zdHlsZXMvcGFsZXR0ZSdcbmltcG9ydCBMaXN0UGFnZSBmcm9tICdjbGllbnQvY29tcG9uZW50cy9MaXN0UGFnZS9MaXN0UGFnZSdcbmltcG9ydCBQbGFpbkJ1dHRvbiwge30gZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvUGxhaW5CdXR0b24nXG5pbXBvcnQgQXJyb3dMZWZ0SWNvbiBmcm9tICdjbGllbnQvY29tcG9uZW50cy9JY29ucy9BcnJvd0xlZnRTVkcnXG5pbXBvcnQgQXJyb3dSaWdodEljb24gZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvSWNvbnMvQXJyb3dSaWdodFNWRydcbmltcG9ydCBBdmF0YXIgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvQXZhdGFyJ1xuaW1wb3J0IGdldEluaXRpYWxzIGZyb20gJ3VuaXZlcnNhbC91dGlscy9nZXRJbml0aWFscydcbmltcG9ydCB0ZXh0T3ZlcmZsb3cgZnJvbSAndW5pdmVyc2FsL3N0eWxlcy9oZWxwZXJzL3RleHRPdmVyZmxvdydcbmltcG9ydCB1c2VNZW51IGZyb20gJ2NsaWVudC9ob29rcy91c2VNZW51J1xuaW1wb3J0IHtNZW51UG9zaXRpb259IGZyb20gJ2NsaWVudC9ob29rcy91c2VDb29yZHMnXG5pbXBvcnQgTGlzdFRpdGxlIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0xpc3RQYWdlL0xpc3RUaXRsZSdcbmltcG9ydCBTdGFuZGFyZE1lbnUgZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvU3RhbmRhcmRNZW51J1xuaW1wb3J0IEZpbHRlckljb24gZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvSWNvbnMvRmlsdGVyU1ZHJ1xuaW1wb3J0IEVtcHR5UGFnZSBmcm9tICdjbGllbnQvY29tcG9uZW50cy9FbXB0eVBhZ2UnXG5pbXBvcnQgRW1wdHlBdWRpdHNJY29uIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0ljb25zL0VtcHR5QXVkaXRzU1ZHJ1xuaW1wb3J0IEljb25CdXR0b25XcmFwcGVyIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0ljb25CdXR0b25XcmFwcGVyJ1xuXG5pbXBvcnQge2NvbG9yRnJvbVN0cmluZ30gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2dldENvbG9yJ1xuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5jb25zdCBDb2x1bW5Db250YWluZXIgPSBzdHlsZWQuZGl2KHtcbiAgbGluZUhlaWdodDogJzQwcHgnLFxuICBoZWlnaHQ6IDQwLFxuICBkaXNwbGF5OiAnZ3JpZCcsXG4gIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICc4MHB4IDEwMHB4IDFmciAxODBweCAxNTBweCcsXG4gIGdyaWRDb2x1bW5HYXA6IDE1XG59KVxuXG5jb25zdCBGb290ZXIgPSBzdHlsZWQuZGl2KHtcbiAgaGVpZ2h0OiA0NSxcbiAgZGlzcGxheTogJ2dyaWQnLFxuICBtYXhXaWR0aDogJzgwJScsXG4gIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICcyMDBweCAyMDBweCcsXG4gIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsXG4gIGFsaWduSXRlbXM6ICdjZW50ZXInXG59KVxuXG5jb25zdCBQYWdpbmF0b3IgPSBzdHlsZWQuZGl2KHtcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAganVzdGlmeUNvbnRlbnQ6ICdmbGV4LWVuZCdcbn0pXG5cbmNvbnN0IExhYmVsID0gc3R5bGVkLnNwYW4oe1xuICBtYXJnaW5MZWZ0OiA3LFxuICB3aWR0aDogJzEwMCUnLFxuICAuLi50ZXh0T3ZlcmZsb3dcbn0pXG5cbmNvbnN0IFNwYWNlciA9IHN0eWxlZC5kaXYoe1xuICBtYXJnaW5SaWdodDogNyxcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJ1xufSlcblxuY29uc3QgTGluZUl0ZW0gPSBzdHlsZWQuZGl2KHtcbiAgZmxleERpcmVjdGlvbjogJ3JvdycsXG4gIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICBjdXJzb3I6ICdwb2ludGVyICFpbXBvcnRhbnQnLFxuICBkaXNwbGF5OiAnYmxvY2snLFxuICAuLi50ZXh0T3ZlcmZsb3dcbn0pXG5cbmNvbnN0IFNtYWxsVGV4dCA9IHN0eWxlZC5zcGFuKHtcbiAgdGV4dEFsaWduOiAnbGVmdCcsXG4gIGNvbG9yOiBQQUxFVFRFLlRFWFRfTUFJTixcbiAgZm9udFNpemU6IDE0LFxuICB1c2VyU2VsZWN0OiAnbm9uZSdcbn0pXG5cbmNvbnN0IEF2YXRhckJsb2NrID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgYWxpZ25JdGVtczogJ2NlbnRlcidcbn0pXG5cbmNvbnN0IFBhZ2VDb3VudCA9IHN0eWxlZChQbGFpbkJ1dHRvbikoe1xuICBjb2xvcjogUEFMRVRURS5URVhUX01BSU4sXG4gIGZvbnRTaXplOiAxNCxcbiAgZm9udFdlaWdodDogNDAwLFxuICB1c2VyU2VsZWN0OiAnbm9uZScsXG4gIGJhY2tncm91bmRDb2xvcjogUEFMRVRURS5CQUNLR1JPVU5EX0hPVkVSLFxuICBtYXJnaW5MZWZ0OiAyLFxuICBtYXJnaW5SaWdodDogMixcbiAgd2lkdGg6ICdhdXRvJyxcbiAgYm9yZGVyUmFkaXVzOiAwLFxuICBoZWlnaHQ6IDI1LFxuICBsaW5lSGVpZ2h0OiAnMjVweCdcbn0pXG5cbmNvbnN0IFBhZ2luYXRlQnRuID0gc3R5bGVkKFBsYWluQnV0dG9uKSgoe2xlZnR9KSA9PiB7XG4gIHJldHVybiB7XG4gICAgaGVpZ2h0OiAyNSxcbiAgICBsaW5lSGVpZ2h0OiAnMjVweCcsXG4gICAgd2lkdGg6IDMwLFxuICAgIHBhZGRpbmc6IDAsXG4gICAgbWFyZ2luOiAwLFxuICAgIGJhY2tncm91bmQ6IFBBTEVUVEUuQkFDS0dST1VORF9IT1ZFUixcbiAgICBib3JkZXJUb3BSaWdodFJhZGl1czogbGVmdCA/IDAgOiA0LFxuICAgIGJvcmRlckJvdHRvbVJpZ2h0UmFkaXVzOiBsZWZ0ID8gMCA6IDQsXG4gICAgYm9yZGVyQm90dG9tTGVmdFJhZGl1czogbGVmdCA/IDQgOiAwLFxuICAgIGJvcmRlclRvcExlZnRSYWRpdXM6IGxlZnQgPyA0IDogMFxuICB9XG59KVxuXG5jb25zdCBTdHlsZWRFbCA9IHN0eWxlZC5kaXYoe1xuICBtYXJnaW46ICcwIDE1cHgnLFxuICBwYWRkaW5nOiAnN3B4IDAnLFxuICBmb250V2VpZ2h0OiA1MDAsXG4gIG1heFdpZHRoOiAzNTAsXG4gIC4uLnRleHRPdmVyZmxvd1xufSlcblxuY29uc3QgSFIgPSBzdHlsZWQuZGl2KHtcbiAgaGVpZ2h0OiAxLFxuICB3aWR0aDogJzEwMCUnLFxuICBiYWNrZ3JvdW5kQ29sb3I6IFBBTEVUVEUuQk9SREVSX01BSU5fR1JBWVxufSlcblxuY29uc3QgT3V0c3RhbmRpbmcgPSAocHJvcHMpID0+IHtcbiAgY29uc3Qge1xuICAgIGNvdW50LFxuICAgIG9uTmV4dCxcbiAgICBvbkJhY2ssXG4gICAgbGltaXQsXG4gICAgb2Zmc2V0LFxuICAgIHF1ZXVlcyxcbiAgICBzZXRRdWV1ZUlkLFxuICAgIHNldFVzZXJJZCxcbiAgICBxdWV1ZUlkLFxuICAgIHVzZXJJZCxcbiAgICB1c2Vyc1xuICB9ID0gcHJvcHNcbiAgY29uc3QgaGlzdG9yeSA9IHVzZUhpc3RvcnkoKVxuXG4gIGNvbnN0IHNlcGFyYXRvciA9IHtsYWJlbDogUmVhY3QuY3JlYXRlRWxlbWVudChIUiwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNTJ9fSApfVxuXG4gIGNvbnN0IHdNZW51SXRlbXMgPSBxdWV1ZXMubWFwKCh3KSA9PiAoe1xuICAgIGxhYmVsOiBxdWV1ZUlkID09PSB3LmlkID8gUmVhY3QuY3JlYXRlRWxlbWVudChTdHlsZWRFbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNTV9fSwgdy5uYW1lKSA6IHcubmFtZSxcbiAgICBvbkNsaWNrOiAoKSA9PiBzZXRRdWV1ZUlkKChwcmV2KSA9PiAocHJldiA9PT0gdy5pZCA/IHVuZGVmaW5lZCA6IHcuaWQpKVxuICB9KSlcbiAgaWYgKHF1ZXVlSWQpIHtcbiAgICB3TWVudUl0ZW1zLnVuc2hpZnQoc2VwYXJhdG9yKVxuICAgIHdNZW51SXRlbXMudW5zaGlmdCh7bGFiZWw6ICdDbGVhciBmaWx0ZXInLCBvbkNsaWNrOiAoKSA9PiBzZXRRdWV1ZUlkKHVuZGVmaW5lZCl9KVxuICB9XG5cbiAgY29uc3QgY2JNZW51SXRlbXMgPSB1c2Vycy5tYXAoKHUpID0+ICh7XG4gICAgbGFiZWw6IHVzZXJJZCA9PT0gdS5pZCA/IFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3R5bGVkRWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTY0fX0sIHUubmFtZSkgOiB1Lm5hbWUsXG4gICAgb25DbGljazogKCkgPT4gc2V0VXNlcklkKChwcmV2KSA9PiAocHJldiA9PT0gdS5pZCA/IHVuZGVmaW5lZCA6IHUuaWQpKVxuICB9KSlcbiAgaWYgKHVzZXJJZCkge1xuICAgIGNiTWVudUl0ZW1zLnVuc2hpZnQoc2VwYXJhdG9yKVxuICAgIGNiTWVudUl0ZW1zLnVuc2hpZnQoe2xhYmVsOiAnQ2xlYXIgZmlsdGVyJywgb25DbGljazogKCkgPT4gc2V0VXNlcklkKHVuZGVmaW5lZCl9KVxuICB9XG5cbiAgY29uc3Qge1xuICAgIG1lbnVQb3J0YWw6IG1lbnVQb3J0YWxRdWV1ZSxcbiAgICBvcmlnaW5SZWY6IG9yaWdpblJlZlF1ZXVlLFxuICAgIG1lbnVQcm9wczogbWVudVByb3BzUXVldWUsXG4gICAgdG9nZ2xlUG9ydGFsOiB0b2dnbGVQb3J0YWxRdWV1ZVxuICB9ID0gdXNlTWVudShNZW51UG9zaXRpb24uVVBQRVJfUklHSFQsIHtcbiAgICBpc0Ryb3Bkb3duOiB0cnVlLFxuICAgIG1lbnVDb250ZW50U3R5bGVzOiB7d2lkdGg6IDM1MH1cbiAgfSlcblxuICBjb25zdCB7XG4gICAgbWVudVBvcnRhbDogbWVudVBvcnRhbENiLFxuICAgIG9yaWdpblJlZjogb3JpZ2luUmVmQ2IsXG4gICAgbWVudVByb3BzOiBtZW51UHJvcHNDYixcbiAgICB0b2dnbGVQb3J0YWw6IHRvZ2dsZVBvcnRhbENiXG4gIH0gPSB1c2VNZW51KE1lbnVQb3NpdGlvbi5VUFBFUl9SSUdIVCwge1xuICAgIGlzRHJvcGRvd246IHRydWUsXG4gICAgbWVudUNvbnRlbnRTdHlsZXM6IHt3aWR0aDogMzUwfVxuICB9KVxuXG4gIGNvbnN0IHBhZ2VIZWFkZXIgPSAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb2x1bW5Db250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTkzfX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMaXN0VGl0bGUsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTk0fX0sIFwiUXVldWUgSURcIiApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGlzdFRpdGxlLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE5NX19LCBcIk9yZyBJRFwiIClcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMaXN0VGl0bGUsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTk2fX1cbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFJlYWN0LkZyYWdtZW50LCBudWxsXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFNwYWNlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxOTh9fSwgXCJRdWV1ZSBOYW1lXCIgKVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChJY29uQnV0dG9uV3JhcHBlciwgeyByZWY6IG9yaWdpblJlZlF1ZXVlLCBvbkNsaWNrOiB0b2dnbGVQb3J0YWxRdWV1ZSwgdHlwZTogXCJidXR0b25cIiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE5OX19XG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRmlsdGVySWNvbiwgeyBjb2xvcjogcXVldWVJZCA/IFBBTEVUVEUuVEVYVF9NQUlOIDogUEFMRVRURS5URVhUX0dSQVksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMDB9fSApXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGlzdFRpdGxlLCB7IGFsaWduOiBcImNlbnRlclwiLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjA0fX0sIFwiQ3JlYXRlZCBBdFwiIClcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMaXN0VGl0bGUsIHsgYWxpZ246IFwiY2VudGVyXCIsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMDV9fSwgXCJQZW5kaW5nIFRhc2tzXCIgKVxuICAgIClcbiAgKVxuXG4gIGNvbnN0IHBhZ2VGb290ZXIgPSAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChGb290ZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjEwfX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTbWFsbFRleHQsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjExfX0sIGNvdW50LCBcIiBDb21wbGV0ZWQgdGFza3NcIiAgKVxuICAgICAgLCBjb3VudCA+IGxpbWl0ICYmIChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChQYWdpbmF0b3IsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjEzfX1cbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUGFnaW5hdGVCdG4sIHsgbGVmdDogdHJ1ZSwgb25DbGljazogb25CYWNrLCBkaXNhYmxlZDogb2Zmc2V0IDwgbGltaXQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMTR9fVxuICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEFycm93TGVmdEljb24sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjE1fX0gKVxuICAgICAgICAgIClcbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUGFnZUNvdW50LCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIxN319LCBgJHsob2Zmc2V0IC8gbGltaXQgKyAxKS50b0ZpeGVkKCl9IC8gJHtNYXRoLmNlaWwoY291bnQgLyBsaW1pdCl9YClcbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUGFnaW5hdGVCdG4sIHsgb25DbGljazogb25OZXh0LCBkaXNhYmxlZDogb2Zmc2V0ID49IE1hdGguYWJzKGNvdW50IC0gbGltaXQpLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjE4fX1cbiAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChBcnJvd1JpZ2h0SWNvbiwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMTl9fSApXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICApXG4gICAgKVxuICApXG5cbiAgY29uc3QgaXRlbUxpc3QgPSBxdWV1ZXMubWFwKCh7aWQsIGNyZWF0ZWRfYXQsIG9yZ19pZCwgbl90YXNrcywgbmFtZX0pID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb2x1bW5Db250YWluZXIsIHtcbiAgICAgICAga2V5OiBpZCxcbiAgICAgICAgb25DbGljazogKCkgPT5cbiAgICAgICAgICBoaXN0b3J5LnB1c2goYC9xdWV1ZXMvJHtpZH1gKVxuICAgICAgICAsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMjh9fVxuICAgICAgXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMaW5lSXRlbSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzR9fSwgaWQpXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMaW5lSXRlbSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzV9fSwgb3JnX2lkKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGluZUl0ZW0sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjM2fX0sIG5hbWUpXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMaW5lSXRlbSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzd9fVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChBdmF0YXJCbG9jaywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzh9fVxuICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEF2YXRhciwgeyBpbml0aWFsczogZ2V0SW5pdGlhbHMobmFtZSksIGNvbG9yOiBjb2xvckZyb21TdHJpbmcobmFtZSksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzl9fSApXG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjQwfX0sIGNyZWF0ZWRfYXQpXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMaW5lSXRlbSwge1xuICAgICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICAgICBqdXN0aWZ5U2VsZjogJ2NlbnRlcicsXG4gICAgICAgICAgICBjb2xvcjogUEFMRVRURS5URVhUX0dSQVlcbiAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjQzfX1cbiAgICAgICAgXG4gICAgICAgICAgLCBuX3Rhc2tzXG4gICAgICAgIClcbiAgICAgIClcbiAgICApXG4gIH0pXG5cbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFJlYWN0LkZyYWdtZW50LCBudWxsXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGlzdFBhZ2UsIHtcbiAgICAgICAgcGFnZUhlYWRlcjogcGFnZUhlYWRlcixcbiAgICAgICAgaXRlbUxpc3Q6IGl0ZW1MaXN0LFxuICAgICAgICBwYWdlRm9vdGVyOiBwYWdlRm9vdGVyLFxuICAgICAgICBlbXB0eUxpc3Q6IFxuICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRW1wdHlQYWdlLCB7XG4gICAgICAgICAgICBzdmc6IFJlYWN0LmNyZWF0ZUVsZW1lbnQoRW1wdHlBdWRpdHNJY29uLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI2NH19ICksXG4gICAgICAgICAgICBoZWFkZXI6ICdObyB0YXNrcyBoZXJl4oCmJyxcbiAgICAgICAgICAgIHN1YkhlYWRlcjogJ1RyeSB1c2luZyBkaWZmZXJlbnQgZmlsdGVycy4nLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjYzfX1cbiAgICAgICAgICApXG4gICAgICAgICwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI1OH19XG4gICAgICApXG4gICAgICAsIG1lbnVQb3J0YWxRdWV1ZShSZWFjdC5jcmVhdGVFbGVtZW50KFN0YW5kYXJkTWVudSwgeyBtZW51UHJvcHM6IG1lbnVQcm9wc1F1ZXVlLCBtZW51SXRlbXM6IHdNZW51SXRlbXMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNzB9fSApKVxuICAgICAgLCBtZW51UG9ydGFsQ2IoUmVhY3QuY3JlYXRlRWxlbWVudChTdGFuZGFyZE1lbnUsIHsgbWVudVByb3BzOiBtZW51UHJvcHNDYiwgbWVudUl0ZW1zOiBjYk1lbnVJdGVtcywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI3MX19ICkpXG4gICAgKVxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE91dHN0YW5kaW5nXG4iXSwic291cmNlUm9vdCI6IiJ9