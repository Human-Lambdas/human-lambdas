(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["DashboardRoot"],{

/***/ "./src/client/components/AppMenu.tsx":
/*!*******************************************!*\
  !*** ./src/client/components/AppMenu.tsx ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Menu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Menu */ "./src/client/components/Menu.tsx");
/* harmony import */ var _MenuItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./MenuItem */ "./src/client/components/MenuItem.tsx");
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/styles/helpers/textOverflow */ "./src/universal/styles/helpers/textOverflow.ts");
/* harmony import */ var client_hooks_useRouter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! client/hooks/useRouter */ "./src/client/hooks/useRouter.ts");
/* harmony import */ var client_components_Icons_DocumentationSVG__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! client/components/Icons/DocumentationSVG */ "./src/client/components/Icons/DocumentationSVG.tsx");
/* harmony import */ var _components_PlainButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../components/PlainButton */ "./src/client/components/PlainButton.tsx");
/* harmony import */ var _Sidebar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Sidebar */ "./src/client/components/Sidebar.tsx");
/* harmony import */ var universal_components_Icon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! universal/components/Icon */ "./src/universal/components/Icon.tsx");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/AppMenu.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}












const Container = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ezlisng0"
})({
  name: "1mmtv2s",
  styles: "width:220px;"
});

const HeadBlock = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ezlisng1"
})({
  display: 'flex',
  flexDirection: 'column',
  padding: '10px 15px',
  userSelect: 'none',
  cursor: 'default',
  borderBottom: `1px solid ${universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BORDER_GRAY}`
});

const ActionBlock = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ezlisng2"
})({
  borderBottom: `1px solid ${universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BORDER_GRAY}`,
  marginBottom: 5,
  padding: '10px 0',
  maxHeight: '60vh',
  overflow: 'auto'
});

const OrgContainer = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(_components_PlainButton__WEBPACK_IMPORTED_MODULE_8__["default"], {
  target: "ezlisng3"
})({
  alignItems: 'center',
  justifyContent: 'start',
  marginBottom: 10,
  margin: 0,
  width: '100%',
  cursor: 'pointer',
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_GRAY
});

const OrgName = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ezlisng4"
})(({
  active
}) => _objectSpread(_objectSpread({
  justifyContent: 'flex-start',
  alignItems: 'center',
  overflow: 'hidden',
  padding: 0
}, universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_5__["default"]), {}, {
  color: active ? universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_MAIN : '#4d4d4d',
  ':hover': {
    color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_MAIN
  }
}));

const StyledName = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ezlisng5"
})(_objectSpread({
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_MAIN,
  fontSize: 15,
  fontWeight: 500,
  marginBottom: 2
}, universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_5__["default"]));

const StyledEmail = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ezlisng6"
})(_objectSpread({
  fontSize: 13,
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_GRAY,
  fontWeight: 400
}, universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_5__["default"]));

const Label = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ezlisng7"
})({
  name: "1ss7i2n",
  styles: "display:flex;flex-direction:row;align-items:center;padding:5px 10px;width:100%;"
});

const Text = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ezlisng8"
})({
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_MAIN,
  marginLeft: 15
});

const StyledIcon = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_Icon__WEBPACK_IMPORTED_MODULE_10__["default"], {
  target: "ezlisng9"
})({
  margin: 0,
  padding: 0,
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_MAIN,
  fontSize: 16
});

const AppMenu = props => {
  const {
    togglePortal,
    switchUserOrg,
    menuProps,
    name,
    email,
    organizations,
    current_organization_id,
    toggleModalPortal
  } = props;
  const {
    history
  } = Object(client_hooks_useRouter__WEBPACK_IMPORTED_MODULE_6__["default"])();
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Container, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 111
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(HeadBlock, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 112
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledName, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 113
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledEmail, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 114
    }
  }, email)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ActionBlock, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 116
    }
  }, organizations.map(({
    name,
    id
  }) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(OrgContainer, {
    key: id,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 118
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Sidebar__WEBPACK_IMPORTED_MODULE_9__["Brand"], {
    active: id === current_organization_id,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 119
    }
  }, _optionalChain([name, 'optionalAccess', _ => _.charAt, 'call', _2 => _2(0)])), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(OrgName, {
    onClick: () => {
      togglePortal();
      switchUserOrg(id);
    },
    active: id === current_organization_id,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 120
    }
  }, name)))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ActionBlock, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 132
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Menu__WEBPACK_IMPORTED_MODULE_2__["default"], _objectSpread(_objectSpread({
    ariaLabel: 'Documentation'
  }, menuProps), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 133
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_MenuItem__WEBPACK_IMPORTED_MODULE_3__["default"], {
    label: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 136
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 137
      }
    }, "add"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Text, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 138
      }
    }, "Add organization")),
    onClick: () => {
      toggleModalPortal();
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 134
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_MenuItem__WEBPACK_IMPORTED_MODULE_3__["default"], {
    label: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 147
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_DocumentationSVG__WEBPACK_IMPORTED_MODULE_7__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 148
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Text, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 149
      }
    }, "Documentation")),
    onClick: () => window.open('https://docs.humanlambdas.com/', '_blank'),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 145
    }
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Menu__WEBPACK_IMPORTED_MODULE_2__["default"], _objectSpread(_objectSpread({
    ariaLabel: 'User menu'
  }, menuProps), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 156
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_MenuItem__WEBPACK_IMPORTED_MODULE_3__["default"], {
    label: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 159
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 160
      }
    }, "exit_to_app"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Text, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 161
      }
    }, "Sign out")),
    onClick: () => history.push('/signout'),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 157
    }
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (AppMenu);

/***/ }),

/***/ "./src/client/components/Dot.tsx":
/*!***************************************!*\
  !*** ./src/client/components/Dot.tsx ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Dot.tsx";


const StyledDot = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e9ugbr60"
})(({
  color
}) => ({
  height: 10,
  width: 10,
  borderRadius: 50,
  backgroundColor: color,
  marginRight: 10
}));

const Dot = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__["memo"](props => {
  const {
    color
  } = props;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__["createElement"](StyledDot, {
    color: color,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 18
    }
  });
});
/* harmony default export */ __webpack_exports__["default"] = (Dot);

/***/ }),

/***/ "./src/client/components/Icons/ArrowDownSVG.tsx":
/*!******************************************************!*\
  !*** ./src/client/components/Icons/ArrowDownSVG.tsx ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Icons/ArrowDownSVG.tsx";


const ArrowDownSVG = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(() => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', {
    height: "13",
    viewBox: "0 0 515.555 515.555",
    width: "13",
    xmlns: "http://www.w3.org/2000/svg",
    fill: styles_palette__WEBPACK_IMPORTED_MODULE_1__["PALETTE"].TEXT_MAIN,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M400 216a23.928 23.928 0 01-16.971-7.029L256 81.941l-127.029 127.03a24 24 0 01-33.942-33.942l144-144a24 24 0 0133.942 0l144 144A24 24 0 01400 216zM272.971 480.971l144-144a24 24 0 00-33.942-33.942L256 430.059l-127.029-127.03a24 24 0 00-33.942 33.942l144 144a24 24 0 0033.942 0z",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }));
});
/* harmony default export */ __webpack_exports__["default"] = (ArrowDownSVG);

/***/ }),

/***/ "./src/client/components/Icons/AuditsSVG.tsx":
/*!***************************************************!*\
  !*** ./src/client/components/Icons/AuditsSVG.tsx ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Icons/AuditsSVG.tsx";


const UsersSVG = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(() => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', {
    height: "15",
    viewBox: "0 0 515.555 515.555",
    width: "17",
    xmlns: "http://www.w3.org/2000/svg",
    fill: styles_palette__WEBPACK_IMPORTED_MODULE_1__["PALETTE"].TEXT_MAIN,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M325.5 40h-75.426c-8.258-23.281-30.5-40-56.574-40s-48.316 16.719-56.574 40H60.5c-33.086 0-60 26.914-60 60v352c0 33.086 26.914 60 60 60h265.063c33.05-.035 59.937-26.95 59.937-60V100c0-33.086-26.914-60-60-60zm-152 40V60c0-11.027 8.973-20 20-20s20 8.973 20 20v20h40v39h-120V80zm172 372c0 11.016-8.965 19.988-19.957 20H60.5c-11.027 0-20-8.973-20-20V100c0-11.027 8.973-20 20-20h33v79h200V80h32c11.027 0 20 8.973 20 20zm-75.793-221.96l29.582 26.92L171.2 397.71l-84.605-81.835 27.812-28.75 54.965 53.164zm0 0",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }));
});
/* harmony default export */ __webpack_exports__["default"] = (UsersSVG);

/***/ }),

/***/ "./src/client/components/Icons/DocumentationSVG.tsx":
/*!**********************************************************!*\
  !*** ./src/client/components/Icons/DocumentationSVG.tsx ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Icons/DocumentationSVG.tsx";


const DocumentationSVG = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(() => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', {
    height: "15",
    viewBox: "0 0 515.555 515.555",
    width: "15",
    xmlns: "http://www.w3.org/2000/svg",
    fill: styles_palette__WEBPACK_IMPORTED_MODULE_1__["PALETTE"].TEXT_MAIN,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M484.333 256c0-19.73-2.515-39.248-7.484-58.162l28.9-21.261-56.093-97.155-32.913 14.42c-28.138-27.938-62.594-47.847-100.689-58.18L312.093 0H199.907l-3.962 35.662c-38.096 10.333-72.551 30.242-100.689 58.18l-32.912-14.42-56.093 97.155 28.9 21.261c-4.97 18.914-7.484 38.432-7.484 58.162s2.515 39.248 7.484 58.162l-28.9 21.26 56.093 97.155 32.912-14.42c28.139 27.939 62.594 47.848 100.689 58.18L199.907 512h112.186l3.962-35.663c38.096-10.332 72.551-30.242 100.689-58.18l32.912 14.42 56.093-97.155-28.9-21.26c4.969-18.914 7.484-38.432 7.484-58.162zM299.061 449.633l-10.481 2.32L285.241 482h-58.482l-3.339-30.047-10.481-2.32c-39.739-8.795-75.382-29.389-103.074-59.555l-7.25-7.898-27.716 12.143-29.241-50.647 24.325-17.894-3.216-10.228c-6.038-19.207-9.1-39.244-9.1-59.554 0-20.311 3.062-40.348 9.1-59.554l3.216-10.228-24.325-17.894 29.241-50.647 27.716 12.143 7.25-7.898c27.692-30.166 63.335-50.76 103.074-59.555l10.481-2.32L226.759 30h58.482l3.339 30.047 10.481 2.32c39.739 8.796 75.382 29.39 103.074 59.555l7.25 7.898 27.716-12.143 29.241 50.647-24.325 17.894 3.216 10.228c6.038 19.207 9.1 39.244 9.1 59.554s-3.061 40.347-9.1 59.554l-3.216 10.228 24.325 17.894-29.241 50.647-27.716-12.143-7.25 7.898c-27.692 30.166-63.334 50.76-103.074 59.555z",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M196.448 221.66l-21.433-20.99-54.863 56.019 56.02 54.863 20.99-21.434-34.586-33.872zM315.552 221.66l33.872 34.586-34.586 33.872 20.99 21.434 56.02-54.863-54.863-56.019zM220.097 354.176l42.664-202.76 29.371 6.18-42.664 202.76z",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    }
  }));
});
/* harmony default export */ __webpack_exports__["default"] = (DocumentationSVG);

/***/ }),

/***/ "./src/client/components/Icons/MetricsSVG.tsx":
/*!****************************************************!*\
  !*** ./src/client/components/Icons/MetricsSVG.tsx ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Icons/MetricsSVG.tsx";


const MetricSVG = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(() => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', {
    height: "15",
    viewBox: "0 0 515.555 515.555",
    width: "15",
    xmlns: "http://www.w3.org/2000/svg",
    fill: styles_palette__WEBPACK_IMPORTED_MODULE_1__["PALETTE"].TEXT_MAIN,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M298.667 85.333l48.96 48.96-104.107 104-85.333-85.333L0 311.147l30.187 30.186 128-128 85.333 85.334 134.187-134.294 48.96 48.96v-128z",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }));
});
/* harmony default export */ __webpack_exports__["default"] = (MetricSVG);

/***/ }),

/***/ "./src/client/components/Icons/QueueSVG.tsx":
/*!**************************************************!*\
  !*** ./src/client/components/Icons/QueueSVG.tsx ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Icons/QueueSVG.tsx";


const QueueSVG = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(() => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', {
    height: "15",
    viewBox: "0 0 515.555 515.555",
    width: "15",
    xmlns: "http://www.w3.org/2000/svg",
    fill: styles_palette__WEBPACK_IMPORTED_MODULE_1__["PALETTE"].TEXT_MAIN,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 426.667 426.667",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M341.333 53.333L256 138.667h64V288c0 23.573-19.093 42.667-42.667 42.667-23.573 0-42.667-19.093-42.667-42.667V138.667c0-47.04-38.293-85.333-85.333-85.333S64 91.627 64 138.667V288H0l85.333 85.333L170.667 288h-64V138.667c0-23.573 19.093-42.667 42.667-42.667S192 115.093 192 138.667V288c0 47.04 38.293 85.333 85.333 85.333S362.666 335.04 362.666 288V138.667h64l-85.333-85.334z",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    }
  })));
});
/* harmony default export */ __webpack_exports__["default"] = (QueueSVG);

/***/ }),

/***/ "./src/client/components/Icons/SettingsSVG.tsx":
/*!*****************************************************!*\
  !*** ./src/client/components/Icons/SettingsSVG.tsx ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Icons/SettingsSVG.tsx";


const SettingsSVG = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(() => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', {
    height: "15",
    viewBox: "0 0 515.555 515.555",
    width: "15",
    xmlns: "http://www.w3.org/2000/svg",
    fill: styles_palette__WEBPACK_IMPORTED_MODULE_1__["PALETTE"].TEXT_MAIN,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M272.066 512h-32.133c-25.989 0-47.134-21.144-47.134-47.133v-10.871a206.698 206.698 0 01-32.097-13.323l-7.704 7.704c-18.659 18.682-48.548 18.134-66.665-.007l-22.711-22.71c-18.149-18.129-18.671-48.008.006-66.665l7.698-7.698A206.714 206.714 0 0158.003 319.2h-10.87C21.145 319.2 0 298.056 0 272.067v-32.134C0 213.944 21.145 192.8 47.134 192.8h10.87a206.755 206.755 0 0113.323-32.097L63.623 153c-18.666-18.646-18.151-48.528.006-66.665l22.713-22.712c18.159-18.184 48.041-18.638 66.664.006l7.697 7.697A206.893 206.893 0 01192.8 58.003v-10.87C192.8 21.144 213.944 0 239.934 0h32.133C298.056 0 319.2 21.144 319.2 47.133v10.871a206.698 206.698 0 0132.097 13.323l7.704-7.704c18.659-18.682 48.548-18.134 66.665.007l22.711 22.71c18.149 18.129 18.671 48.008-.006 66.665l-7.698 7.698a206.714 206.714 0 0113.323 32.097h10.87c25.989 0 47.134 21.144 47.134 47.133v32.134c0 25.989-21.145 47.133-47.134 47.133h-10.87a206.755 206.755 0 01-13.323 32.097l7.704 7.704c18.666 18.646 18.151 48.528-.006 66.665l-22.713 22.712c-18.159 18.184-48.041 18.638-66.664-.006l-7.697-7.697a206.893 206.893 0 01-32.097 13.323v10.871c0 25.987-21.144 47.131-47.134 47.131zM165.717 409.17a176.812 176.812 0 0045.831 19.025 14.999 14.999 0 0111.252 14.524v22.148c0 9.447 7.687 17.133 17.134 17.133h32.133c9.447 0 17.134-7.686 17.134-17.133v-22.148a14.999 14.999 0 0111.252-14.524 176.812 176.812 0 0045.831-19.025 15 15 0 0118.243 2.305l15.688 15.689c6.764 6.772 17.626 6.615 24.224.007l22.727-22.726c6.582-6.574 6.802-17.438.006-24.225l-15.695-15.695a15 15 0 01-2.305-18.242 176.78 176.78 0 0019.024-45.831 15 15 0 0114.524-11.251h22.147c9.447 0 17.134-7.686 17.134-17.133v-32.134c0-9.447-7.687-17.133-17.134-17.133H442.72a15 15 0 01-14.524-11.251 176.815 176.815 0 00-19.024-45.831 15 15 0 012.305-18.242l15.689-15.689c6.782-6.774 6.605-17.634.006-24.225l-22.725-22.725c-6.587-6.596-17.451-6.789-24.225-.006l-15.694 15.695a15 15 0 01-18.243 2.305 176.812 176.812 0 00-45.831-19.025 14.999 14.999 0 01-11.252-14.524v-22.15c0-9.447-7.687-17.133-17.134-17.133h-32.133c-9.447 0-17.134 7.686-17.134 17.133v22.148a14.999 14.999 0 01-11.252 14.524 176.812 176.812 0 00-45.831 19.025 15.002 15.002 0 01-18.243-2.305l-15.688-15.689c-6.764-6.772-17.627-6.615-24.224-.007l-22.727 22.726c-6.582 6.574-6.802 17.437-.006 24.225l15.695 15.695a15 15 0 012.305 18.242 176.78 176.78 0 00-19.024 45.831 15 15 0 01-14.524 11.251H47.134C37.687 222.8 30 230.486 30 239.933v32.134c0 9.447 7.687 17.133 17.134 17.133h22.147a15 15 0 0114.524 11.251 176.815 176.815 0 0019.024 45.831 15 15 0 01-2.305 18.242l-15.689 15.689c-6.782 6.774-6.605 17.634-.006 24.225l22.725 22.725c6.587 6.596 17.451 6.789 24.225.006l15.694-15.695c3.568-3.567 10.991-6.594 18.244-2.304z",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M256 367.4c-61.427 0-111.4-49.974-111.4-111.4S194.573 144.6 256 144.6 367.4 194.574 367.4 256 317.427 367.4 256 367.4zm0-192.8c-44.885 0-81.4 36.516-81.4 81.4s36.516 81.4 81.4 81.4 81.4-36.516 81.4-81.4-36.515-81.4-81.4-81.4z",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14
    }
  }));
});
/* harmony default export */ __webpack_exports__["default"] = (SettingsSVG);

/***/ }),

/***/ "./src/client/components/Icons/UsersSVG.tsx":
/*!**************************************************!*\
  !*** ./src/client/components/Icons/UsersSVG.tsx ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Icons/UsersSVG.tsx";


const UsersSVG = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(() => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('svg', {
    height: "15",
    viewBox: "0 0 515.555 515.555",
    width: "17",
    xmlns: "http://www.w3.org/2000/svg",
    fill: styles_palette__WEBPACK_IMPORTED_MODULE_1__["PALETTE"].TEXT_MAIN,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('path', {
    d: "M210.352 246.633c33.882 0 63.218-12.153 87.195-36.13 23.969-23.972 36.125-53.304 36.125-87.19 0-33.876-12.152-63.211-36.129-87.192C273.566 12.152 244.23 0 210.352 0c-33.887 0-63.22 12.152-87.192 36.125s-36.129 53.309-36.129 87.188c0 33.886 12.156 63.222 36.13 87.195 23.98 23.969 53.316 36.125 87.19 36.125zM144.379 57.34c18.394-18.395 39.973-27.336 65.973-27.336 25.996 0 47.578 8.941 65.976 27.336 18.395 18.398 27.34 39.98 27.34 65.972 0 26-8.945 47.579-27.34 65.977-18.398 18.399-39.98 27.34-65.976 27.34-25.993 0-47.57-8.945-65.973-27.34-18.399-18.394-27.344-39.976-27.344-65.976 0-25.993 8.945-47.575 27.344-65.973zm0 0M426.129 393.703c-.692-9.976-2.09-20.86-4.149-32.351-2.078-11.579-4.753-22.524-7.957-32.528-3.312-10.34-7.808-20.55-13.375-30.336-5.77-10.156-12.55-19-20.16-26.277-7.957-7.613-17.699-13.734-28.965-18.2-11.226-4.44-23.668-6.69-36.976-6.69-5.227 0-10.281 2.144-20.043 8.5a2711.03 2711.03 0 01-20.879 13.46c-6.707 4.274-15.793 8.278-27.016 11.903-10.949 3.543-22.066 5.34-33.043 5.34-10.968 0-22.086-1.797-33.043-5.34-11.21-3.622-20.3-7.625-26.996-11.899-7.77-4.965-14.8-9.496-20.898-13.469-9.754-6.355-14.809-8.5-20.035-8.5-13.313 0-25.75 2.254-36.973 6.7-11.258 4.457-21.004 10.578-28.969 18.199-7.609 7.281-14.39 16.12-20.156 26.273-5.558 9.785-10.058 19.992-13.371 30.34-3.2 10.004-5.875 20.945-7.953 32.524-2.063 11.476-3.457 22.363-4.149 32.363C.343 403.492 0 413.668 0 423.949c0 26.727 8.496 48.363 25.25 64.32C41.797 504.017 63.688 512 90.316 512h246.532c26.62 0 48.511-7.984 65.062-23.73 16.758-15.946 25.254-37.59 25.254-64.325-.004-10.316-.351-20.492-1.035-30.242zm-44.906 72.828c-10.934 10.406-25.45 15.465-44.38 15.465H90.317c-18.933 0-33.449-5.059-44.379-15.46-10.722-10.208-15.933-24.141-15.933-42.587 0-9.594.316-19.066.95-28.16.616-8.922 1.878-18.723 3.75-29.137 1.847-10.285 4.198-19.937 6.995-28.675 2.684-8.38 6.344-16.676 10.883-24.668 4.332-7.618 9.316-14.153 14.816-19.418 5.145-4.926 11.63-8.957 19.27-11.98 7.066-2.798 15.008-4.329 23.629-4.56 1.05.56 2.922 1.626 5.953 3.602 6.168 4.02 13.277 8.606 21.137 13.625 8.86 5.649 20.273 10.75 33.91 15.152 13.941 4.508 28.16 6.797 42.273 6.797 14.114 0 28.336-2.289 42.27-6.793 13.648-4.41 25.058-9.507 33.93-15.164 8.043-5.14 14.953-9.593 21.12-13.617 3.032-1.973 4.903-3.043 5.954-3.601 8.625.23 16.566 1.761 23.636 4.558 7.637 3.024 14.122 7.059 19.266 11.98 5.5 5.262 10.484 11.798 14.816 19.423 4.543 7.988 8.208 16.289 10.887 24.66 2.801 8.75 5.156 18.398 7 28.675 1.867 10.434 3.133 20.239 3.75 29.145v.008c.637 9.058.957 18.527.961 28.148-.004 18.45-5.215 32.38-15.937 42.582zm0 0",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13
    }
  }));
});
/* harmony default export */ __webpack_exports__["default"] = (UsersSVG);

/***/ }),

/***/ "./src/client/components/NewOrgModal.tsx":
/*!***********************************************!*\
  !*** ./src/client/components/NewOrgModal.tsx ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var universal_validations_yupSchema__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/validations/yupSchema */ "./src/universal/validations/yupSchema.ts");
/* harmony import */ var universal_components_InputField__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! universal/components/InputField */ "./src/universal/components/InputField.tsx");
/* harmony import */ var client_styles_palette__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! client/styles/palette */ "./src/client/styles/palette.ts");
/* harmony import */ var client_utils_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! client/utils/constants */ "./src/client/utils/constants.ts");
/* harmony import */ var universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! universal/components/SecondaryButton */ "./src/universal/components/SecondaryButton.tsx");
/* harmony import */ var universal_components_PrimaryButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/components/PrimaryButton */ "./src/universal/components/PrimaryButton.tsx");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/NewOrgModal.tsx";









const ModalRoot = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "eizdsro0"
})({
  display: 'flex',
  flexDirection: 'column',
  width: 500,
  borderRadius: 10,
  backgroundColor: '#fff',
  border: `1px solid ${client_styles_palette__WEBPACK_IMPORTED_MODULE_5__["PALETTE"].BORDER_MAIN_GRAY}`,
  boxShadow: client_utils_constants__WEBPACK_IMPORTED_MODULE_6__["BoxShadow"].MODAL
});

const MainTitle = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "eizdsro1"
})({
  name: "1xxpbhg",
  styles: "font-size:22px;font-weight:600;display:flex;align-items:center;margin-bottom:35px;"
});

const FormContent = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(formik__WEBPACK_IMPORTED_MODULE_2__["Form"], {
  target: "eizdsro2"
})({
  name: "r9hl0f",
  styles: "padding:50px 50px 30px;"
});

const ButtonSection = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "eizdsro3"
})({
  name: "1htoikp",
  styles: "display:grid;grid-template-columns:repeat(2, auto);justify-content:space-between;padding-top:25px;"
});

const NewOrgModal = ({
  closePortal,
  handleNewOrganization
}) => {
  const onSubmitHandler = Object(react__WEBPACK_IMPORTED_MODULE_1__["useCallback"])((values, actions) => {
    handleNewOrganization(values);
    actions.setSubmitting();
    closePortal();
  }, [closePortal, handleNewOrganization]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ModalRoot, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(formik__WEBPACK_IMPORTED_MODULE_2__["Formik"], {
    validateOnChange: true,
    initialValues: {
      name: ''
    },
    validationSchema: universal_validations_yupSchema__WEBPACK_IMPORTED_MODULE_3__["organizationSchema"],
    onSubmit: onSubmitHandler,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    }
  }, ({
    isSubmitting,
    values,
    handleChange
  }) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FormContent, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 63
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(MainTitle, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    }
  }, "Add new organization"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_InputField__WEBPACK_IMPORTED_MODULE_4__["default"], {
    placeholder: "Enter organization name",
    name: "name",
    value: values.name,
    onChange: handleChange,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ButtonSection, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_7__["default"], {
    type: "button",
    onClick: closePortal,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 72
    }
  }, "Cancel"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_PrimaryButton__WEBPACK_IMPORTED_MODULE_8__["default"], {
    type: "submit",
    disabled: isSubmitting,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 75
    }
  }, "Create")))));
};

/* harmony default export */ __webpack_exports__["default"] = (NewOrgModal);

/***/ }),

/***/ "./src/client/components/Sidebar.tsx":
/*!*******************************************!*\
  !*** ./src/client/components/Sidebar.tsx ***!
  \*******************************************/
/*! exports provided: Brand, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Brand", function() { return Brand; });
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _emotion_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @emotion/core */ "./node_modules/@emotion/core/dist/core.browser.esm.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/styles/helpers/textOverflow */ "./src/universal/styles/helpers/textOverflow.ts");
/* harmony import */ var client_components_Icons_QueueSVG__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! client/components/Icons/QueueSVG */ "./src/client/components/Icons/QueueSVG.tsx");
/* harmony import */ var client_components_Icons_UsersSVG__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! client/components/Icons/UsersSVG */ "./src/client/components/Icons/UsersSVG.tsx");
/* harmony import */ var client_components_Icons_MetricsSVG__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! client/components/Icons/MetricsSVG */ "./src/client/components/Icons/MetricsSVG.tsx");
/* harmony import */ var client_components_Icons_SettingsSVG__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! client/components/Icons/SettingsSVG */ "./src/client/components/Icons/SettingsSVG.tsx");
/* harmony import */ var client_components_Icons_AuditsSVG__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! client/components/Icons/AuditsSVG */ "./src/client/components/Icons/AuditsSVG.tsx");
/* harmony import */ var client_hooks_useMenu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! client/hooks/useMenu */ "./src/client/hooks/useMenu.ts");
/* harmony import */ var client_components_AppMenu__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! client/components/AppMenu */ "./src/client/components/AppMenu.tsx");
/* harmony import */ var client_hooks_useCoords__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! client/hooks/useCoords */ "./src/client/hooks/useCoords.ts");
/* harmony import */ var client_components_Icons_ArrowDownSVG__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! client/components/Icons/ArrowDownSVG */ "./src/client/components/Icons/ArrowDownSVG.tsx");
/* harmony import */ var client_components_Dot__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! client/components/Dot */ "./src/client/components/Dot.tsx");
/* harmony import */ var client_hooks_useModal__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! client/hooks/useModal */ "./src/client/hooks/useModal.ts");
/* harmony import */ var client_components_NewOrgModal__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! client/components/NewOrgModal */ "./src/client/components/NewOrgModal.tsx");
/* harmony import */ var client_utils_isUserStaff__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! client/utils/isUserStaff */ "./src/client/utils/isUserStaff.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Sidebar.tsx";




















const StyledRoot = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ei3w2qh0"
})({
  position: 'relative',
  backgroundColor: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BACKGROUND_MAIN,
  overflow: 'hidden',
  borderRight: `1px solid ${universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BORDER_MAIN_GRAY}`,
  height: '100%',
  userSelect: 'none'
});

const NavContents = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ei3w2qh1"
})({
  name: "bozjad",
  styles: "display:flex;flex-direction:column;justify-content:space-between;height:100%;padding:0;width:250px;overflow-y:auto;"
});

const MenuBlock = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ei3w2qh2"
})({
  height: 45,
  display: 'flex',
  flexDirection: 'row',
  fontSize: 15,
  padding: '0 15px',
  fontWeight: 500,
  alignItems: 'center',
  cursor: 'pointer',
  backgroundColor: 'inherit',
  marginBottom: 50,
  transition: 'background-color 0.25s linear',
  ':hover': {
    backgroundColor: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].PRIMARY_MAIN_LIGHTEST,
    color: `${universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].PRIMARY_MAIN} !important`
  }
});

const Footer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ei3w2qh3"
})({
  name: "d2znx6",
  styles: "margin-bottom:25px;"
});

const Brand = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ei3w2qh4"
})(({
  active
}) => ({
  height: 25,
  width: 25,
  minWidth: 25,
  minHeight: 25,
  color: active ? universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].PRIMARY_MAIN_DARK : universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_GRAY,
  borderRadius: 4,
  backgroundColor: '#fff',
  border: `1px solid ${active ? universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].PRIMARY_MAIN : universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BORDER_MAIN_GRAY}`,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  userSelect: 'none',
  marginRight: 10
}));

const Company = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ei3w2qh5"
})(_objectSpread({
  lineHeight: '32px',
  marginRight: 5
}, universal_styles_helpers_textOverflow__WEBPACK_IMPORTED_MODULE_5__["default"]));

const NavItems = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ei3w2qh6"
})({
  name: "j7qwjs",
  styles: "display:flex;flex-direction:column;"
});

const Label = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ei3w2qh7"
})({
  name: "455iix",
  styles: "margin-left:15px;font-weight:400;font-size:15px;"
});

const NavItem = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["NavLink"], {
  target: "ei3w2qh8"
})({
  textDecoration: 'none',
  borderRadius: 4,
  height: 30,
  lineHeight: '30px',
  paddingLeft: 10,
  margin: '2px 10px',
  opacity: 0.75,
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  transition: 'all 0.25s ease-in-out',
  ':hover': {
    backgroundColor: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BACKGROUND_HOVER_LIGHT,
    opacity: 1
  }
});

const NavSubItem = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["NavLink"], {
  target: "ei3w2qh9"
})({
  textDecoration: 'none',
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_MAIN,
  borderRadius: 4,
  fontWeight: 400,
  height: 25,
  lineHeight: '25px',
  paddingLeft: 10,
  margin: '2px 10px 2px 40px',
  opacity: 0.75,
  fontSize: 14,
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  transition: 'all 0.25s ease-in-out',
  ':hover': {
    backgroundColor: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BACKGROUND_HOVER_LIGHT,
    color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_MAIN,
    opacity: 1
  }
});

const activeLinkStyles = {
  backgroundColor: `${universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BACKGROUND_HOVER} !important`,
  color: `${universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].PRIMARY_MAIN} !important`,
  opacity: '1 !important'
};

const Sidebar = props => {
  const {
    user,
    location,
    organizations,
    orgName = 'Human Lambdas',
    switchUserOrg,
    handleNewOrganization
  } = props;
  const {
    email,
    name,
    current_organization_id
  } = user;
  const isMetricRoute = location.pathname.includes('/metrics');
  const {
    menuPortal,
    togglePortal,
    originRef,
    menuProps
  } = Object(client_hooks_useMenu__WEBPACK_IMPORTED_MODULE_11__["default"])(client_hooks_useCoords__WEBPACK_IMPORTED_MODULE_13__["MenuPosition"].UPPER_LEFT, {
    isDropdown: true
  });
  const {
    modalPortal,
    togglePortal: toggleModalPortal,
    closePortal: closeModalPortal
  } = Object(client_hooks_useModal__WEBPACK_IMPORTED_MODULE_16__["default"])({});
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledRoot, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 166
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavContents, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 167
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('div', {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 168
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(MenuBlock, {
    onClick: togglePortal,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 169
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Brand, {
    ref: originRef,
    active: true,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 170
    }
  }, orgName.charAt(0)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Company, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 173
    }
  }, orgName), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_ArrowDownSVG__WEBPACK_IMPORTED_MODULE_14__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 174
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavItems, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 176
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_emotion_core__WEBPACK_IMPORTED_MODULE_2__["ClassNames"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 177
    }
  }, ({
    css
  }) => {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, Object(client_utils_isUserStaff__WEBPACK_IMPORTED_MODULE_18__["default"])(organizations, current_organization_id) && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavItem, {
      to: `/outstanding-queues`,
      activeClassName: css(activeLinkStyles),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 183
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_UsersSVG__WEBPACK_IMPORTED_MODULE_7__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 184
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 185
      }
    }, "Outstanding Queues")), !user.is_admin && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavItem, {
      to: `/audits`,
      activeClassName: css(activeLinkStyles),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 188
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_AuditsSVG__WEBPACK_IMPORTED_MODULE_10__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 189
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 190
      }
    }, "Audits"))), !Object(client_utils_isUserStaff__WEBPACK_IMPORTED_MODULE_18__["default"])(organizations, current_organization_id) && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavItem, {
      to: `/queues`,
      activeClassName: css(activeLinkStyles),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 197
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_QueueSVG__WEBPACK_IMPORTED_MODULE_6__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 198
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 199
      }
    }, "Queues")), user.is_admin && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavItem, {
      to: `/users`,
      activeClassName: css(activeLinkStyles),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 203
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_UsersSVG__WEBPACK_IMPORTED_MODULE_7__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 204
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 205
      }
    }, "Users")), user.is_admin && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavItem, {
      to: `/audits`,
      activeClassName: css(activeLinkStyles),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 210
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_AuditsSVG__WEBPACK_IMPORTED_MODULE_10__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 211
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 212
      }
    }, "Audits")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavItem, {
      to: `/metrics`,
      activeClassName: css(activeLinkStyles),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 214
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_MetricsSVG__WEBPACK_IMPORTED_MODULE_8__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 215
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 216
      }
    }, "Metrics")), isMetricRoute && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavSubItem, {
      exact: true,
      to: `/metrics`,
      activeClassName: css(activeLinkStyles),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 220
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Dot__WEBPACK_IMPORTED_MODULE_15__["default"], {
      color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].LINK,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 225
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('span', {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 226
      }
    }, "Overview")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavSubItem, {
      to: `/metrics/queues`,
      activeClassName: css(activeLinkStyles),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 228
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Dot__WEBPACK_IMPORTED_MODULE_15__["default"], {
      color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].PRIMARY_GREEN,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 232
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('span', {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 233
      }
    }, "Queues")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavSubItem, {
      to: `/metrics/workers`,
      activeClassName: css(activeLinkStyles),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 235
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Dot__WEBPACK_IMPORTED_MODULE_15__["default"], {
      color: "#ff4c4c",
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 239
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('span', {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 240
      }
    }, "Workers")))));
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Footer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 252
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavItem, {
    to: `/settings/profile`,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 253
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Icons_SettingsSVG__WEBPACK_IMPORTED_MODULE_9__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 254
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 255
    }
  }, "Settings")))), menuPortal( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_AppMenu__WEBPACK_IMPORTED_MODULE_12__["default"], {
    togglePortal: togglePortal,
    toggleModalPortal: toggleModalPortal,
    organizations: organizations,
    switchUserOrg: switchUserOrg,
    menuProps: menuProps,
    name: name,
    email: email,
    current_organization_id: current_organization_id,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 260
    }
  })), modalPortal( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_NewOrgModal__WEBPACK_IMPORTED_MODULE_17__["default"], {
    closePortal: closeModalPortal,
    handleNewOrganization: handleNewOrganization,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 272
    }
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["withRouter"])(Sidebar));

/***/ }),

/***/ "./src/client/modules/dashboard/DashboardRoot.tsx":
/*!********************************************************!*\
  !*** ./src/client/modules/dashboard/DashboardRoot.tsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _containers_Dashboard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./containers/Dashboard */ "./src/client/modules/dashboard/containers/Dashboard.tsx");
/* harmony import */ var client_hooks_useNetworker__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! client/hooks/useNetworker */ "./src/client/hooks/useNetworker.ts");
/* harmony import */ var client_redux_currentUserReducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! client/redux/currentUserReducer */ "./src/client/redux/currentUserReducer.ts");
/* harmony import */ var client_utils_isUserStaff__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! client/utils/isUserStaff */ "./src/client/utils/isUserStaff.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/modules/dashboard/DashboardRoot.tsx";







const DashboardRoot = props => {
  const {
    history
  } = props;
  const networker = Object(client_hooks_useNetworker__WEBPACK_IMPORTED_MODULE_3__["default"])();
  const {
    accessObj: {
      user_id: userId
    }
  } = networker || {
    accessObj: {}
  };
  const [user, setUser] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({});
  const {
    current_organization_id: currentOrgId
  } = user || {};
  const [organization, setOrg] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({});
  const [organizations, setOrgs] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);

  async function fetchUserAndOrgInfo() {
    const resp = await networker.httpHandler(`/users/${userId}`, {
      method: 'GET'
    });
    let data, errors;

    if (resp) {
      data = resp.data;
      errors = resp.errors;
    }

    const {
      current_organization_id
    } = data || {};
    if (currentOrgId === current_organization_id) return;

    if (!errors) {
      if (current_organization_id) {
        const {
          data: org
        } = await networker.httpHandler(`/orgs/${data.current_organization_id}`, {
          method: 'GET'
        });
        const {
          data: orgs
        } = await networker.httpHandler(`/orgs`, {
          method: 'GET'
        });
        setUser(data);
        setOrg(org);
        setOrgs(orgs);
        const isStaff = Object(client_utils_isUserStaff__WEBPACK_IMPORTED_MODULE_5__["default"])(orgs, data.current_organization_id);
        props.addUser(_objectSpread(_objectSpread({}, data), {}, {
          isStaff
        }));
      } else {
        console.error('No organization ID!');
      }
    } else {
      errors.forEach(e => console.error(e.message));
    }
  }

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    fetchUserAndOrgInfo();
  }, [userId, user]);

  const switchUserOrg = async id => {
    const {
      errors
    } = await networker.httpHandler(`/users/${user.id}`, {
      data: {
        current_organization_id: id
      },
      method: 'PATCH'
    });

    if (!errors) {
      history.push('/');
    } else {
      console.error('Error fetching organization information!', JSON.stringify(errors));
    }
  };

  const handleNewOrganization = async orgName => {
    if (!orgName) return;
    const {
      data: {
        id: newOrgId
      }
    } = await networker.httpHandler(`/orgs/create`, {
      data: orgName,
      method: 'POST'
    });
    await networker.httpHandler(`/users/${user.id}`, {
      data: {
        current_organization_id: newOrgId
      },
      method: 'PATCH'
    });
    history.push('/');
  };

  if (!user.id && !organization.name) return null;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_containers_Dashboard__WEBPACK_IMPORTED_MODULE_2__["default"], _objectSpread(_objectSpread({}, props), {}, {
    user: user,
    orgName: organization.name,
    organizations: organizations,
    switchUserOrg: switchUserOrg,
    handleNewOrganization: handleNewOrganization,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 91
    }
  }));
};

const mapDispatchToProps = dispatch => ({
  addUser: arg => dispatch(Object(client_redux_currentUserReducer__WEBPACK_IMPORTED_MODULE_4__["addUser"])(arg))
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_1__["connect"])(null, mapDispatchToProps)(DashboardRoot));

/***/ }),

/***/ "./src/client/modules/dashboard/containers/Dashboard.tsx":
/*!***************************************************************!*\
  !*** ./src/client/modules/dashboard/containers/Dashboard.tsx ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var client_components_Sidebar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! client/components/Sidebar */ "./src/client/components/Sidebar.tsx");
/* harmony import */ var universal_utils_handleChunkError__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/utils/handleChunkError */ "./src/universal/utils/handleChunkError.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/modules/dashboard/containers/Dashboard.tsx";







const DashLayout = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ehhunrg0"
})({
  name: "7axs56",
  styles: "display:flex;overflow:auto;height:100%;"
});

const DashMain = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])('div', {
  target: "ehhunrg1"
})({
  display: 'flex',
  flex: 1,
  flexDirection: 'column',
  height: '100%',
  overflow: 'hidden',
  background: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BACKGROUND_MAIN
});

const QueuesRoot = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["lazy"])(() => __webpack_require__.e(/*! import() | QueuesRoot */ "QueuesRoot").then(__webpack_require__.bind(null, /*! client/modules/queues/QueuesRoot */ "./src/client/modules/queues/QueuesRoot.tsx")).catch(error => Object(universal_utils_handleChunkError__WEBPACK_IMPORTED_MODULE_6__["default"])(error)));
const UsersRoot = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["lazy"])(() => Promise.all(/*! import() | UsersRoot */[__webpack_require__.e("AuditsRoot~UsersRoot"), __webpack_require__.e("UsersRoot")]).then(__webpack_require__.bind(null, /*! client/modules/users/containers/UsersRoot */ "./src/client/modules/users/containers/UsersRoot.tsx")).catch(error => Object(universal_utils_handleChunkError__WEBPACK_IMPORTED_MODULE_6__["default"])(error)));
const AuditsRoot = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["lazy"])(() => Promise.all(/*! import() | AuditsRoot */[__webpack_require__.e("vendors~AuditsRoot~Queue~TaskRoot"), __webpack_require__.e("vendors~AuditsRoot"), __webpack_require__.e("AuditsRoot~TaskRoot"), __webpack_require__.e("AuditsRoot~UsersRoot"), __webpack_require__.e("AuditsRoot")]).then(__webpack_require__.bind(null, /*! universal/modules/audits/AuditsRoot */ "./src/universal/modules/audits/AuditsRoot.tsx")).catch(error => Object(universal_utils_handleChunkError__WEBPACK_IMPORTED_MODULE_6__["default"])(error)));
const OutstandingRoot = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["lazy"])(() => Promise.all(/*! import() | AuditsRoot */[__webpack_require__.e("vendors~AuditsRoot~Queue~TaskRoot"), __webpack_require__.e("vendors~AuditsRoot"), __webpack_require__.e("AuditsRoot~TaskRoot"), __webpack_require__.e("AuditsRoot~UsersRoot"), __webpack_require__.e("AuditsRoot")]).then(__webpack_require__.bind(null, /*! universal/modules/outstanding/OutstandingRoot */ "./src/universal/modules/outstanding/OutstandingRoot.tsx")).catch(error => Object(universal_utils_handleChunkError__WEBPACK_IMPORTED_MODULE_6__["default"])(error)));
const MetricsRoot = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["lazy"])(() => __webpack_require__.e(/*! import() | MetricsRoot */ "MetricsRoot").then(__webpack_require__.bind(null, /*! client/modules/metrics/MetricsRoot */ "./src/client/modules/metrics/MetricsRoot.tsx")).catch(error => Object(universal_utils_handleChunkError__WEBPACK_IMPORTED_MODULE_6__["default"])(error)));
const NotFound = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["lazy"])(() => __webpack_require__.e(/*! import() | NotFound */ "NotFound").then(__webpack_require__.bind(null, /*! client/components/NotFound */ "./src/client/components/NotFound.tsx")).catch(error => Object(universal_utils_handleChunkError__WEBPACK_IMPORTED_MODULE_6__["default"])(error)));

const Dashboard = props => {
  const {
    user,
    orgName,
    organizations,
    handleNewOrganization,
    switchUserOrg,
    history: {
      location
    },
    isStaff
  } = props || {};
  const hideSidebar = location.pathname.includes('task');
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(DashLayout, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 79
    }
  }, !hideSidebar && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Sidebar__WEBPACK_IMPORTED_MODULE_5__["default"], {
    switchUserOrg: switchUserOrg,
    user: user,
    orgName: orgName,
    organizations: organizations,
    handleNewOrganization: handleNewOrganization,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 81
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(DashMain, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 89
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Switch"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 90
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Route"], {
    path: "/outstanding-queues",
    render: p => {
      if (isStaff) return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(OutstandingRoot, _objectSpread(_objectSpread({}, p), {}, {
        user: user,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 94
        }
      }));
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Redirect"], {
        to: "/queues",
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 95
        }
      });
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 91
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Route"], {
    path: "/queues",
    render: p => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(QueuesRoot, _objectSpread(_objectSpread({
      organizations: organizations
    }, p), {}, {
      user: user,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 100
      }
    })),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 98
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Route"], {
    path: "/users",
    render: p => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(UsersRoot, _objectSpread(_objectSpread({}, p), {}, {
      user: user,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 102
      }
    })),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 102
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Route"], {
    path: "/audits",
    render: p => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(AuditsRoot, _objectSpread(_objectSpread({}, p), {}, {
      user: user,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 103
      }
    })),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 103
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Route"], {
    path: "/metrics",
    render: p => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(MetricsRoot, _objectSpread(_objectSpread({}, p), {}, {
      user: user,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 104
      }
    })),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 104
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Route"], {
    component: NotFound,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 105
    }
  }))));
};

const mapStateToProps = state => ({
  isStaff: state.currentUser.isStaff
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps, null)(Dashboard));

/***/ }),

/***/ "./src/client/utils/isUserStaff.ts":
/*!*****************************************!*\
  !*** ./src/client/utils/isUserStaff.ts ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");


const isUserStaff = (organizations, current_organization_id) => {
  for (const org of organizations) {
    if (org.id === universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["STAFF_ORG_ID"] && current_organization_id === universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["STAFF_ORG_ID"]) return true;
  }

  return false;
};

/* harmony default export */ __webpack_exports__["default"] = (isUserStaff);

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY2xpZW50L2NvbXBvbmVudHMvQXBwTWVudS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NsaWVudC9jb21wb25lbnRzL0RvdC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NsaWVudC9jb21wb25lbnRzL0ljb25zL0Fycm93RG93blNWRy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NsaWVudC9jb21wb25lbnRzL0ljb25zL0F1ZGl0c1NWRy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NsaWVudC9jb21wb25lbnRzL0ljb25zL0RvY3VtZW50YXRpb25TVkcudHN4Iiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvY29tcG9uZW50cy9JY29ucy9NZXRyaWNzU1ZHLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY2xpZW50L2NvbXBvbmVudHMvSWNvbnMvUXVldWVTVkcudHN4Iiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvY29tcG9uZW50cy9JY29ucy9TZXR0aW5nc1NWRy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NsaWVudC9jb21wb25lbnRzL0ljb25zL1VzZXJzU1ZHLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY2xpZW50L2NvbXBvbmVudHMvTmV3T3JnTW9kYWwudHN4Iiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvY29tcG9uZW50cy9TaWRlYmFyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY2xpZW50L21vZHVsZXMvZGFzaGJvYXJkL0Rhc2hib2FyZFJvb3QudHN4Iiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvbW9kdWxlcy9kYXNoYm9hcmQvY29udGFpbmVycy9EYXNoYm9hcmQudHN4Iiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvdXRpbHMvaXNVc2VyU3RhZmYudHMiXSwibmFtZXMiOlsiX2pzeEZpbGVOYW1lIiwiX29wdGlvbmFsQ2hhaW4iLCJvcHMiLCJsYXN0QWNjZXNzTEhTIiwidW5kZWZpbmVkIiwidmFsdWUiLCJpIiwibGVuZ3RoIiwib3AiLCJmbiIsImFyZ3MiLCJjYWxsIiwiQ29udGFpbmVyIiwiSGVhZEJsb2NrIiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJwYWRkaW5nIiwidXNlclNlbGVjdCIsImN1cnNvciIsImJvcmRlckJvdHRvbSIsIlBBTEVUVEUiLCJCT1JERVJfR1JBWSIsIkFjdGlvbkJsb2NrIiwibWFyZ2luQm90dG9tIiwibWF4SGVpZ2h0Iiwib3ZlcmZsb3ciLCJPcmdDb250YWluZXIiLCJQbGFpbkJ1dHRvbiIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsIm1hcmdpbiIsIndpZHRoIiwiY29sb3IiLCJURVhUX0dSQVkiLCJPcmdOYW1lIiwiYWN0aXZlIiwidGV4dE92ZXJmbG93IiwiVEVYVF9NQUlOIiwiU3R5bGVkTmFtZSIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsIlN0eWxlZEVtYWlsIiwiTGFiZWwiLCJUZXh0IiwibWFyZ2luTGVmdCIsIlN0eWxlZEljb24iLCJJY29uIiwiQXBwTWVudSIsInByb3BzIiwidG9nZ2xlUG9ydGFsIiwic3dpdGNoVXNlck9yZyIsIm1lbnVQcm9wcyIsIm5hbWUiLCJlbWFpbCIsIm9yZ2FuaXphdGlvbnMiLCJjdXJyZW50X29yZ2FuaXphdGlvbl9pZCIsInRvZ2dsZU1vZGFsUG9ydGFsIiwiaGlzdG9yeSIsInVzZVJvdXRlciIsIlJlYWN0IiwiY3JlYXRlRWxlbWVudCIsIl9fc2VsZiIsIl9fc291cmNlIiwiZmlsZU5hbWUiLCJsaW5lTnVtYmVyIiwibWFwIiwiaWQiLCJrZXkiLCJCcmFuZCIsIl8iLCJjaGFyQXQiLCJfMiIsIm9uQ2xpY2siLCJNZW51IiwiYXJpYUxhYmVsIiwiTWVudUl0ZW0iLCJsYWJlbCIsIkRvY3VtZW50YXRpb25TVkciLCJ3aW5kb3ciLCJvcGVuIiwicHVzaCIsIlN0eWxlZERvdCIsImhlaWdodCIsImJvcmRlclJhZGl1cyIsImJhY2tncm91bmRDb2xvciIsIm1hcmdpblJpZ2h0IiwiRG90IiwiQXJyb3dEb3duU1ZHIiwibWVtbyIsInZpZXdCb3giLCJ4bWxucyIsImZpbGwiLCJkIiwiVXNlcnNTVkciLCJNZXRyaWNTVkciLCJRdWV1ZVNWRyIsIlNldHRpbmdzU1ZHIiwiTW9kYWxSb290IiwiYm9yZGVyIiwiQk9SREVSX01BSU5fR1JBWSIsImJveFNoYWRvdyIsIkJveFNoYWRvdyIsIk1PREFMIiwiTWFpblRpdGxlIiwiRm9ybUNvbnRlbnQiLCJGb3JtIiwiQnV0dG9uU2VjdGlvbiIsIk5ld09yZ01vZGFsIiwiY2xvc2VQb3J0YWwiLCJoYW5kbGVOZXdPcmdhbml6YXRpb24iLCJvblN1Ym1pdEhhbmRsZXIiLCJ1c2VDYWxsYmFjayIsInZhbHVlcyIsImFjdGlvbnMiLCJzZXRTdWJtaXR0aW5nIiwiRm9ybWlrIiwidmFsaWRhdGVPbkNoYW5nZSIsImluaXRpYWxWYWx1ZXMiLCJ2YWxpZGF0aW9uU2NoZW1hIiwib3JnYW5pemF0aW9uU2NoZW1hIiwib25TdWJtaXQiLCJpc1N1Ym1pdHRpbmciLCJoYW5kbGVDaGFuZ2UiLCJJbnB1dEZpZWxkIiwicGxhY2Vob2xkZXIiLCJvbkNoYW5nZSIsIlNlY29uZGFyeUJ1dHRvbiIsInR5cGUiLCJQcmltYXJ5QnV0dG9uIiwiZGlzYWJsZWQiLCJTdHlsZWRSb290IiwicG9zaXRpb24iLCJCQUNLR1JPVU5EX01BSU4iLCJib3JkZXJSaWdodCIsIk5hdkNvbnRlbnRzIiwiTWVudUJsb2NrIiwidHJhbnNpdGlvbiIsIlBSSU1BUllfTUFJTl9MSUdIVEVTVCIsIlBSSU1BUllfTUFJTiIsIkZvb3RlciIsIm1pbldpZHRoIiwibWluSGVpZ2h0IiwiUFJJTUFSWV9NQUlOX0RBUksiLCJDb21wYW55IiwibGluZUhlaWdodCIsIk5hdkl0ZW1zIiwiTmF2SXRlbSIsIk5hdkxpbmsiLCJ0ZXh0RGVjb3JhdGlvbiIsInBhZGRpbmdMZWZ0Iiwib3BhY2l0eSIsIkJBQ0tHUk9VTkRfSE9WRVJfTElHSFQiLCJOYXZTdWJJdGVtIiwiYWN0aXZlTGlua1N0eWxlcyIsIkJBQ0tHUk9VTkRfSE9WRVIiLCJTaWRlYmFyIiwidXNlciIsImxvY2F0aW9uIiwib3JnTmFtZSIsImlzTWV0cmljUm91dGUiLCJwYXRobmFtZSIsImluY2x1ZGVzIiwibWVudVBvcnRhbCIsIm9yaWdpblJlZiIsInVzZU1lbnUiLCJNZW51UG9zaXRpb24iLCJVUFBFUl9MRUZUIiwiaXNEcm9wZG93biIsIm1vZGFsUG9ydGFsIiwiY2xvc2VNb2RhbFBvcnRhbCIsInVzZU1vZGFsIiwicmVmIiwiQ2xhc3NOYW1lcyIsImNzcyIsIkZyYWdtZW50IiwiaXNVc2VyU3RhZmYiLCJ0byIsImFjdGl2ZUNsYXNzTmFtZSIsIlVzZXJzSWNvbiIsImlzX2FkbWluIiwiQXVkaXRzU1ZHIiwiUXVldWVJY29uIiwiTWV0cmljc0ljb24iLCJleGFjdCIsIkxJTksiLCJQUklNQVJZX0dSRUVOIiwid2l0aFJvdXRlciIsIkRhc2hib2FyZFJvb3QiLCJuZXR3b3JrZXIiLCJ1c2VOZXR3b3JrZXIiLCJhY2Nlc3NPYmoiLCJ1c2VyX2lkIiwidXNlcklkIiwic2V0VXNlciIsInVzZVN0YXRlIiwiY3VycmVudE9yZ0lkIiwib3JnYW5pemF0aW9uIiwic2V0T3JnIiwic2V0T3JncyIsImZldGNoVXNlckFuZE9yZ0luZm8iLCJyZXNwIiwiaHR0cEhhbmRsZXIiLCJtZXRob2QiLCJkYXRhIiwiZXJyb3JzIiwib3JnIiwib3JncyIsImlzU3RhZmYiLCJhZGRVc2VyIiwiY29uc29sZSIsImVycm9yIiwiZm9yRWFjaCIsImUiLCJtZXNzYWdlIiwidXNlRWZmZWN0IiwiSlNPTiIsInN0cmluZ2lmeSIsIm5ld09yZ0lkIiwiRGFzaGJvYXJkIiwibWFwRGlzcGF0Y2hUb1Byb3BzIiwiZGlzcGF0Y2giLCJhcmciLCJjb25uZWN0IiwiRGFzaExheW91dCIsIkRhc2hNYWluIiwiZmxleCIsImJhY2tncm91bmQiLCJRdWV1ZXNSb290IiwibGF6eSIsImNhdGNoIiwiaGFuZGxlQ2h1bmtFcnJvciIsIlVzZXJzUm9vdCIsIkF1ZGl0c1Jvb3QiLCJPdXRzdGFuZGluZ1Jvb3QiLCJNZXRyaWNzUm9vdCIsIk5vdEZvdW5kIiwiaGlkZVNpZGViYXIiLCJTd2l0Y2giLCJSb3V0ZSIsInBhdGgiLCJyZW5kZXIiLCJwIiwiUmVkaXJlY3QiLCJjb21wb25lbnQiLCJtYXBTdGF0ZVRvUHJvcHMiLCJzdGF0ZSIsImN1cnJlbnRVc2VyIiwiU1RBRkZfT1JHX0lEIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsTUFBTUEsWUFBWSxHQUFHLHFFQUFyQjs7QUFBNEYsU0FBU0MsY0FBVCxDQUF3QkMsR0FBeEIsRUFBNkI7QUFBRSxNQUFJQyxhQUFhLEdBQUdDLFNBQXBCO0FBQStCLE1BQUlDLEtBQUssR0FBR0gsR0FBRyxDQUFDLENBQUQsQ0FBZjtBQUFvQixNQUFJSSxDQUFDLEdBQUcsQ0FBUjs7QUFBVyxTQUFPQSxDQUFDLEdBQUdKLEdBQUcsQ0FBQ0ssTUFBZixFQUF1QjtBQUFFLFVBQU1DLEVBQUUsR0FBR04sR0FBRyxDQUFDSSxDQUFELENBQWQ7QUFBbUIsVUFBTUcsRUFBRSxHQUFHUCxHQUFHLENBQUNJLENBQUMsR0FBRyxDQUFMLENBQWQ7QUFBdUJBLEtBQUMsSUFBSSxDQUFMOztBQUFRLFFBQUksQ0FBQ0UsRUFBRSxLQUFLLGdCQUFQLElBQTJCQSxFQUFFLEtBQUssY0FBbkMsS0FBc0RILEtBQUssSUFBSSxJQUFuRSxFQUF5RTtBQUFFLGFBQU9ELFNBQVA7QUFBbUI7O0FBQUMsUUFBSUksRUFBRSxLQUFLLFFBQVAsSUFBbUJBLEVBQUUsS0FBSyxnQkFBOUIsRUFBZ0Q7QUFBRUwsbUJBQWEsR0FBR0UsS0FBaEI7QUFBdUJBLFdBQUssR0FBR0ksRUFBRSxDQUFDSixLQUFELENBQVY7QUFBb0IsS0FBN0YsTUFBbUcsSUFBSUcsRUFBRSxLQUFLLE1BQVAsSUFBaUJBLEVBQUUsS0FBSyxjQUE1QixFQUE0QztBQUFFSCxXQUFLLEdBQUdJLEVBQUUsQ0FBQyxDQUFDLEdBQUdDLElBQUosS0FBYUwsS0FBSyxDQUFDTSxJQUFOLENBQVdSLGFBQVgsRUFBMEIsR0FBR08sSUFBN0IsQ0FBZCxDQUFWO0FBQTZEUCxtQkFBYSxHQUFHQyxTQUFoQjtBQUE0QjtBQUFFOztBQUFDLFNBQU9DLEtBQVA7QUFBZTs7QUFBQTtBQUUvbEI7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVFBLE1BQU1PLFNBQVMsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBbEI7O0FBSUEsTUFBTUMsU0FBUyxHQUFHO0FBQUE7QUFBQSxHQUFXO0FBQzNCQyxTQUFPLEVBQUUsTUFEa0I7QUFFM0JDLGVBQWEsRUFBRSxRQUZZO0FBRzNCQyxTQUFPLEVBQUUsV0FIa0I7QUFJM0JDLFlBQVUsRUFBRSxNQUplO0FBSzNCQyxRQUFNLEVBQUUsU0FMbUI7QUFNM0JDLGNBQVksRUFBRyxhQUFZQyxnRUFBTyxDQUFDQyxXQUFZO0FBTnBCLENBQVgsQ0FBbEI7O0FBU0EsTUFBTUMsV0FBVyxHQUFHO0FBQUE7QUFBQSxHQUFXO0FBQzdCSCxjQUFZLEVBQUcsYUFBWUMsZ0VBQU8sQ0FBQ0MsV0FBWSxFQURsQjtBQUU3QkUsY0FBWSxFQUFFLENBRmU7QUFHN0JQLFNBQU8sRUFBRSxRQUhvQjtBQUk3QlEsV0FBUyxFQUFFLE1BSmtCO0FBSzdCQyxVQUFRLEVBQUU7QUFMbUIsQ0FBWCxDQUFwQjs7QUFRQSxNQUFNQyxZQUFZLEdBQUcsa0ZBQU9DLCtEQUFQO0FBQUE7QUFBQSxHQUFvQjtBQUN2Q0MsWUFBVSxFQUFFLFFBRDJCO0FBRXZDQyxnQkFBYyxFQUFFLE9BRnVCO0FBR3ZDTixjQUFZLEVBQUUsRUFIeUI7QUFJdkNPLFFBQU0sRUFBRSxDQUorQjtBQUt2Q0MsT0FBSyxFQUFFLE1BTGdDO0FBTXZDYixRQUFNLEVBQUUsU0FOK0I7QUFPdkNjLE9BQUssRUFBRVosZ0VBQU8sQ0FBQ2E7QUFQd0IsQ0FBcEIsQ0FBckI7O0FBVUEsTUFBTUMsT0FBTyxHQUFHO0FBQUE7QUFBQSxHQUFXLENBQUM7QUFBQ0M7QUFBRCxDQUFEO0FBQ3pCTixnQkFBYyxFQUFFLFlBRFM7QUFFekJELFlBQVUsRUFBRSxRQUZhO0FBR3pCSCxVQUFRLEVBQUUsUUFIZTtBQUl6QlQsU0FBTyxFQUFFO0FBSmdCLEdBS3RCb0IsNkVBTHNCO0FBTXpCSixPQUFLLEVBQUVHLE1BQU0sR0FBR2YsZ0VBQU8sQ0FBQ2lCLFNBQVgsR0FBdUIsU0FOWDtBQU96QixZQUFVO0FBQ1JMLFNBQUssRUFBRVosZ0VBQU8sQ0FBQ2lCO0FBRFA7QUFQZSxFQUFYLENBQWhCOztBQVlBLE1BQU1DLFVBQVUsR0FBRztBQUFBO0FBQUE7QUFDakJOLE9BQUssRUFBRVosZ0VBQU8sQ0FBQ2lCLFNBREU7QUFFakJFLFVBQVEsRUFBRSxFQUZPO0FBR2pCQyxZQUFVLEVBQUUsR0FISztBQUlqQmpCLGNBQVksRUFBRTtBQUpHLEdBS2RhLDZFQUxjLEVBQW5COztBQVFBLE1BQU1LLFdBQVcsR0FBRztBQUFBO0FBQUE7QUFDbEJGLFVBQVEsRUFBRSxFQURRO0FBRWxCUCxPQUFLLEVBQUVaLGdFQUFPLENBQUNhLFNBRkc7QUFHbEJPLFlBQVUsRUFBRTtBQUhNLEdBSWZKLDZFQUplLEVBQXBCOztBQU9BLE1BQU1NLEtBQUssR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBZDs7QUFRQSxNQUFNQyxJQUFJLEdBQUc7QUFBQTtBQUFBLEdBQVc7QUFDdEJYLE9BQUssRUFBRVosZ0VBQU8sQ0FBQ2lCLFNBRE87QUFFdEJPLFlBQVUsRUFBRTtBQUZVLENBQVgsQ0FBYjs7QUFLQSxNQUFNQyxVQUFVLEdBQUcsa0ZBQU9DLGtFQUFQO0FBQUE7QUFBQSxHQUFhO0FBQzlCaEIsUUFBTSxFQUFFLENBRHNCO0FBRTlCZCxTQUFPLEVBQUUsQ0FGcUI7QUFHOUJnQixPQUFLLEVBQUVaLGdFQUFPLENBQUNpQixTQUhlO0FBSTlCRSxVQUFRLEVBQUU7QUFKb0IsQ0FBYixDQUFuQjs7QUFPQSxNQUFNUSxPQUFPLEdBQUlDLEtBQUQsSUFBVztBQUN6QixRQUFNO0FBQ0pDLGdCQURJO0FBRUpDLGlCQUZJO0FBR0pDLGFBSEk7QUFJSkMsUUFKSTtBQUtKQyxTQUxJO0FBTUpDLGlCQU5JO0FBT0pDLDJCQVBJO0FBUUpDO0FBUkksTUFTRlIsS0FUSjtBQVVBLFFBQU07QUFBQ1M7QUFBRCxNQUFZQyxzRUFBUyxFQUEzQjtBQUNBLHNCQUNFQyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CaEQsU0FBcEIsRUFBK0I7QUFBQ2lELFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEvQixlQUNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CL0MsU0FBcEIsRUFBK0I7QUFBQ2dELFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEvQixlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CdEIsVUFBcEIsRUFBZ0M7QUFBQ3VCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFoQyxFQUFxR1osSUFBckcsQ0FERixlQUVFTyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CbkIsV0FBcEIsRUFBaUM7QUFBQ29CLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFqQyxFQUFzR1gsS0FBdEcsQ0FGRixDQURKLGVBS0lNLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J0QyxXQUFwQixFQUFpQztBQUFDdUMsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQWpDLEVBQ0VWLGFBQWEsQ0FBQ1csR0FBZCxDQUFrQixDQUFDO0FBQUNiLFFBQUQ7QUFBT2M7QUFBUCxHQUFELGtCQUNsQlAsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmxDLFlBQXBCLEVBQWtDO0FBQUV5QyxPQUFHLEVBQUVELEVBQVA7QUFBV0wsVUFBTSxFQUFFLFNBQW5CO0FBQXlCQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBbkMsR0FBbEMsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQlEsOENBQXBCLEVBQTJCO0FBQUVqQyxVQUFNLEVBQUUrQixFQUFFLEtBQUtYLHVCQUFqQjtBQUEwQ00sVUFBTSxFQUFFLFNBQWxEO0FBQXdEQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBbEUsR0FBM0IsRUFBeUkvRCxjQUFjLENBQUMsQ0FBQ21ELElBQUQsRUFBTyxnQkFBUCxFQUF5QmlCLENBQUMsSUFBSUEsQ0FBQyxDQUFDQyxNQUFoQyxFQUF3QyxNQUF4QyxFQUFnREMsRUFBRSxJQUFJQSxFQUFFLENBQUMsQ0FBRCxDQUF4RCxDQUFELENBQXZKLENBREosZUFFSVosNENBQUssQ0FBQ0MsYUFBTixDQUFvQjFCLE9BQXBCLEVBQTZCO0FBQzdCc0MsV0FBTyxFQUFFLE1BQU07QUFDYnZCLGtCQUFZO0FBQ1pDLG1CQUFhLENBQUNnQixFQUFELENBQWI7QUFDRCxLQUo0QjtBQUs3Qi9CLFVBQU0sRUFBRStCLEVBQUUsS0FBS1gsdUJBTGM7QUFLV00sVUFBTSxFQUFFLFNBTG5CO0FBS3lCQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFMbkMsR0FBN0IsRUFPRVosSUFQRixDQUZKLENBREEsQ0FERixDQUxKLGVBcUJJTyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CdEMsV0FBcEIsRUFBaUM7QUFBQ3VDLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFqQyxlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CYSw2Q0FBcEI7QUFBNEJDLGFBQVMsRUFBRTtBQUF2QyxLQUEyRHZCLFNBQTNEO0FBQXNFVSxVQUFNLEVBQUUsU0FBOUU7QUFBb0ZDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUE5RixtQkFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmUsaURBQXBCLEVBQThCO0FBQzlCQyxTQUFLLGVBQ0hqQiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CbEIsS0FBcEIsRUFBMkI7QUFBQ21CLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBM0IsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmYsVUFBcEIsRUFBZ0M7QUFBQ2dCLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBaEMsRUFBcUcsS0FBckcsQ0FESixlQUVJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CakIsSUFBcEIsRUFBMEI7QUFBQ2tCLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBMUIsRUFBK0Ysa0JBQS9GLENBRkosQ0FGNEI7QUFPOUJRLFdBQU8sRUFBRSxNQUFNO0FBQ2JoQix1QkFBaUI7QUFDbEIsS0FUNkI7QUFTM0JLLFVBQU0sRUFBRSxTQVRtQjtBQVNiQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFURyxHQUE5QixDQURGLGVBWUVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JlLGlEQUFwQixFQUE4QjtBQUM5QkMsU0FBSyxlQUNIakIsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmxCLEtBQXBCLEVBQTJCO0FBQUNtQixZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTNCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JpQixnRkFBcEIsRUFBc0M7QUFBQ2hCLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBdEMsQ0FESixlQUVJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CakIsSUFBcEIsRUFBMEI7QUFBQ2tCLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBMUIsRUFBK0YsZUFBL0YsQ0FGSixDQUY0QjtBQU85QlEsV0FBTyxFQUFFLE1BQU1NLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQThDLFFBQTlDLENBUGU7QUFPMENsQixVQUFNLEVBQUUsU0FQbEQ7QUFPd0RDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQVBsRSxHQUE5QixDQVpGLENBREYsQ0FyQkosZUE2Q0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JhLDZDQUFwQjtBQUE0QkMsYUFBUyxFQUFFO0FBQXZDLEtBQXVEdkIsU0FBdkQ7QUFBa0VVLFVBQU0sRUFBRSxTQUExRTtBQUFnRkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQTFGLG1CQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CZSxpREFBcEIsRUFBOEI7QUFDOUJDLFNBQUssZUFDSGpCLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JsQixLQUFwQixFQUEyQjtBQUFDbUIsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUEzQixlQUNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CZixVQUFwQixFQUFnQztBQUFDZ0IsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUFoQyxFQUFxRyxhQUFyRyxDQURKLGVBRUlMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JqQixJQUFwQixFQUEwQjtBQUFDa0IsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUExQixFQUErRixVQUEvRixDQUZKLENBRjRCO0FBTzlCUSxXQUFPLEVBQUUsTUFBTWYsT0FBTyxDQUFDdUIsSUFBUixDQUFhLFVBQWIsQ0FQZTtBQU9XbkIsVUFBTSxFQUFFLFNBUG5CO0FBT3lCQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFQbkMsR0FBOUIsQ0FERixDQTdDSixDQURGO0FBMkRELENBdkVEOztBQXlFZWpCLHNFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUtBLE1BQU0vQyxZQUFZLEdBQUcsaUVBQXJCO0FBQXVGOztBQU92RixNQUFNaUYsU0FBUyxHQUFHO0FBQUE7QUFBQSxHQUFXLENBQUM7QUFBQ2pEO0FBQUQsQ0FBRCxNQUFjO0FBQ3pDa0QsUUFBTSxFQUFFLEVBRGlDO0FBRXpDbkQsT0FBSyxFQUFFLEVBRmtDO0FBR3pDb0QsY0FBWSxFQUFFLEVBSDJCO0FBSXpDQyxpQkFBZSxFQUFFcEQsS0FKd0I7QUFLekNxRCxhQUFXLEVBQUU7QUFMNEIsQ0FBZCxDQUFYLENBQWxCOztBQVFBLE1BQU1DLEdBQUcsZ0JBQUczQiwwQ0FBQSxDQUFZWCxLQUFELElBQVc7QUFDaEMsUUFBTTtBQUFDaEI7QUFBRCxNQUFVZ0IsS0FBaEI7QUFDQSxzQkFBT1csbURBQUEsQ0FBb0JzQixTQUFwQixFQUErQjtBQUFFakQsU0FBSyxFQUFFQSxLQUFUO0FBQWdCNkIsVUFBTSxFQUFFLFNBQXhCO0FBQThCQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBeEMsR0FBL0IsQ0FBUDtBQUNELENBSFcsQ0FBWjtBQUtlc0Isa0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDcEJBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBTXRGLFlBQVksR0FBRyxnRkFBckI7QUFBc0c7QUFDdEc7QUFFQSxNQUFNdUYsWUFBWSxnQkFBR0Msa0RBQUksQ0FBQyxNQUFNO0FBQzlCLHNCQUNFN0IsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixLQUFwQixFQUEyQjtBQUN6QnNCLFVBQU0sRUFBRSxJQURpQjtBQUV6Qk8sV0FBTyxFQUFFLHFCQUZnQjtBQUd6QjFELFNBQUssRUFBRSxJQUhrQjtBQUl6QjJELFNBQUssRUFBRSw0QkFKa0I7QUFLekJDLFFBQUksRUFBRXZFLHNEQUFPLENBQUNpQixTQUxXO0FBS0F3QixVQUFNLEVBQUUsU0FMUjtBQUtjQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFMeEIsR0FBM0IsZUFPSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixNQUFwQixFQUE0QjtBQUFFZ0MsS0FBQyxFQUFFLHNSQUFMO0FBQTZUL0IsVUFBTSxFQUFFLFNBQXJVO0FBQTJVQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBclYsR0FBNUIsQ0FQSixDQURGO0FBV0QsQ0Fad0IsQ0FBekI7QUFjZXVCLDJFQUFmLEU7Ozs7Ozs7Ozs7OztBQ2pCQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQU12RixZQUFZLEdBQUcsNkVBQXJCO0FBQW1HO0FBQ25HO0FBRUEsTUFBTTZGLFFBQVEsZ0JBQUdMLGtEQUFJLENBQUMsTUFBTTtBQUMxQixzQkFDRTdCLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsS0FBcEIsRUFBMkI7QUFDekJzQixVQUFNLEVBQUUsSUFEaUI7QUFFekJPLFdBQU8sRUFBRSxxQkFGZ0I7QUFHekIxRCxTQUFLLEVBQUUsSUFIa0I7QUFJekIyRCxTQUFLLEVBQUUsNEJBSmtCO0FBS3pCQyxRQUFJLEVBQUV2RSxzREFBTyxDQUFDaUIsU0FMVztBQUtBd0IsVUFBTSxFQUFFLFNBTFI7QUFLY0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBTHhCLEdBQTNCLGVBT0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsTUFBcEIsRUFBNEI7QUFBRWdDLEtBQUMsRUFBRSx1ZkFBTDtBQUFtaUIvQixVQUFNLEVBQUUsU0FBM2lCO0FBQWlqQkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQTNqQixHQUE1QixDQVBKLENBREY7QUFXRCxDQVpvQixDQUFyQjtBQWNlNkIsdUVBQWYsRTs7Ozs7Ozs7Ozs7O0FDakJBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBTTdGLFlBQVksR0FBRyxvRkFBckI7QUFBMEc7QUFDMUc7QUFFQSxNQUFNNkUsZ0JBQWdCLGdCQUFHVyxrREFBSSxDQUFDLE1BQU07QUFDbEMsc0JBQ0U3Qiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLEtBQXBCLEVBQTJCO0FBQ3pCc0IsVUFBTSxFQUFFLElBRGlCO0FBRXpCTyxXQUFPLEVBQUUscUJBRmdCO0FBR3pCMUQsU0FBSyxFQUFFLElBSGtCO0FBSXpCMkQsU0FBSyxFQUFFLDRCQUprQjtBQUt6QkMsUUFBSSxFQUFFdkUsc0RBQU8sQ0FBQ2lCLFNBTFc7QUFLQXdCLFVBQU0sRUFBRSxTQUxSO0FBS2NDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUx4QixHQUEzQixlQU9JTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLE1BQXBCLEVBQTRCO0FBQUVnQyxLQUFDLEVBQUUsdXRDQUFMO0FBQTJ5Qy9CLFVBQU0sRUFBRSxTQUFuekM7QUFBeXpDQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBbjBDLEdBQTVCLENBUEosZUFRSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixNQUFwQixFQUE0QjtBQUFFZ0MsS0FBQyxFQUFFLG1PQUFMO0FBQXlQL0IsVUFBTSxFQUFFLFNBQWpRO0FBQXVRQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBalIsR0FBNUIsQ0FSSixDQURGO0FBWUQsQ0FiNEIsQ0FBN0I7QUFlZWEsK0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDbEJBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBTTdFLFlBQVksR0FBRyw4RUFBckI7QUFBb0c7QUFDcEc7QUFFQSxNQUFNOEYsU0FBUyxnQkFBR04sa0RBQUksQ0FBQyxNQUFNO0FBQzNCLHNCQUNFN0IsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixLQUFwQixFQUEyQjtBQUN6QnNCLFVBQU0sRUFBRSxJQURpQjtBQUV6Qk8sV0FBTyxFQUFFLHFCQUZnQjtBQUd6QjFELFNBQUssRUFBRSxJQUhrQjtBQUl6QjJELFNBQUssRUFBRSw0QkFKa0I7QUFLekJDLFFBQUksRUFBRXZFLHNEQUFPLENBQUNpQixTQUxXO0FBS0F3QixVQUFNLEVBQUUsU0FMUjtBQUtjQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFMeEIsR0FBM0IsZUFPSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixNQUFwQixFQUE0QjtBQUFFZ0MsS0FBQyxFQUFFLHVJQUFMO0FBQXlKL0IsVUFBTSxFQUFFLFNBQWpLO0FBQXVLQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBakwsR0FBNUIsQ0FQSixDQURGO0FBV0QsQ0FacUIsQ0FBdEI7QUFjZThCLHdFQUFmLEU7Ozs7Ozs7Ozs7OztBQ2pCQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQU05RixZQUFZLEdBQUcsNEVBQXJCO0FBQWtHO0FBQ2xHO0FBRUEsTUFBTStGLFFBQVEsZ0JBQUdQLGtEQUFJLENBQUMsTUFBTTtBQUMxQixzQkFDRTdCLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsS0FBcEIsRUFBMkI7QUFDekJzQixVQUFNLEVBQUUsSUFEaUI7QUFFekJPLFdBQU8sRUFBRSxxQkFGZ0I7QUFHekIxRCxTQUFLLEVBQUUsSUFIa0I7QUFJekIyRCxTQUFLLEVBQUUsNEJBSmtCO0FBS3pCQyxRQUFJLEVBQUV2RSxzREFBTyxDQUFDaUIsU0FMVztBQUtBd0IsVUFBTSxFQUFFLFNBTFI7QUFLY0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBTHhCLEdBQTNCLGVBT0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsS0FBcEIsRUFBMkI7QUFBRThCLFNBQUssRUFBRSw0QkFBVDtBQUF1Q0QsV0FBTyxFQUFFLHFCQUFoRDtBQUEwRTVCLFVBQU0sRUFBRSxTQUFsRjtBQUF3RkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQWxHLEdBQTNCLGVBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsTUFBcEIsRUFBNEI7QUFBRWdDLEtBQUMsRUFBRSxzWEFBTDtBQUFxWi9CLFVBQU0sRUFBRSxTQUE3WjtBQUFtYUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQTdhLEdBQTVCLENBREYsQ0FQSixDQURGO0FBYUQsQ0Fkb0IsQ0FBckI7QUFnQmUrQix1RUFBZixFOzs7Ozs7Ozs7Ozs7QUNuQkE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUFNL0YsWUFBWSxHQUFHLCtFQUFyQjtBQUFxRztBQUNyRztBQUVBLE1BQU1nRyxXQUFXLGdCQUFHUixrREFBSSxDQUFDLE1BQU07QUFDN0Isc0JBQ0U3Qiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLEtBQXBCLEVBQTJCO0FBQ3pCc0IsVUFBTSxFQUFFLElBRGlCO0FBRXpCTyxXQUFPLEVBQUUscUJBRmdCO0FBR3pCMUQsU0FBSyxFQUFFLElBSGtCO0FBSXpCMkQsU0FBSyxFQUFFLDRCQUprQjtBQUt6QkMsUUFBSSxFQUFFdkUsc0RBQU8sQ0FBQ2lCLFNBTFc7QUFLQXdCLFVBQU0sRUFBRSxTQUxSO0FBS2NDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUx4QixHQUEzQixlQU9JTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLE1BQXBCLEVBQTRCO0FBQUVnQyxLQUFDLEVBQUUsMm9GQUFMO0FBQXkzRi9CLFVBQU0sRUFBRSxTQUFqNEY7QUFBdTRGQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBajVGLEdBQTVCLENBUEosZUFRSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixNQUFwQixFQUE0QjtBQUFFZ0MsS0FBQyxFQUFFLG1PQUFMO0FBQStQL0IsVUFBTSxFQUFFLFNBQXZRO0FBQTZRQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBdlIsR0FBNUIsQ0FSSixDQURGO0FBWUQsQ0FidUIsQ0FBeEI7QUFlZWdDLDBFQUFmLEU7Ozs7Ozs7Ozs7OztBQ2xCQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQU1oRyxZQUFZLEdBQUcsNEVBQXJCO0FBQWtHO0FBQ2xHO0FBRUEsTUFBTTZGLFFBQVEsZ0JBQUdMLGtEQUFJLENBQUMsTUFBTTtBQUMxQixzQkFDRTdCLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsS0FBcEIsRUFBMkI7QUFDekJzQixVQUFNLEVBQUUsSUFEaUI7QUFFekJPLFdBQU8sRUFBRSxxQkFGZ0I7QUFHekIxRCxTQUFLLEVBQUUsSUFIa0I7QUFJekIyRCxTQUFLLEVBQUUsNEJBSmtCO0FBS3pCQyxRQUFJLEVBQUV2RSxzREFBTyxDQUFDaUIsU0FMVztBQUtBd0IsVUFBTSxFQUFFLFNBTFI7QUFLY0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBTHhCLEdBQTNCLGVBT0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsTUFBcEIsRUFBNEI7QUFBRWdDLEtBQUMsRUFBRSxzaEZBQUw7QUFBZ3ZGL0IsVUFBTSxFQUFFLFNBQXh2RjtBQUE4dkZDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF4d0YsR0FBNUIsQ0FQSixDQURGO0FBV0QsQ0Fab0IsQ0FBckI7QUFjZTZCLHVFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pCQSxNQUFNN0YsWUFBWSxHQUFHLHlFQUFyQjtBQUErRjtBQUUvRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFPQSxNQUFNaUcsU0FBUyxHQUFHO0FBQUE7QUFBQSxHQUFXO0FBQzNCbkYsU0FBTyxFQUFFLE1BRGtCO0FBRTNCQyxlQUFhLEVBQUUsUUFGWTtBQUczQmdCLE9BQUssRUFBRSxHQUhvQjtBQUkzQm9ELGNBQVksRUFBRSxFQUphO0FBSzNCQyxpQkFBZSxFQUFFLE1BTFU7QUFNM0JjLFFBQU0sRUFBRyxhQUFZOUUsNkRBQU8sQ0FBQytFLGdCQUFpQixFQU5uQjtBQU8zQkMsV0FBUyxFQUFFQyxnRUFBUyxDQUFDQztBQVBNLENBQVgsQ0FBbEI7O0FBVUEsTUFBTUMsU0FBUyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFsQjs7QUFRQSxNQUFNQyxXQUFXLEdBQUcsa0ZBQU9DLDJDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFwQjs7QUFJQSxNQUFNQyxhQUFhLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXRCOztBQU9BLE1BQU1DLFdBQVcsR0FBRyxDQUFDO0FBQUNDLGFBQUQ7QUFBY0M7QUFBZCxDQUFELEtBQTBDO0FBQzVELFFBQU1DLGVBQWUsR0FBR0MseURBQVcsQ0FDakMsQ0FBQ0MsTUFBRCxFQUFTQyxPQUFULEtBQXFCO0FBQ25CSix5QkFBcUIsQ0FBQ0csTUFBRCxDQUFyQjtBQUNBQyxXQUFPLENBQUNDLGFBQVI7QUFDQU4sZUFBVztBQUNaLEdBTGdDLEVBTWpDLENBQUNBLFdBQUQsRUFBY0MscUJBQWQsQ0FOaUMsQ0FBbkM7QUFRQSxzQkFDRWxELDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JxQyxTQUFwQixFQUErQjtBQUFDcEMsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQS9CLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1RCw2Q0FBcEIsRUFBNEI7QUFDNUJDLG9CQUFnQixFQUFFLElBRFU7QUFFNUJDLGlCQUFhLEVBQUU7QUFBQ2pFLFVBQUksRUFBRTtBQUFQLEtBRmE7QUFHNUJrRSxvQkFBZ0IsRUFBRUMsa0ZBSFU7QUFJNUJDLFlBQVEsRUFBRVYsZUFKa0I7QUFJRGpELFVBQU0sRUFBRSxTQUpQO0FBSWFDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUp2QixHQUE1QixFQU1FLENBQUM7QUFBQ3lELGdCQUFEO0FBQWVULFVBQWY7QUFBdUJVO0FBQXZCLEdBQUQsa0JBQ0EvRCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CNEMsV0FBcEIsRUFBaUM7QUFBQzNDLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFqQyxlQUNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMkMsU0FBcEIsRUFBK0I7QUFBQzFDLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEvQixFQUFtRyxzQkFBbkcsQ0FESixlQUVJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK0QsdUVBQXBCLEVBQWdDO0FBQ2hDQyxlQUFXLEVBQUUseUJBRG1CO0FBRWhDeEUsUUFBSSxFQUFFLE1BRjBCO0FBR2hDL0MsU0FBSyxFQUFFMkcsTUFBTSxDQUFDNUQsSUFIa0I7QUFJaEN5RSxZQUFRLEVBQUVILFlBSnNCO0FBSVI3RCxVQUFNLEVBQUUsU0FKQTtBQUlNQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFKaEIsR0FBaEMsQ0FGSixlQVFJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9COEMsYUFBcEIsRUFBbUM7QUFBQzdDLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFuQyxlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0UsNEVBQXBCLEVBQXFDO0FBQUVDLFFBQUksRUFBRSxRQUFSO0FBQWtCdkQsV0FBTyxFQUFFb0MsV0FBM0I7QUFBd0MvQyxVQUFNLEVBQUUsU0FBaEQ7QUFBc0RDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUFoRSxHQUFyQyxFQUFnSixRQUFoSixDQURGLGVBSUVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvRSwwRUFBcEIsRUFBbUM7QUFBRUQsUUFBSSxFQUFFLFFBQVI7QUFBa0JFLFlBQVEsRUFBRVIsWUFBNUI7QUFBMEM1RCxVQUFNLEVBQUUsU0FBbEQ7QUFBd0RDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUFsRSxHQUFuQyxFQUFnSixRQUFoSixDQUpGLENBUkosQ0FQRixDQURKLENBREY7QUE4QkQsQ0F2Q0Q7O0FBeUNlMkMsMEVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDckZBLE1BQU0zRyxZQUFZLEdBQUcscUVBQXJCO0FBQTJGO0FBRTNGO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFRQSxNQUFNa0ksVUFBVSxHQUFHO0FBQUE7QUFBQSxHQUFXO0FBQzVCQyxVQUFRLEVBQUUsVUFEa0I7QUFFNUIvQyxpQkFBZSxFQUFFaEUsZ0VBQU8sQ0FBQ2dILGVBRkc7QUFHNUIzRyxVQUFRLEVBQUUsUUFIa0I7QUFJNUI0RyxhQUFXLEVBQUcsYUFBWWpILGdFQUFPLENBQUMrRSxnQkFBaUIsRUFKdkI7QUFLNUJqQixRQUFNLEVBQUUsTUFMb0I7QUFNNUJqRSxZQUFVLEVBQUU7QUFOZ0IsQ0FBWCxDQUFuQjs7QUFTQSxNQUFNcUgsV0FBVyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFwQjs7QUFVQSxNQUFNQyxTQUFTLEdBQUc7QUFBQTtBQUFBLEdBQVc7QUFDM0JyRCxRQUFNLEVBQUUsRUFEbUI7QUFFM0JwRSxTQUFPLEVBQUUsTUFGa0I7QUFHM0JDLGVBQWEsRUFBRSxLQUhZO0FBSTNCd0IsVUFBUSxFQUFFLEVBSmlCO0FBSzNCdkIsU0FBTyxFQUFFLFFBTGtCO0FBTTNCd0IsWUFBVSxFQUFFLEdBTmU7QUFPM0JaLFlBQVUsRUFBRSxRQVBlO0FBUTNCVixRQUFNLEVBQUUsU0FSbUI7QUFTM0JrRSxpQkFBZSxFQUFFLFNBVFU7QUFVM0I3RCxjQUFZLEVBQUUsRUFWYTtBQVczQmlILFlBQVUsRUFBRSwrQkFYZTtBQVkzQixZQUFVO0FBQ1JwRCxtQkFBZSxFQUFFaEUsZ0VBQU8sQ0FBQ3FILHFCQURqQjtBQUVSekcsU0FBSyxFQUFHLEdBQUVaLGdFQUFPLENBQUNzSCxZQUFhO0FBRnZCO0FBWmlCLENBQVgsQ0FBbEI7O0FBa0JBLE1BQU1DLE1BQU0sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBZjs7QUFJTyxNQUFNdkUsS0FBSyxHQUFHO0FBQUE7QUFBQSxHQUFXLENBQUM7QUFBQ2pDO0FBQUQsQ0FBRCxNQUFlO0FBQzdDK0MsUUFBTSxFQUFFLEVBRHFDO0FBRTdDbkQsT0FBSyxFQUFFLEVBRnNDO0FBRzdDNkcsVUFBUSxFQUFFLEVBSG1DO0FBSTdDQyxXQUFTLEVBQUUsRUFKa0M7QUFLN0M3RyxPQUFLLEVBQUVHLE1BQU0sR0FBR2YsZ0VBQU8sQ0FBQzBILGlCQUFYLEdBQStCMUgsZ0VBQU8sQ0FBQ2EsU0FMUDtBQU03Q2tELGNBQVksRUFBRSxDQU4rQjtBQU83Q0MsaUJBQWUsRUFBRSxNQVA0QjtBQVE3Q2MsUUFBTSxFQUFHLGFBQVkvRCxNQUFNLEdBQUdmLGdFQUFPLENBQUNzSCxZQUFYLEdBQTBCdEgsZ0VBQU8sQ0FBQytFLGdCQUFpQixFQVJqQztBQVM3Q3JGLFNBQU8sRUFBRSxNQVRvQztBQVU3Q2MsWUFBVSxFQUFFLFFBVmlDO0FBVzdDQyxnQkFBYyxFQUFFLFFBWDZCO0FBWTdDWixZQUFVLEVBQUUsTUFaaUM7QUFhN0NvRSxhQUFXLEVBQUU7QUFiZ0MsQ0FBZixDQUFYLENBQWQ7O0FBZ0JQLE1BQU0wRCxPQUFPLEdBQUc7QUFBQTtBQUFBO0FBQ2RDLFlBQVUsRUFBRSxNQURFO0FBRWQzRCxhQUFXLEVBQUU7QUFGQyxHQUdYakQsNkVBSFcsRUFBaEI7O0FBTUEsTUFBTTZHLFFBQVEsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBakI7O0FBS0EsTUFBTXZHLEtBQUssR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBZDs7QUFPQSxNQUFNd0csT0FBTyxHQUFHLGtGQUFPQyx3REFBUDtBQUFBO0FBQUEsR0FBZ0I7QUFDOUJDLGdCQUFjLEVBQUUsTUFEYztBQUU5QmpFLGNBQVksRUFBRSxDQUZnQjtBQUc5QkQsUUFBTSxFQUFFLEVBSHNCO0FBSTlCOEQsWUFBVSxFQUFFLE1BSmtCO0FBSzlCSyxhQUFXLEVBQUUsRUFMaUI7QUFNOUJ2SCxRQUFNLEVBQUUsVUFOc0I7QUFPOUJ3SCxTQUFPLEVBQUUsSUFQcUI7QUFROUJ4SSxTQUFPLEVBQUUsTUFScUI7QUFTOUJDLGVBQWEsRUFBRSxLQVRlO0FBVTlCYSxZQUFVLEVBQUUsUUFWa0I7QUFXOUI0RyxZQUFVLEVBQUUsdUJBWGtCO0FBWTlCLFlBQVU7QUFDUnBELG1CQUFlLEVBQUVoRSxnRUFBTyxDQUFDbUksc0JBRGpCO0FBRVJELFdBQU8sRUFBRTtBQUZEO0FBWm9CLENBQWhCLENBQWhCOztBQWtCQSxNQUFNRSxVQUFVLEdBQUcsa0ZBQU9MLHdEQUFQO0FBQUE7QUFBQSxHQUFnQjtBQUNqQ0MsZ0JBQWMsRUFBRSxNQURpQjtBQUVqQ3BILE9BQUssRUFBRVosZ0VBQU8sQ0FBQ2lCLFNBRmtCO0FBR2pDOEMsY0FBWSxFQUFFLENBSG1CO0FBSWpDM0MsWUFBVSxFQUFFLEdBSnFCO0FBS2pDMEMsUUFBTSxFQUFFLEVBTHlCO0FBTWpDOEQsWUFBVSxFQUFFLE1BTnFCO0FBT2pDSyxhQUFXLEVBQUUsRUFQb0I7QUFRakN2SCxRQUFNLEVBQUUsbUJBUnlCO0FBU2pDd0gsU0FBTyxFQUFFLElBVHdCO0FBVWpDL0csVUFBUSxFQUFFLEVBVnVCO0FBV2pDekIsU0FBTyxFQUFFLE1BWHdCO0FBWWpDQyxlQUFhLEVBQUUsS0Faa0I7QUFhakNhLFlBQVUsRUFBRSxRQWJxQjtBQWNqQzRHLFlBQVUsRUFBRSx1QkFkcUI7QUFlakMsWUFBVTtBQUNScEQsbUJBQWUsRUFBRWhFLGdFQUFPLENBQUNtSSxzQkFEakI7QUFFUnZILFNBQUssRUFBRVosZ0VBQU8sQ0FBQ2lCLFNBRlA7QUFHUmlILFdBQU8sRUFBRTtBQUhEO0FBZnVCLENBQWhCLENBQW5COztBQXNCQSxNQUFNRyxnQkFBZ0IsR0FBRztBQUN2QnJFLGlCQUFlLEVBQUcsR0FBRWhFLGdFQUFPLENBQUNzSSxnQkFBaUIsYUFEdEI7QUFFdkIxSCxPQUFLLEVBQUcsR0FBRVosZ0VBQU8sQ0FBQ3NILFlBQWEsYUFGUjtBQUd2QlksU0FBTyxFQUFFO0FBSGMsQ0FBekI7O0FBTUEsTUFBTUssT0FBTyxHQUFJM0csS0FBRCxJQUFXO0FBQ3pCLFFBQU07QUFDSjRHLFFBREk7QUFFSkMsWUFGSTtBQUdKdkcsaUJBSEk7QUFJSndHLFdBQU8sR0FBRyxlQUpOO0FBS0o1RyxpQkFMSTtBQU1KMkQ7QUFOSSxNQU9GN0QsS0FQSjtBQVFBLFFBQU07QUFBQ0ssU0FBRDtBQUFRRCxRQUFSO0FBQWNHO0FBQWQsTUFBeUNxRyxJQUEvQztBQUNBLFFBQU1HLGFBQWEsR0FBR0YsUUFBUSxDQUFDRyxRQUFULENBQWtCQyxRQUFsQixDQUEyQixVQUEzQixDQUF0QjtBQUNBLFFBQU07QUFBQ0MsY0FBRDtBQUFhakgsZ0JBQWI7QUFBMkJrSCxhQUEzQjtBQUFzQ2hIO0FBQXRDLE1BQW1EaUgscUVBQU8sQ0FBQ0Msb0VBQVksQ0FBQ0MsVUFBZCxFQUEwQjtBQUN4RkMsY0FBVSxFQUFFO0FBRDRFLEdBQTFCLENBQWhFO0FBR0EsUUFBTTtBQUFDQyxlQUFEO0FBQWN2SCxnQkFBWSxFQUFFTyxpQkFBNUI7QUFBK0NvRCxlQUFXLEVBQUU2RDtBQUE1RCxNQUFnRkMsc0VBQVEsQ0FBQyxFQUFELENBQTlGO0FBQ0Esc0JBQ0UvRyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc0UsVUFBcEIsRUFBZ0M7QUFBQ3JFLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFoQyxlQUNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMEUsV0FBcEIsRUFBaUM7QUFBQ3pFLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFqQyxlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLEtBQXBCLEVBQTJCO0FBQUNDLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEzQixlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMkUsU0FBcEIsRUFBK0I7QUFBRS9ELFdBQU8sRUFBRXZCLFlBQVg7QUFBeUJZLFVBQU0sRUFBRSxTQUFqQztBQUF1Q0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQWpELEdBQS9CLGVBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JRLEtBQXBCLEVBQTJCO0FBQUV1RyxPQUFHLEVBQUVSLFNBQVA7QUFBa0JoSSxVQUFNLEVBQUUsSUFBMUI7QUFBZ0MwQixVQUFNLEVBQUUsU0FBeEM7QUFBOENDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF4RCxHQUEzQixFQUNFOEYsT0FBTyxDQUFDeEYsTUFBUixDQUFlLENBQWYsQ0FERixDQURGLGVBSUVYLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JtRixPQUFwQixFQUE2QjtBQUFDbEYsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTdCLEVBQWtHOEYsT0FBbEcsQ0FKRixlQUtFbkcsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjJCLDZFQUFwQixFQUFrQztBQUFDMUIsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQWxDLENBTEYsQ0FERixlQVFFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CcUYsUUFBcEIsRUFBOEI7QUFBQ3BGLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUE5QixlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CZ0gsd0RBQXBCLEVBQWdDO0FBQUMvRyxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBaEMsRUFDRSxDQUFDO0FBQUM2RztBQUFELEdBQUQsS0FBVztBQUNYLHdCQUNFbEgsNENBQUssQ0FBQ0MsYUFBTixDQUFvQkQsNENBQUssQ0FBQ21ILFFBQTFCLEVBQW9DLElBQXBDLEVBQ0lDLHlFQUFXLENBQUN6SCxhQUFELEVBQWdCQyx1QkFBaEIsQ0FBWCxpQkFDQUksNENBQUssQ0FBQ0MsYUFBTixDQUFvQkQsNENBQUssQ0FBQ21ILFFBQTFCLEVBQW9DLElBQXBDLGVBQ0luSCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc0YsT0FBcEIsRUFBNkI7QUFBRThCLFFBQUUsRUFBRyxxQkFBUDtBQUE2QkMscUJBQWUsRUFBRUosR0FBRyxDQUFDcEIsZ0JBQUQsQ0FBakQ7QUFBcUU1RixZQUFNLEVBQUUsU0FBN0U7QUFBbUZDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGtCQUFVLEVBQUU7QUFBckM7QUFBN0YsS0FBN0IsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnNILHdFQUFwQixFQUErQjtBQUFDckgsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUEvQixDQURGLGVBRUVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JsQixLQUFwQixFQUEyQjtBQUFDbUIsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUEzQixFQUFnRyxvQkFBaEcsQ0FGRixDQURKLEVBS0ksQ0FBQzRGLElBQUksQ0FBQ3VCLFFBQU4saUJBQ0F4SCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc0YsT0FBcEIsRUFBNkI7QUFBRThCLFFBQUUsRUFBRyxTQUFQO0FBQWlCQyxxQkFBZSxFQUFFSixHQUFHLENBQUNwQixnQkFBRCxDQUFyQztBQUF5RDVGLFlBQU0sRUFBRSxTQUFqRTtBQUF1RUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUFqRixLQUE3QixlQUNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd0gsMEVBQXBCLEVBQStCO0FBQUN2SCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQS9CLENBREosZUFFSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmxCLEtBQXBCLEVBQTJCO0FBQUNtQixZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTNCLEVBQWdHLFFBQWhHLENBRkosQ0FOSixDQUZKLEVBZ0JJLENBQUMrRyx5RUFBVyxDQUFDekgsYUFBRCxFQUFnQkMsdUJBQWhCLENBQVosaUJBQ0FJLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JzRixPQUFwQixFQUE2QjtBQUFFOEIsUUFBRSxFQUFHLFNBQVA7QUFBaUJDLHFCQUFlLEVBQUVKLEdBQUcsQ0FBQ3BCLGdCQUFELENBQXJDO0FBQXlENUYsWUFBTSxFQUFFLFNBQWpFO0FBQXVFQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQWpGLEtBQTdCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5SCx3RUFBcEIsRUFBK0I7QUFBQ3hILFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBL0IsQ0FESixlQUVJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CbEIsS0FBcEIsRUFBMkI7QUFBQ21CLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBM0IsRUFBZ0csUUFBaEcsQ0FGSixDQWpCSixFQXNCSTRGLElBQUksQ0FBQ3VCLFFBQUwsaUJBQ0F4SCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc0YsT0FBcEIsRUFBNkI7QUFBRThCLFFBQUUsRUFBRyxRQUFQO0FBQWdCQyxxQkFBZSxFQUFFSixHQUFHLENBQUNwQixnQkFBRCxDQUFwQztBQUF3RDVGLFlBQU0sRUFBRSxTQUFoRTtBQUFzRUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUFoRixLQUE3QixlQUNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc0gsd0VBQXBCLEVBQStCO0FBQUNySCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQS9CLENBREosZUFFSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmxCLEtBQXBCLEVBQTJCO0FBQUNtQixZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTNCLEVBQWdHLE9BQWhHLENBRkosQ0F2QkosRUE0Qkk0RixJQUFJLENBQUN1QixRQUFMLGlCQUNBeEgsNENBQUssQ0FBQ0MsYUFBTixDQUFvQkQsNENBQUssQ0FBQ21ILFFBQTFCLEVBQW9DLElBQXBDLGVBQ0luSCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc0YsT0FBcEIsRUFBNkI7QUFBRThCLFFBQUUsRUFBRyxTQUFQO0FBQWlCQyxxQkFBZSxFQUFFSixHQUFHLENBQUNwQixnQkFBRCxDQUFyQztBQUF5RDVGLFlBQU0sRUFBRSxTQUFqRTtBQUF1RUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUFqRixLQUE3QixlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd0gsMEVBQXBCLEVBQStCO0FBQUN2SCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQS9CLENBREYsZUFFRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmxCLEtBQXBCLEVBQTJCO0FBQUNtQixZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTNCLEVBQWdHLFFBQWhHLENBRkYsQ0FESixlQUtJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc0YsT0FBcEIsRUFBNkI7QUFBRThCLFFBQUUsRUFBRyxVQUFQO0FBQWtCQyxxQkFBZSxFQUFFSixHQUFHLENBQUNwQixnQkFBRCxDQUF0QztBQUEwRDVGLFlBQU0sRUFBRSxTQUFsRTtBQUF3RUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUFsRixLQUE3QixlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMEgsMEVBQXBCLEVBQWlDO0FBQUN6SCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQWpDLENBREYsZUFFRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmxCLEtBQXBCLEVBQTJCO0FBQUNtQixZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTNCLEVBQWdHLFNBQWhHLENBRkYsQ0FMSixFQVNJK0YsYUFBYSxpQkFDYnBHLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JELDRDQUFLLENBQUNtSCxRQUExQixFQUFvQyxJQUFwQyxlQUNJbkgsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjRGLFVBQXBCLEVBQWdDO0FBQ2hDK0IsV0FBSyxFQUFFLElBRHlCO0FBRWhDUCxRQUFFLEVBQUcsVUFGMkI7QUFHaENDLHFCQUFlLEVBQUVKLEdBQUcsQ0FBQ3BCLGdCQUFELENBSFk7QUFHUTVGLFlBQU0sRUFBRSxTQUhoQjtBQUdzQkMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUhoQyxLQUFoQyxlQUtFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMEIsOERBQXBCLEVBQXlCO0FBQUV0RCxXQUFLLEVBQUVaLGdFQUFPLENBQUNvSyxJQUFqQjtBQUF1QjNILFlBQU0sRUFBRSxTQUEvQjtBQUFxQ0MsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUEvQyxLQUF6QixDQUxGLGVBTUVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsTUFBcEIsRUFBNEI7QUFBQ0MsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUE1QixFQUFpRyxVQUFqRyxDQU5GLENBREosZUFTSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjRGLFVBQXBCLEVBQWdDO0FBQ2hDd0IsUUFBRSxFQUFHLGlCQUQyQjtBQUVoQ0MscUJBQWUsRUFBRUosR0FBRyxDQUFDcEIsZ0JBQUQsQ0FGWTtBQUVRNUYsWUFBTSxFQUFFLFNBRmhCO0FBRXNCQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBRmhDLEtBQWhDLGVBSUVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IwQiw4REFBcEIsRUFBeUI7QUFBRXRELFdBQUssRUFBRVosZ0VBQU8sQ0FBQ3FLLGFBQWpCO0FBQWdDNUgsWUFBTSxFQUFFLFNBQXhDO0FBQThDQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQXhELEtBQXpCLENBSkYsZUFLRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixNQUFwQixFQUE0QjtBQUFDQyxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTVCLEVBQWlHLFFBQWpHLENBTEYsQ0FUSixlQWdCSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjRGLFVBQXBCLEVBQWdDO0FBQ2hDd0IsUUFBRSxFQUFHLGtCQUQyQjtBQUVoQ0MscUJBQWUsRUFBRUosR0FBRyxDQUFDcEIsZ0JBQUQsQ0FGWTtBQUVRNUYsWUFBTSxFQUFFLFNBRmhCO0FBRXNCQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBRmhDLEtBQWhDLGVBSUVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IwQiw4REFBcEIsRUFBeUI7QUFBRXRELFdBQUssRUFBRSxTQUFUO0FBQW9CNkIsWUFBTSxFQUFFLFNBQTVCO0FBQWtDQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQTVDLEtBQXpCLENBSkYsZUFLRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixNQUFwQixFQUE0QjtBQUFDQyxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTVCLEVBQWlHLFNBQWpHLENBTEYsQ0FoQkosQ0FWSixDQTdCSixDQURGO0FBcUVELEdBdkVELENBREYsQ0FSRixDQURGLGVBcUZFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK0UsTUFBcEIsRUFBNEI7QUFBQzlFLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUE1QixlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc0YsT0FBcEIsRUFBNkI7QUFBRThCLE1BQUUsRUFBRyxtQkFBUDtBQUEyQm5ILFVBQU0sRUFBRSxTQUFuQztBQUF5Q0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQW5ELEdBQTdCLGVBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvQywyRUFBcEIsRUFBaUM7QUFBQ25DLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFqQyxDQURGLGVBRUVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JsQixLQUFwQixFQUEyQjtBQUFDbUIsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTNCLEVBQWdHLFVBQWhHLENBRkYsQ0FERixDQXJGRixDQURKLEVBNkZJa0csVUFBVSxlQUNWdkcsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmIsa0VBQXBCLEVBQTZCO0FBQzNCRSxnQkFBWSxFQUFFQSxZQURhO0FBRTNCTyxxQkFBaUIsRUFBRUEsaUJBRlE7QUFHM0JGLGlCQUFhLEVBQUVBLGFBSFk7QUFJM0JKLGlCQUFhLEVBQUVBLGFBSlk7QUFLM0JDLGFBQVMsRUFBRUEsU0FMZ0I7QUFNM0JDLFFBQUksRUFBRUEsSUFOcUI7QUFPM0JDLFNBQUssRUFBRUEsS0FQb0I7QUFRM0JFLDJCQUF1QixFQUFFQSx1QkFSRTtBQVF1Qk0sVUFBTSxFQUFFLFNBUi9CO0FBUXFDQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFSL0MsR0FBN0IsQ0FEVSxDQTdGZCxFQXlHSXdHLFdBQVcsZUFDWDdHLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IrQyxzRUFBcEIsRUFBaUM7QUFBRUMsZUFBVyxFQUFFNkQsZ0JBQWY7QUFBaUM1RCx5QkFBcUIsRUFBRUEscUJBQXhEO0FBQStFaEQsVUFBTSxFQUFFLFNBQXZGO0FBQTZGQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBdkcsR0FBakMsQ0FEVyxDQXpHZixDQURGO0FBK0dELENBOUhEOztBQWdJZTBILGtJQUFVLENBQUMvQixPQUFELENBQXpCLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDclJBLE1BQU0zSixZQUFZLEdBQUcsa0ZBQXJCO0FBQXdHO0FBQ3hHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBT0EsTUFBTTJMLGFBQWEsR0FBSTNJLEtBQUQsSUFBVztBQUMvQixRQUFNO0FBQUNTO0FBQUQsTUFBWVQsS0FBbEI7QUFDQSxRQUFNNEksU0FBUyxHQUFHQyx5RUFBWSxFQUE5QjtBQUNBLFFBQU07QUFDSkMsYUFBUyxFQUFFO0FBQUNDLGFBQU8sRUFBRUM7QUFBVjtBQURQLE1BRUZKLFNBQVMsSUFBSTtBQUFDRSxhQUFTLEVBQUU7QUFBWixHQUZqQjtBQUdBLFFBQU0sQ0FBQ2xDLElBQUQsRUFBT3FDLE9BQVAsSUFBa0JDLHNEQUFRLENBQUMsRUFBRCxDQUFoQztBQUNBLFFBQU07QUFBQzNJLDJCQUF1QixFQUFFNEk7QUFBMUIsTUFBMEN2QyxJQUFJLElBQUksRUFBeEQ7QUFDQSxRQUFNLENBQUN3QyxZQUFELEVBQWVDLE1BQWYsSUFBeUJILHNEQUFRLENBQUMsRUFBRCxDQUF2QztBQUNBLFFBQU0sQ0FBQzVJLGFBQUQsRUFBZ0JnSixPQUFoQixJQUEyQkosc0RBQVEsQ0FBQyxFQUFELENBQXpDOztBQUVBLGlCQUFlSyxtQkFBZixHQUFxQztBQUNuQyxVQUFNQyxJQUFJLEdBQUcsTUFBTVosU0FBUyxDQUFDYSxXQUFWLENBQXVCLFVBQVNULE1BQU8sRUFBdkMsRUFBMEM7QUFBQ1UsWUFBTSxFQUFFO0FBQVQsS0FBMUMsQ0FBbkI7QUFDQSxRQUFJQyxJQUFKLEVBQVVDLE1BQVY7O0FBRUEsUUFBSUosSUFBSixFQUFVO0FBQ1JHLFVBQUksR0FBR0gsSUFBSSxDQUFDRyxJQUFaO0FBQ0FDLFlBQU0sR0FBR0osSUFBSSxDQUFDSSxNQUFkO0FBQ0Q7O0FBQ0QsVUFBTTtBQUFDcko7QUFBRCxRQUE0Qm9KLElBQUksSUFBSSxFQUExQztBQUNBLFFBQUlSLFlBQVksS0FBSzVJLHVCQUFyQixFQUE4Qzs7QUFDOUMsUUFBSSxDQUFDcUosTUFBTCxFQUFhO0FBQ1gsVUFBSXJKLHVCQUFKLEVBQTZCO0FBQzNCLGNBQU07QUFBQ29KLGNBQUksRUFBRUU7QUFBUCxZQUFjLE1BQU1qQixTQUFTLENBQUNhLFdBQVYsQ0FBdUIsU0FBUUUsSUFBSSxDQUFDcEosdUJBQXdCLEVBQTVELEVBQStEO0FBQ3ZGbUosZ0JBQU0sRUFBRTtBQUQrRSxTQUEvRCxDQUExQjtBQUdBLGNBQU07QUFBQ0MsY0FBSSxFQUFFRztBQUFQLFlBQWUsTUFBTWxCLFNBQVMsQ0FBQ2EsV0FBVixDQUF1QixPQUF2QixFQUErQjtBQUFDQyxnQkFBTSxFQUFFO0FBQVQsU0FBL0IsQ0FBM0I7QUFDQVQsZUFBTyxDQUFDVSxJQUFELENBQVA7QUFDQU4sY0FBTSxDQUFDUSxHQUFELENBQU47QUFDQVAsZUFBTyxDQUFDUSxJQUFELENBQVA7QUFDQSxjQUFNQyxPQUFPLEdBQUdoQyx3RUFBVyxDQUFDK0IsSUFBRCxFQUFPSCxJQUFJLENBQUNwSix1QkFBWixDQUEzQjtBQUNBUCxhQUFLLENBQUNnSyxPQUFOLGlDQUFrQkwsSUFBbEI7QUFBd0JJO0FBQXhCO0FBQ0QsT0FWRCxNQVVPO0FBQ0xFLGVBQU8sQ0FBQ0MsS0FBUixDQUFjLHFCQUFkO0FBQ0Q7QUFDRixLQWRELE1BY087QUFDTE4sWUFBTSxDQUFDTyxPQUFQLENBQWdCQyxDQUFELElBQU9ILE9BQU8sQ0FBQ0MsS0FBUixDQUFjRSxDQUFDLENBQUNDLE9BQWhCLENBQXRCO0FBQ0Q7QUFDRjs7QUFFREMseURBQVMsQ0FBQyxNQUFNO0FBQ2RmLHVCQUFtQjtBQUNwQixHQUZRLEVBRU4sQ0FBQ1AsTUFBRCxFQUFTcEMsSUFBVCxDQUZNLENBQVQ7O0FBSUEsUUFBTTFHLGFBQWEsR0FBRyxNQUFPZ0IsRUFBUCxJQUFjO0FBQ2xDLFVBQU07QUFBQzBJO0FBQUQsUUFBVyxNQUFNaEIsU0FBUyxDQUFDYSxXQUFWLENBQXVCLFVBQVM3QyxJQUFJLENBQUMxRixFQUFHLEVBQXhDLEVBQTJDO0FBQ2hFeUksVUFBSSxFQUFFO0FBQ0pwSiwrQkFBdUIsRUFBRVc7QUFEckIsT0FEMEQ7QUFJaEV3SSxZQUFNLEVBQUU7QUFKd0QsS0FBM0MsQ0FBdkI7O0FBTUEsUUFBSSxDQUFDRSxNQUFMLEVBQWE7QUFDWG5KLGFBQU8sQ0FBQ3VCLElBQVIsQ0FBYSxHQUFiO0FBQ0QsS0FGRCxNQUVPO0FBQ0xpSSxhQUFPLENBQUNDLEtBQVIsQ0FBYywwQ0FBZCxFQUEwREssSUFBSSxDQUFDQyxTQUFMLENBQWVaLE1BQWYsQ0FBMUQ7QUFDRDtBQUNGLEdBWkQ7O0FBY0EsUUFBTS9GLHFCQUFxQixHQUFHLE1BQU9pRCxPQUFQLElBQW1CO0FBQy9DLFFBQUksQ0FBQ0EsT0FBTCxFQUFjO0FBQ2QsVUFBTTtBQUNKNkMsVUFBSSxFQUFFO0FBQUN6SSxVQUFFLEVBQUV1SjtBQUFMO0FBREYsUUFFRixNQUFNN0IsU0FBUyxDQUFDYSxXQUFWLENBQXVCLGNBQXZCLEVBQXNDO0FBQzlDRSxVQUFJLEVBQUU3QyxPQUR3QztBQUU5QzRDLFlBQU0sRUFBRTtBQUZzQyxLQUF0QyxDQUZWO0FBTUEsVUFBTWQsU0FBUyxDQUFDYSxXQUFWLENBQXVCLFVBQVM3QyxJQUFJLENBQUMxRixFQUFHLEVBQXhDLEVBQTJDO0FBQy9DeUksVUFBSSxFQUFFO0FBQ0pwSiwrQkFBdUIsRUFBRWtLO0FBRHJCLE9BRHlDO0FBSS9DZixZQUFNLEVBQUU7QUFKdUMsS0FBM0MsQ0FBTjtBQU1BakosV0FBTyxDQUFDdUIsSUFBUixDQUFhLEdBQWI7QUFDRCxHQWZEOztBQWlCQSxNQUFJLENBQUM0RSxJQUFJLENBQUMxRixFQUFOLElBQVksQ0FBQ2tJLFlBQVksQ0FBQ2hKLElBQTlCLEVBQW9DLE9BQU8sSUFBUDtBQUVwQyxzQkFDRU8sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhKLDZEQUFwQixrQ0FDSzFLLEtBREw7QUFFRTRHLFFBQUksRUFBRUEsSUFGUjtBQUdFRSxXQUFPLEVBQUVzQyxZQUFZLENBQUNoSixJQUh4QjtBQUlFRSxpQkFBYSxFQUFFQSxhQUpqQjtBQUtFSixpQkFBYSxFQUFFQSxhQUxqQjtBQU1FMkQseUJBQXFCLEVBQUVBLHFCQU56QjtBQU1nRGhELFVBQU0sRUFBRSxTQU54RDtBQU04REMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBTnhFLEtBREY7QUFVRCxDQXZGRDs7QUF3RkEsTUFBTTJKLGtCQUFrQixHQUFJQyxRQUFELEtBQWU7QUFDeENaLFNBQU8sRUFBR2EsR0FBRCxJQUFTRCxRQUFRLENBQUNaLCtFQUFPLENBQUNhLEdBQUQsQ0FBUjtBQURjLENBQWYsQ0FBM0I7O0FBSWVDLDBIQUFPLENBQUMsSUFBRCxFQUFPSCxrQkFBUCxDQUFQLENBQWtDaEMsYUFBbEMsQ0FBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hHQSxNQUFNM0wsWUFBWSxHQUFHLHlGQUFyQjtBQUErRztBQUMvRztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQVNBLE1BQU0rTixVQUFVLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQW5COztBQU1BLE1BQU1DLFFBQVEsR0FBRyxrRkFBTyxLQUFQO0FBQUE7QUFBQSxHQUFjO0FBQzdCbE4sU0FBTyxFQUFFLE1BRG9CO0FBRTdCbU4sTUFBSSxFQUFFLENBRnVCO0FBRzdCbE4sZUFBYSxFQUFFLFFBSGM7QUFJN0JtRSxRQUFNLEVBQUUsTUFKcUI7QUFLN0J6RCxVQUFRLEVBQUUsUUFMbUI7QUFNN0J5TSxZQUFVLEVBQUU5TSxnRUFBTyxDQUFDZ0g7QUFOUyxDQUFkLENBQWpCOztBQVNBLE1BQU0rRixVQUFVLGdCQUFHQyxrREFBSSxDQUFDLE1BQ3RCLDRMQUFnRkMsS0FBaEYsQ0FBdUZuQixLQUFELElBQ3BGb0IsZ0ZBQWdCLENBQUNwQixLQUFELENBRGxCLENBRHFCLENBQXZCO0FBTUEsTUFBTXFCLFNBQVMsZ0JBQUdILGtEQUFJLENBQUMsTUFDckIseVFBRUVDLEtBRkYsQ0FFU25CLEtBQUQsSUFBV29CLGdGQUFnQixDQUFDcEIsS0FBRCxDQUZuQyxDQURvQixDQUF0QjtBQU1BLE1BQU1zQixVQUFVLGdCQUFHSixrREFBSSxDQUFDLE1BQ3RCLHNaQUVFQyxLQUZGLENBRVNuQixLQUFELElBQVdvQixnRkFBZ0IsQ0FBQ3BCLEtBQUQsQ0FGbkMsQ0FEcUIsQ0FBdkI7QUFNQSxNQUFNdUIsZUFBZSxnQkFBR0wsa0RBQUksQ0FBQyxNQUMzQiwwYUFFRUMsS0FGRixDQUVTbkIsS0FBRCxJQUFXb0IsZ0ZBQWdCLENBQUNwQixLQUFELENBRm5DLENBRDBCLENBQTVCO0FBTUEsTUFBTXdCLFdBQVcsZ0JBQUdOLGtEQUFJLENBQUMsTUFDdkIsa01BRUVDLEtBRkYsQ0FFU25CLEtBQUQsSUFBV29CLGdGQUFnQixDQUFDcEIsS0FBRCxDQUZuQyxDQURzQixDQUF4QjtBQU1BLE1BQU15QixRQUFRLGdCQUFHUCxrREFBSSxDQUFDLE1BQ3BCLDRLQUF3RUMsS0FBeEUsQ0FBK0VuQixLQUFELElBQzVFb0IsZ0ZBQWdCLENBQUNwQixLQUFELENBRGxCLENBRG1CLENBQXJCOztBQU1BLE1BQU1RLFNBQVMsR0FBSTFLLEtBQUQsSUFBVztBQUMzQixRQUFNO0FBQ0o0RyxRQURJO0FBRUpFLFdBRkk7QUFHSnhHLGlCQUhJO0FBSUp1RCx5QkFKSTtBQUtKM0QsaUJBTEk7QUFNSk8sV0FBTyxFQUFFO0FBQUNvRztBQUFELEtBTkw7QUFPSmtEO0FBUEksTUFRRi9KLEtBQUssSUFBSSxFQVJiO0FBU0EsUUFBTTRMLFdBQVcsR0FBRy9FLFFBQVEsQ0FBQ0csUUFBVCxDQUFrQkMsUUFBbEIsQ0FBMkIsTUFBM0IsQ0FBcEI7QUFDQSxzQkFDRXRHLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JtSyxVQUFwQixFQUFnQztBQUFDbEssVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQWhDLEVBQ0ksQ0FBQzRLLFdBQUQsaUJBQ0FqTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK0YsaUVBQXBCLEVBQTZCO0FBQzNCekcsaUJBQWEsRUFBRUEsYUFEWTtBQUUzQjBHLFFBQUksRUFBRUEsSUFGcUI7QUFHM0JFLFdBQU8sRUFBRUEsT0FIa0I7QUFJM0J4RyxpQkFBYSxFQUFFQSxhQUpZO0FBSzNCdUQseUJBQXFCLEVBQUVBLHFCQUxJO0FBS21CaEQsVUFBTSxFQUFFLFNBTDNCO0FBS2lDQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFMM0MsR0FBN0IsQ0FGSixlQVVJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cb0ssUUFBcEIsRUFBOEI7QUFBQ25LLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUE5QixlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CaUwsdURBQXBCLEVBQTRCO0FBQUNoTCxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBNUIsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmtMLHNEQUFwQixFQUEyQjtBQUMzQkMsUUFBSSxFQUFFLHFCQURxQjtBQUUzQkMsVUFBTSxFQUFHQyxDQUFELElBQU87QUFDYixVQUFJbEMsT0FBSixFQUFhLG9CQUFPcEosNENBQUssQ0FBQ0MsYUFBTixDQUFvQjZLLGVBQXBCLGtDQUEwQ1EsQ0FBMUM7QUFBNkNyRixZQUFJLEVBQUVBLElBQW5EO0FBQXlEL0YsY0FBTSxFQUFFLFNBQWpFO0FBQXVFQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usb0JBQVUsRUFBRTtBQUFyQztBQUFqRixTQUFQO0FBQ2IsMEJBQU9MLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JzTCx5REFBcEIsRUFBOEI7QUFBRWxFLFVBQUUsRUFBRSxTQUFOO0FBQWlCbkgsY0FBTSxFQUFFLFNBQXpCO0FBQStCQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usb0JBQVUsRUFBRTtBQUFyQztBQUF6QyxPQUE5QixDQUFQO0FBQ0QsS0FMMEI7QUFLeEJILFVBQU0sRUFBRSxTQUxnQjtBQUtWQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFMQSxHQUEzQixDQURGLGVBUUVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JrTCxzREFBcEIsRUFBMkI7QUFDM0JDLFFBQUksRUFBRSxTQURxQjtBQUUzQkMsVUFBTSxFQUFHQyxDQUFELGlCQUFPdEwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnVLLFVBQXBCO0FBQWtDN0ssbUJBQWEsRUFBRUE7QUFBakQsT0FBbUUyTCxDQUFuRTtBQUFzRXJGLFVBQUksRUFBRUEsSUFBNUU7QUFBa0YvRixZQUFNLEVBQUUsU0FBMUY7QUFBZ0dDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGtCQUFVLEVBQUU7QUFBckM7QUFBMUcsT0FGWTtBQUU0SUgsVUFBTSxFQUFFLFNBRnBKO0FBRTBKQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFGcEssR0FBM0IsQ0FSRixlQVlFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0wsc0RBQXBCLEVBQTJCO0FBQUVDLFFBQUksRUFBRSxRQUFSO0FBQWtCQyxVQUFNLEVBQUdDLENBQUQsaUJBQU90TCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMkssU0FBcEIsa0NBQW9DVSxDQUFwQztBQUF1Q3JGLFVBQUksRUFBRUEsSUFBN0M7QUFBbUQvRixZQUFNLEVBQUUsU0FBM0Q7QUFBaUVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGtCQUFVLEVBQUU7QUFBckM7QUFBM0UsT0FBakM7QUFBMEpILFVBQU0sRUFBRSxTQUFsSztBQUF3S0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQWxMLEdBQTNCLENBWkYsZUFhRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmtMLHNEQUFwQixFQUEyQjtBQUFFQyxRQUFJLEVBQUUsU0FBUjtBQUFtQkMsVUFBTSxFQUFHQyxDQUFELGlCQUFPdEwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjRLLFVBQXBCLGtDQUFxQ1MsQ0FBckM7QUFBd0NyRixVQUFJLEVBQUVBLElBQTlDO0FBQW9EL0YsWUFBTSxFQUFFLFNBQTVEO0FBQWtFQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxrQkFBVSxFQUFFO0FBQXJDO0FBQTVFLE9BQWxDO0FBQTRKSCxVQUFNLEVBQUUsU0FBcEs7QUFBMEtDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0UsZ0JBQVUsRUFBRTtBQUFyQztBQUFwTCxHQUEzQixDQWJGLGVBY0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JrTCxzREFBcEIsRUFBMkI7QUFBRUMsUUFBSSxFQUFFLFVBQVI7QUFBb0JDLFVBQU0sRUFBR0MsQ0FBRCxpQkFBT3RMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I4SyxXQUFwQixrQ0FBc0NPLENBQXRDO0FBQXlDckYsVUFBSSxFQUFFQSxJQUEvQztBQUFxRC9GLFlBQU0sRUFBRSxTQUE3RDtBQUFtRUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUUvRCxZQUFYO0FBQXlCZ0Usa0JBQVUsRUFBRTtBQUFyQztBQUE3RSxPQUFuQztBQUE4SkgsVUFBTSxFQUFFLFNBQXRLO0FBQTRLQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFL0QsWUFBWDtBQUF5QmdFLGdCQUFVLEVBQUU7QUFBckM7QUFBdEwsR0FBM0IsQ0FkRixlQWVFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0wsc0RBQXBCLEVBQTJCO0FBQUVLLGFBQVMsRUFBRVIsUUFBYjtBQUF1QjlLLFVBQU0sRUFBRSxTQUEvQjtBQUFxQ0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRS9ELFlBQVg7QUFBeUJnRSxnQkFBVSxFQUFFO0FBQXJDO0FBQS9DLEdBQTNCLENBZkYsQ0FERixDQVZKLENBREY7QUFnQ0QsQ0EzQ0Q7O0FBNkNBLE1BQU1vTCxlQUFlLEdBQUlDLEtBQUQsS0FBWTtBQUNsQ3RDLFNBQU8sRUFBRXNDLEtBQUssQ0FBQ0MsV0FBTixDQUFrQnZDO0FBRE8sQ0FBWixDQUF4Qjs7QUFJZWUsMEhBQU8sQ0FBQ3NCLGVBQUQsRUFBa0IsSUFBbEIsQ0FBUCxDQUErQjFCLFNBQS9CLENBQWYsRTs7Ozs7Ozs7Ozs7O0FDbkhBO0FBQUE7QUFBQTs7QUFFQSxNQUFNM0MsV0FBVyxHQUFHLENBQUN6SCxhQUFELEVBQWdCQyx1QkFBaEIsS0FBNEM7QUFDOUQsT0FBSyxNQUFNc0osR0FBWCxJQUFrQnZKLGFBQWxCLEVBQWlDO0FBQy9CLFFBQUl1SixHQUFHLENBQUMzSSxFQUFKLEtBQVdxTCxzRUFBWCxJQUEyQmhNLHVCQUF1QixLQUFLZ00sc0VBQTNELEVBQXlFLE9BQU8sSUFBUDtBQUMxRTs7QUFFRCxTQUFPLEtBQVA7QUFDRCxDQU5EOztBQU9leEUsMEVBQWYsRSIsImZpbGUiOiJEYXNoYm9hcmRSb290XzRkM2ViZDhjMGY0NTJjNzFlOWM4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL2NsaWVudC9jb21wb25lbnRzL0FwcE1lbnUudHN4XCI7IGZ1bmN0aW9uIF9vcHRpb25hbENoYWluKG9wcykgeyBsZXQgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgbGV0IHZhbHVlID0gb3BzWzBdOyBsZXQgaSA9IDE7IHdoaWxlIChpIDwgb3BzLmxlbmd0aCkgeyBjb25zdCBvcCA9IG9wc1tpXTsgY29uc3QgZm4gPSBvcHNbaSArIDFdOyBpICs9IDI7IGlmICgob3AgPT09ICdvcHRpb25hbEFjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSAmJiB2YWx1ZSA9PSBudWxsKSB7IHJldHVybiB1bmRlZmluZWQ7IH0gaWYgKG9wID09PSAnYWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJykgeyBsYXN0QWNjZXNzTEhTID0gdmFsdWU7IHZhbHVlID0gZm4odmFsdWUpOyB9IGVsc2UgaWYgKG9wID09PSAnY2FsbCcgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSB7IHZhbHVlID0gZm4oKC4uLmFyZ3MpID0+IHZhbHVlLmNhbGwobGFzdEFjY2Vzc0xIUywgLi4uYXJncykpOyBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyB9IH0gcmV0dXJuIHZhbHVlOyB9aW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5pbXBvcnQgTWVudSBmcm9tICcuL01lbnUnXG5cbmltcG9ydCBNZW51SXRlbSBmcm9tICcuL01lbnVJdGVtJ1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICd1bml2ZXJzYWwvc3R5bGVzL3BhbGV0dGUnXG5pbXBvcnQgdGV4dE92ZXJmbG93IGZyb20gJ3VuaXZlcnNhbC9zdHlsZXMvaGVscGVycy90ZXh0T3ZlcmZsb3cnXG5pbXBvcnQgdXNlUm91dGVyIGZyb20gJ2NsaWVudC9ob29rcy91c2VSb3V0ZXInXG5pbXBvcnQgRG9jdW1lbnRhdGlvblNWRyBmcm9tICdjbGllbnQvY29tcG9uZW50cy9JY29ucy9Eb2N1bWVudGF0aW9uU1ZHJ1xuaW1wb3J0IFBsYWluQnV0dG9uIGZyb20gJy4uL2NvbXBvbmVudHMvUGxhaW5CdXR0b24nXG5pbXBvcnQge0JyYW5kfSBmcm9tICcuL1NpZGViYXInXG5pbXBvcnQgSWNvbiBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9JY29uJ1xuXG5cblxuXG5cblxuXG5jb25zdCBDb250YWluZXIgPSBzdHlsZWQuZGl2KHtcbiAgd2lkdGg6IDIyMFxufSlcblxuY29uc3QgSGVhZEJsb2NrID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXG4gIHBhZGRpbmc6ICcxMHB4IDE1cHgnLFxuICB1c2VyU2VsZWN0OiAnbm9uZScsXG4gIGN1cnNvcjogJ2RlZmF1bHQnLFxuICBib3JkZXJCb3R0b206IGAxcHggc29saWQgJHtQQUxFVFRFLkJPUkRFUl9HUkFZfWBcbn0pXG5cbmNvbnN0IEFjdGlvbkJsb2NrID0gc3R5bGVkLmRpdih7XG4gIGJvcmRlckJvdHRvbTogYDFweCBzb2xpZCAke1BBTEVUVEUuQk9SREVSX0dSQVl9YCxcbiAgbWFyZ2luQm90dG9tOiA1LFxuICBwYWRkaW5nOiAnMTBweCAwJyxcbiAgbWF4SGVpZ2h0OiAnNjB2aCcsXG4gIG92ZXJmbG93OiAnYXV0bydcbn0pXG5cbmNvbnN0IE9yZ0NvbnRhaW5lciA9IHN0eWxlZChQbGFpbkJ1dHRvbikoe1xuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAganVzdGlmeUNvbnRlbnQ6ICdzdGFydCcsXG4gIG1hcmdpbkJvdHRvbTogMTAsXG4gIG1hcmdpbjogMCxcbiAgd2lkdGg6ICcxMDAlJyxcbiAgY3Vyc29yOiAncG9pbnRlcicsXG4gIGNvbG9yOiBQQUxFVFRFLlRFWFRfR1JBWVxufSlcblxuY29uc3QgT3JnTmFtZSA9IHN0eWxlZC5kaXYoKHthY3RpdmV9KSA9PiAoe1xuICBqdXN0aWZ5Q29udGVudDogJ2ZsZXgtc3RhcnQnLFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICBwYWRkaW5nOiAwLFxuICAuLi50ZXh0T3ZlcmZsb3csXG4gIGNvbG9yOiBhY3RpdmUgPyBQQUxFVFRFLlRFWFRfTUFJTiA6ICcjNGQ0ZDRkJyxcbiAgJzpob3Zlcic6IHtcbiAgICBjb2xvcjogUEFMRVRURS5URVhUX01BSU5cbiAgfVxufSkpXG5cbmNvbnN0IFN0eWxlZE5hbWUgPSBzdHlsZWQuZGl2KHtcbiAgY29sb3I6IFBBTEVUVEUuVEVYVF9NQUlOLFxuICBmb250U2l6ZTogMTUsXG4gIGZvbnRXZWlnaHQ6IDUwMCxcbiAgbWFyZ2luQm90dG9tOiAyLFxuICAuLi50ZXh0T3ZlcmZsb3dcbn0pXG5cbmNvbnN0IFN0eWxlZEVtYWlsID0gc3R5bGVkLmRpdih7XG4gIGZvbnRTaXplOiAxMyxcbiAgY29sb3I6IFBBTEVUVEUuVEVYVF9HUkFZLFxuICBmb250V2VpZ2h0OiA0MDAsXG4gIC4uLnRleHRPdmVyZmxvd1xufSlcblxuY29uc3QgTGFiZWwgPSBzdHlsZWQuZGl2KHtcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBmbGV4RGlyZWN0aW9uOiAncm93JyxcbiAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gIHBhZGRpbmc6ICc1cHggMTBweCcsXG4gIHdpZHRoOiAnMTAwJSdcbn0pXG5cbmNvbnN0IFRleHQgPSBzdHlsZWQuZGl2KHtcbiAgY29sb3I6IFBBTEVUVEUuVEVYVF9NQUlOLFxuICBtYXJnaW5MZWZ0OiAxNVxufSlcblxuY29uc3QgU3R5bGVkSWNvbiA9IHN0eWxlZChJY29uKSh7XG4gIG1hcmdpbjogMCxcbiAgcGFkZGluZzogMCxcbiAgY29sb3I6IFBBTEVUVEUuVEVYVF9NQUlOLFxuICBmb250U2l6ZTogMTZcbn0pXG5cbmNvbnN0IEFwcE1lbnUgPSAocHJvcHMpID0+IHtcbiAgY29uc3Qge1xuICAgIHRvZ2dsZVBvcnRhbCxcbiAgICBzd2l0Y2hVc2VyT3JnLFxuICAgIG1lbnVQcm9wcyxcbiAgICBuYW1lLFxuICAgIGVtYWlsLFxuICAgIG9yZ2FuaXphdGlvbnMsXG4gICAgY3VycmVudF9vcmdhbml6YXRpb25faWQsXG4gICAgdG9nZ2xlTW9kYWxQb3J0YWxcbiAgfSA9IHByb3BzXG4gIGNvbnN0IHtoaXN0b3J5fSA9IHVzZVJvdXRlcigpIFxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDExMX19XG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSGVhZEJsb2NrLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDExMn19XG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTdHlsZWROYW1lLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDExM319LCBuYW1lKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3R5bGVkRW1haWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTE0fX0sIGVtYWlsKVxuICAgICAgKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEFjdGlvbkJsb2NrLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDExNn19XG4gICAgICAgICwgb3JnYW5pemF0aW9ucy5tYXAoKHtuYW1lLCBpZH0pID0+IChcbiAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KE9yZ0NvbnRhaW5lciwgeyBrZXk6IGlkLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTE4fX1cbiAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChCcmFuZCwgeyBhY3RpdmU6IGlkID09PSBjdXJyZW50X29yZ2FuaXphdGlvbl9pZCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDExOX19LCBfb3B0aW9uYWxDaGFpbihbbmFtZSwgJ29wdGlvbmFsQWNjZXNzJywgXyA9PiBfLmNoYXJBdCwgJ2NhbGwnLCBfMiA9PiBfMigwKV0pKVxuICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KE9yZ05hbWUsIHtcbiAgICAgICAgICAgICAgb25DbGljazogKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRvZ2dsZVBvcnRhbCgpXG4gICAgICAgICAgICAgICAgc3dpdGNoVXNlck9yZyhpZClcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgYWN0aXZlOiBpZCA9PT0gY3VycmVudF9vcmdhbml6YXRpb25faWQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMjB9fVxuICAgICAgICAgICAgXG4gICAgICAgICAgICAgICwgbmFtZVxuICAgICAgICAgICAgKVxuICAgICAgICAgIClcbiAgICAgICAgKSlcbiAgICAgIClcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChBY3Rpb25CbG9jaywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMzJ9fVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTWVudSwgeyBhcmlhTGFiZWw6ICdEb2N1bWVudGF0aW9uJywgLi4ubWVudVByb3BzLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTMzfX1cbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTWVudUl0ZW0sIHtcbiAgICAgICAgICAgIGxhYmVsOiBcbiAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMzZ9fVxuICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTdHlsZWRJY29uLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEzN319LCBcImFkZFwiKVxuICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0LCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEzOH19LCBcIkFkZCBvcmdhbml6YXRpb25cIiApXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICxcbiAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IHtcbiAgICAgICAgICAgICAgdG9nZ2xlTW9kYWxQb3J0YWwoKVxuICAgICAgICAgICAgfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEzNH19XG4gICAgICAgICAgKVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChNZW51SXRlbSwge1xuICAgICAgICAgICAgbGFiZWw6IFxuICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE0N319XG4gICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KERvY3VtZW50YXRpb25TVkcsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTQ4fX0gKVxuICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0LCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE0OX19LCBcIkRvY3VtZW50YXRpb25cIilcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgLFxuICAgICAgICAgICAgb25DbGljazogKCkgPT4gd2luZG93Lm9wZW4oJ2h0dHBzOi8vZG9jcy5odW1hbmxhbWJkYXMuY29tLycsICdfYmxhbmsnKSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE0NX19XG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTWVudSwgeyBhcmlhTGFiZWw6ICdVc2VyIG1lbnUnLCAuLi5tZW51UHJvcHMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNTZ9fVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTWVudUl0ZW0sIHtcbiAgICAgICAgICBsYWJlbDogXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE1OX19XG4gICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTdHlsZWRJY29uLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE2MH19LCBcImV4aXRfdG9fYXBwXCIpXG4gICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0LCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE2MX19LCBcIlNpZ24gb3V0XCIgKVxuICAgICAgICAgICAgKVxuICAgICAgICAgICxcbiAgICAgICAgICBvbkNsaWNrOiAoKSA9PiBoaXN0b3J5LnB1c2goJy9zaWdub3V0JyksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNTd9fVxuICAgICAgICApXG4gICAgICApXG4gICAgKVxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcE1lbnVcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy9jbGllbnQvY29tcG9uZW50cy9Eb3QudHN4XCI7aW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcblxuXG5cblxuXG5jb25zdCBTdHlsZWREb3QgPSBzdHlsZWQuZGl2KCh7Y29sb3J9KSA9PiAoe1xuICBoZWlnaHQ6IDEwLFxuICB3aWR0aDogMTAsXG4gIGJvcmRlclJhZGl1czogNTAsXG4gIGJhY2tncm91bmRDb2xvcjogY29sb3IsXG4gIG1hcmdpblJpZ2h0OiAxMFxufSkpXG5cbmNvbnN0IERvdCA9IFJlYWN0Lm1lbW8oKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtjb2xvcn0gPSBwcm9wc1xuICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChTdHlsZWREb3QsIHsgY29sb3I6IGNvbG9yLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTh9fSApXG59KVxuXG5leHBvcnQgZGVmYXVsdCBEb3RcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy9jbGllbnQvY29tcG9uZW50cy9JY29ucy9BcnJvd0Rvd25TVkcudHN4XCI7aW1wb3J0IFJlYWN0LCB7bWVtb30gZnJvbSAncmVhY3QnXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3N0eWxlcy9wYWxldHRlJ1xuXG5jb25zdCBBcnJvd0Rvd25TVkcgPSBtZW1vKCgpID0+IHtcbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KCdzdmcnLCB7XG4gICAgICBoZWlnaHQ6IFwiMTNcIixcbiAgICAgIHZpZXdCb3g6IFwiMCAwIDUxNS41NTUgNTE1LjU1NVwiICAgLFxuICAgICAgd2lkdGg6IFwiMTNcIixcbiAgICAgIHhtbG5zOiBcImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIsXG4gICAgICBmaWxsOiBQQUxFVFRFLlRFWFRfTUFJTiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDZ9fVxuICAgIFxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdwYXRoJywgeyBkOiBcIk00MDAgMjE2YTIzLjkyOCAyMy45MjggMCAwMS0xNi45NzEtNy4wMjlMMjU2IDgxLjk0MWwtMTI3LjAyOSAxMjcuMDNhMjQgMjQgMCAwMS0zMy45NDItMzMuOTQybDE0NC0xNDRhMjQgMjQgMCAwMTMzLjk0MiAwbDE0NCAxNDRBMjQgMjQgMCAwMTQwMCAyMTZ6TTI3Mi45NzEgNDgwLjk3MWwxNDQtMTQ0YTI0IDI0IDAgMDAtMzMuOTQyLTMzLjk0MkwyNTYgNDMwLjA1OWwtMTI3LjAyOS0xMjcuMDNhMjQgMjQgMCAwMC0zMy45NDIgMzMuOTQybDE0NCAxNDRhMjQgMjQgMCAwMDMzLjk0MiAwelwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxM319IClcbiAgICApXG4gIClcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IEFycm93RG93blNWR1xuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL2NsaWVudC9jb21wb25lbnRzL0ljb25zL0F1ZGl0c1NWRy50c3hcIjtpbXBvcnQgUmVhY3QsIHttZW1vfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7UEFMRVRURX0gZnJvbSAnc3R5bGVzL3BhbGV0dGUnXG5cbmNvbnN0IFVzZXJzU1ZHID0gbWVtbygoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudCgnc3ZnJywge1xuICAgICAgaGVpZ2h0OiBcIjE1XCIsXG4gICAgICB2aWV3Qm94OiBcIjAgMCA1MTUuNTU1IDUxNS41NTVcIiAgICxcbiAgICAgIHdpZHRoOiBcIjE3XCIsXG4gICAgICB4bWxuczogXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiLFxuICAgICAgZmlsbDogUEFMRVRURS5URVhUX01BSU4sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2fX1cbiAgICBcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgncGF0aCcsIHsgZDogXCJNMzI1LjUgNDBoLTc1LjQyNmMtOC4yNTgtMjMuMjgxLTMwLjUtNDAtNTYuNTc0LTQwcy00OC4zMTYgMTYuNzE5LTU2LjU3NCA0MEg2MC41Yy0zMy4wODYgMC02MCAyNi45MTQtNjAgNjB2MzUyYzAgMzMuMDg2IDI2LjkxNCA2MCA2MCA2MGgyNjUuMDYzYzMzLjA1LS4wMzUgNTkuOTM3LTI2Ljk1IDU5LjkzNy02MFYxMDBjMC0zMy4wODYtMjYuOTE0LTYwLTYwLTYwem0tMTUyIDQwVjYwYzAtMTEuMDI3IDguOTczLTIwIDIwLTIwczIwIDguOTczIDIwIDIwdjIwaDQwdjM5aC0xMjBWODB6bTE3MiAzNzJjMCAxMS4wMTYtOC45NjUgMTkuOTg4LTE5Ljk1NyAyMEg2MC41Yy0xMS4wMjcgMC0yMC04Ljk3My0yMC0yMFYxMDBjMC0xMS4wMjcgOC45NzMtMjAgMjAtMjBoMzN2NzloMjAwVjgwaDMyYzExLjAyNyAwIDIwIDguOTczIDIwIDIwem0tNzUuNzkzLTIyMS45NmwyOS41ODIgMjYuOTJMMTcxLjIgMzk3LjcxbC04NC42MDUtODEuODM1IDI3LjgxMi0yOC43NSA1NC45NjUgNTMuMTY0em0wIDBcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxM319IClcbiAgICApXG4gIClcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IFVzZXJzU1ZHXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvY2xpZW50L2NvbXBvbmVudHMvSWNvbnMvRG9jdW1lbnRhdGlvblNWRy50c3hcIjtpbXBvcnQgUmVhY3QsIHttZW1vfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7UEFMRVRURX0gZnJvbSAnc3R5bGVzL3BhbGV0dGUnXG5cbmNvbnN0IERvY3VtZW50YXRpb25TVkcgPSBtZW1vKCgpID0+IHtcbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KCdzdmcnLCB7XG4gICAgICBoZWlnaHQ6IFwiMTVcIixcbiAgICAgIHZpZXdCb3g6IFwiMCAwIDUxNS41NTUgNTE1LjU1NVwiICAgLFxuICAgICAgd2lkdGg6IFwiMTVcIixcbiAgICAgIHhtbG5zOiBcImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIsXG4gICAgICBmaWxsOiBQQUxFVFRFLlRFWFRfTUFJTiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDZ9fVxuICAgIFxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdwYXRoJywgeyBkOiBcIk00ODQuMzMzIDI1NmMwLTE5LjczLTIuNTE1LTM5LjI0OC03LjQ4NC01OC4xNjJsMjguOS0yMS4yNjEtNTYuMDkzLTk3LjE1NS0zMi45MTMgMTQuNDJjLTI4LjEzOC0yNy45MzgtNjIuNTk0LTQ3Ljg0Ny0xMDAuNjg5LTU4LjE4TDMxMi4wOTMgMEgxOTkuOTA3bC0zLjk2MiAzNS42NjJjLTM4LjA5NiAxMC4zMzMtNzIuNTUxIDMwLjI0Mi0xMDAuNjg5IDU4LjE4bC0zMi45MTItMTQuNDItNTYuMDkzIDk3LjE1NSAyOC45IDIxLjI2MWMtNC45NyAxOC45MTQtNy40ODQgMzguNDMyLTcuNDg0IDU4LjE2MnMyLjUxNSAzOS4yNDggNy40ODQgNTguMTYybC0yOC45IDIxLjI2IDU2LjA5MyA5Ny4xNTUgMzIuOTEyLTE0LjQyYzI4LjEzOSAyNy45MzkgNjIuNTk0IDQ3Ljg0OCAxMDAuNjg5IDU4LjE4TDE5OS45MDcgNTEyaDExMi4xODZsMy45NjItMzUuNjYzYzM4LjA5Ni0xMC4zMzIgNzIuNTUxLTMwLjI0MiAxMDAuNjg5LTU4LjE4bDMyLjkxMiAxNC40MiA1Ni4wOTMtOTcuMTU1LTI4LjktMjEuMjZjNC45NjktMTguOTE0IDcuNDg0LTM4LjQzMiA3LjQ4NC01OC4xNjJ6TTI5OS4wNjEgNDQ5LjYzM2wtMTAuNDgxIDIuMzJMMjg1LjI0MSA0ODJoLTU4LjQ4MmwtMy4zMzktMzAuMDQ3LTEwLjQ4MS0yLjMyYy0zOS43MzktOC43OTUtNzUuMzgyLTI5LjM4OS0xMDMuMDc0LTU5LjU1NWwtNy4yNS03Ljg5OC0yNy43MTYgMTIuMTQzLTI5LjI0MS01MC42NDcgMjQuMzI1LTE3Ljg5NC0zLjIxNi0xMC4yMjhjLTYuMDM4LTE5LjIwNy05LjEtMzkuMjQ0LTkuMS01OS41NTQgMC0yMC4zMTEgMy4wNjItNDAuMzQ4IDkuMS01OS41NTRsMy4yMTYtMTAuMjI4LTI0LjMyNS0xNy44OTQgMjkuMjQxLTUwLjY0NyAyNy43MTYgMTIuMTQzIDcuMjUtNy44OThjMjcuNjkyLTMwLjE2NiA2My4zMzUtNTAuNzYgMTAzLjA3NC01OS41NTVsMTAuNDgxLTIuMzJMMjI2Ljc1OSAzMGg1OC40ODJsMy4zMzkgMzAuMDQ3IDEwLjQ4MSAyLjMyYzM5LjczOSA4Ljc5NiA3NS4zODIgMjkuMzkgMTAzLjA3NCA1OS41NTVsNy4yNSA3Ljg5OCAyNy43MTYtMTIuMTQzIDI5LjI0MSA1MC42NDctMjQuMzI1IDE3Ljg5NCAzLjIxNiAxMC4yMjhjNi4wMzggMTkuMjA3IDkuMSAzOS4yNDQgOS4xIDU5LjU1NHMtMy4wNjEgNDAuMzQ3LTkuMSA1OS41NTRsLTMuMjE2IDEwLjIyOCAyNC4zMjUgMTcuODk0LTI5LjI0MSA1MC42NDctMjcuNzE2LTEyLjE0My03LjI1IDcuODk4Yy0yNy42OTIgMzAuMTY2LTYzLjMzNCA1MC43Ni0xMDMuMDc0IDU5LjU1NXpcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTN9fSApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3BhdGgnLCB7IGQ6IFwiTTE5Ni40NDggMjIxLjY2bC0yMS40MzMtMjAuOTktNTQuODYzIDU2LjAxOSA1Ni4wMiA1NC44NjMgMjAuOTktMjEuNDM0LTM0LjU4Ni0zMy44NzJ6TTMxNS41NTIgMjIxLjY2bDMzLjg3MiAzNC41ODYtMzQuNTg2IDMzLjg3MiAyMC45OSAyMS40MzQgNTYuMDItNTQuODYzLTU0Ljg2My01Ni4wMTl6TTIyMC4wOTcgMzU0LjE3Nmw0Mi42NjQtMjAyLjc2IDI5LjM3MSA2LjE4LTQyLjY2NCAyMDIuNzZ6XCIgICAgICAgICAgICAgICAsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNH19IClcbiAgICApXG4gIClcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IERvY3VtZW50YXRpb25TVkdcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy9jbGllbnQvY29tcG9uZW50cy9JY29ucy9NZXRyaWNzU1ZHLnRzeFwiO2ltcG9ydCBSZWFjdCwge21lbW99IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICdzdHlsZXMvcGFsZXR0ZSdcblxuY29uc3QgTWV0cmljU1ZHID0gbWVtbygoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudCgnc3ZnJywge1xuICAgICAgaGVpZ2h0OiBcIjE1XCIsXG4gICAgICB2aWV3Qm94OiBcIjAgMCA1MTUuNTU1IDUxNS41NTVcIiAgICxcbiAgICAgIHdpZHRoOiBcIjE1XCIsXG4gICAgICB4bWxuczogXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiLFxuICAgICAgZmlsbDogUEFMRVRURS5URVhUX01BSU4sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2fX1cbiAgICBcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgncGF0aCcsIHsgZDogXCJNMjk4LjY2NyA4NS4zMzNsNDguOTYgNDguOTYtMTA0LjEwNyAxMDQtODUuMzMzLTg1LjMzM0wwIDMxMS4xNDdsMzAuMTg3IDMwLjE4NiAxMjgtMTI4IDg1LjMzMyA4NS4zMzQgMTM0LjE4Ny0xMzQuMjk0IDQ4Ljk2IDQ4Ljk2di0xMjh6XCIgICAgICAgICAgICwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEzfX0gKVxuICAgIClcbiAgKVxufSlcblxuZXhwb3J0IGRlZmF1bHQgTWV0cmljU1ZHXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvY2xpZW50L2NvbXBvbmVudHMvSWNvbnMvUXVldWVTVkcudHN4XCI7aW1wb3J0IFJlYWN0LCB7bWVtb30gZnJvbSAncmVhY3QnXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3N0eWxlcy9wYWxldHRlJ1xuXG5jb25zdCBRdWV1ZVNWRyA9IG1lbW8oKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3N2ZycsIHtcbiAgICAgIGhlaWdodDogXCIxNVwiLFxuICAgICAgdmlld0JveDogXCIwIDAgNTE1LjU1NSA1MTUuNTU1XCIgICAsXG4gICAgICB3aWR0aDogXCIxNVwiLFxuICAgICAgeG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIixcbiAgICAgIGZpbGw6IFBBTEVUVEUuVEVYVF9NQUlOLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNn19XG4gICAgXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3N2ZycsIHsgeG1sbnM6IFwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiwgdmlld0JveDogXCIwIDAgNDI2LjY2NyA0MjYuNjY3XCIgICAsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxM319XG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgncGF0aCcsIHsgZDogXCJNMzQxLjMzMyA1My4zMzNMMjU2IDEzOC42NjdoNjRWMjg4YzAgMjMuNTczLTE5LjA5MyA0Mi42NjctNDIuNjY3IDQyLjY2Ny0yMy41NzMgMC00Mi42NjctMTkuMDkzLTQyLjY2Ny00Mi42NjdWMTM4LjY2N2MwLTQ3LjA0LTM4LjI5My04NS4zMzMtODUuMzMzLTg1LjMzM1M2NCA5MS42MjcgNjQgMTM4LjY2N1YyODhIMGw4NS4zMzMgODUuMzMzTDE3MC42NjcgMjg4aC02NFYxMzguNjY3YzAtMjMuNTczIDE5LjA5My00Mi42NjcgNDIuNjY3LTQyLjY2N1MxOTIgMTE1LjA5MyAxOTIgMTM4LjY2N1YyODhjMCA0Ny4wNCAzOC4yOTMgODUuMzMzIDg1LjMzMyA4NS4zMzNTMzYyLjY2NiAzMzUuMDQgMzYyLjY2NiAyODhWMTM4LjY2N2g2NGwtODUuMzMzLTg1LjMzNHpcIiAgICAgICAgICAgICAgICAgICAgICAgICwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE0fX0gKVxuICAgICAgKVxuICAgIClcbiAgKVxufSlcblxuZXhwb3J0IGRlZmF1bHQgUXVldWVTVkdcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy9jbGllbnQvY29tcG9uZW50cy9JY29ucy9TZXR0aW5nc1NWRy50c3hcIjtpbXBvcnQgUmVhY3QsIHttZW1vfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7UEFMRVRURX0gZnJvbSAnc3R5bGVzL3BhbGV0dGUnXG5cbmNvbnN0IFNldHRpbmdzU1ZHID0gbWVtbygoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudCgnc3ZnJywge1xuICAgICAgaGVpZ2h0OiBcIjE1XCIsXG4gICAgICB2aWV3Qm94OiBcIjAgMCA1MTUuNTU1IDUxNS41NTVcIiAgICxcbiAgICAgIHdpZHRoOiBcIjE1XCIsXG4gICAgICB4bWxuczogXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiLFxuICAgICAgZmlsbDogUEFMRVRURS5URVhUX01BSU4sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2fX1cbiAgICBcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgncGF0aCcsIHsgZDogXCJNMjcyLjA2NiA1MTJoLTMyLjEzM2MtMjUuOTg5IDAtNDcuMTM0LTIxLjE0NC00Ny4xMzQtNDcuMTMzdi0xMC44NzFhMjA2LjY5OCAyMDYuNjk4IDAgMDEtMzIuMDk3LTEzLjMyM2wtNy43MDQgNy43MDRjLTE4LjY1OSAxOC42ODItNDguNTQ4IDE4LjEzNC02Ni42NjUtLjAwN2wtMjIuNzExLTIyLjcxYy0xOC4xNDktMTguMTI5LTE4LjY3MS00OC4wMDguMDA2LTY2LjY2NWw3LjY5OC03LjY5OEEyMDYuNzE0IDIwNi43MTQgMCAwMTU4LjAwMyAzMTkuMmgtMTAuODdDMjEuMTQ1IDMxOS4yIDAgMjk4LjA1NiAwIDI3Mi4wNjd2LTMyLjEzNEMwIDIxMy45NDQgMjEuMTQ1IDE5Mi44IDQ3LjEzNCAxOTIuOGgxMC44N2EyMDYuNzU1IDIwNi43NTUgMCAwMTEzLjMyMy0zMi4wOTdMNjMuNjIzIDE1M2MtMTguNjY2LTE4LjY0Ni0xOC4xNTEtNDguNTI4LjAwNi02Ni42NjVsMjIuNzEzLTIyLjcxMmMxOC4xNTktMTguMTg0IDQ4LjA0MS0xOC42MzggNjYuNjY0LjAwNmw3LjY5NyA3LjY5N0EyMDYuODkzIDIwNi44OTMgMCAwMTE5Mi44IDU4LjAwM3YtMTAuODdDMTkyLjggMjEuMTQ0IDIxMy45NDQgMCAyMzkuOTM0IDBoMzIuMTMzQzI5OC4wNTYgMCAzMTkuMiAyMS4xNDQgMzE5LjIgNDcuMTMzdjEwLjg3MWEyMDYuNjk4IDIwNi42OTggMCAwMTMyLjA5NyAxMy4zMjNsNy43MDQtNy43MDRjMTguNjU5LTE4LjY4MiA0OC41NDgtMTguMTM0IDY2LjY2NS4wMDdsMjIuNzExIDIyLjcxYzE4LjE0OSAxOC4xMjkgMTguNjcxIDQ4LjAwOC0uMDA2IDY2LjY2NWwtNy42OTggNy42OThhMjA2LjcxNCAyMDYuNzE0IDAgMDExMy4zMjMgMzIuMDk3aDEwLjg3YzI1Ljk4OSAwIDQ3LjEzNCAyMS4xNDQgNDcuMTM0IDQ3LjEzM3YzMi4xMzRjMCAyNS45ODktMjEuMTQ1IDQ3LjEzMy00Ny4xMzQgNDcuMTMzaC0xMC44N2EyMDYuNzU1IDIwNi43NTUgMCAwMS0xMy4zMjMgMzIuMDk3bDcuNzA0IDcuNzA0YzE4LjY2NiAxOC42NDYgMTguMTUxIDQ4LjUyOC0uMDA2IDY2LjY2NWwtMjIuNzEzIDIyLjcxMmMtMTguMTU5IDE4LjE4NC00OC4wNDEgMTguNjM4LTY2LjY2NC0uMDA2bC03LjY5Ny03LjY5N2EyMDYuODkzIDIwNi44OTMgMCAwMS0zMi4wOTcgMTMuMzIzdjEwLjg3MWMwIDI1Ljk4Ny0yMS4xNDQgNDcuMTMxLTQ3LjEzNCA0Ny4xMzF6TTE2NS43MTcgNDA5LjE3YTE3Ni44MTIgMTc2LjgxMiAwIDAwNDUuODMxIDE5LjAyNSAxNC45OTkgMTQuOTk5IDAgMDExMS4yNTIgMTQuNTI0djIyLjE0OGMwIDkuNDQ3IDcuNjg3IDE3LjEzMyAxNy4xMzQgMTcuMTMzaDMyLjEzM2M5LjQ0NyAwIDE3LjEzNC03LjY4NiAxNy4xMzQtMTcuMTMzdi0yMi4xNDhhMTQuOTk5IDE0Ljk5OSAwIDAxMTEuMjUyLTE0LjUyNCAxNzYuODEyIDE3Ni44MTIgMCAwMDQ1LjgzMS0xOS4wMjUgMTUgMTUgMCAwMTE4LjI0MyAyLjMwNWwxNS42ODggMTUuNjg5YzYuNzY0IDYuNzcyIDE3LjYyNiA2LjYxNSAyNC4yMjQuMDA3bDIyLjcyNy0yMi43MjZjNi41ODItNi41NzQgNi44MDItMTcuNDM4LjAwNi0yNC4yMjVsLTE1LjY5NS0xNS42OTVhMTUgMTUgMCAwMS0yLjMwNS0xOC4yNDIgMTc2Ljc4IDE3Ni43OCAwIDAwMTkuMDI0LTQ1LjgzMSAxNSAxNSAwIDAxMTQuNTI0LTExLjI1MWgyMi4xNDdjOS40NDcgMCAxNy4xMzQtNy42ODYgMTcuMTM0LTE3LjEzM3YtMzIuMTM0YzAtOS40NDctNy42ODctMTcuMTMzLTE3LjEzNC0xNy4xMzNINDQyLjcyYTE1IDE1IDAgMDEtMTQuNTI0LTExLjI1MSAxNzYuODE1IDE3Ni44MTUgMCAwMC0xOS4wMjQtNDUuODMxIDE1IDE1IDAgMDEyLjMwNS0xOC4yNDJsMTUuNjg5LTE1LjY4OWM2Ljc4Mi02Ljc3NCA2LjYwNS0xNy42MzQuMDA2LTI0LjIyNWwtMjIuNzI1LTIyLjcyNWMtNi41ODctNi41OTYtMTcuNDUxLTYuNzg5LTI0LjIyNS0uMDA2bC0xNS42OTQgMTUuNjk1YTE1IDE1IDAgMDEtMTguMjQzIDIuMzA1IDE3Ni44MTIgMTc2LjgxMiAwIDAwLTQ1LjgzMS0xOS4wMjUgMTQuOTk5IDE0Ljk5OSAwIDAxLTExLjI1Mi0xNC41MjR2LTIyLjE1YzAtOS40NDctNy42ODctMTcuMTMzLTE3LjEzNC0xNy4xMzNoLTMyLjEzM2MtOS40NDcgMC0xNy4xMzQgNy42ODYtMTcuMTM0IDE3LjEzM3YyMi4xNDhhMTQuOTk5IDE0Ljk5OSAwIDAxLTExLjI1MiAxNC41MjQgMTc2LjgxMiAxNzYuODEyIDAgMDAtNDUuODMxIDE5LjAyNSAxNS4wMDIgMTUuMDAyIDAgMDEtMTguMjQzLTIuMzA1bC0xNS42ODgtMTUuNjg5Yy02Ljc2NC02Ljc3Mi0xNy42MjctNi42MTUtMjQuMjI0LS4wMDdsLTIyLjcyNyAyMi43MjZjLTYuNTgyIDYuNTc0LTYuODAyIDE3LjQzNy0uMDA2IDI0LjIyNWwxNS42OTUgMTUuNjk1YTE1IDE1IDAgMDEyLjMwNSAxOC4yNDIgMTc2Ljc4IDE3Ni43OCAwIDAwLTE5LjAyNCA0NS44MzEgMTUgMTUgMCAwMS0xNC41MjQgMTEuMjUxSDQ3LjEzNEMzNy42ODcgMjIyLjggMzAgMjMwLjQ4NiAzMCAyMzkuOTMzdjMyLjEzNGMwIDkuNDQ3IDcuNjg3IDE3LjEzMyAxNy4xMzQgMTcuMTMzaDIyLjE0N2ExNSAxNSAwIDAxMTQuNTI0IDExLjI1MSAxNzYuODE1IDE3Ni44MTUgMCAwMDE5LjAyNCA0NS44MzEgMTUgMTUgMCAwMS0yLjMwNSAxOC4yNDJsLTE1LjY4OSAxNS42ODljLTYuNzgyIDYuNzc0LTYuNjA1IDE3LjYzNC0uMDA2IDI0LjIyNWwyMi43MjUgMjIuNzI1YzYuNTg3IDYuNTk2IDE3LjQ1MSA2Ljc4OSAyNC4yMjUuMDA2bDE1LjY5NC0xNS42OTVjMy41NjgtMy41NjcgMTAuOTkxLTYuNTk0IDE4LjI0NC0yLjMwNHpcIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEzfX0gKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdwYXRoJywgeyBkOiBcIk0yNTYgMzY3LjRjLTYxLjQyNyAwLTExMS40LTQ5Ljk3NC0xMTEuNC0xMTEuNFMxOTQuNTczIDE0NC42IDI1NiAxNDQuNiAzNjcuNCAxOTQuNTc0IDM2Ny40IDI1NiAzMTcuNDI3IDM2Ny40IDI1NiAzNjcuNHptMC0xOTIuOGMtNDQuODg1IDAtODEuNCAzNi41MTYtODEuNCA4MS40czM2LjUxNiA4MS40IDgxLjQgODEuNCA4MS40LTM2LjUxNiA4MS40LTgxLjQtMzYuNTE1LTgxLjQtODEuNC04MS40elwiICAgICAgICAgICAgICAgICAgICAgLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTR9fSApXG4gICAgKVxuICApXG59KVxuXG5leHBvcnQgZGVmYXVsdCBTZXR0aW5nc1NWR1xuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL2NsaWVudC9jb21wb25lbnRzL0ljb25zL1VzZXJzU1ZHLnRzeFwiO2ltcG9ydCBSZWFjdCwge21lbW99IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICdzdHlsZXMvcGFsZXR0ZSdcblxuY29uc3QgVXNlcnNTVkcgPSBtZW1vKCgpID0+IHtcbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KCdzdmcnLCB7XG4gICAgICBoZWlnaHQ6IFwiMTVcIixcbiAgICAgIHZpZXdCb3g6IFwiMCAwIDUxNS41NTUgNTE1LjU1NVwiICAgLFxuICAgICAgd2lkdGg6IFwiMTdcIixcbiAgICAgIHhtbG5zOiBcImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIsXG4gICAgICBmaWxsOiBQQUxFVFRFLlRFWFRfTUFJTiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDZ9fVxuICAgIFxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdwYXRoJywgeyBkOiBcIk0yMTAuMzUyIDI0Ni42MzNjMzMuODgyIDAgNjMuMjE4LTEyLjE1MyA4Ny4xOTUtMzYuMTMgMjMuOTY5LTIzLjk3MiAzNi4xMjUtNTMuMzA0IDM2LjEyNS04Ny4xOSAwLTMzLjg3Ni0xMi4xNTItNjMuMjExLTM2LjEyOS04Ny4xOTJDMjczLjU2NiAxMi4xNTIgMjQ0LjIzIDAgMjEwLjM1MiAwYy0zMy44ODcgMC02My4yMiAxMi4xNTItODcuMTkyIDM2LjEyNXMtMzYuMTI5IDUzLjMwOS0zNi4xMjkgODcuMTg4YzAgMzMuODg2IDEyLjE1NiA2My4yMjIgMzYuMTMgODcuMTk1IDIzLjk4IDIzLjk2OSA1My4zMTYgMzYuMTI1IDg3LjE5IDM2LjEyNXpNMTQ0LjM3OSA1Ny4zNGMxOC4zOTQtMTguMzk1IDM5Ljk3My0yNy4zMzYgNjUuOTczLTI3LjMzNiAyNS45OTYgMCA0Ny41NzggOC45NDEgNjUuOTc2IDI3LjMzNiAxOC4zOTUgMTguMzk4IDI3LjM0IDM5Ljk4IDI3LjM0IDY1Ljk3MiAwIDI2LTguOTQ1IDQ3LjU3OS0yNy4zNCA2NS45NzctMTguMzk4IDE4LjM5OS0zOS45OCAyNy4zNC02NS45NzYgMjcuMzQtMjUuOTkzIDAtNDcuNTctOC45NDUtNjUuOTczLTI3LjM0LTE4LjM5OS0xOC4zOTQtMjcuMzQ0LTM5Ljk3Ni0yNy4zNDQtNjUuOTc2IDAtMjUuOTkzIDguOTQ1LTQ3LjU3NSAyNy4zNDQtNjUuOTczem0wIDBNNDI2LjEyOSAzOTMuNzAzYy0uNjkyLTkuOTc2LTIuMDktMjAuODYtNC4xNDktMzIuMzUxLTIuMDc4LTExLjU3OS00Ljc1My0yMi41MjQtNy45NTctMzIuNTI4LTMuMzEyLTEwLjM0LTcuODA4LTIwLjU1LTEzLjM3NS0zMC4zMzYtNS43Ny0xMC4xNTYtMTIuNTUtMTktMjAuMTYtMjYuMjc3LTcuOTU3LTcuNjEzLTE3LjY5OS0xMy43MzQtMjguOTY1LTE4LjItMTEuMjI2LTQuNDQtMjMuNjY4LTYuNjktMzYuOTc2LTYuNjktNS4yMjcgMC0xMC4yODEgMi4xNDQtMjAuMDQzIDguNWEyNzExLjAzIDI3MTEuMDMgMCAwMS0yMC44NzkgMTMuNDZjLTYuNzA3IDQuMjc0LTE1Ljc5MyA4LjI3OC0yNy4wMTYgMTEuOTAzLTEwLjk0OSAzLjU0My0yMi4wNjYgNS4zNC0zMy4wNDMgNS4zNC0xMC45NjggMC0yMi4wODYtMS43OTctMzMuMDQzLTUuMzQtMTEuMjEtMy42MjItMjAuMy03LjYyNS0yNi45OTYtMTEuODk5LTcuNzctNC45NjUtMTQuOC05LjQ5Ni0yMC44OTgtMTMuNDY5LTkuNzU0LTYuMzU1LTE0LjgwOS04LjUtMjAuMDM1LTguNS0xMy4zMTMgMC0yNS43NSAyLjI1NC0zNi45NzMgNi43LTExLjI1OCA0LjQ1Ny0yMS4wMDQgMTAuNTc4LTI4Ljk2OSAxOC4xOTktNy42MDkgNy4yODEtMTQuMzkgMTYuMTItMjAuMTU2IDI2LjI3My01LjU1OCA5Ljc4NS0xMC4wNTggMTkuOTkyLTEzLjM3MSAzMC4zNC0zLjIgMTAuMDA0LTUuODc1IDIwLjk0NS03Ljk1MyAzMi41MjQtMi4wNjMgMTEuNDc2LTMuNDU3IDIyLjM2My00LjE0OSAzMi4zNjNDLjM0MyA0MDMuNDkyIDAgNDEzLjY2OCAwIDQyMy45NDljMCAyNi43MjcgOC40OTYgNDguMzYzIDI1LjI1IDY0LjMyQzQxLjc5NyA1MDQuMDE3IDYzLjY4OCA1MTIgOTAuMzE2IDUxMmgyNDYuNTMyYzI2LjYyIDAgNDguNTExLTcuOTg0IDY1LjA2Mi0yMy43MyAxNi43NTgtMTUuOTQ2IDI1LjI1NC0zNy41OSAyNS4yNTQtNjQuMzI1LS4wMDQtMTAuMzE2LS4zNTEtMjAuNDkyLTEuMDM1LTMwLjI0MnptLTQ0LjkwNiA3Mi44MjhjLTEwLjkzNCAxMC40MDYtMjUuNDUgMTUuNDY1LTQ0LjM4IDE1LjQ2NUg5MC4zMTdjLTE4LjkzMyAwLTMzLjQ0OS01LjA1OS00NC4zNzktMTUuNDYtMTAuNzIyLTEwLjIwOC0xNS45MzMtMjQuMTQxLTE1LjkzMy00Mi41ODcgMC05LjU5NC4zMTYtMTkuMDY2Ljk1LTI4LjE2LjYxNi04LjkyMiAxLjg3OC0xOC43MjMgMy43NS0yOS4xMzcgMS44NDctMTAuMjg1IDQuMTk4LTE5LjkzNyA2Ljk5NS0yOC42NzUgMi42ODQtOC4zOCA2LjM0NC0xNi42NzYgMTAuODgzLTI0LjY2OCA0LjMzMi03LjYxOCA5LjMxNi0xNC4xNTMgMTQuODE2LTE5LjQxOCA1LjE0NS00LjkyNiAxMS42My04Ljk1NyAxOS4yNy0xMS45OCA3LjA2Ni0yLjc5OCAxNS4wMDgtNC4zMjkgMjMuNjI5LTQuNTYgMS4wNS41NiAyLjkyMiAxLjYyNiA1Ljk1MyAzLjYwMiA2LjE2OCA0LjAyIDEzLjI3NyA4LjYwNiAyMS4xMzcgMTMuNjI1IDguODYgNS42NDkgMjAuMjczIDEwLjc1IDMzLjkxIDE1LjE1MiAxMy45NDEgNC41MDggMjguMTYgNi43OTcgNDIuMjczIDYuNzk3IDE0LjExNCAwIDI4LjMzNi0yLjI4OSA0Mi4yNy02Ljc5MyAxMy42NDgtNC40MSAyNS4wNTgtOS41MDcgMzMuOTMtMTUuMTY0IDguMDQzLTUuMTQgMTQuOTUzLTkuNTkzIDIxLjEyLTEzLjYxNyAzLjAzMi0xLjk3MyA0LjkwMy0zLjA0MyA1Ljk1NC0zLjYwMSA4LjYyNS4yMyAxNi41NjYgMS43NjEgMjMuNjM2IDQuNTU4IDcuNjM3IDMuMDI0IDE0LjEyMiA3LjA1OSAxOS4yNjYgMTEuOTggNS41IDUuMjYyIDEwLjQ4NCAxMS43OTggMTQuODE2IDE5LjQyMyA0LjU0MyA3Ljk4OCA4LjIwOCAxNi4yODkgMTAuODg3IDI0LjY2IDIuODAxIDguNzUgNS4xNTYgMTguMzk4IDcgMjguNjc1IDEuODY3IDEwLjQzNCAzLjEzMyAyMC4yMzkgMy43NSAyOS4xNDV2LjAwOGMuNjM3IDkuMDU4Ljk1NyAxOC41MjcuOTYxIDI4LjE0OC0uMDA0IDE4LjQ1LTUuMjE1IDMyLjM4LTE1LjkzNyA0Mi41ODJ6bTAgMFwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEzfX0gKVxuICAgIClcbiAgKVxufSlcblxuZXhwb3J0IGRlZmF1bHQgVXNlcnNTVkdcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy9jbGllbnQvY29tcG9uZW50cy9OZXdPcmdNb2RhbC50c3hcIjtpbXBvcnQgUmVhY3QsIHt1c2VDYWxsYmFja30gZnJvbSAncmVhY3QnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcbmltcG9ydCB7Rm9ybWlrLCBGb3JtfSBmcm9tICdmb3JtaWsnXG5pbXBvcnQge29yZ2FuaXphdGlvblNjaGVtYX0gZnJvbSAndW5pdmVyc2FsL3ZhbGlkYXRpb25zL3l1cFNjaGVtYSdcbmltcG9ydCBJbnB1dEZpZWxkIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0lucHV0RmllbGQnXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ2NsaWVudC9zdHlsZXMvcGFsZXR0ZSdcbmltcG9ydCB7Qm94U2hhZG93fSBmcm9tICdjbGllbnQvdXRpbHMvY29uc3RhbnRzJ1xuaW1wb3J0IFNlY29uZGFyeUJ1dHRvbiBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9TZWNvbmRhcnlCdXR0b24nXG5pbXBvcnQgUHJpbWFyeUJ1dHRvbiBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9QcmltYXJ5QnV0dG9uJ1xuXG5cblxuXG5cblxuY29uc3QgTW9kYWxSb290ID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXG4gIHdpZHRoOiA1MDAsXG4gIGJvcmRlclJhZGl1czogMTAsXG4gIGJhY2tncm91bmRDb2xvcjogJyNmZmYnLFxuICBib3JkZXI6IGAxcHggc29saWQgJHtQQUxFVFRFLkJPUkRFUl9NQUlOX0dSQVl9YCxcbiAgYm94U2hhZG93OiBCb3hTaGFkb3cuTU9EQUxcbn0pXG5cbmNvbnN0IE1haW5UaXRsZSA9IHN0eWxlZC5kaXYoe1xuICBmb250U2l6ZTogMjIsXG4gIGZvbnRXZWlnaHQ6IDYwMCxcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgbWFyZ2luQm90dG9tOiAzNVxufSlcblxuY29uc3QgRm9ybUNvbnRlbnQgPSBzdHlsZWQoRm9ybSkoe1xuICBwYWRkaW5nOiAnNTBweCA1MHB4IDMwcHgnXG59KVxuXG5jb25zdCBCdXR0b25TZWN0aW9uID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdncmlkJyxcbiAgZ3JpZFRlbXBsYXRlQ29sdW1uczogJ3JlcGVhdCgyLCBhdXRvKScsXG4gIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsXG4gIHBhZGRpbmdUb3A6ICcyNXB4J1xufSlcblxuY29uc3QgTmV3T3JnTW9kYWwgPSAoe2Nsb3NlUG9ydGFsLCBoYW5kbGVOZXdPcmdhbml6YXRpb259KSA9PiB7XG4gIGNvbnN0IG9uU3VibWl0SGFuZGxlciA9IHVzZUNhbGxiYWNrKFxuICAgICh2YWx1ZXMsIGFjdGlvbnMpID0+IHtcbiAgICAgIGhhbmRsZU5ld09yZ2FuaXphdGlvbih2YWx1ZXMpXG4gICAgICBhY3Rpb25zLnNldFN1Ym1pdHRpbmcoKVxuICAgICAgY2xvc2VQb3J0YWwoKVxuICAgIH0sXG4gICAgW2Nsb3NlUG9ydGFsLCBoYW5kbGVOZXdPcmdhbml6YXRpb25dXG4gIClcbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KE1vZGFsUm9vdCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1NX19XG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRm9ybWlrLCB7XG4gICAgICAgIHZhbGlkYXRlT25DaGFuZ2U6IHRydWUsXG4gICAgICAgIGluaXRpYWxWYWx1ZXM6IHtuYW1lOiAnJ30sXG4gICAgICAgIHZhbGlkYXRpb25TY2hlbWE6IG9yZ2FuaXphdGlvblNjaGVtYSxcbiAgICAgICAgb25TdWJtaXQ6IG9uU3VibWl0SGFuZGxlciwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDU2fX1cbiAgICAgIFxuICAgICAgICAsICh7aXNTdWJtaXR0aW5nLCB2YWx1ZXMsIGhhbmRsZUNoYW5nZX0pID0+IChcbiAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEZvcm1Db250ZW50LCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDYzfX1cbiAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChNYWluVGl0bGUsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNjR9fSwgXCJBZGQgbmV3IG9yZ2FuaXphdGlvblwiICApXG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSW5wdXRGaWVsZCwge1xuICAgICAgICAgICAgICBwbGFjZWhvbGRlcjogXCJFbnRlciBvcmdhbml6YXRpb24gbmFtZVwiICAsXG4gICAgICAgICAgICAgIG5hbWU6IFwibmFtZVwiLFxuICAgICAgICAgICAgICB2YWx1ZTogdmFsdWVzLm5hbWUsXG4gICAgICAgICAgICAgIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2NX19XG4gICAgICAgICAgICApXG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnV0dG9uU2VjdGlvbiwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA3MX19XG4gICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTZWNvbmRhcnlCdXR0b24sIHsgdHlwZTogXCJidXR0b25cIiwgb25DbGljazogY2xvc2VQb3J0YWwsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA3Mn19LCBcIkNhbmNlbFwiXG5cbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUHJpbWFyeUJ1dHRvbiwgeyB0eXBlOiBcInN1Ym1pdFwiLCBkaXNhYmxlZDogaXNTdWJtaXR0aW5nLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNzV9fSwgXCJDcmVhdGVcIlxuXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgIClcbiAgICApXG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgTmV3T3JnTW9kYWxcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy9jbGllbnQvY29tcG9uZW50cy9TaWRlYmFyLnRzeFwiO2ltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IHtDbGFzc05hbWVzfSBmcm9tICdAZW1vdGlvbi9jb3JlJ1xuaW1wb3J0IHtOYXZMaW5rfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICd1bml2ZXJzYWwvc3R5bGVzL3BhbGV0dGUnXG5pbXBvcnQgdGV4dE92ZXJmbG93IGZyb20gJ3VuaXZlcnNhbC9zdHlsZXMvaGVscGVycy90ZXh0T3ZlcmZsb3cnXG5cbmltcG9ydCB7d2l0aFJvdXRlcn0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCBRdWV1ZUljb24gZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvSWNvbnMvUXVldWVTVkcnXG5pbXBvcnQgVXNlcnNJY29uIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0ljb25zL1VzZXJzU1ZHJ1xuaW1wb3J0IE1ldHJpY3NJY29uIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0ljb25zL01ldHJpY3NTVkcnXG5pbXBvcnQgU2V0dGluZ3NTVkcgZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvSWNvbnMvU2V0dGluZ3NTVkcnXG5pbXBvcnQgQXVkaXRzU1ZHIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0ljb25zL0F1ZGl0c1NWRydcbmltcG9ydCB1c2VNZW51IGZyb20gJ2NsaWVudC9ob29rcy91c2VNZW51J1xuaW1wb3J0IEFwcE1lbnUgZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvQXBwTWVudSdcbmltcG9ydCB7TWVudVBvc2l0aW9ufSBmcm9tICdjbGllbnQvaG9va3MvdXNlQ29vcmRzJ1xuaW1wb3J0IEFycm93RG93blNWRyBmcm9tICdjbGllbnQvY29tcG9uZW50cy9JY29ucy9BcnJvd0Rvd25TVkcnXG5pbXBvcnQgRG90IGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0RvdCdcbmltcG9ydCB1c2VNb2RhbCBmcm9tICdjbGllbnQvaG9va3MvdXNlTW9kYWwnXG5pbXBvcnQgTmV3T3JnTW9kYWwgZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvTmV3T3JnTW9kYWwnXG5pbXBvcnQgaXNVc2VyU3RhZmYgZnJvbSAnY2xpZW50L3V0aWxzL2lzVXNlclN0YWZmJ1xuXG5cblxuXG5cblxuXG5jb25zdCBTdHlsZWRSb290ID0gc3R5bGVkLmRpdih7XG4gIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICBiYWNrZ3JvdW5kQ29sb3I6IFBBTEVUVEUuQkFDS0dST1VORF9NQUlOLFxuICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gIGJvcmRlclJpZ2h0OiBgMXB4IHNvbGlkICR7UEFMRVRURS5CT1JERVJfTUFJTl9HUkFZfWAsXG4gIGhlaWdodDogJzEwMCUnLFxuICB1c2VyU2VsZWN0OiAnbm9uZSdcbn0pXG5cbmNvbnN0IE5hdkNvbnRlbnRzID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXG4gIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsXG4gIGhlaWdodDogJzEwMCUnLFxuICBwYWRkaW5nOiAwLFxuICB3aWR0aDogMjUwLFxuICBvdmVyZmxvd1k6ICdhdXRvJ1xufSlcblxuY29uc3QgTWVudUJsb2NrID0gc3R5bGVkLmRpdih7XG4gIGhlaWdodDogNDUsXG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgZmxleERpcmVjdGlvbjogJ3JvdycsXG4gIGZvbnRTaXplOiAxNSxcbiAgcGFkZGluZzogJzAgMTVweCcsXG4gIGZvbnRXZWlnaHQ6IDUwMCxcbiAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gIGN1cnNvcjogJ3BvaW50ZXInLFxuICBiYWNrZ3JvdW5kQ29sb3I6ICdpbmhlcml0JyxcbiAgbWFyZ2luQm90dG9tOiA1MCxcbiAgdHJhbnNpdGlvbjogJ2JhY2tncm91bmQtY29sb3IgMC4yNXMgbGluZWFyJyxcbiAgJzpob3Zlcic6IHtcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IFBBTEVUVEUuUFJJTUFSWV9NQUlOX0xJR0hURVNULFxuICAgIGNvbG9yOiBgJHtQQUxFVFRFLlBSSU1BUllfTUFJTn0gIWltcG9ydGFudGBcbiAgfVxufSlcblxuY29uc3QgRm9vdGVyID0gc3R5bGVkLmRpdih7XG4gIG1hcmdpbkJvdHRvbTogMjVcbn0pXG5cbmV4cG9ydCBjb25zdCBCcmFuZCA9IHN0eWxlZC5kaXYoKHthY3RpdmV9KSA9PiAoe1xuICBoZWlnaHQ6IDI1LFxuICB3aWR0aDogMjUsXG4gIG1pbldpZHRoOiAyNSxcbiAgbWluSGVpZ2h0OiAyNSxcbiAgY29sb3I6IGFjdGl2ZSA/IFBBTEVUVEUuUFJJTUFSWV9NQUlOX0RBUksgOiBQQUxFVFRFLlRFWFRfR1JBWSxcbiAgYm9yZGVyUmFkaXVzOiA0LFxuICBiYWNrZ3JvdW5kQ29sb3I6ICcjZmZmJyxcbiAgYm9yZGVyOiBgMXB4IHNvbGlkICR7YWN0aXZlID8gUEFMRVRURS5QUklNQVJZX01BSU4gOiBQQUxFVFRFLkJPUkRFUl9NQUlOX0dSQVl9YCxcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxuICB1c2VyU2VsZWN0OiAnbm9uZScsXG4gIG1hcmdpblJpZ2h0OiAxMFxufSkpXG5cbmNvbnN0IENvbXBhbnkgPSBzdHlsZWQuZGl2KHtcbiAgbGluZUhlaWdodDogJzMycHgnLFxuICBtYXJnaW5SaWdodDogNSxcbiAgLi4udGV4dE92ZXJmbG93XG59KVxuXG5jb25zdCBOYXZJdGVtcyA9IHN0eWxlZC5kaXYoe1xuICBkaXNwbGF5OiAnZmxleCcsXG4gIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nXG59KVxuXG5jb25zdCBMYWJlbCA9IHN0eWxlZC5kaXYoe1xuICAvLyBjb2xvcjogUEFMRVRURS5URVhUX01BSU4sXG4gIG1hcmdpbkxlZnQ6IDE1LFxuICBmb250V2VpZ2h0OiA0MDAsXG4gIGZvbnRTaXplOiAxNVxufSlcblxuY29uc3QgTmF2SXRlbSA9IHN0eWxlZChOYXZMaW5rKSh7XG4gIHRleHREZWNvcmF0aW9uOiAnbm9uZScsXG4gIGJvcmRlclJhZGl1czogNCxcbiAgaGVpZ2h0OiAzMCxcbiAgbGluZUhlaWdodDogJzMwcHgnLFxuICBwYWRkaW5nTGVmdDogMTAsXG4gIG1hcmdpbjogJzJweCAxMHB4JyxcbiAgb3BhY2l0eTogMC43NSxcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBmbGV4RGlyZWN0aW9uOiAncm93JyxcbiAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gIHRyYW5zaXRpb246ICdhbGwgMC4yNXMgZWFzZS1pbi1vdXQnLFxuICAnOmhvdmVyJzoge1xuICAgIGJhY2tncm91bmRDb2xvcjogUEFMRVRURS5CQUNLR1JPVU5EX0hPVkVSX0xJR0hULFxuICAgIG9wYWNpdHk6IDFcbiAgfVxufSlcblxuY29uc3QgTmF2U3ViSXRlbSA9IHN0eWxlZChOYXZMaW5rKSh7XG4gIHRleHREZWNvcmF0aW9uOiAnbm9uZScsXG4gIGNvbG9yOiBQQUxFVFRFLlRFWFRfTUFJTixcbiAgYm9yZGVyUmFkaXVzOiA0LFxuICBmb250V2VpZ2h0OiA0MDAsXG4gIGhlaWdodDogMjUsXG4gIGxpbmVIZWlnaHQ6ICcyNXB4JyxcbiAgcGFkZGluZ0xlZnQ6IDEwLFxuICBtYXJnaW46ICcycHggMTBweCAycHggNDBweCcsXG4gIG9wYWNpdHk6IDAuNzUsXG4gIGZvbnRTaXplOiAxNCxcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBmbGV4RGlyZWN0aW9uOiAncm93JyxcbiAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gIHRyYW5zaXRpb246ICdhbGwgMC4yNXMgZWFzZS1pbi1vdXQnLFxuICAnOmhvdmVyJzoge1xuICAgIGJhY2tncm91bmRDb2xvcjogUEFMRVRURS5CQUNLR1JPVU5EX0hPVkVSX0xJR0hULFxuICAgIGNvbG9yOiBQQUxFVFRFLlRFWFRfTUFJTixcbiAgICBvcGFjaXR5OiAxXG4gIH1cbn0pXG5cbmNvbnN0IGFjdGl2ZUxpbmtTdHlsZXMgPSB7XG4gIGJhY2tncm91bmRDb2xvcjogYCR7UEFMRVRURS5CQUNLR1JPVU5EX0hPVkVSfSAhaW1wb3J0YW50YCxcbiAgY29sb3I6IGAke1BBTEVUVEUuUFJJTUFSWV9NQUlOfSAhaW1wb3J0YW50YCxcbiAgb3BhY2l0eTogJzEgIWltcG9ydGFudCdcbn1cblxuY29uc3QgU2lkZWJhciA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7XG4gICAgdXNlcixcbiAgICBsb2NhdGlvbixcbiAgICBvcmdhbml6YXRpb25zLFxuICAgIG9yZ05hbWUgPSAnSHVtYW4gTGFtYmRhcycsXG4gICAgc3dpdGNoVXNlck9yZyxcbiAgICBoYW5kbGVOZXdPcmdhbml6YXRpb25cbiAgfSA9IHByb3BzXG4gIGNvbnN0IHtlbWFpbCwgbmFtZSwgY3VycmVudF9vcmdhbml6YXRpb25faWR9ID0gdXNlclxuICBjb25zdCBpc01ldHJpY1JvdXRlID0gbG9jYXRpb24ucGF0aG5hbWUuaW5jbHVkZXMoJy9tZXRyaWNzJylcbiAgY29uc3Qge21lbnVQb3J0YWwsIHRvZ2dsZVBvcnRhbCwgb3JpZ2luUmVmLCBtZW51UHJvcHN9ID0gdXNlTWVudShNZW51UG9zaXRpb24uVVBQRVJfTEVGVCwge1xuICAgIGlzRHJvcGRvd246IHRydWVcbiAgfSlcbiAgY29uc3Qge21vZGFsUG9ydGFsLCB0b2dnbGVQb3J0YWw6IHRvZ2dsZU1vZGFsUG9ydGFsLCBjbG9zZVBvcnRhbDogY2xvc2VNb2RhbFBvcnRhbH0gPSB1c2VNb2RhbCh7fSlcbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZFJvb3QsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTY2fX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChOYXZDb250ZW50cywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNjd9fVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ2RpdicsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTY4fX1cbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTWVudUJsb2NrLCB7IG9uQ2xpY2s6IHRvZ2dsZVBvcnRhbCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE2OX19XG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQnJhbmQsIHsgcmVmOiBvcmlnaW5SZWYsIGFjdGl2ZTogdHJ1ZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE3MH19XG4gICAgICAgICAgICAgICwgb3JnTmFtZS5jaGFyQXQoMClcbiAgICAgICAgICAgIClcbiAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChDb21wYW55LCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE3M319LCBvcmdOYW1lKVxuICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEFycm93RG93blNWRywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNzR9fSApXG4gICAgICAgICAgKVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChOYXZJdGVtcywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNzZ9fVxuICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KENsYXNzTmFtZXMsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTc3fX1cbiAgICAgICAgICAgICAgLCAoe2Nzc30pID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwgbnVsbFxuICAgICAgICAgICAgICAgICAgICAsIGlzVXNlclN0YWZmKG9yZ2FuaXphdGlvbnMsIGN1cnJlbnRfb3JnYW5pemF0aW9uX2lkKSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwgbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KE5hdkl0ZW0sIHsgdG86IGAvb3V0c3RhbmRpbmctcXVldWVzYCwgYWN0aXZlQ2xhc3NOYW1lOiBjc3MoYWN0aXZlTGlua1N0eWxlcyksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxODN9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVXNlcnNJY29uLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE4NH19IClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE4NX19LCBcIk91dHN0YW5kaW5nIFF1ZXVlc1wiIClcbiAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICwgIXVzZXIuaXNfYWRtaW4gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KE5hdkl0ZW0sIHsgdG86IGAvYXVkaXRzYCwgYWN0aXZlQ2xhc3NOYW1lOiBjc3MoYWN0aXZlTGlua1N0eWxlcyksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxODh9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChBdWRpdHNTVkcsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTg5fX0gKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxOTB9fSwgXCJBdWRpdHNcIilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgKVxuXG4gICAgICAgICAgICAgICAgICAgICwgIWlzVXNlclN0YWZmKG9yZ2FuaXphdGlvbnMsIGN1cnJlbnRfb3JnYW5pemF0aW9uX2lkKSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChOYXZJdGVtLCB7IHRvOiBgL3F1ZXVlc2AsIGFjdGl2ZUNsYXNzTmFtZTogY3NzKGFjdGl2ZUxpbmtTdHlsZXMpLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTk3fX1cbiAgICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChRdWV1ZUljb24sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTk4fX0gKVxuICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE5OX19LCBcIlF1ZXVlc1wiKVxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAsIHVzZXIuaXNfYWRtaW4gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTmF2SXRlbSwgeyB0bzogYC91c2Vyc2AsIGFjdGl2ZUNsYXNzTmFtZTogY3NzKGFjdGl2ZUxpbmtTdHlsZXMpLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjAzfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChVc2Vyc0ljb24sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjA0fX0gKVxuICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIwNX19LCBcIlVzZXJzXCIpXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICwgdXNlci5pc19hZG1pbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwgbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KE5hdkl0ZW0sIHsgdG86IGAvYXVkaXRzYCwgYWN0aXZlQ2xhc3NOYW1lOiBjc3MoYWN0aXZlTGlua1N0eWxlcyksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMTB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQXVkaXRzU1ZHLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIxMX19IClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIxMn19LCBcIkF1ZGl0c1wiKVxuICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KE5hdkl0ZW0sIHsgdG86IGAvbWV0cmljc2AsIGFjdGl2ZUNsYXNzTmFtZTogY3NzKGFjdGl2ZUxpbmtTdHlsZXMpLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjE0fX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KE1ldHJpY3NJY29uLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIxNX19IClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIxNn19LCBcIk1ldHJpY3NcIilcbiAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICwgaXNNZXRyaWNSb3V0ZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTmF2U3ViSXRlbSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhhY3Q6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bzogYC9tZXRyaWNzYCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZUNsYXNzTmFtZTogY3NzKGFjdGl2ZUxpbmtTdHlsZXMpLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjIwfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChEb3QsIHsgY29sb3I6IFBBTEVUVEUuTElOSywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIyNX19IClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgnc3BhbicsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjI2fX0sIFwiT3ZlcnZpZXdcIilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KE5hdlN1Ykl0ZW0sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvOiBgL21ldHJpY3MvcXVldWVzYCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZUNsYXNzTmFtZTogY3NzKGFjdGl2ZUxpbmtTdHlsZXMpLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjI4fX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChEb3QsIHsgY29sb3I6IFBBTEVUVEUuUFJJTUFSWV9HUkVFTiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIzMn19IClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgnc3BhbicsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjMzfX0sIFwiUXVldWVzXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChOYXZTdWJJdGVtLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bzogYC9tZXRyaWNzL3dvcmtlcnNgLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZlQ2xhc3NOYW1lOiBjc3MoYWN0aXZlTGlua1N0eWxlcyksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzV9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KERvdCwgeyBjb2xvcjogXCIjZmY0YzRjXCIsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzl9fSApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI0MH19LCBcIldvcmtlcnNcIilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEZvb3Rlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNTJ9fVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChOYXZJdGVtLCB7IHRvOiBgL3NldHRpbmdzL3Byb2ZpbGVgLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjUzfX1cbiAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTZXR0aW5nc1NWRywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNTR9fSApXG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjU1fX0sIFwiU2V0dGluZ3NcIilcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgIClcbiAgICAgICwgbWVudVBvcnRhbChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChBcHBNZW51LCB7XG4gICAgICAgICAgdG9nZ2xlUG9ydGFsOiB0b2dnbGVQb3J0YWwsXG4gICAgICAgICAgdG9nZ2xlTW9kYWxQb3J0YWw6IHRvZ2dsZU1vZGFsUG9ydGFsLFxuICAgICAgICAgIG9yZ2FuaXphdGlvbnM6IG9yZ2FuaXphdGlvbnMsXG4gICAgICAgICAgc3dpdGNoVXNlck9yZzogc3dpdGNoVXNlck9yZyxcbiAgICAgICAgICBtZW51UHJvcHM6IG1lbnVQcm9wcyxcbiAgICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICAgIGVtYWlsOiBlbWFpbCxcbiAgICAgICAgICBjdXJyZW50X29yZ2FuaXphdGlvbl9pZDogY3VycmVudF9vcmdhbml6YXRpb25faWQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNjB9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICAsIG1vZGFsUG9ydGFsKFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KE5ld09yZ01vZGFsLCB7IGNsb3NlUG9ydGFsOiBjbG9zZU1vZGFsUG9ydGFsLCBoYW5kbGVOZXdPcmdhbml6YXRpb246IGhhbmRsZU5ld09yZ2FuaXphdGlvbiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI3Mn19IClcbiAgICAgIClcbiAgICApXG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgd2l0aFJvdXRlcihTaWRlYmFyKVxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL2NsaWVudC9tb2R1bGVzL2Rhc2hib2FyZC9EYXNoYm9hcmRSb290LnRzeFwiO2ltcG9ydCBSZWFjdCwge3VzZUVmZmVjdCwgdXNlU3RhdGV9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtjb25uZWN0fSBmcm9tICdyZWFjdC1yZWR1eCdcbmltcG9ydCBEYXNoYm9hcmQgZnJvbSAnLi9jb250YWluZXJzL0Rhc2hib2FyZCdcbmltcG9ydCB1c2VOZXR3b3JrZXIgZnJvbSAnY2xpZW50L2hvb2tzL3VzZU5ldHdvcmtlcidcbmltcG9ydCB7YWRkVXNlcn0gZnJvbSAnY2xpZW50L3JlZHV4L2N1cnJlbnRVc2VyUmVkdWNlcidcbmltcG9ydCBpc1VzZXJTdGFmZiBmcm9tICdjbGllbnQvdXRpbHMvaXNVc2VyU3RhZmYnXG5cblxuXG5cblxuXG5jb25zdCBEYXNoYm9hcmRSb290ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtoaXN0b3J5fSA9IHByb3BzXG4gIGNvbnN0IG5ldHdvcmtlciA9IHVzZU5ldHdvcmtlcigpXG4gIGNvbnN0IHtcbiAgICBhY2Nlc3NPYmo6IHt1c2VyX2lkOiB1c2VySWR9XG4gIH0gPSBuZXR3b3JrZXIgfHwge2FjY2Vzc09iajoge319XG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKHt9KVxuICBjb25zdCB7Y3VycmVudF9vcmdhbml6YXRpb25faWQ6IGN1cnJlbnRPcmdJZH0gPSB1c2VyIHx8IHt9XG4gIGNvbnN0IFtvcmdhbml6YXRpb24sIHNldE9yZ10gPSB1c2VTdGF0ZSh7fSlcbiAgY29uc3QgW29yZ2FuaXphdGlvbnMsIHNldE9yZ3NdID0gdXNlU3RhdGUoW10pXG5cbiAgYXN5bmMgZnVuY3Rpb24gZmV0Y2hVc2VyQW5kT3JnSW5mbygpIHtcbiAgICBjb25zdCByZXNwID0gYXdhaXQgbmV0d29ya2VyLmh0dHBIYW5kbGVyKGAvdXNlcnMvJHt1c2VySWR9YCwge21ldGhvZDogJ0dFVCd9KVxuICAgIGxldCBkYXRhLCBlcnJvcnNcblxuICAgIGlmIChyZXNwKSB7XG4gICAgICBkYXRhID0gcmVzcC5kYXRhXG4gICAgICBlcnJvcnMgPSByZXNwLmVycm9yc1xuICAgIH1cbiAgICBjb25zdCB7Y3VycmVudF9vcmdhbml6YXRpb25faWR9ID0gZGF0YSB8fCB7fVxuICAgIGlmIChjdXJyZW50T3JnSWQgPT09IGN1cnJlbnRfb3JnYW5pemF0aW9uX2lkKSByZXR1cm5cbiAgICBpZiAoIWVycm9ycykge1xuICAgICAgaWYgKGN1cnJlbnRfb3JnYW5pemF0aW9uX2lkKSB7XG4gICAgICAgIGNvbnN0IHtkYXRhOiBvcmd9ID0gYXdhaXQgbmV0d29ya2VyLmh0dHBIYW5kbGVyKGAvb3Jncy8ke2RhdGEuY3VycmVudF9vcmdhbml6YXRpb25faWR9YCwge1xuICAgICAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICAgICAgfSlcbiAgICAgICAgY29uc3Qge2RhdGE6IG9yZ3N9ID0gYXdhaXQgbmV0d29ya2VyLmh0dHBIYW5kbGVyKGAvb3Jnc2AsIHttZXRob2Q6ICdHRVQnfSlcbiAgICAgICAgc2V0VXNlcihkYXRhKVxuICAgICAgICBzZXRPcmcob3JnKVxuICAgICAgICBzZXRPcmdzKG9yZ3MpXG4gICAgICAgIGNvbnN0IGlzU3RhZmYgPSBpc1VzZXJTdGFmZihvcmdzLCBkYXRhLmN1cnJlbnRfb3JnYW5pemF0aW9uX2lkKVxuICAgICAgICBwcm9wcy5hZGRVc2VyKHsuLi5kYXRhLCBpc1N0YWZmfSlcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ05vIG9yZ2FuaXphdGlvbiBJRCEnKVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBlcnJvcnMuZm9yRWFjaCgoZSkgPT4gY29uc29sZS5lcnJvcihlLm1lc3NhZ2UpKVxuICAgIH1cbiAgfVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZmV0Y2hVc2VyQW5kT3JnSW5mbygpXG4gIH0sIFt1c2VySWQsIHVzZXJdKVxuXG4gIGNvbnN0IHN3aXRjaFVzZXJPcmcgPSBhc3luYyAoaWQpID0+IHtcbiAgICBjb25zdCB7ZXJyb3JzfSA9IGF3YWl0IG5ldHdvcmtlci5odHRwSGFuZGxlcihgL3VzZXJzLyR7dXNlci5pZH1gLCB7XG4gICAgICBkYXRhOiB7XG4gICAgICAgIGN1cnJlbnRfb3JnYW5pemF0aW9uX2lkOiBpZFxuICAgICAgfSxcbiAgICAgIG1ldGhvZDogJ1BBVENIJ1xuICAgIH0pXG4gICAgaWYgKCFlcnJvcnMpIHtcbiAgICAgIGhpc3RvcnkucHVzaCgnLycpXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGZldGNoaW5nIG9yZ2FuaXphdGlvbiBpbmZvcm1hdGlvbiEnLCBKU09OLnN0cmluZ2lmeShlcnJvcnMpKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZU5ld09yZ2FuaXphdGlvbiA9IGFzeW5jIChvcmdOYW1lKSA9PiB7XG4gICAgaWYgKCFvcmdOYW1lKSByZXR1cm5cbiAgICBjb25zdCB7XG4gICAgICBkYXRhOiB7aWQ6IG5ld09yZ0lkfVxuICAgIH0gPSBhd2FpdCBuZXR3b3JrZXIuaHR0cEhhbmRsZXIoYC9vcmdzL2NyZWF0ZWAsIHtcbiAgICAgIGRhdGE6IG9yZ05hbWUsXG4gICAgICBtZXRob2Q6ICdQT1NUJ1xuICAgIH0pXG4gICAgYXdhaXQgbmV0d29ya2VyLmh0dHBIYW5kbGVyKGAvdXNlcnMvJHt1c2VyLmlkfWAsIHtcbiAgICAgIGRhdGE6IHtcbiAgICAgICAgY3VycmVudF9vcmdhbml6YXRpb25faWQ6IG5ld09yZ0lkXG4gICAgICB9LFxuICAgICAgbWV0aG9kOiAnUEFUQ0gnXG4gICAgfSlcbiAgICBoaXN0b3J5LnB1c2goJy8nKVxuICB9XG5cbiAgaWYgKCF1c2VyLmlkICYmICFvcmdhbml6YXRpb24ubmFtZSkgcmV0dXJuIG51bGxcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRGFzaGJvYXJkLCB7XG4gICAgICAuLi5wcm9wcyxcbiAgICAgIHVzZXI6IHVzZXIsXG4gICAgICBvcmdOYW1lOiBvcmdhbml6YXRpb24ubmFtZSxcbiAgICAgIG9yZ2FuaXphdGlvbnM6IG9yZ2FuaXphdGlvbnMsXG4gICAgICBzd2l0Y2hVc2VyT3JnOiBzd2l0Y2hVc2VyT3JnLFxuICAgICAgaGFuZGxlTmV3T3JnYW5pemF0aW9uOiBoYW5kbGVOZXdPcmdhbml6YXRpb24sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA5MX19XG4gICAgKVxuICApXG59XG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSAoZGlzcGF0Y2gpID0+ICh7XG4gIGFkZFVzZXI6IChhcmcpID0+IGRpc3BhdGNoKGFkZFVzZXIoYXJnKSlcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobnVsbCwgbWFwRGlzcGF0Y2hUb1Byb3BzKShEYXNoYm9hcmRSb290KVxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL2NsaWVudC9tb2R1bGVzL2Rhc2hib2FyZC9jb250YWluZXJzL0Rhc2hib2FyZC50c3hcIjtpbXBvcnQgUmVhY3QsIHtsYXp5fSBmcm9tICdyZWFjdCdcbmltcG9ydCB7Y29ubmVjdH0gZnJvbSAncmVhY3QtcmVkdXgnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcbmltcG9ydCB7U3dpdGNoLCBSb3V0ZSwgUmVkaXJlY3R9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3VuaXZlcnNhbC9zdHlsZXMvcGFsZXR0ZSdcbmltcG9ydCBTaWRlYmFyIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL1NpZGViYXInXG5pbXBvcnQgaGFuZGxlQ2h1bmtFcnJvciBmcm9tICd1bml2ZXJzYWwvdXRpbHMvaGFuZGxlQ2h1bmtFcnJvcidcblxuXG5cblxuXG5cblxuXG5jb25zdCBEYXNoTGF5b3V0ID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgb3ZlcmZsb3c6ICdhdXRvJyxcbiAgaGVpZ2h0OiAnMTAwJSdcbn0pXG5cbmNvbnN0IERhc2hNYWluID0gc3R5bGVkKCdkaXYnKSh7XG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgZmxleDogMSxcbiAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXG4gIGhlaWdodDogJzEwMCUnLFxuICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gIGJhY2tncm91bmQ6IFBBTEVUVEUuQkFDS0dST1VORF9NQUlOXG59KVxuXG5jb25zdCBRdWV1ZXNSb290ID0gbGF6eSgoKSA9PlxuICBpbXBvcnQoLyogd2VicGFja0NodW5rTmFtZTogJ1F1ZXVlc1Jvb3QnICovICdjbGllbnQvbW9kdWxlcy9xdWV1ZXMvUXVldWVzUm9vdCcpLmNhdGNoKChlcnJvcikgPT5cbiAgICBoYW5kbGVDaHVua0Vycm9yKGVycm9yKVxuICApXG4pXG5cbmNvbnN0IFVzZXJzUm9vdCA9IGxhenkoKCkgPT5cbiAgaW1wb3J0KFxuICAgIC8qIHdlYnBhY2tDaHVua05hbWU6ICdVc2Vyc1Jvb3QnICovICdjbGllbnQvbW9kdWxlcy91c2Vycy9jb250YWluZXJzL1VzZXJzUm9vdCdcbiAgKS5jYXRjaCgoZXJyb3IpID0+IGhhbmRsZUNodW5rRXJyb3IoZXJyb3IpKVxuKVxuXG5jb25zdCBBdWRpdHNSb290ID0gbGF6eSgoKSA9PlxuICBpbXBvcnQoXG4gICAgLyogd2VicGFja0NodW5rTmFtZTogJ0F1ZGl0c1Jvb3QnICovICd1bml2ZXJzYWwvbW9kdWxlcy9hdWRpdHMvQXVkaXRzUm9vdCdcbiAgKS5jYXRjaCgoZXJyb3IpID0+IGhhbmRsZUNodW5rRXJyb3IoZXJyb3IpKVxuKVxuXG5jb25zdCBPdXRzdGFuZGluZ1Jvb3QgPSBsYXp5KCgpID0+XG4gIGltcG9ydChcbiAgICAvKiB3ZWJwYWNrQ2h1bmtOYW1lOiAnQXVkaXRzUm9vdCcgKi8gJ3VuaXZlcnNhbC9tb2R1bGVzL291dHN0YW5kaW5nL091dHN0YW5kaW5nUm9vdCdcbiAgKS5jYXRjaCgoZXJyb3IpID0+IGhhbmRsZUNodW5rRXJyb3IoZXJyb3IpKVxuKVxuXG5jb25zdCBNZXRyaWNzUm9vdCA9IGxhenkoKCkgPT5cbiAgaW1wb3J0KFxuICAgIC8qIHdlYnBhY2tDaHVua05hbWU6ICdNZXRyaWNzUm9vdCcgKi8gJ2NsaWVudC9tb2R1bGVzL21ldHJpY3MvTWV0cmljc1Jvb3QnXG4gICkuY2F0Y2goKGVycm9yKSA9PiBoYW5kbGVDaHVua0Vycm9yKGVycm9yKSlcbilcblxuY29uc3QgTm90Rm91bmQgPSBsYXp5KCgpID0+XG4gIGltcG9ydCgvKiB3ZWJwYWNrQ2h1bmtOYW1lOiAnTm90Rm91bmQnICovICdjbGllbnQvY29tcG9uZW50cy9Ob3RGb3VuZCcpLmNhdGNoKChlcnJvcikgPT5cbiAgICBoYW5kbGVDaHVua0Vycm9yKGVycm9yKVxuICApXG4pXG5cbmNvbnN0IERhc2hib2FyZCA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7XG4gICAgdXNlcixcbiAgICBvcmdOYW1lLFxuICAgIG9yZ2FuaXphdGlvbnMsXG4gICAgaGFuZGxlTmV3T3JnYW5pemF0aW9uLFxuICAgIHN3aXRjaFVzZXJPcmcsXG4gICAgaGlzdG9yeToge2xvY2F0aW9ufSxcbiAgICBpc1N0YWZmXG4gIH0gPSBwcm9wcyB8fCB7fVxuICBjb25zdCBoaWRlU2lkZWJhciA9IGxvY2F0aW9uLnBhdGhuYW1lLmluY2x1ZGVzKCd0YXNrJylcbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KERhc2hMYXlvdXQsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNzl9fVxuICAgICAgLCAhaGlkZVNpZGViYXIgJiYgKFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFNpZGViYXIsIHtcbiAgICAgICAgICBzd2l0Y2hVc2VyT3JnOiBzd2l0Y2hVc2VyT3JnLFxuICAgICAgICAgIHVzZXI6IHVzZXIsXG4gICAgICAgICAgb3JnTmFtZTogb3JnTmFtZSxcbiAgICAgICAgICBvcmdhbml6YXRpb25zOiBvcmdhbml6YXRpb25zLFxuICAgICAgICAgIGhhbmRsZU5ld09yZ2FuaXphdGlvbjogaGFuZGxlTmV3T3JnYW5pemF0aW9uLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogODF9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRGFzaE1haW4sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogODl9fVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3dpdGNoLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDkwfX1cbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUm91dGUsIHtcbiAgICAgICAgICAgIHBhdGg6IFwiL291dHN0YW5kaW5nLXF1ZXVlc1wiLFxuICAgICAgICAgICAgcmVuZGVyOiAocCkgPT4ge1xuICAgICAgICAgICAgICBpZiAoaXNTdGFmZikgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoT3V0c3RhbmRpbmdSb290LCB7IC4uLnAsIHVzZXI6IHVzZXIsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA5NH19IClcbiAgICAgICAgICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVkaXJlY3QsIHsgdG86IFwiL3F1ZXVlc1wiLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogOTV9fSApXG4gICAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogOTF9fVxuICAgICAgICAgIClcbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUm91dGUsIHtcbiAgICAgICAgICAgIHBhdGg6IFwiL3F1ZXVlc1wiLFxuICAgICAgICAgICAgcmVuZGVyOiAocCkgPT4gUmVhY3QuY3JlYXRlRWxlbWVudChRdWV1ZXNSb290LCB7IG9yZ2FuaXphdGlvbnM6IG9yZ2FuaXphdGlvbnMsIC4uLnAsIHVzZXI6IHVzZXIsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMDB9fSApLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogOTh9fVxuICAgICAgICAgIClcbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUm91dGUsIHsgcGF0aDogXCIvdXNlcnNcIiwgcmVuZGVyOiAocCkgPT4gUmVhY3QuY3JlYXRlRWxlbWVudChVc2Vyc1Jvb3QsIHsgLi4ucCwgdXNlcjogdXNlciwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEwMn19ICksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMDJ9fSApXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFJvdXRlLCB7IHBhdGg6IFwiL2F1ZGl0c1wiLCByZW5kZXI6IChwKSA9PiBSZWFjdC5jcmVhdGVFbGVtZW50KEF1ZGl0c1Jvb3QsIHsgLi4ucCwgdXNlcjogdXNlciwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEwM319ICksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMDN9fSApXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFJvdXRlLCB7IHBhdGg6IFwiL21ldHJpY3NcIiwgcmVuZGVyOiAocCkgPT4gUmVhY3QuY3JlYXRlRWxlbWVudChNZXRyaWNzUm9vdCwgeyAuLi5wLCB1c2VyOiB1c2VyLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTA0fX0gKSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEwNH19IClcbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUm91dGUsIHsgY29tcG9uZW50OiBOb3RGb3VuZCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEwNX19IClcbiAgICAgICAgKVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSAoc3RhdGUpID0+ICh7XG4gIGlzU3RhZmY6IHN0YXRlLmN1cnJlbnRVc2VyLmlzU3RhZmZcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBudWxsKShEYXNoYm9hcmQpXG4iLCJpbXBvcnQge1NUQUZGX09SR19JRH0gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcblxuY29uc3QgaXNVc2VyU3RhZmYgPSAob3JnYW5pemF0aW9ucywgY3VycmVudF9vcmdhbml6YXRpb25faWQpID0+IHtcbiAgZm9yIChjb25zdCBvcmcgb2Ygb3JnYW5pemF0aW9ucykge1xuICAgIGlmIChvcmcuaWQgPT09IFNUQUZGX09SR19JRCAmJiBjdXJyZW50X29yZ2FuaXphdGlvbl9pZCA9PT0gU1RBRkZfT1JHX0lEKSByZXR1cm4gdHJ1ZVxuICB9XG5cbiAgcmV0dXJuIGZhbHNlXG59XG5leHBvcnQgZGVmYXVsdCBpc1VzZXJTdGFmZlxuIl0sInNvdXJjZVJvb3QiOiIifQ==