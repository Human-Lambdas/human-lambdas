(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["TaskRoot"],{

/***/ "./node_modules/dayjs/dayjs.min.js":
/*!*****************************************!*\
  !*** ./node_modules/dayjs/dayjs.min.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

!function(t,e){ true?module.exports=e():undefined}(this,function(){"use strict";var t="millisecond",e="second",n="minute",r="hour",i="day",s="week",u="month",a="quarter",o="year",f="date",h=/^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[^0-9]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,c=/\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,d={name:"en",weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_")},$=function(t,e,n){var r=String(t);return!r||r.length>=e?t:""+Array(e+1-r.length).join(n)+t},l={s:$,z:function(t){var e=-t.utcOffset(),n=Math.abs(e),r=Math.floor(n/60),i=n%60;return(e<=0?"+":"-")+$(r,2,"0")+":"+$(i,2,"0")},m:function t(e,n){if(e.date()<n.date())return-t(n,e);var r=12*(n.year()-e.year())+(n.month()-e.month()),i=e.clone().add(r,u),s=n-i<0,a=e.clone().add(r+(s?-1:1),u);return+(-(r+(n-i)/(s?i-a:a-i))||0)},a:function(t){return t<0?Math.ceil(t)||0:Math.floor(t)},p:function(h){return{M:u,y:o,w:s,d:i,D:f,h:r,m:n,s:e,ms:t,Q:a}[h]||String(h||"").toLowerCase().replace(/s$/,"")},u:function(t){return void 0===t}},y="en",M={};M[y]=d;var m=function(t){return t instanceof S},D=function(t,e,n){var r;if(!t)return y;if("string"==typeof t)M[t]&&(r=t),e&&(M[t]=e,r=t);else{var i=t.name;M[i]=t,r=i}return!n&&r&&(y=r),r||!n&&y},v=function(t,e){if(m(t))return t.clone();var n="object"==typeof e?e:{};return n.date=t,n.args=arguments,new S(n)},g=l;g.l=D,g.i=m,g.w=function(t,e){return v(t,{locale:e.$L,utc:e.$u,x:e.$x,$offset:e.$offset})};var S=function(){function d(t){this.$L=D(t.locale,null,!0),this.parse(t)}var $=d.prototype;return $.parse=function(t){this.$d=function(t){var e=t.date,n=t.utc;if(null===e)return new Date(NaN);if(g.u(e))return new Date;if(e instanceof Date)return new Date(e);if("string"==typeof e&&!/Z$/i.test(e)){var r=e.match(h);if(r){var i=r[2]-1||0,s=(r[7]||"0").substring(0,3);return n?new Date(Date.UTC(r[1],i,r[3]||1,r[4]||0,r[5]||0,r[6]||0,s)):new Date(r[1],i,r[3]||1,r[4]||0,r[5]||0,r[6]||0,s)}}return new Date(e)}(t),this.$x=t.x||{},this.init()},$.init=function(){var t=this.$d;this.$y=t.getFullYear(),this.$M=t.getMonth(),this.$D=t.getDate(),this.$W=t.getDay(),this.$H=t.getHours(),this.$m=t.getMinutes(),this.$s=t.getSeconds(),this.$ms=t.getMilliseconds()},$.$utils=function(){return g},$.isValid=function(){return!("Invalid Date"===this.$d.toString())},$.isSame=function(t,e){var n=v(t);return this.startOf(e)<=n&&n<=this.endOf(e)},$.isAfter=function(t,e){return v(t)<this.startOf(e)},$.isBefore=function(t,e){return this.endOf(e)<v(t)},$.$g=function(t,e,n){return g.u(t)?this[e]:this.set(n,t)},$.unix=function(){return Math.floor(this.valueOf()/1e3)},$.valueOf=function(){return this.$d.getTime()},$.startOf=function(t,a){var h=this,c=!!g.u(a)||a,d=g.p(t),$=function(t,e){var n=g.w(h.$u?Date.UTC(h.$y,e,t):new Date(h.$y,e,t),h);return c?n:n.endOf(i)},l=function(t,e){return g.w(h.toDate()[t].apply(h.toDate("s"),(c?[0,0,0,0]:[23,59,59,999]).slice(e)),h)},y=this.$W,M=this.$M,m=this.$D,D="set"+(this.$u?"UTC":"");switch(d){case o:return c?$(1,0):$(31,11);case u:return c?$(1,M):$(0,M+1);case s:var v=this.$locale().weekStart||0,S=(y<v?y+7:y)-v;return $(c?m-S:m+(6-S),M);case i:case f:return l(D+"Hours",0);case r:return l(D+"Minutes",1);case n:return l(D+"Seconds",2);case e:return l(D+"Milliseconds",3);default:return this.clone()}},$.endOf=function(t){return this.startOf(t,!1)},$.$set=function(s,a){var h,c=g.p(s),d="set"+(this.$u?"UTC":""),$=(h={},h[i]=d+"Date",h[f]=d+"Date",h[u]=d+"Month",h[o]=d+"FullYear",h[r]=d+"Hours",h[n]=d+"Minutes",h[e]=d+"Seconds",h[t]=d+"Milliseconds",h)[c],l=c===i?this.$D+(a-this.$W):a;if(c===u||c===o){var y=this.clone().set(f,1);y.$d[$](l),y.init(),this.$d=y.set(f,Math.min(this.$D,y.daysInMonth())).$d}else $&&this.$d[$](l);return this.init(),this},$.set=function(t,e){return this.clone().$set(t,e)},$.get=function(t){return this[g.p(t)]()},$.add=function(t,a){var f,h=this;t=Number(t);var c=g.p(a),d=function(e){var n=v(h);return g.w(n.date(n.date()+Math.round(e*t)),h)};if(c===u)return this.set(u,this.$M+t);if(c===o)return this.set(o,this.$y+t);if(c===i)return d(1);if(c===s)return d(7);var $=(f={},f[n]=6e4,f[r]=36e5,f[e]=1e3,f)[c]||1,l=this.$d.getTime()+t*$;return g.w(l,this)},$.subtract=function(t,e){return this.add(-1*t,e)},$.format=function(t){var e=this;if(!this.isValid())return"Invalid Date";var n=t||"YYYY-MM-DDTHH:mm:ssZ",r=g.z(this),i=this.$locale(),s=this.$H,u=this.$m,a=this.$M,o=i.weekdays,f=i.months,h=function(t,r,i,s){return t&&(t[r]||t(e,n))||i[r].substr(0,s)},d=function(t){return g.s(s%12||12,t,"0")},$=i.meridiem||function(t,e,n){var r=t<12?"AM":"PM";return n?r.toLowerCase():r},l={YY:String(this.$y).slice(-2),YYYY:this.$y,M:a+1,MM:g.s(a+1,2,"0"),MMM:h(i.monthsShort,a,f,3),MMMM:h(f,a),D:this.$D,DD:g.s(this.$D,2,"0"),d:String(this.$W),dd:h(i.weekdaysMin,this.$W,o,2),ddd:h(i.weekdaysShort,this.$W,o,3),dddd:o[this.$W],H:String(s),HH:g.s(s,2,"0"),h:d(1),hh:d(2),a:$(s,u,!0),A:$(s,u,!1),m:String(u),mm:g.s(u,2,"0"),s:String(this.$s),ss:g.s(this.$s,2,"0"),SSS:g.s(this.$ms,3,"0"),Z:r};return n.replace(c,function(t,e){return e||l[t]||r.replace(":","")})},$.utcOffset=function(){return 15*-Math.round(this.$d.getTimezoneOffset()/15)},$.diff=function(t,f,h){var c,d=g.p(f),$=v(t),l=6e4*($.utcOffset()-this.utcOffset()),y=this-$,M=g.m(this,$);return M=(c={},c[o]=M/12,c[u]=M,c[a]=M/3,c[s]=(y-l)/6048e5,c[i]=(y-l)/864e5,c[r]=y/36e5,c[n]=y/6e4,c[e]=y/1e3,c)[d]||y,h?M:g.a(M)},$.daysInMonth=function(){return this.endOf(u).$D},$.$locale=function(){return M[this.$L]},$.locale=function(t,e){if(!t)return this.$L;var n=this.clone(),r=D(t,e,!0);return r&&(n.$L=r),n},$.clone=function(){return g.w(this.$d,this)},$.toDate=function(){return new Date(this.valueOf())},$.toJSON=function(){return this.isValid()?this.toISOString():null},$.toISOString=function(){return this.$d.toISOString()},$.toString=function(){return this.$d.toUTCString()},d}(),p=S.prototype;return v.prototype=p,[["$ms",t],["$s",e],["$m",n],["$H",r],["$W",i],["$M",u],["$y",o],["$D",f]].forEach(function(t){p[t[1]]=function(e){return this.$g(e,t[0],t[1])}}),v.extend=function(t,e){return t.$i||(t(e,S,v),t.$i=!0),v},v.locale=D,v.isDayjs=m,v.unix=function(t){return v(1e3*t)},v.en=M[y],v.Ls=M,v.p={},v});


/***/ }),

/***/ "./src/client/components/Spinner.tsx":
/*!*******************************************!*\
  !*** ./src/client/components/Spinner.tsx ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _emotion_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @emotion/core */ "./node_modules/@emotion/core/dist/core.browser.esm.js");
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/Spinner.tsx";



const keyframesSpin = _emotion_core__WEBPACK_IMPORTED_MODULE_2__["keyframes"]`
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
`;

const Loader = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1rnj20u0"
})({
  border: `2px solid ${styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].BORDER_GRAY}`,
  borderRadius: '50%',
  borderTop: `2px solid ${styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].PRIMARY_MAIN}`,
  width: 20,
  height: 20,
  animationName: keyframesSpin.toString(),
  animationDuration: '1s',
  animationIterationCount: 'infinite'
});

const Spinner = () => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Loader, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 26
  }
});

/* harmony default export */ __webpack_exports__["default"] = (Spinner);

/***/ }),

/***/ "./src/client/utils/isUserStaff.ts":
/*!*****************************************!*\
  !*** ./src/client/utils/isUserStaff.ts ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");


const isUserStaff = (organizations, current_organization_id) => {
  for (const org of organizations) {
    if (org.id === universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["STAFF_ORG_ID"] && current_organization_id === universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["STAFF_ORG_ID"]) return true;
  }

  return false;
};

/* harmony default export */ __webpack_exports__["default"] = (isUserStaff);

/***/ }),

/***/ "./src/universal/modules/audits/components/AuditDecision.tsx":
/*!*******************************************************************!*\
  !*** ./src/universal/modules/audits/components/AuditDecision.tsx ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var client_components_PlainButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! client/components/PlainButton */ "./src/client/components/PlainButton.tsx");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var universal_components_Icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! universal/components/Icon */ "./src/universal/components/Icon.tsx");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/modules/audits/components/AuditDecision.tsx";





const DecisionButton = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(client_components_PlainButton__WEBPACK_IMPORTED_MODULE_1__["default"], {
  target: "e1k1yrn20"
})(props => {
  const {
    isApprove,
    isActive
  } = props;
  const color = isApprove ? universal_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].PRIMARY_GREEN : universal_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].ERROR_MAIN;
  return {
    width: 'auto',
    backgroundColor: isActive ? color : 'white',
    color: isActive ? 'white' : color,
    border: `1px solid ${isActive ? 'white' : color}`,
    fontSize: '14px',
    fontWeight: 500,
    boxShadow: 'rgba(15, 15, 15, 0.1) 0px 0px 0px 1px inset, rgba(15, 15, 15, 0.1) 0px 1px 2px',
    outline: 0,
    transition: 'all 0.25s ease-in-out',
    ':hover': {
      boxShadow: `0 4px 8px ${isApprove ? 'rgba(0,173,69,0.05)' : 'rgba(255,74,0,0.05)'}`
    },
    ':active': {
      backgroundColor: isActive ? 'white' : color,
      color: isActive ? color : 'white',
      border: `1px solid ${isActive ? color : 'white'}`
    }
  };
});

const StyledIcon = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_Icon__WEBPACK_IMPORTED_MODULE_4__["default"], {
  target: "e1k1yrn21"
})({
  name: "1283jhr",
  styles: "margin:0;padding:0;font-size:16px;"
});
/*
Key parameters:
- decision: true if the button is Approve, false if the button is Reject
- correct: current audit decision

We flip the state of the button by comparing decision and correct: ie if decision is true, the state can only flip between true and null.

The server takes some time to respond (onAuditDecision) which results in a feedback delay, so we change its state directly (setCorrectState) on click
*/


function clickHandler(onAuditDecision, setCorrectState, correct, decision) {
  const newDecision = correct === decision ? null : decision;
  setCorrectState(newDecision);
  onAuditDecision(newDecision);
}

const AuditDecision = props => {
  const {
    correct,
    onAuditDecision
  } = props;
  const [correctState, setCorrectState] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(correct);
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
    setCorrectState(correct);
  }, [correct]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 80
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(DecisionButton, {
    key: "approve",
    type: "button",
    onClick: () => {
      clickHandler(onAuditDecision, setCorrectState, correctState, true);
    },
    isApprove: true,
    isActive: correctState === true,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 81
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(StyledIcon, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 90
    }
  }, "done")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(DecisionButton, {
    key: "reject",
    type: "button",
    onClick: () => {
      clickHandler(onAuditDecision, setCorrectState, correctState, false);
    },
    isApprove: false,
    isActive: correctState === false,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 92
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(StyledIcon, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 101
    }
  }, "close")));
};

/* harmony default export */ __webpack_exports__["default"] = (AuditDecision);

/***/ }),

/***/ "./src/universal/modules/task/TaskRoot.tsx":
/*!*************************************************!*\
  !*** ./src/universal/modules/task/TaskRoot.tsx ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! qs */ "./node_modules/qs/lib/index.js");
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(qs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_Task__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/Task */ "./src/universal/modules/task/components/Task.tsx");
/* harmony import */ var client_hooks_useNetworker__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! client/hooks/useNetworker */ "./src/client/hooks/useNetworker.ts");
/* harmony import */ var client_utils_segmentIo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! client/utils/segmentIo */ "./src/client/utils/segmentIo.ts");
/* harmony import */ var client_hooks_useRouter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! client/hooks/useRouter */ "./src/client/hooks/useRouter.ts");
/* harmony import */ var client_modules_notificationSystem_ducks_notificationSystemDuck__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! client/modules/notificationSystem/ducks/notificationSystemDuck */ "./src/client/modules/notificationSystem/ducks/notificationSystemDuck.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var universal_utils_formatValues__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! universal/utils/formatValues */ "./src/universal/utils/formatValues.ts");
/* harmony import */ var client_utils_isUserStaff__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! client/utils/isUserStaff */ "./src/client/utils/isUserStaff.ts");
/* harmony import */ var client_utils_dateHelpers__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! client/utils/dateHelpers */ "./src/client/utils/dateHelpers.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/modules/task/TaskRoot.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}
















const TaskRoot = props => {
  const networker = Object(client_hooks_useNetworker__WEBPACK_IMPORTED_MODULE_5__["default"])();
  const {
    history
  } = Object(client_hooks_useRouter__WEBPACK_IMPORTED_MODULE_7__["default"])();
  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_1__["useDispatch"])();
  const {
    user,
    auditFilters
  } = props;
  const {
    id: userId,
    email,
    orgId
  } = user || {};
  const {
    taskId,
    queueId
  } = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["useParams"])();
  const [task, setTask] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({});
  const [taskLoading, setTaskLoading] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const [activity, setActivity] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [activityLoading, setActivityLoading] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const [taskNav, setTaskNav] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({});
  const [isStaff, setIsStaff] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const {
    location: {
      pathname,
      state
    }
  } = history || {};
  const isAuditsRequestedFromUrl = pathname.includes('audit');

  async function getTask() {
    const payload = {
      method: 'GET'
    };
    const url = `/orgs/${orgId}/queues/${queueId}/tasks/${taskId}`;
    const auditsUrl = `/orgs/${orgId}/queues/tasks/${taskId}/audit`;
    setTaskLoading(true);

    if (isAuditsRequestedFromUrl) {
      const {
        data: task
      } = await networker.httpHandler(auditsUrl, {
        params: auditFilters,
        paramsSerializer: params => qs__WEBPACK_IMPORTED_MODULE_3___default.a.stringify(params),
        method: 'GET'
      });
      const {
        result,
        next,
        previous
      } = task || {};
      setTask(result);
      setTaskNav({
        previous,
        next
      });
    } else {
      const {
        data: task
      } = await networker.httpHandler(url, payload);
      setTask(task);
    }

    const {
      data: orgs
    } = await networker.httpHandler(`/orgs`, {
      method: 'GET'
    });
    setIsStaff(Object(client_utils_isUserStaff__WEBPACK_IMPORTED_MODULE_11__["default"])(orgs, orgId));
    setTaskLoading(false);
  }

  async function getRefreshedTask() {
    const payload = {
      method: 'GET'
    };
    const url = `/orgs/${orgId}/queues/${queueId}/tasks/${taskId}/refresh`;
    const {
      data: task
    } = await networker.httpHandler(url, payload);

    if (!task) {
      console.error('ERROR FETCHING REFRESHED TASK');
    } else {
      setTask(task);
    }
  }

  const getActivity = async () => {
    const {
      id: taskId,
      queue_id: queueId
    } = task || {};

    if (taskId && queueId) {
      setActivityLoading(true);
      const payload = {
        method: 'GET'
      };
      const url = `/orgs/${orgId}/queues/${queueId}/tasks/${taskId}/activity`;
      const {
        data
      } = await _optionalChain([networker, 'optionalAccess', _ => _.httpHandler, 'call', _2 => _2(url, payload)]);

      if (!data) {
        console.error('ERROR FETCHING ACTIVITY DATA');
      } else {
        setActivity(data);
      }
    }

    setActivityLoading(false);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    if (_optionalChain([state, 'optionalAccess', _3 => _3.nextTask, 'optionalAccess', _4 => _4.id])) {
      setTask(state.nextTask);
    } else if (taskId && orgId) {
      getTask();
    }
  }, [taskId, orgId, user, queueId]);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    const {
      id,
      queue_id: queueId
    } = task || {};

    if (id && queueId) {
      getActivity();
    }
  }, [taskId, _optionalChain([task, 'optionalAccess', _5 => _5.id])]);
  const onSubmit = react__WEBPACK_IMPORTED_MODULE_0___default.a.useCallback(async (e, values, orgId) => {
    const {
      id: taskId
    } = values;
    let nextUrl;

    if (taskId && orgId) {
      const config = {
        method: 'PATCH',
        data: Object(client_utils_dateHelpers__WEBPACK_IMPORTED_MODULE_12__["transformDates"])(null, Object(universal_utils_formatValues__WEBPACK_IMPORTED_MODULE_10__["default"])(values))
      };
      const updateUrl = `/orgs/${orgId}/queues/${queueId}/tasks/${taskId}`;
      const nextTaskUrl = `/orgs/${orgId}/queues/${queueId}/tasks/next`;
      let requiredType;
      let requiredName;

      const required = block => {
        if (!universal_utils_constants__WEBPACK_IMPORTED_MODULE_9__["BLOCK_TYPE"].FORM_SEQUENCE) {
          const {
            type,
            name
          } = block;
          const {
            is_required: isRequired,
            value: blockValue
          } = block[type];
          requiredName = name;
          requiredType = type;
          return isRequired && blockValue === '' || isRequired && !blockValue;
        } else {
          return false;
        }
      };

      const requiredError = Object(universal_utils_formatValues__WEBPACK_IMPORTED_MODULE_10__["default"])(values.data).map(client_utils_dateHelpers__WEBPACK_IMPORTED_MODULE_12__["transformDates"]).some(required);
      const requiredValue = requiredType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_9__["BLOCK_TYPE"].TEXT || requiredType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_9__["BLOCK_TYPE"].NUMBER || requiredType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_9__["BLOCK_TYPE"].EMAIL || requiredType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_9__["BLOCK_TYPE"].LINK ? 'value' : 'selection';

      if (requiredError) {
        dispatch(Object(client_modules_notificationSystem_ducks_notificationSystemDuck__WEBPACK_IMPORTED_MODULE_8__["addFailureNotification"])(`A ${requiredValue} is required for ${requiredName}`));
        return;
      } // Update task


      const {
        data: updatedTask
      } = await _optionalChain([networker, 'optionalAccess', _6 => _6.httpHandler, 'call', _7 => _7(updateUrl, config)]);

      if (!updatedTask) {
        console.error(`ERROR UPDATING TASK`);
      } else {
        Object(client_utils_segmentIo__WEBPACK_IMPORTED_MODULE_6__["segmentTrack"])('Task Completed', {
          taskId: taskId,
          orgId,
          userId,
          email,
          queueId
        });
        const {
          data: nextTask
        } = await _optionalChain([networker, 'optionalAccess', _8 => _8.httpHandler, 'call', _9 => _9(nextTaskUrl, {
          method: 'GET'
        })]);

        if (!nextTask) {
          return history.replace(`/queues/${queueId}`);
        } else {
          if (nextTask.id) {
            nextUrl = `/queues/${queueId}/tasks/${nextTask.id}`;
            Object(client_utils_segmentIo__WEBPACK_IMPORTED_MODULE_6__["segmentTrack"])('Task Fetched', {
              taskId: nextTask.id,
              orgId,
              userId,
              email,
              queueId
            });
            history.push({
              pathname: nextUrl,
              state: {
                nextTask
              }
            });
          } else {
            dispatch(Object(client_modules_notificationSystem_ducks_notificationSystemDuck__WEBPACK_IMPORTED_MODULE_8__["addSuccessNotification"])('Congratulations! You have completed all tasks in this queue.'));
            Object(client_utils_segmentIo__WEBPACK_IMPORTED_MODULE_6__["segmentTrack"])('All Tasks Completed', {
              orgId,
              userId,
              email,
              queueId
            });
            return history.replace(`/queues/${queueId}`);
          }
        }
      }
    } else {
      console.error('FAILED TO SUBMIT TASK');
    }
  }, []);
  const onSave = react__WEBPACK_IMPORTED_MODULE_0___default.a.useCallback(async values => {
    if (task.id) {
      const config = {
        method: 'PATCH',
        data: Object(client_utils_dateHelpers__WEBPACK_IMPORTED_MODULE_12__["transformDates"])(null, Object(universal_utils_formatValues__WEBPACK_IMPORTED_MODULE_10__["default"])(values))
      };
      const url = `/orgs/${orgId}/queues/${queueId}/tasks/${task.id}/save`;
      const {
        data
      } = await _optionalChain([networker, 'optionalAccess', _10 => _10.httpHandler, 'call', _11 => _11(url, config)]);

      if (!data) {
        console.error(`ERROR SAVING TASK`);
      } else {
        getRefreshedTask();
        getActivity();
      }
    } else {
      console.error('INVALID TASK');
    }
  }, [task, orgId]);
  const onPost = react__WEBPACK_IMPORTED_MODULE_0___default.a.useCallback(async comment => {
    const {
      id: taskId,
      queue_id: queueId
    } = task || {};

    if (taskId && queueId) {
      const payload = {
        method: 'POST',
        data: {
          action: 'comment',
          comment: comment
        }
      };
      const url = `/orgs/${orgId}/queues/${queueId}/tasks/${taskId}/activity`;
      await _optionalChain([networker, 'optionalAccess', _12 => _12.httpHandler, 'call', _13 => _13(url, payload)]);
      getActivity();
    }
  }, [task, orgId, queueId]);
  const onDelete = react__WEBPACK_IMPORTED_MODULE_0___default.a.useCallback(async deleteId => {
    const {
      id: taskId,
      queue_id: queueId
    } = task || {};

    if (taskId && queueId) {
      const payload = {
        method: 'DELETE'
      };
      const url = `/orgs/${orgId}/queues/${queueId}/tasks/${taskId}/activity/${deleteId}`;
      await _optionalChain([networker, 'optionalAccess', _14 => _14.httpHandler, 'call', _15 => _15(url, payload)]);
      getActivity();
    }
  }, [task, orgId, queueId]);
  const onAuditDecision = react__WEBPACK_IMPORTED_MODULE_0___default.a.useCallback(async correct => {
    const {
      id: taskId
    } = task || {};

    if (taskId && orgId) {
      const payload = {
        method: 'PUT',
        data: {
          correct: correct
        }
      };
      const url = `/orgs/${orgId}/queues/tasks/${taskId}/audit`;
      await _optionalChain([networker, 'optionalAccess', _16 => _16.httpHandler, 'call', _17 => _17(url, payload)]);
      getTask();
      getActivity();
    }
  }, [task, orgId, queueId]);
  const onAssign = react__WEBPACK_IMPORTED_MODULE_0___default.a.useCallback(async userId => {
    const config = {
      method: 'POST',
      data: {
        assigned_to: userId
      }
    };
    const url = `/orgs/${orgId}/queues/${queueId}/tasks/${task.id}/assign`;
    const {
      data
    } = await networker.httpHandler(url, config);

    if (!data) {
      if (userId) {
        console.error(`FAILED TO ASSIGN TASK`);
      } else {
        console.error(`FAILED TO UNASSIGN TASK`);
      }

      console.error('ERROR ASSIGNING TASK');
    } else {
      getRefreshedTask();
      getActivity();
    }
  }, [task]);
  if (!_optionalChain([task, 'optionalAccess', _18 => _18.id])) return null;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_Task__WEBPACK_IMPORTED_MODULE_4__["default"], {
    userId: userId,
    isAudits: _optionalChain([task, 'optionalAccess', _19 => _19.status]) === 'completed',
    task: task,
    onSubmit: onSubmit,
    orgId: orgId,
    onSave: onSave,
    onPost: onPost,
    onDelete: onDelete,
    onAssign: onAssign,
    taskNav: taskNav,
    activity: activity,
    isStaff: isStaff,
    onAuditDecision: onAuditDecision,
    isLoading: taskLoading || activityLoading,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 278
    }
  });
};

const mapStateToProps = state => ({
  auditFilters: state.filters.auditFilters
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_1__["connect"])(mapStateToProps, null)(TaskRoot));

/***/ }),

/***/ "./src/universal/modules/task/components/Task.tsx":
/*!********************************************************!*\
  !*** ./src/universal/modules/task/components/Task.tsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var universal_components_RGL__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! universal/components/RGL */ "./src/universal/components/RGL.tsx");
/* harmony import */ var universal_components_BlockComponent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/components/BlockComponent */ "./src/universal/components/BlockComponent.tsx");
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var universal_components_PrimaryButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! universal/components/PrimaryButton */ "./src/universal/components/PrimaryButton.tsx");
/* harmony import */ var universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/components/SecondaryButton */ "./src/universal/components/SecondaryButton.tsx");
/* harmony import */ var _Sidebar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Sidebar */ "./src/universal/modules/task/components/Sidebar.tsx");
/* harmony import */ var client_hooks_useRouter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! client/hooks/useRouter */ "./src/client/hooks/useRouter.ts");
/* harmony import */ var universal_components_AppHeader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! universal/components/AppHeader */ "./src/universal/components/AppHeader.tsx");
/* harmony import */ var universal_components_BlockWrapper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! universal/components/BlockWrapper */ "./src/universal/components/BlockWrapper.tsx");
/* harmony import */ var universal_validations_yupSchema__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! universal/validations/yupSchema */ "./src/universal/validations/yupSchema.ts");
/* harmony import */ var universal_modules_audits_components_AuditDecision__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! universal/modules/audits/components/AuditDecision */ "./src/universal/modules/audits/components/AuditDecision.tsx");
/* harmony import */ var client_components_Spinner__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! client/components/Spinner */ "./src/client/components/Spinner.tsx");
/* harmony import */ var client_hooks_useModal__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! client/hooks/useModal */ "./src/client/hooks/useModal.ts");
/* harmony import */ var client_components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! client/components/ConfirmationModal */ "./src/client/components/ConfirmationModal.tsx");
/* harmony import */ var client_redux_queuesReducers__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! client/redux/queuesReducers */ "./src/client/redux/queuesReducers.ts");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/modules/task/components/Task.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}




















const FormContainer = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(formik__WEBPACK_IMPORTED_MODULE_3__["Form"], {
  target: "e90iyce0"
})({
  name: "py5jdu",
  styles: "display:flex;height:100%;flex-direction:column;"
});

const Content = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e90iyce1"
})({
  name: "t40y15",
  styles: "display:flex;flex-direction:row;width:100%;height:100%;overflow:hidden;"
});

const ActionBlock = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e90iyce2"
})("width:100%;display:grid;grid-template-columns:min-content ", props => props.audits ? '35px 35px' : '', " min-content;column-gap:20px;justify-content:flex-end;flex-direction:row;");

const QueueName = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e90iyce3"
})({
  fontWeight: 500,
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_6__["PALETTE"].TEXT_MAIN
});

const Task = props => {
  const {
    onDelete,
    onPost,
    userId,
    activity,
    task,
    onSubmit,
    taskNav,
    orgId,
    onSave,
    users,
    onAssign,
    isAudits,
    onAuditDecision,
    isLoading,
    isStaff,
    queues,
    setSelectedQueue
  } = props;
  const {
    id: taskId,
    queue_id: queueId,
    correct: correct
  } = task || {};
  const {
    history
  } = Object(client_hooks_useRouter__WEBPACK_IMPORTED_MODULE_10__["default"])();
  const [assignedTo, setAssignedTo] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(taskId);
  const {
    next,
    previous
  } = taskNav || {};
  const returnUrl = `/queues/${queueId}` || 'queues';
  const {
    queue
  } = task || '';
  const layouts = task.data.map(block => block.layout);
  const isNotAssignedToMe = assignedTo !== userId;
  let readOnly = isAudits || isNotAssignedToMe;

  if (isStaff && isNotAssignedToMe) {
    readOnly = true;
  }

  const [isSubmiting, setSubmiting] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const [isSaving, setSaving] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const [view, setView] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const [assigneeDetails, setAssigneeDetails] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const {
    location: {
      pathname,
      state: locationState
    }
  } = history || {};
  const formRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])();
  const [taskChanged, setTaskChanged] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(_optionalChain([locationState, 'optionalAccess', _ => _.taskChanged]) || false);
  const {
    modalPortal: confirmTask,
    togglePortal: toggleTaskModal,
    closePortal: closeTaskModal
  } = Object(client_hooks_useModal__WEBPACK_IMPORTED_MODULE_16__["default"])();
  const {
    modalPortal: confirmAssignee,
    togglePortal: toggleAssigneeModal,
    closePortal: closeAssigneeModal
  } = Object(client_hooks_useModal__WEBPACK_IMPORTED_MODULE_16__["default"])();
  const isAuditsRequestedFromUrl = pathname.includes('audit');
  const isLoadingPrevious = view === 'previous';
  const isLoadingNext = view === 'next';
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    const {
      assigned_to
    } = task || {};
    setAssignedTo(assigned_to);
    const currentQueue = queues.find(q => q.id === task.queue_id);

    if (currentQueue) {
      setSelectedQueue(currentQueue);
    }
  }, [isAudits, task]);

  const resetView = () => setView(null);

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(formik__WEBPACK_IMPORTED_MODULE_3__["Formik"], {
    enableReinitialize: true,
    initialValues: task,
    onSubmit: (_values, formikBag) => {
      formikBag.setSubmitting(false);
    },
    validateOnChange: true,
    validateOnBlur: true,
    validateOnMount: true,
    validationSchema: universal_validations_yupSchema__WEBPACK_IMPORTED_MODULE_13__["taskSchema"],
    innerRef: formRef,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 139
    }
  }, ({
    handleChange,
    values,
    setFieldValue,
    isSubmitting,
    isValid,
    errors,
    handleBlur,
    validateForm
  }) => {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FormContainer, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 162
      }
    }, isAudits && isAuditsRequestedFromUrl ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_AppHeader__WEBPACK_IMPORTED_MODULE_11__["default"], {
      leftBarItems: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_8__["default"], {
        key: "back",
        type: "button",
        onClick: () => history.replace('/audits'),
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 166
        }
      }, "Back"),
      midBarItems: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(QueueName, {
        key: "name",
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 174
        }
      }, queue),
      rightBarItems: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ActionBlock, {
        audits: !isStaff ? true : false,
        key: "nav_block",
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 176
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_8__["default"], {
        hideFocus: true,
        disabled: !previous,
        type: "button",
        onClick: () => {
          setView('previous');
          history.replace(previous);
        },
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 177
        }
      }, isLoadingPrevious && isLoading ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Spinner__WEBPACK_IMPORTED_MODULE_15__["default"], {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 186
        }
      }) : `Previous`), !isStaff && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_modules_audits_components_AuditDecision__WEBPACK_IMPORTED_MODULE_14__["default"], {
        orgId: orgId,
        queueId: queueId,
        taskId: taskId,
        correct: correct,
        onAuditDecision: args => {
          resetView();
          onAuditDecision(args);
        },
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 189
        }
      }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_PrimaryButton__WEBPACK_IMPORTED_MODULE_7__["default"], {
        hideFocus: true,
        disabled: !next,
        type: "button",
        onClick: () => {
          setView('next');
          history.replace(next);
        },
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 200
        }
      }, isLoadingNext && isLoading ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Spinner__WEBPACK_IMPORTED_MODULE_15__["default"], {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 209
        }
      }) : `Next`)),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 164
      }
    }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_AppHeader__WEBPACK_IMPORTED_MODULE_11__["default"], {
      leftBarItems: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_8__["default"], {
        key: "back",
        type: "button",
        onClick: () => {
          if (taskChanged && formRef.current.dirty) {
            toggleTaskModal();
          } else {
            history.replace(returnUrl);
          }
        },
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 217
        }
      }, "Back"),
      midBarItems: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(QueueName, {
        key: "name",
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 231
        }
      }, queue),
      rightBarItems: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ActionBlock, {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 233
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_8__["default"], {
        hideFocus: true,
        disabled: readOnly || isSubmitting,
        type: "button",
        onClick: async () => {
          setSaving(true);
          await onSave(values);
          setTaskChanged(false);
          setSaving(false);
          validateForm(values);
        },
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 234
        }
      }, isSaving ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Spinner__WEBPACK_IMPORTED_MODULE_15__["default"], {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 246
        }
      }) : `Save`), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_PrimaryButton__WEBPACK_IMPORTED_MODULE_7__["default"], {
        hideFocus: true,
        disabled: readOnly || isSubmitting || !isValid,
        type: "submit",
        onClick: async e => {
          setSubmiting(true);
          await onSubmit(e, values, orgId);
          setSubmiting(false);
        },
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 248
        }
      }, isSubmiting ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_Spinner__WEBPACK_IMPORTED_MODULE_15__["default"], {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 258
        }
      }) : `Submit`)),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 215
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(formik__WEBPACK_IMPORTED_MODULE_3__["FieldArray"], {
      name: "data",
      render: () => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Content, {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 267
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Sidebar__WEBPACK_IMPORTED_MODULE_9__["default"], {
        onPost: args => {
          resetView();
          onPost(args);
        },
        onDelete: args => {
          resetView();
          onDelete(args);
        },
        assignedTo: assignedTo,
        task: task,
        users: users,
        onAssign: (assignee, assignor) => {
          resetView();
          setAssigneeDetails({
            assignee,
            assignor
          });

          if (taskChanged && formRef.current.dirty) {
            toggleAssigneeModal();
          } else {
            onAssign(assignee, assignor);
          }
        },
        queueId: queueId,
        orgId: orgId,
        activity: activity,
        isAudits: isAudits,
        correct: correct,
        queue: queue,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 268
        }
      }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('div', {
        style: {
          width: '100%'
        },
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 299
        }
      }, !(isAudits && isLoadingNext && isLoading || isLoadingPrevious && isLoading) && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_RGL__WEBPACK_IMPORTED_MODULE_4__["default"], {
        isDraggable: false,
        isDroppable: false,
        isResizable: false,
        layouts: layouts,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 304
        }
      }, values.data.map((block, idx) => {
        let errorsForBlock = {};

        if (errors.data && errors.data[idx] !== undefined) {
          errorsForBlock = errors.data[idx];
        }

        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockWrapper__WEBPACK_IMPORTED_MODULE_12__["default"], {
          key: block.id,
          'data-grid': block.layout,
          index: idx,
          type: block.type,
          __self: undefined,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 316
          }
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockComponent__WEBPACK_IMPORTED_MODULE_5__["default"], {
          setFieldValue: (field, data) => {
            setTaskChanged(true);
            setFieldValue(field, data);
          },
          block: block,
          errors: errorsForBlock,
          handleChange: e => {
            setTaskChanged(true);
            handleChange(e);
          },
          handleBlur: handleBlur,
          index: idx,
          isEditing: false,
          isAudits: readOnly,
          __self: undefined,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 322
          }
        }));
      }))), confirmTask( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_17__["default"], {
        closePortal: closeTaskModal,
        label: `Exit without saving`,
        cancelLabel: `Save and Exit`,
        message: `You have made changes but they haven't been saved.`,
        onConfirm: () => {
          history.replace(returnUrl);
        },
        onCancel: async () => {
          setSaving(true);
          await onSave(values);
          setTaskChanged(false);
          setSaving(false);
          history.replace(returnUrl);
        },
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 346
        }
      })), confirmAssignee( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_17__["default"], {
        closePortal: closeAssigneeModal,
        label: `Reassign without saving`,
        cancelLabel: `Save and Reassign`,
        message: `You have made changes but they haven't been saved.`,
        onConfirm: () => {
          resetView();
          onAssign(assigneeDetails.assignee, assigneeDetails.assignor);
          setAssigneeDetails(null);
        },
        onCancel: async () => {
          setSaving(true);
          await onSave(values);
          setTaskChanged(false);
          setSaving(false);
          resetView();
          onAssign(assigneeDetails.assignee, assigneeDetails.assignor);
        },
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 364
        }
      }))),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 264
      }
    }));
  }));
};

const mapStateToProps = state => ({
  users: state.users,
  queues: state.queues.queues
});

const mapDispatchToProps = dispatch => ({
  setSelectedQueue: arg => dispatch(client_redux_queuesReducers__WEBPACK_IMPORTED_MODULE_18__["workfllowActions"].setSelectedQueue(arg))
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps, mapDispatchToProps)(Task));

/***/ }),

/***/ "./src/universal/utils/formatValues.ts":
/*!*********************************************!*\
  !*** ./src/universal/utils/formatValues.ts ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}



const formatValues = values => {
  let fields;

  if (Array.isArray(values.data)) {
    fields = values.data;
  } else if (Array.isArray(values)) {
    fields = values;
  } else {
    return values;
  }

  fields.filter(val => {
    if (val[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION] !== undefined) {
      _optionalChain([val, 'access', _ => _[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION], 'access', _2 => _2.entities, 'optionalAccess', _3 => _3.filter, 'call', _4 => _4(entity => {
        delete entity.color;
        delete entity.text;
      })]);
    }

    if (val[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].BOUNDING_BOXES] !== undefined) {
      if (Array.isArray(val[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].BOUNDING_BOXES].value.objects)) {
        val[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].BOUNDING_BOXES].value.objects.filter(entity => {
          delete entity.color;
        });
      }

      if (val[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].BOUNDING_BOXES].value.image === '') {
        val[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].BOUNDING_BOXES].value.image = null;
      }
    }

    return val;
  });
  return values;
};

/* harmony default export */ __webpack_exports__["default"] = (formatValues);

/***/ }),

/***/ 1:
/*!********************************!*\
  !*** ./util.inspect (ignored) ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvZGF5anMvZGF5anMubWluLmpzIiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvY29tcG9uZW50cy9TcGlubmVyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY2xpZW50L3V0aWxzL2lzVXNlclN0YWZmLnRzIiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvbW9kdWxlcy9hdWRpdHMvY29tcG9uZW50cy9BdWRpdERlY2lzaW9uLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL21vZHVsZXMvdGFzay9UYXNrUm9vdC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9tb2R1bGVzL3Rhc2svY29tcG9uZW50cy9UYXNrLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL3V0aWxzL2Zvcm1hdFZhbHVlcy50cyIsIndlYnBhY2s6Ly8vLi91dGlsLmluc3BlY3QgKGlnbm9yZWQpIl0sIm5hbWVzIjpbIl9qc3hGaWxlTmFtZSIsImtleWZyYW1lc1NwaW4iLCJrZXlmcmFtZXMiLCJMb2FkZXIiLCJib3JkZXIiLCJQQUxFVFRFIiwiQk9SREVSX0dSQVkiLCJib3JkZXJSYWRpdXMiLCJib3JkZXJUb3AiLCJQUklNQVJZX01BSU4iLCJ3aWR0aCIsImhlaWdodCIsImFuaW1hdGlvbk5hbWUiLCJ0b1N0cmluZyIsImFuaW1hdGlvbkR1cmF0aW9uIiwiYW5pbWF0aW9uSXRlcmF0aW9uQ291bnQiLCJTcGlubmVyIiwiUmVhY3QiLCJjcmVhdGVFbGVtZW50IiwiX19zZWxmIiwiX19zb3VyY2UiLCJmaWxlTmFtZSIsImxpbmVOdW1iZXIiLCJpc1VzZXJTdGFmZiIsIm9yZ2FuaXphdGlvbnMiLCJjdXJyZW50X29yZ2FuaXphdGlvbl9pZCIsIm9yZyIsImlkIiwiU1RBRkZfT1JHX0lEIiwiRGVjaXNpb25CdXR0b24iLCJQbGFpbkJ1dHRvbiIsInByb3BzIiwiaXNBcHByb3ZlIiwiaXNBY3RpdmUiLCJjb2xvciIsIlBSSU1BUllfR1JFRU4iLCJFUlJPUl9NQUlOIiwiYmFja2dyb3VuZENvbG9yIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwiYm94U2hhZG93Iiwib3V0bGluZSIsInRyYW5zaXRpb24iLCJTdHlsZWRJY29uIiwiSWNvbiIsImNsaWNrSGFuZGxlciIsIm9uQXVkaXREZWNpc2lvbiIsInNldENvcnJlY3RTdGF0ZSIsImNvcnJlY3QiLCJkZWNpc2lvbiIsIm5ld0RlY2lzaW9uIiwiQXVkaXREZWNpc2lvbiIsImNvcnJlY3RTdGF0ZSIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiRnJhZ21lbnQiLCJrZXkiLCJ0eXBlIiwib25DbGljayIsIl9vcHRpb25hbENoYWluIiwib3BzIiwibGFzdEFjY2Vzc0xIUyIsInVuZGVmaW5lZCIsInZhbHVlIiwiaSIsImxlbmd0aCIsIm9wIiwiZm4iLCJhcmdzIiwiY2FsbCIsIlRhc2tSb290IiwibmV0d29ya2VyIiwidXNlTmV0d29ya2VyIiwiaGlzdG9yeSIsInVzZVJvdXRlciIsImRpc3BhdGNoIiwidXNlRGlzcGF0Y2giLCJ1c2VyIiwiYXVkaXRGaWx0ZXJzIiwidXNlcklkIiwiZW1haWwiLCJvcmdJZCIsInRhc2tJZCIsInF1ZXVlSWQiLCJ1c2VQYXJhbXMiLCJ0YXNrIiwic2V0VGFzayIsInRhc2tMb2FkaW5nIiwic2V0VGFza0xvYWRpbmciLCJhY3Rpdml0eSIsInNldEFjdGl2aXR5IiwiYWN0aXZpdHlMb2FkaW5nIiwic2V0QWN0aXZpdHlMb2FkaW5nIiwidGFza05hdiIsInNldFRhc2tOYXYiLCJpc1N0YWZmIiwic2V0SXNTdGFmZiIsImxvY2F0aW9uIiwicGF0aG5hbWUiLCJzdGF0ZSIsImlzQXVkaXRzUmVxdWVzdGVkRnJvbVVybCIsImluY2x1ZGVzIiwiZ2V0VGFzayIsInBheWxvYWQiLCJtZXRob2QiLCJ1cmwiLCJhdWRpdHNVcmwiLCJkYXRhIiwiaHR0cEhhbmRsZXIiLCJwYXJhbXMiLCJwYXJhbXNTZXJpYWxpemVyIiwicXMiLCJzdHJpbmdpZnkiLCJyZXN1bHQiLCJuZXh0IiwicHJldmlvdXMiLCJvcmdzIiwiZ2V0UmVmcmVzaGVkVGFzayIsImNvbnNvbGUiLCJlcnJvciIsImdldEFjdGl2aXR5IiwicXVldWVfaWQiLCJfIiwiXzIiLCJfMyIsIm5leHRUYXNrIiwiXzQiLCJfNSIsIm9uU3VibWl0IiwidXNlQ2FsbGJhY2siLCJlIiwidmFsdWVzIiwibmV4dFVybCIsImNvbmZpZyIsInRyYW5zZm9ybURhdGVzIiwiZm9ybWF0VmFsdWVzIiwidXBkYXRlVXJsIiwibmV4dFRhc2tVcmwiLCJyZXF1aXJlZFR5cGUiLCJyZXF1aXJlZE5hbWUiLCJyZXF1aXJlZCIsImJsb2NrIiwiQkxPQ0tfVFlQRSIsIkZPUk1fU0VRVUVOQ0UiLCJuYW1lIiwiaXNfcmVxdWlyZWQiLCJpc1JlcXVpcmVkIiwiYmxvY2tWYWx1ZSIsInJlcXVpcmVkRXJyb3IiLCJtYXAiLCJzb21lIiwicmVxdWlyZWRWYWx1ZSIsIlRFWFQiLCJOVU1CRVIiLCJFTUFJTCIsIkxJTksiLCJhZGRGYWlsdXJlTm90aWZpY2F0aW9uIiwidXBkYXRlZFRhc2siLCJfNiIsIl83Iiwic2VnbWVudFRyYWNrIiwiXzgiLCJfOSIsInJlcGxhY2UiLCJwdXNoIiwiYWRkU3VjY2Vzc05vdGlmaWNhdGlvbiIsIm9uU2F2ZSIsIl8xMCIsIl8xMSIsIm9uUG9zdCIsImNvbW1lbnQiLCJhY3Rpb24iLCJfMTIiLCJfMTMiLCJvbkRlbGV0ZSIsImRlbGV0ZUlkIiwiXzE0IiwiXzE1IiwiXzE2IiwiXzE3Iiwib25Bc3NpZ24iLCJhc3NpZ25lZF90byIsIl8xOCIsIlRhc2siLCJpc0F1ZGl0cyIsIl8xOSIsInN0YXR1cyIsImlzTG9hZGluZyIsIm1hcFN0YXRlVG9Qcm9wcyIsImZpbHRlcnMiLCJjb25uZWN0IiwiRm9ybUNvbnRhaW5lciIsIkZvcm0iLCJDb250ZW50IiwiQWN0aW9uQmxvY2siLCJhdWRpdHMiLCJRdWV1ZU5hbWUiLCJURVhUX01BSU4iLCJ1c2VycyIsInF1ZXVlcyIsInNldFNlbGVjdGVkUXVldWUiLCJhc3NpZ25lZFRvIiwic2V0QXNzaWduZWRUbyIsInJldHVyblVybCIsInF1ZXVlIiwibGF5b3V0cyIsImxheW91dCIsImlzTm90QXNzaWduZWRUb01lIiwicmVhZE9ubHkiLCJpc1N1Ym1pdGluZyIsInNldFN1Ym1pdGluZyIsImlzU2F2aW5nIiwic2V0U2F2aW5nIiwidmlldyIsInNldFZpZXciLCJhc3NpZ25lZURldGFpbHMiLCJzZXRBc3NpZ25lZURldGFpbHMiLCJsb2NhdGlvblN0YXRlIiwiZm9ybVJlZiIsInVzZVJlZiIsInRhc2tDaGFuZ2VkIiwic2V0VGFza0NoYW5nZWQiLCJtb2RhbFBvcnRhbCIsImNvbmZpcm1UYXNrIiwidG9nZ2xlUG9ydGFsIiwidG9nZ2xlVGFza01vZGFsIiwiY2xvc2VQb3J0YWwiLCJjbG9zZVRhc2tNb2RhbCIsInVzZU1vZGFsIiwiY29uZmlybUFzc2lnbmVlIiwidG9nZ2xlQXNzaWduZWVNb2RhbCIsImNsb3NlQXNzaWduZWVNb2RhbCIsImlzTG9hZGluZ1ByZXZpb3VzIiwiaXNMb2FkaW5nTmV4dCIsImN1cnJlbnRRdWV1ZSIsImZpbmQiLCJxIiwicmVzZXRWaWV3IiwiRm9ybWlrIiwiZW5hYmxlUmVpbml0aWFsaXplIiwiaW5pdGlhbFZhbHVlcyIsIl92YWx1ZXMiLCJmb3JtaWtCYWciLCJzZXRTdWJtaXR0aW5nIiwidmFsaWRhdGVPbkNoYW5nZSIsInZhbGlkYXRlT25CbHVyIiwidmFsaWRhdGVPbk1vdW50IiwidmFsaWRhdGlvblNjaGVtYSIsInRhc2tTY2hlbWEiLCJpbm5lclJlZiIsImhhbmRsZUNoYW5nZSIsInNldEZpZWxkVmFsdWUiLCJpc1N1Ym1pdHRpbmciLCJpc1ZhbGlkIiwiZXJyb3JzIiwiaGFuZGxlQmx1ciIsInZhbGlkYXRlRm9ybSIsIkFwcEhlYWRlciIsImxlZnRCYXJJdGVtcyIsIlNlY29uZGFyeUJ1dHRvbiIsIm1pZEJhckl0ZW1zIiwicmlnaHRCYXJJdGVtcyIsImhpZGVGb2N1cyIsImRpc2FibGVkIiwiUHJpbWFyeUJ1dHRvbiIsImN1cnJlbnQiLCJkaXJ0eSIsIkZpZWxkQXJyYXkiLCJyZW5kZXIiLCJTaWRlYmFyIiwiYXNzaWduZWUiLCJhc3NpZ25vciIsInN0eWxlIiwiUkdMIiwiaXNEcmFnZ2FibGUiLCJpc0Ryb3BwYWJsZSIsImlzUmVzaXphYmxlIiwiaWR4IiwiZXJyb3JzRm9yQmxvY2siLCJCbG9ja1dyYXBwZXIiLCJpbmRleCIsIkJsb2NrQ29tcG9uZW50IiwiZmllbGQiLCJpc0VkaXRpbmciLCJDb25maXJtYXRpb25Nb2RhbCIsImxhYmVsIiwiY2FuY2VsTGFiZWwiLCJtZXNzYWdlIiwib25Db25maXJtIiwib25DYW5jZWwiLCJtYXBEaXNwYXRjaFRvUHJvcHMiLCJhcmciLCJ3b3JrZmxsb3dBY3Rpb25zIiwiZmllbGRzIiwiQXJyYXkiLCJpc0FycmF5IiwiZmlsdGVyIiwidmFsIiwiTkFNRURfRU5USVRZX1JFQ09HTklUSU9OIiwiZW50aXRpZXMiLCJlbnRpdHkiLCJ0ZXh0IiwiQk9VTkRJTkdfQk9YRVMiLCJvYmplY3RzIiwiaW1hZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLGVBQWUsS0FBb0Qsb0JBQW9CLFNBQTJELENBQUMsaUJBQWlCLGFBQWEsb0hBQW9ILEVBQUUsVUFBVSxJQUFJLFdBQVcsSUFBSSxZQUFZLElBQUksUUFBUSxJQUFJLFFBQVEsSUFBSSxpQ0FBaUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLE9BQU8sSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLFVBQVUsbU1BQW1NLG1CQUFtQixnQkFBZ0IseURBQXlELElBQUksa0JBQWtCLDZEQUE2RCwrQ0FBK0MsbUJBQW1CLG1DQUFtQyw4R0FBOEcsbUNBQW1DLGVBQWUseUNBQXlDLGVBQWUsT0FBTyx5Q0FBeUMsa0RBQWtELGVBQWUsbUJBQW1CLGFBQWEsT0FBTyxrQkFBa0Isc0JBQXNCLG1CQUFtQixNQUFNLGVBQWUsa0RBQWtELEtBQUssYUFBYSxXQUFXLDRCQUE0QixpQkFBaUIseUJBQXlCLDhCQUE4QiwwQ0FBMEMsS0FBSyw4QkFBOEIsWUFBWSw4Q0FBOEMsR0FBRyxpQkFBaUIsY0FBYywwQ0FBMEMsa0JBQWtCLDJCQUEyQixvQkFBb0IscUJBQXFCLGlDQUFpQywwQkFBMEIsd0NBQXdDLHVDQUF1QyxpQkFBaUIsTUFBTSw2Q0FBNkMsMEhBQTBILG1CQUFtQixtQkFBbUIsYUFBYSxtQkFBbUIsY0FBYyxvTEFBb0wscUJBQXFCLFNBQVMsc0JBQXNCLDZDQUE2Qyx3QkFBd0IsV0FBVyw0Q0FBNEMseUJBQXlCLDRCQUE0QiwwQkFBMEIsMEJBQTBCLHNCQUFzQixvQ0FBb0MsbUJBQW1CLHNDQUFzQyxzQkFBc0IseUJBQXlCLHlCQUF5QixrREFBa0Qsd0RBQXdELHNCQUFzQixpQkFBaUIsdUZBQXVGLDBEQUEwRCxVQUFVLGdDQUFnQyxnQ0FBZ0MseURBQXlELDBCQUEwQixvQ0FBb0MsK0JBQStCLCtCQUErQixvQ0FBb0MsNkJBQTZCLHFCQUFxQiwwQkFBMEIsc0JBQXNCLGlEQUFpRCx5S0FBeUssaUJBQWlCLDRCQUE0QiwwRUFBMEUsc0JBQXNCLHdCQUF3QixxQkFBcUIsOEJBQThCLG1CQUFtQixzQkFBc0IscUJBQXFCLGFBQWEsWUFBWSwyQkFBMkIsV0FBVyxnREFBZ0Qsc0NBQXNDLHNDQUFzQyxxQkFBcUIscUJBQXFCLFdBQVcsOERBQThELG1CQUFtQiwwQkFBMEIsd0JBQXdCLHNCQUFzQixXQUFXLHdDQUF3Qyx1SUFBdUksMkNBQTJDLGVBQWUsMkJBQTJCLCtCQUErQixxQkFBcUIsMkJBQTJCLElBQUksa1pBQWtaLGlDQUFpQyxrQ0FBa0MsRUFBRSx3QkFBd0Isc0RBQXNELHdCQUF3QixvRkFBb0YsY0FBYyxvSEFBb0gsMEJBQTBCLHdCQUF3QixzQkFBc0Isa0JBQWtCLHdCQUF3QixxQkFBcUIsK0JBQStCLHFCQUFxQixvQkFBb0IseUJBQXlCLHFCQUFxQixnQ0FBZ0MscUJBQXFCLDhDQUE4QywwQkFBMEIsNkJBQTZCLHVCQUF1Qiw2QkFBNkIsR0FBRyxpQkFBaUIsb0hBQW9ILG9CQUFvQiw2QkFBNkIseUJBQXlCLGtDQUFrQywyQ0FBMkMsZ0JBQWdCLHdCQUF3QixHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0F4eE0sTUFBTUEsWUFBWSxHQUFHLHFFQUFyQjtBQUEyRjtBQUMzRjtBQUVBO0FBRUEsTUFBTUMsYUFBYSxHQUFHQyx1REFBVTtBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVBBOztBQVNBLE1BQU1DLE1BQU0sR0FBRztBQUFBO0FBQUEsR0FBVztBQUN4QkMsUUFBTSxFQUFHLGFBQVlDLHNEQUFPLENBQUNDLFdBQVksRUFEakI7QUFFeEJDLGNBQVksRUFBRSxLQUZVO0FBR3hCQyxXQUFTLEVBQUcsYUFBWUgsc0RBQU8sQ0FBQ0ksWUFBYSxFQUhyQjtBQUl4QkMsT0FBSyxFQUFFLEVBSmlCO0FBS3hCQyxRQUFNLEVBQUUsRUFMZ0I7QUFNeEJDLGVBQWEsRUFBRVgsYUFBYSxDQUFDWSxRQUFkLEVBTlM7QUFPeEJDLG1CQUFpQixFQUFFLElBUEs7QUFReEJDLHlCQUF1QixFQUFFO0FBUkQsQ0FBWCxDQUFmOztBQVdBLE1BQU1DLE9BQU8sR0FBRyxtQkFBTUMsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmYsTUFBcEIsRUFBNEI7QUFBQ2dCLFFBQU0sRUFBRSxTQUFUO0FBQWVDLFVBQVEsRUFBRTtBQUFDQyxZQUFRLEVBQUVyQixZQUFYO0FBQXlCc0IsY0FBVSxFQUFFO0FBQXJDO0FBQXpCLENBQTVCLENBQXRCOztBQUVlTixzRUFBZixFOzs7Ozs7Ozs7Ozs7QUMzQkE7QUFBQTtBQUFBOztBQUVBLE1BQU1PLFdBQVcsR0FBRyxDQUFDQyxhQUFELEVBQWdCQyx1QkFBaEIsS0FBNEM7QUFDOUQsT0FBSyxNQUFNQyxHQUFYLElBQWtCRixhQUFsQixFQUFpQztBQUMvQixRQUFJRSxHQUFHLENBQUNDLEVBQUosS0FBV0Msc0VBQVgsSUFBMkJILHVCQUF1QixLQUFLRyxzRUFBM0QsRUFBeUUsT0FBTyxJQUFQO0FBQzFFOztBQUVELFNBQU8sS0FBUDtBQUNELENBTkQ7O0FBT2VMLDBFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDVEEsTUFBTXZCLFlBQVksR0FBRyw2RkFBckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFlQSxNQUFNNkIsY0FBYyxHQUFHLGtGQUFPQyxxRUFBUDtBQUFBO0FBQUEsR0FBcUJDLEtBQUQsSUFBVztBQUNwRCxRQUFNO0FBQUNDLGFBQUQ7QUFBWUM7QUFBWixNQUF3QkYsS0FBOUI7QUFDQSxRQUFNRyxLQUFLLEdBQUdGLFNBQVMsR0FBRzNCLGdFQUFPLENBQUM4QixhQUFYLEdBQTJCOUIsZ0VBQU8sQ0FBQytCLFVBQTFEO0FBRUEsU0FBTztBQUNMMUIsU0FBSyxFQUFFLE1BREY7QUFFTDJCLG1CQUFlLEVBQUVKLFFBQVEsR0FBR0MsS0FBSCxHQUFXLE9BRi9CO0FBR0xBLFNBQUssRUFBRUQsUUFBUSxHQUFHLE9BQUgsR0FBYUMsS0FIdkI7QUFJTDlCLFVBQU0sRUFBRyxhQUFZNkIsUUFBUSxHQUFHLE9BQUgsR0FBYUMsS0FBTSxFQUozQztBQUtMSSxZQUFRLEVBQUUsTUFMTDtBQU1MQyxjQUFVLEVBQUUsR0FOUDtBQU9MQyxhQUFTLEVBQUUsZ0ZBUE47QUFRTEMsV0FBTyxFQUFFLENBUko7QUFTTEMsY0FBVSxFQUFFLHVCQVRQO0FBVUwsY0FBVTtBQUNSRixlQUFTLEVBQUcsYUFBWVIsU0FBUyxHQUFHLHFCQUFILEdBQTJCLHFCQUFzQjtBQUQxRSxLQVZMO0FBYUwsZUFBVztBQUNUSyxxQkFBZSxFQUFFSixRQUFRLEdBQUcsT0FBSCxHQUFhQyxLQUQ3QjtBQUVUQSxXQUFLLEVBQUVELFFBQVEsR0FBR0MsS0FBSCxHQUFXLE9BRmpCO0FBR1Q5QixZQUFNLEVBQUcsYUFBWTZCLFFBQVEsR0FBR0MsS0FBSCxHQUFXLE9BQVE7QUFIdkM7QUFiTixHQUFQO0FBbUJELENBdkJzQixDQUF2Qjs7QUF5QkEsTUFBTVMsVUFBVSxHQUFHLGtGQUFPQyxpRUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBbkI7QUFNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFNBQVNDLFlBQVQsQ0FDRUMsZUFERixFQUVFQyxlQUZGLEVBR0VDLE9BSEYsRUFJRUMsUUFKRixFQUtFO0FBQ0EsUUFBTUMsV0FBVyxHQUFHRixPQUFPLEtBQUtDLFFBQVosR0FBdUIsSUFBdkIsR0FBOEJBLFFBQWxEO0FBQ0FGLGlCQUFlLENBQUNHLFdBQUQsQ0FBZjtBQUNBSixpQkFBZSxDQUFDSSxXQUFELENBQWY7QUFDRDs7QUFFRCxNQUFNQyxhQUFhLEdBQUlwQixLQUFELElBQVc7QUFDL0IsUUFBTTtBQUFDaUIsV0FBRDtBQUFVRjtBQUFWLE1BQTZCZixLQUFuQztBQUNBLFFBQU0sQ0FBQ3FCLFlBQUQsRUFBZUwsZUFBZixJQUFrQ00sc0RBQVEsQ0FBQ0wsT0FBRCxDQUFoRDtBQUVBTSx5REFBUyxDQUFDLE1BQU07QUFDZFAsbUJBQWUsQ0FBQ0MsT0FBRCxDQUFmO0FBQ0QsR0FGUSxFQUVOLENBQUNBLE9BQUQsQ0FGTSxDQUFUO0FBSUEsc0JBQ0UvQiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CcUMsOENBQXBCLEVBQThCO0FBQUNwQyxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFckIsWUFBWDtBQUF5QnNCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBOUIsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQlcsY0FBcEIsRUFBb0M7QUFDcEMyQixPQUFHLEVBQUUsU0FEK0I7QUFFcENDLFFBQUksRUFBRSxRQUY4QjtBQUdwQ0MsV0FBTyxFQUFFLE1BQU07QUFDYmIsa0JBQVksQ0FBQ0MsZUFBRCxFQUFrQkMsZUFBbEIsRUFBbUNLLFlBQW5DLEVBQWlELElBQWpELENBQVo7QUFDRCxLQUxtQztBQU1wQ3BCLGFBQVMsRUFBRSxJQU55QjtBQU9wQ0MsWUFBUSxFQUFFbUIsWUFBWSxLQUFLLElBUFM7QUFPSGpDLFVBQU0sRUFBRSxTQVBMO0FBT1dDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUVyQixZQUFYO0FBQXlCc0IsZ0JBQVUsRUFBRTtBQUFyQztBQVByQixHQUFwQyxlQVNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeUIsVUFBcEIsRUFBZ0M7QUFBQ3hCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUVyQixZQUFYO0FBQXlCc0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFoQyxFQUFvRyxNQUFwRyxDQVRGLENBREosZUFZSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQlcsY0FBcEIsRUFBb0M7QUFDcEMyQixPQUFHLEVBQUUsUUFEK0I7QUFFcENDLFFBQUksRUFBRSxRQUY4QjtBQUdwQ0MsV0FBTyxFQUFFLE1BQU07QUFDYmIsa0JBQVksQ0FBQ0MsZUFBRCxFQUFrQkMsZUFBbEIsRUFBbUNLLFlBQW5DLEVBQWlELEtBQWpELENBQVo7QUFDRCxLQUxtQztBQU1wQ3BCLGFBQVMsRUFBRSxLQU55QjtBQU9wQ0MsWUFBUSxFQUFFbUIsWUFBWSxLQUFLLEtBUFM7QUFPRmpDLFVBQU0sRUFBRSxTQVBOO0FBT1lDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUVyQixZQUFYO0FBQXlCc0IsZ0JBQVUsRUFBRTtBQUFyQztBQVB0QixHQUFwQyxlQVNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeUIsVUFBcEIsRUFBZ0M7QUFBQ3hCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUVyQixZQUFYO0FBQXlCc0IsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFoQyxFQUFxRyxPQUFyRyxDQVRGLENBWkosQ0FERjtBQTBCRCxDQWxDRDs7QUFvQ2U2Qiw0RUFBZixFOzs7Ozs7Ozs7Ozs7QUMxR0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUFNbkQsWUFBWSxHQUFHLDJFQUFyQjs7QUFBa0csU0FBUzJELGNBQVQsQ0FBd0JDLEdBQXhCLEVBQTZCO0FBQUUsTUFBSUMsYUFBYSxHQUFHQyxTQUFwQjtBQUErQixNQUFJQyxLQUFLLEdBQUdILEdBQUcsQ0FBQyxDQUFELENBQWY7QUFBb0IsTUFBSUksQ0FBQyxHQUFHLENBQVI7O0FBQVcsU0FBT0EsQ0FBQyxHQUFHSixHQUFHLENBQUNLLE1BQWYsRUFBdUI7QUFBRSxVQUFNQyxFQUFFLEdBQUdOLEdBQUcsQ0FBQ0ksQ0FBRCxDQUFkO0FBQW1CLFVBQU1HLEVBQUUsR0FBR1AsR0FBRyxDQUFDSSxDQUFDLEdBQUcsQ0FBTCxDQUFkO0FBQXVCQSxLQUFDLElBQUksQ0FBTDs7QUFBUSxRQUFJLENBQUNFLEVBQUUsS0FBSyxnQkFBUCxJQUEyQkEsRUFBRSxLQUFLLGNBQW5DLEtBQXNESCxLQUFLLElBQUksSUFBbkUsRUFBeUU7QUFBRSxhQUFPRCxTQUFQO0FBQW1COztBQUFDLFFBQUlJLEVBQUUsS0FBSyxRQUFQLElBQW1CQSxFQUFFLEtBQUssZ0JBQTlCLEVBQWdEO0FBQUVMLG1CQUFhLEdBQUdFLEtBQWhCO0FBQXVCQSxXQUFLLEdBQUdJLEVBQUUsQ0FBQ0osS0FBRCxDQUFWO0FBQW9CLEtBQTdGLE1BQW1HLElBQUlHLEVBQUUsS0FBSyxNQUFQLElBQWlCQSxFQUFFLEtBQUssY0FBNUIsRUFBNEM7QUFBRUgsV0FBSyxHQUFHSSxFQUFFLENBQUMsQ0FBQyxHQUFHQyxJQUFKLEtBQWFMLEtBQUssQ0FBQ00sSUFBTixDQUFXUixhQUFYLEVBQTBCLEdBQUdPLElBQTdCLENBQWQsQ0FBVjtBQUE2RFAsbUJBQWEsR0FBR0MsU0FBaEI7QUFBNEI7QUFBRTs7QUFBQyxTQUFPQyxLQUFQO0FBQWU7O0FBQUE7QUFDcm1CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUlBO0FBQ0E7QUFDQTtBQUNBOztBQU9BLE1BQU1PLFFBQVEsR0FBSXZDLEtBQUQsSUFBVztBQUMxQixRQUFNd0MsU0FBUyxHQUFHQyx5RUFBWSxFQUE5QjtBQUNBLFFBQU07QUFBQ0M7QUFBRCxNQUFZQyxzRUFBUyxFQUEzQjtBQUNBLFFBQU1DLFFBQVEsR0FBR0MsK0RBQVcsRUFBNUI7QUFDQSxRQUFNO0FBQUNDLFFBQUQ7QUFBT0M7QUFBUCxNQUF1Qi9DLEtBQTdCO0FBQ0EsUUFBTTtBQUFDSixNQUFFLEVBQUVvRCxNQUFMO0FBQWFDLFNBQWI7QUFBb0JDO0FBQXBCLE1BQTZCSixJQUFJLElBQUksRUFBM0M7QUFDQSxRQUFNO0FBQUNLLFVBQUQ7QUFBU0M7QUFBVCxNQUFvQkMsa0VBQVMsRUFBbkM7QUFDQSxRQUFNLENBQUNDLElBQUQsRUFBT0MsT0FBUCxJQUFrQmpDLHNEQUFRLENBQUMsRUFBRCxDQUFoQztBQUNBLFFBQU0sQ0FBQ2tDLFdBQUQsRUFBY0MsY0FBZCxJQUFnQ25DLHNEQUFRLENBQUMsS0FBRCxDQUE5QztBQUNBLFFBQU0sQ0FBQ29DLFFBQUQsRUFBV0MsV0FBWCxJQUEwQnJDLHNEQUFRLENBQUMsRUFBRCxDQUF4QztBQUNBLFFBQU0sQ0FBQ3NDLGVBQUQsRUFBa0JDLGtCQUFsQixJQUF3Q3ZDLHNEQUFRLENBQUMsS0FBRCxDQUF0RDtBQUNBLFFBQU0sQ0FBQ3dDLE9BQUQsRUFBVUMsVUFBVixJQUF3QnpDLHNEQUFRLENBQUMsRUFBRCxDQUF0QztBQUNBLFFBQU0sQ0FBQzBDLE9BQUQsRUFBVUMsVUFBVixJQUF3QjNDLHNEQUFRLENBQUMsS0FBRCxDQUF0QztBQUVBLFFBQU07QUFDSjRDLFlBQVEsRUFBRTtBQUFDQyxjQUFEO0FBQVdDO0FBQVg7QUFETixNQUVGMUIsT0FBTyxJQUFJLEVBRmY7QUFJQSxRQUFNMkIsd0JBQXdCLEdBQUdGLFFBQVEsQ0FBQ0csUUFBVCxDQUFrQixPQUFsQixDQUFqQzs7QUFFQSxpQkFBZUMsT0FBZixHQUF5QjtBQUN2QixVQUFNQyxPQUFPLEdBQUc7QUFBQ0MsWUFBTSxFQUFFO0FBQVQsS0FBaEI7QUFDQSxVQUFNQyxHQUFHLEdBQUksU0FBUXhCLEtBQU0sV0FBVUUsT0FBUSxVQUFTRCxNQUFPLEVBQTdEO0FBQ0EsVUFBTXdCLFNBQVMsR0FBSSxTQUFRekIsS0FBTSxpQkFBZ0JDLE1BQU8sUUFBeEQ7QUFDQU0sa0JBQWMsQ0FBQyxJQUFELENBQWQ7O0FBQ0EsUUFBSVksd0JBQUosRUFBOEI7QUFDNUIsWUFBTTtBQUFDTyxZQUFJLEVBQUV0QjtBQUFQLFVBQWUsTUFBTWQsU0FBUyxDQUFDcUMsV0FBVixDQUFzQkYsU0FBdEIsRUFBaUM7QUFDMURHLGNBQU0sRUFBRS9CLFlBRGtEO0FBRTFEZ0Msd0JBQWdCLEVBQUdELE1BQUQsSUFBWUUseUNBQUUsQ0FBQ0MsU0FBSCxDQUFhSCxNQUFiLENBRjRCO0FBRzFETCxjQUFNLEVBQUU7QUFIa0QsT0FBakMsQ0FBM0I7QUFLQSxZQUFNO0FBQUNTLGNBQUQ7QUFBU0MsWUFBVDtBQUFlQztBQUFmLFVBQTJCOUIsSUFBSSxJQUFJLEVBQXpDO0FBQ0FDLGFBQU8sQ0FBQzJCLE1BQUQsQ0FBUDtBQUNBbkIsZ0JBQVUsQ0FBQztBQUFDcUIsZ0JBQUQ7QUFBV0Q7QUFBWCxPQUFELENBQVY7QUFDRCxLQVRELE1BU087QUFDTCxZQUFNO0FBQUNQLFlBQUksRUFBRXRCO0FBQVAsVUFBZSxNQUFNZCxTQUFTLENBQUNxQyxXQUFWLENBQXNCSCxHQUF0QixFQUEyQkYsT0FBM0IsQ0FBM0I7QUFDQWpCLGFBQU8sQ0FBQ0QsSUFBRCxDQUFQO0FBQ0Q7O0FBRUQsVUFBTTtBQUFDc0IsVUFBSSxFQUFFUztBQUFQLFFBQWUsTUFBTTdDLFNBQVMsQ0FBQ3FDLFdBQVYsQ0FBdUIsT0FBdkIsRUFBK0I7QUFBQ0osWUFBTSxFQUFFO0FBQVQsS0FBL0IsQ0FBM0I7QUFDQVIsY0FBVSxDQUFDekUseUVBQVcsQ0FBQzZGLElBQUQsRUFBT25DLEtBQVAsQ0FBWixDQUFWO0FBRUFPLGtCQUFjLENBQUMsS0FBRCxDQUFkO0FBQ0Q7O0FBRUQsaUJBQWU2QixnQkFBZixHQUFrQztBQUNoQyxVQUFNZCxPQUFPLEdBQUc7QUFBQ0MsWUFBTSxFQUFFO0FBQVQsS0FBaEI7QUFDQSxVQUFNQyxHQUFHLEdBQUksU0FBUXhCLEtBQU0sV0FBVUUsT0FBUSxVQUFTRCxNQUFPLFVBQTdEO0FBQ0EsVUFBTTtBQUFDeUIsVUFBSSxFQUFFdEI7QUFBUCxRQUFlLE1BQU1kLFNBQVMsQ0FBQ3FDLFdBQVYsQ0FBc0JILEdBQXRCLEVBQTJCRixPQUEzQixDQUEzQjs7QUFDQSxRQUFJLENBQUNsQixJQUFMLEVBQVc7QUFDVGlDLGFBQU8sQ0FBQ0MsS0FBUixDQUFjLCtCQUFkO0FBQ0QsS0FGRCxNQUVPO0FBQ0xqQyxhQUFPLENBQUNELElBQUQsQ0FBUDtBQUNEO0FBQ0Y7O0FBRUQsUUFBTW1DLFdBQVcsR0FBRyxZQUFZO0FBQzlCLFVBQU07QUFBQzdGLFFBQUUsRUFBRXVELE1BQUw7QUFBYXVDLGNBQVEsRUFBRXRDO0FBQXZCLFFBQWtDRSxJQUFJLElBQUksRUFBaEQ7O0FBQ0EsUUFBSUgsTUFBTSxJQUFJQyxPQUFkLEVBQXVCO0FBQ3JCUyx3QkFBa0IsQ0FBQyxJQUFELENBQWxCO0FBQ0EsWUFBTVcsT0FBTyxHQUFHO0FBQUNDLGNBQU0sRUFBRTtBQUFULE9BQWhCO0FBQ0EsWUFBTUMsR0FBRyxHQUFJLFNBQVF4QixLQUFNLFdBQVVFLE9BQVEsVUFBU0QsTUFBTyxXQUE3RDtBQUNBLFlBQU07QUFBQ3lCO0FBQUQsVUFBUyxNQUFNaEQsY0FBYyxDQUFDLENBQUNZLFNBQUQsRUFBWSxnQkFBWixFQUE4Qm1ELENBQUMsSUFBSUEsQ0FBQyxDQUFDZCxXQUFyQyxFQUFrRCxNQUFsRCxFQUEwRGUsRUFBRSxJQUFJQSxFQUFFLENBQUNsQixHQUFELEVBQU1GLE9BQU4sQ0FBbEUsQ0FBRCxDQUFuQzs7QUFDQSxVQUFJLENBQUNJLElBQUwsRUFBVztBQUNUVyxlQUFPLENBQUNDLEtBQVIsQ0FBYyw4QkFBZDtBQUNELE9BRkQsTUFFTztBQUNMN0IsbUJBQVcsQ0FBQ2lCLElBQUQsQ0FBWDtBQUNEO0FBQ0Y7O0FBQ0RmLHNCQUFrQixDQUFDLEtBQUQsQ0FBbEI7QUFDRCxHQWREOztBQWdCQXRDLHlEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUlLLGNBQWMsQ0FBQyxDQUFDd0MsS0FBRCxFQUFRLGdCQUFSLEVBQTBCeUIsRUFBRSxJQUFJQSxFQUFFLENBQUNDLFFBQW5DLEVBQTZDLGdCQUE3QyxFQUErREMsRUFBRSxJQUFJQSxFQUFFLENBQUNuRyxFQUF4RSxDQUFELENBQWxCLEVBQWlHO0FBQy9GMkQsYUFBTyxDQUFDYSxLQUFLLENBQUMwQixRQUFQLENBQVA7QUFDRCxLQUZELE1BRU8sSUFBSTNDLE1BQU0sSUFBSUQsS0FBZCxFQUFxQjtBQUMxQnFCLGFBQU87QUFDUjtBQUNGLEdBTlEsRUFNTixDQUFDcEIsTUFBRCxFQUFTRCxLQUFULEVBQWdCSixJQUFoQixFQUFzQk0sT0FBdEIsQ0FOTSxDQUFUO0FBUUE3Qix5REFBUyxDQUFDLE1BQU07QUFDZCxVQUFNO0FBQUMzQixRQUFEO0FBQUs4RixjQUFRLEVBQUV0QztBQUFmLFFBQTBCRSxJQUFJLElBQUksRUFBeEM7O0FBQ0EsUUFBSTFELEVBQUUsSUFBSXdELE9BQVYsRUFBbUI7QUFDakJxQyxpQkFBVztBQUNaO0FBQ0YsR0FMUSxFQUtOLENBQUN0QyxNQUFELEVBQVN2QixjQUFjLENBQUMsQ0FBQzBCLElBQUQsRUFBTyxnQkFBUCxFQUF5QjBDLEVBQUUsSUFBSUEsRUFBRSxDQUFDcEcsRUFBbEMsQ0FBRCxDQUF2QixDQUxNLENBQVQ7QUFPQSxRQUFNcUcsUUFBUSxHQUFHL0csNENBQUssQ0FBQ2dILFdBQU4sQ0FBa0IsT0FBT0MsQ0FBUCxFQUFVQyxNQUFWLEVBQWtCbEQsS0FBbEIsS0FBNEI7QUFDN0QsVUFBTTtBQUFDdEQsUUFBRSxFQUFFdUQ7QUFBTCxRQUFlaUQsTUFBckI7QUFFQSxRQUFJQyxPQUFKOztBQUNBLFFBQUlsRCxNQUFNLElBQUlELEtBQWQsRUFBcUI7QUFDbkIsWUFBTW9ELE1BQU0sR0FBRztBQUNiN0IsY0FBTSxFQUFFLE9BREs7QUFFYkcsWUFBSSxFQUFFMkIsZ0ZBQWMsQ0FBQyxJQUFELEVBQU9DLDZFQUFZLENBQUNKLE1BQUQsQ0FBbkI7QUFGUCxPQUFmO0FBSUEsWUFBTUssU0FBUyxHQUFJLFNBQVF2RCxLQUFNLFdBQVVFLE9BQVEsVUFBU0QsTUFBTyxFQUFuRTtBQUNBLFlBQU11RCxXQUFXLEdBQUksU0FBUXhELEtBQU0sV0FBVUUsT0FBUSxhQUFyRDtBQUVBLFVBQUl1RCxZQUFKO0FBQ0EsVUFBSUMsWUFBSjs7QUFDQSxZQUFNQyxRQUFRLEdBQUlDLEtBQUQsSUFBVztBQUMxQixZQUFJLENBQUNDLG9FQUFVLENBQUNDLGFBQWhCLEVBQStCO0FBQzdCLGdCQUFNO0FBQUN0RixnQkFBRDtBQUFPdUY7QUFBUCxjQUFlSCxLQUFyQjtBQUNBLGdCQUFNO0FBQUNJLHVCQUFXLEVBQUVDLFVBQWQ7QUFBMEJuRixpQkFBSyxFQUFFb0Y7QUFBakMsY0FBK0NOLEtBQUssQ0FBQ3BGLElBQUQsQ0FBMUQ7QUFDQWtGLHNCQUFZLEdBQUdLLElBQWY7QUFDQU4sc0JBQVksR0FBR2pGLElBQWY7QUFDQSxpQkFBUXlGLFVBQVUsSUFBSUMsVUFBVSxLQUFLLEVBQTlCLElBQXNDRCxVQUFVLElBQUksQ0FBQ0MsVUFBNUQ7QUFDRCxTQU5ELE1BTU87QUFDTCxpQkFBTyxLQUFQO0FBQ0Q7QUFDRixPQVZEOztBQVlBLFlBQU1DLGFBQWEsR0FBR2IsNkVBQVksQ0FBQ0osTUFBTSxDQUFDeEIsSUFBUixDQUFaLENBQTBCMEMsR0FBMUIsQ0FBOEJmLHdFQUE5QixFQUE4Q2dCLElBQTlDLENBQW1EVixRQUFuRCxDQUF0QjtBQUNBLFlBQU1XLGFBQWEsR0FDakJiLFlBQVksS0FBS0ksb0VBQVUsQ0FBQ1UsSUFBNUIsSUFDQWQsWUFBWSxLQUFLSSxvRUFBVSxDQUFDVyxNQUQ1QixJQUVBZixZQUFZLEtBQUtJLG9FQUFVLENBQUNZLEtBRjVCLElBR0FoQixZQUFZLEtBQUtJLG9FQUFVLENBQUNhLElBSDVCLEdBSUksT0FKSixHQUtJLFdBTk47O0FBUUEsVUFBSVAsYUFBSixFQUFtQjtBQUNqQnpFLGdCQUFRLENBQUNpRiw2SEFBc0IsQ0FBRSxLQUFJTCxhQUFjLG9CQUFtQlosWUFBYSxFQUFwRCxDQUF2QixDQUFSO0FBQ0E7QUFDRCxPQWxDa0IsQ0FvQ25COzs7QUFDQSxZQUFNO0FBQUNoQyxZQUFJLEVBQUVrRDtBQUFQLFVBQXNCLE1BQU1sRyxjQUFjLENBQUMsQ0FBQ1ksU0FBRCxFQUFZLGdCQUFaLEVBQThCdUYsRUFBRSxJQUFJQSxFQUFFLENBQUNsRCxXQUF2QyxFQUFvRCxNQUFwRCxFQUE0RG1ELEVBQUUsSUFBSUEsRUFBRSxDQUFDdkIsU0FBRCxFQUFZSCxNQUFaLENBQXBFLENBQUQsQ0FBaEQ7O0FBQ0EsVUFBSSxDQUFDd0IsV0FBTCxFQUFrQjtBQUNoQnZDLGVBQU8sQ0FBQ0MsS0FBUixDQUFlLHFCQUFmO0FBQ0QsT0FGRCxNQUVPO0FBQ0x5QyxtRkFBWSxDQUFDLGdCQUFELEVBQW1CO0FBQUM5RSxnQkFBTSxFQUFFQSxNQUFUO0FBQWlCRCxlQUFqQjtBQUF3QkYsZ0JBQXhCO0FBQWdDQyxlQUFoQztBQUF1Q0c7QUFBdkMsU0FBbkIsQ0FBWjtBQUNBLGNBQU07QUFBQ3dCLGNBQUksRUFBRWtCO0FBQVAsWUFBbUIsTUFBTWxFLGNBQWMsQ0FBQyxDQUFDWSxTQUFELEVBQVksZ0JBQVosRUFBOEIwRixFQUFFLElBQUlBLEVBQUUsQ0FBQ3JELFdBQXZDLEVBQW9ELE1BQXBELEVBQTREc0QsRUFBRSxJQUFJQSxFQUFFLENBQUN6QixXQUFELEVBQWM7QUFBQ2pDLGdCQUFNLEVBQUU7QUFBVCxTQUFkLENBQXBFLENBQUQsQ0FBN0M7O0FBRUEsWUFBSSxDQUFDcUIsUUFBTCxFQUFlO0FBQ2IsaUJBQU9wRCxPQUFPLENBQUMwRixPQUFSLENBQWlCLFdBQVVoRixPQUFRLEVBQW5DLENBQVA7QUFDRCxTQUZELE1BRU87QUFDTCxjQUFJMEMsUUFBUSxDQUFDbEcsRUFBYixFQUFpQjtBQUNmeUcsbUJBQU8sR0FBSSxXQUFVakQsT0FBUSxVQUFTMEMsUUFBUSxDQUFDbEcsRUFBRyxFQUFsRDtBQUNBcUksdUZBQVksQ0FBQyxjQUFELEVBQWlCO0FBQUM5RSxvQkFBTSxFQUFFMkMsUUFBUSxDQUFDbEcsRUFBbEI7QUFBc0JzRCxtQkFBdEI7QUFBNkJGLG9CQUE3QjtBQUFxQ0MsbUJBQXJDO0FBQTRDRztBQUE1QyxhQUFqQixDQUFaO0FBQ0FWLG1CQUFPLENBQUMyRixJQUFSLENBQWE7QUFDWGxFLHNCQUFRLEVBQUVrQyxPQURDO0FBRVhqQyxtQkFBSyxFQUFFO0FBQUMwQjtBQUFEO0FBRkksYUFBYjtBQUlELFdBUEQsTUFPTztBQUNMbEQsb0JBQVEsQ0FDTjBGLDZIQUFzQixDQUFDLDhEQUFELENBRGhCLENBQVI7QUFHQUwsdUZBQVksQ0FBQyxxQkFBRCxFQUF3QjtBQUFDL0UsbUJBQUQ7QUFBUUYsb0JBQVI7QUFBZ0JDLG1CQUFoQjtBQUF1Qkc7QUFBdkIsYUFBeEIsQ0FBWjtBQUNBLG1CQUFPVixPQUFPLENBQUMwRixPQUFSLENBQWlCLFdBQVVoRixPQUFRLEVBQW5DLENBQVA7QUFDRDtBQUNGO0FBQ0Y7QUFDRixLQS9ERCxNQStETztBQUNMbUMsYUFBTyxDQUFDQyxLQUFSLENBQWMsdUJBQWQ7QUFDRDtBQUNGLEdBdEVnQixFQXNFZCxFQXRFYyxDQUFqQjtBQXdFQSxRQUFNK0MsTUFBTSxHQUFHckosNENBQUssQ0FBQ2dILFdBQU4sQ0FDYixNQUFPRSxNQUFQLElBQWtCO0FBQ2hCLFFBQUk5QyxJQUFJLENBQUMxRCxFQUFULEVBQWE7QUFDWCxZQUFNMEcsTUFBTSxHQUFHO0FBQ2I3QixjQUFNLEVBQUUsT0FESztBQUViRyxZQUFJLEVBQUUyQixnRkFBYyxDQUFDLElBQUQsRUFBT0MsNkVBQVksQ0FBQ0osTUFBRCxDQUFuQjtBQUZQLE9BQWY7QUFJQSxZQUFNMUIsR0FBRyxHQUFJLFNBQVF4QixLQUFNLFdBQVVFLE9BQVEsVUFBU0UsSUFBSSxDQUFDMUQsRUFBRyxPQUE5RDtBQUNBLFlBQU07QUFBQ2dGO0FBQUQsVUFBUyxNQUFNaEQsY0FBYyxDQUFDLENBQUNZLFNBQUQsRUFBWSxnQkFBWixFQUE4QmdHLEdBQUcsSUFBSUEsR0FBRyxDQUFDM0QsV0FBekMsRUFBc0QsTUFBdEQsRUFBOEQ0RCxHQUFHLElBQUlBLEdBQUcsQ0FBQy9ELEdBQUQsRUFBTTRCLE1BQU4sQ0FBeEUsQ0FBRCxDQUFuQzs7QUFDQSxVQUFJLENBQUMxQixJQUFMLEVBQVc7QUFDVFcsZUFBTyxDQUFDQyxLQUFSLENBQWUsbUJBQWY7QUFDRCxPQUZELE1BRU87QUFDTEYsd0JBQWdCO0FBQ2hCRyxtQkFBVztBQUNaO0FBQ0YsS0FiRCxNQWFPO0FBQ0xGLGFBQU8sQ0FBQ0MsS0FBUixDQUFjLGNBQWQ7QUFDRDtBQUNGLEdBbEJZLEVBbUJiLENBQUNsQyxJQUFELEVBQU9KLEtBQVAsQ0FuQmEsQ0FBZjtBQXNCQSxRQUFNd0YsTUFBTSxHQUFHeEosNENBQUssQ0FBQ2dILFdBQU4sQ0FDYixNQUFPeUMsT0FBUCxJQUFtQjtBQUNqQixVQUFNO0FBQUMvSSxRQUFFLEVBQUV1RCxNQUFMO0FBQWF1QyxjQUFRLEVBQUV0QztBQUF2QixRQUFrQ0UsSUFBSSxJQUFJLEVBQWhEOztBQUNBLFFBQUlILE1BQU0sSUFBSUMsT0FBZCxFQUF1QjtBQUNyQixZQUFNb0IsT0FBTyxHQUFHO0FBQ2RDLGNBQU0sRUFBRSxNQURNO0FBRWRHLFlBQUksRUFBRTtBQUFDZ0UsZ0JBQU0sRUFBRSxTQUFUO0FBQW9CRCxpQkFBTyxFQUFFQTtBQUE3QjtBQUZRLE9BQWhCO0FBSUEsWUFBTWpFLEdBQUcsR0FBSSxTQUFReEIsS0FBTSxXQUFVRSxPQUFRLFVBQVNELE1BQU8sV0FBN0Q7QUFDQSxZQUFNdkIsY0FBYyxDQUFDLENBQUNZLFNBQUQsRUFBWSxnQkFBWixFQUE4QnFHLEdBQUcsSUFBSUEsR0FBRyxDQUFDaEUsV0FBekMsRUFBc0QsTUFBdEQsRUFBOERpRSxHQUFHLElBQUlBLEdBQUcsQ0FBQ3BFLEdBQUQsRUFBTUYsT0FBTixDQUF4RSxDQUFELENBQXBCO0FBQ0FpQixpQkFBVztBQUNaO0FBQ0YsR0FaWSxFQWFiLENBQUNuQyxJQUFELEVBQU9KLEtBQVAsRUFBY0UsT0FBZCxDQWJhLENBQWY7QUFnQkEsUUFBTTJGLFFBQVEsR0FBRzdKLDRDQUFLLENBQUNnSCxXQUFOLENBQ2YsTUFBTzhDLFFBQVAsSUFBb0I7QUFDbEIsVUFBTTtBQUFDcEosUUFBRSxFQUFFdUQsTUFBTDtBQUFhdUMsY0FBUSxFQUFFdEM7QUFBdkIsUUFBa0NFLElBQUksSUFBSSxFQUFoRDs7QUFDQSxRQUFJSCxNQUFNLElBQUlDLE9BQWQsRUFBdUI7QUFDckIsWUFBTW9CLE9BQU8sR0FBRztBQUNkQyxjQUFNLEVBQUU7QUFETSxPQUFoQjtBQUdBLFlBQU1DLEdBQUcsR0FBSSxTQUFReEIsS0FBTSxXQUFVRSxPQUFRLFVBQVNELE1BQU8sYUFBWTZGLFFBQVMsRUFBbEY7QUFDQSxZQUFNcEgsY0FBYyxDQUFDLENBQUNZLFNBQUQsRUFBWSxnQkFBWixFQUE4QnlHLEdBQUcsSUFBSUEsR0FBRyxDQUFDcEUsV0FBekMsRUFBc0QsTUFBdEQsRUFBOERxRSxHQUFHLElBQUlBLEdBQUcsQ0FBQ3hFLEdBQUQsRUFBTUYsT0FBTixDQUF4RSxDQUFELENBQXBCO0FBQ0FpQixpQkFBVztBQUNaO0FBQ0YsR0FYYyxFQVlmLENBQUNuQyxJQUFELEVBQU9KLEtBQVAsRUFBY0UsT0FBZCxDQVplLENBQWpCO0FBZUEsUUFBTXJDLGVBQWUsR0FBRzdCLDRDQUFLLENBQUNnSCxXQUFOLENBQ3RCLE1BQU9qRixPQUFQLElBQW1CO0FBQ2pCLFVBQU07QUFBQ3JCLFFBQUUsRUFBRXVEO0FBQUwsUUFBZUcsSUFBSSxJQUFJLEVBQTdCOztBQUNBLFFBQUlILE1BQU0sSUFBSUQsS0FBZCxFQUFxQjtBQUNuQixZQUFNc0IsT0FBTyxHQUFHO0FBQ2RDLGNBQU0sRUFBRSxLQURNO0FBRWRHLFlBQUksRUFBRTtBQUFDM0QsaUJBQU8sRUFBRUE7QUFBVjtBQUZRLE9BQWhCO0FBSUEsWUFBTXlELEdBQUcsR0FBSSxTQUFReEIsS0FBTSxpQkFBZ0JDLE1BQU8sUUFBbEQ7QUFDQSxZQUFNdkIsY0FBYyxDQUFDLENBQUNZLFNBQUQsRUFBWSxnQkFBWixFQUE4QjJHLEdBQUcsSUFBSUEsR0FBRyxDQUFDdEUsV0FBekMsRUFBc0QsTUFBdEQsRUFBOER1RSxHQUFHLElBQUlBLEdBQUcsQ0FBQzFFLEdBQUQsRUFBTUYsT0FBTixDQUF4RSxDQUFELENBQXBCO0FBQ0FELGFBQU87QUFDUGtCLGlCQUFXO0FBQ1o7QUFDRixHQWJxQixFQWN0QixDQUFDbkMsSUFBRCxFQUFPSixLQUFQLEVBQWNFLE9BQWQsQ0Fkc0IsQ0FBeEI7QUFpQkEsUUFBTWlHLFFBQVEsR0FBR25LLDRDQUFLLENBQUNnSCxXQUFOLENBQ2YsTUFBT2xELE1BQVAsSUFBa0I7QUFDaEIsVUFBTXNELE1BQU0sR0FBRztBQUFDN0IsWUFBTSxFQUFFLE1BQVQ7QUFBaUJHLFVBQUksRUFBRTtBQUFDMEUsbUJBQVcsRUFBRXRHO0FBQWQ7QUFBdkIsS0FBZjtBQUNBLFVBQU0wQixHQUFHLEdBQUksU0FBUXhCLEtBQU0sV0FBVUUsT0FBUSxVQUFTRSxJQUFJLENBQUMxRCxFQUFHLFNBQTlEO0FBQ0EsVUFBTTtBQUFDZ0Y7QUFBRCxRQUFTLE1BQU1wQyxTQUFTLENBQUNxQyxXQUFWLENBQXNCSCxHQUF0QixFQUEyQjRCLE1BQTNCLENBQXJCOztBQUNBLFFBQUksQ0FBQzFCLElBQUwsRUFBVztBQUNULFVBQUk1QixNQUFKLEVBQVk7QUFDVnVDLGVBQU8sQ0FBQ0MsS0FBUixDQUFlLHVCQUFmO0FBQ0QsT0FGRCxNQUVPO0FBQ0xELGVBQU8sQ0FBQ0MsS0FBUixDQUFlLHlCQUFmO0FBQ0Q7O0FBQ0RELGFBQU8sQ0FBQ0MsS0FBUixDQUFjLHNCQUFkO0FBQ0QsS0FQRCxNQU9PO0FBQ0xGLHNCQUFnQjtBQUNoQkcsaUJBQVc7QUFDWjtBQUNGLEdBaEJjLEVBaUJmLENBQUNuQyxJQUFELENBakJlLENBQWpCO0FBb0JBLE1BQUksQ0FBQzFCLGNBQWMsQ0FBQyxDQUFDMEIsSUFBRCxFQUFPLGdCQUFQLEVBQXlCaUcsR0FBRyxJQUFJQSxHQUFHLENBQUMzSixFQUFwQyxDQUFELENBQW5CLEVBQThELE9BQU8sSUFBUDtBQUU5RCxzQkFDRVYsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnFLLHdEQUFwQixFQUEwQjtBQUN4QnhHLFVBQU0sRUFBRUEsTUFEZ0I7QUFFeEJ5RyxZQUFRLEVBQUU3SCxjQUFjLENBQUMsQ0FBQzBCLElBQUQsRUFBTyxnQkFBUCxFQUF5Qm9HLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxNQUFwQyxDQUFELENBQWQsS0FBZ0UsV0FGbEQ7QUFHeEJyRyxRQUFJLEVBQUVBLElBSGtCO0FBSXhCMkMsWUFBUSxFQUFFQSxRQUpjO0FBS3hCL0MsU0FBSyxFQUFFQSxLQUxpQjtBQU14QnFGLFVBQU0sRUFBRUEsTUFOZ0I7QUFPeEJHLFVBQU0sRUFBRUEsTUFQZ0I7QUFReEJLLFlBQVEsRUFBRUEsUUFSYztBQVN4Qk0sWUFBUSxFQUFFQSxRQVRjO0FBVXhCdkYsV0FBTyxFQUFFQSxPQVZlO0FBV3hCSixZQUFRLEVBQUVBLFFBWGM7QUFZeEJNLFdBQU8sRUFBRUEsT0FaZTtBQWF4QmpELG1CQUFlLEVBQUVBLGVBYk87QUFjeEI2SSxhQUFTLEVBQUVwRyxXQUFXLElBQUlJLGVBZEY7QUFjbUJ4RSxVQUFNLEVBQUUsU0FkM0I7QUFjaUNDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUVyQixZQUFYO0FBQXlCc0IsZ0JBQVUsRUFBRTtBQUFyQztBQWQzQyxHQUExQixDQURGO0FBa0JELENBN1FEOztBQStRQSxNQUFNc0ssZUFBZSxHQUFJekYsS0FBRCxLQUFZO0FBQ2xDckIsY0FBWSxFQUFFcUIsS0FBSyxDQUFDMEYsT0FBTixDQUFjL0c7QUFETSxDQUFaLENBQXhCOztBQUllZ0gsMEhBQU8sQ0FBQ0YsZUFBRCxFQUFrQixJQUFsQixDQUFQLENBQStCdEgsUUFBL0IsQ0FBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNVNBLE1BQU10RSxZQUFZLEdBQUcsa0ZBQXJCOztBQUF5RyxTQUFTMkQsY0FBVCxDQUF3QkMsR0FBeEIsRUFBNkI7QUFBRSxNQUFJQyxhQUFhLEdBQUdDLFNBQXBCO0FBQStCLE1BQUlDLEtBQUssR0FBR0gsR0FBRyxDQUFDLENBQUQsQ0FBZjtBQUFvQixNQUFJSSxDQUFDLEdBQUcsQ0FBUjs7QUFBVyxTQUFPQSxDQUFDLEdBQUdKLEdBQUcsQ0FBQ0ssTUFBZixFQUF1QjtBQUFFLFVBQU1DLEVBQUUsR0FBR04sR0FBRyxDQUFDSSxDQUFELENBQWQ7QUFBbUIsVUFBTUcsRUFBRSxHQUFHUCxHQUFHLENBQUNJLENBQUMsR0FBRyxDQUFMLENBQWQ7QUFBdUJBLEtBQUMsSUFBSSxDQUFMOztBQUFRLFFBQUksQ0FBQ0UsRUFBRSxLQUFLLGdCQUFQLElBQTJCQSxFQUFFLEtBQUssY0FBbkMsS0FBc0RILEtBQUssSUFBSSxJQUFuRSxFQUF5RTtBQUFFLGFBQU9ELFNBQVA7QUFBbUI7O0FBQUMsUUFBSUksRUFBRSxLQUFLLFFBQVAsSUFBbUJBLEVBQUUsS0FBSyxnQkFBOUIsRUFBZ0Q7QUFBRUwsbUJBQWEsR0FBR0UsS0FBaEI7QUFBdUJBLFdBQUssR0FBR0ksRUFBRSxDQUFDSixLQUFELENBQVY7QUFBb0IsS0FBN0YsTUFBbUcsSUFBSUcsRUFBRSxLQUFLLE1BQVAsSUFBaUJBLEVBQUUsS0FBSyxjQUE1QixFQUE0QztBQUFFSCxXQUFLLEdBQUdJLEVBQUUsQ0FBQyxDQUFDLEdBQUdDLElBQUosS0FBYUwsS0FBSyxDQUFDTSxJQUFOLENBQVdSLGFBQVgsRUFBMEIsR0FBR08sSUFBN0IsQ0FBZCxDQUFWO0FBQTZEUCxtQkFBYSxHQUFHQyxTQUFoQjtBQUE0QjtBQUFFOztBQUFDLFNBQU9DLEtBQVA7QUFBZTs7QUFBQTtBQUM1bUI7QUFFQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFxQkEsTUFBTWdJLGFBQWEsR0FBRyxrRkFBT0MsMkNBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXRCOztBQU1BLE1BQU1DLE9BQU8sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBaEI7O0FBUUEsTUFBTUMsV0FBVyxHQUFHO0FBQUg7QUFBQSxpRUFHdUJuSyxLQUFELElBQVlBLEtBQUssQ0FBQ29LLE1BQU4sR0FBZSxXQUFmLEdBQTZCLEVBSC9ELDhFQUFqQjs7QUFTQSxNQUFNQyxTQUFTLEdBQUc7QUFBQTtBQUFBLEdBQVc7QUFDM0I3SixZQUFVLEVBQUUsR0FEZTtBQUUzQkwsT0FBSyxFQUFFN0IsZ0VBQU8sQ0FBQ2dNO0FBRlksQ0FBWCxDQUFsQjs7QUFLQSxNQUFNZCxJQUFJLEdBQUl4SixLQUFELElBQVc7QUFDdEIsUUFBTTtBQUNKK0ksWUFESTtBQUVKTCxVQUZJO0FBR0oxRixVQUhJO0FBSUpVLFlBSkk7QUFLSkosUUFMSTtBQU1KMkMsWUFOSTtBQU9KbkMsV0FQSTtBQVFKWixTQVJJO0FBU0pxRixVQVRJO0FBVUpnQyxTQVZJO0FBV0psQixZQVhJO0FBWUpJLFlBWkk7QUFhSjFJLG1CQWJJO0FBY0o2SSxhQWRJO0FBZUo1RixXQWZJO0FBZ0JKd0csVUFoQkk7QUFpQkpDO0FBakJJLE1Ba0JGekssS0FsQko7QUFtQkEsUUFBTTtBQUFDSixNQUFFLEVBQUV1RCxNQUFMO0FBQWF1QyxZQUFRLEVBQUV0QyxPQUF2QjtBQUFnQ25DLFdBQU8sRUFBRUE7QUFBekMsTUFBb0RxQyxJQUFJLElBQUksRUFBbEU7QUFDQSxRQUFNO0FBQUNaO0FBQUQsTUFBWUMsdUVBQVMsRUFBM0I7QUFDQSxRQUFNLENBQUMrSCxVQUFELEVBQWFDLGFBQWIsSUFBOEJySixzREFBUSxDQUFDNkIsTUFBRCxDQUE1QztBQUNBLFFBQU07QUFBQ2dDLFFBQUQ7QUFBT0M7QUFBUCxNQUFtQnRCLE9BQU8sSUFBSSxFQUFwQztBQUNBLFFBQU04RyxTQUFTLEdBQUksV0FBVXhILE9BQVEsRUFBbkIsSUFBd0IsUUFBMUM7QUFDQSxRQUFNO0FBQUN5SDtBQUFELE1BQVV2SCxJQUFJLElBQUksRUFBeEI7QUFDQSxRQUFNd0gsT0FBTyxHQUFHeEgsSUFBSSxDQUFDc0IsSUFBTCxDQUFVMEMsR0FBVixDQUFlUixLQUFELElBQVdBLEtBQUssQ0FBQ2lFLE1BQS9CLENBQWhCO0FBQ0EsUUFBTUMsaUJBQWlCLEdBQUdOLFVBQVUsS0FBSzFILE1BQXpDO0FBQ0EsTUFBSWlJLFFBQVEsR0FBR3hCLFFBQVEsSUFBSXVCLGlCQUEzQjs7QUFDQSxNQUFJaEgsT0FBTyxJQUFJZ0gsaUJBQWYsRUFBa0M7QUFDaENDLFlBQVEsR0FBRyxJQUFYO0FBQ0Q7O0FBQ0QsUUFBTSxDQUFDQyxXQUFELEVBQWNDLFlBQWQsSUFBOEI3SixzREFBUSxDQUFDLEtBQUQsQ0FBNUM7QUFDQSxRQUFNLENBQUM4SixRQUFELEVBQVdDLFNBQVgsSUFBd0IvSixzREFBUSxDQUFDLEtBQUQsQ0FBdEM7QUFDQSxRQUFNLENBQUNnSyxJQUFELEVBQU9DLE9BQVAsSUFBa0JqSyxzREFBUSxDQUFDLElBQUQsQ0FBaEM7QUFDQSxRQUFNLENBQUNrSyxlQUFELEVBQWtCQyxrQkFBbEIsSUFBd0NuSyxzREFBUSxDQUFDLElBQUQsQ0FBdEQ7QUFDQSxRQUFNO0FBQ0o0QyxZQUFRLEVBQUU7QUFBQ0MsY0FBRDtBQUFXQyxXQUFLLEVBQUVzSDtBQUFsQjtBQUROLE1BRUZoSixPQUFPLElBQUksRUFGZjtBQUdBLFFBQU1pSixPQUFPLEdBQUdDLG9EQUFNLEVBQXRCO0FBRUEsUUFBTSxDQUFDQyxXQUFELEVBQWNDLGNBQWQsSUFBZ0N4SyxzREFBUSxDQUFDTSxjQUFjLENBQUMsQ0FBQzhKLGFBQUQsRUFBZ0IsZ0JBQWhCLEVBQWtDL0YsQ0FBQyxJQUFJQSxDQUFDLENBQUNrRyxXQUF6QyxDQUFELENBQWQsSUFBeUUsS0FBMUUsQ0FBOUM7QUFFQSxRQUFNO0FBQ0pFLGVBQVcsRUFBRUMsV0FEVDtBQUVKQyxnQkFBWSxFQUFFQyxlQUZWO0FBR0pDLGVBQVcsRUFBRUM7QUFIVCxNQUlGQyxzRUFBUSxFQUpaO0FBS0EsUUFBTTtBQUNKTixlQUFXLEVBQUVPLGVBRFQ7QUFFSkwsZ0JBQVksRUFBRU0sbUJBRlY7QUFHSkosZUFBVyxFQUFFSztBQUhULE1BSUZILHNFQUFRLEVBSlo7QUFNQSxRQUFNaEksd0JBQXdCLEdBQUdGLFFBQVEsQ0FBQ0csUUFBVCxDQUFrQixPQUFsQixDQUFqQztBQUNBLFFBQU1tSSxpQkFBaUIsR0FBR25CLElBQUksS0FBSyxVQUFuQztBQUNBLFFBQU1vQixhQUFhLEdBQUdwQixJQUFJLEtBQUssTUFBL0I7QUFFQS9KLHlEQUFTLENBQUMsTUFBTTtBQUNkLFVBQU07QUFBQytIO0FBQUQsUUFBZ0JoRyxJQUFJLElBQUksRUFBOUI7QUFDQXFILGlCQUFhLENBQUNyQixXQUFELENBQWI7QUFDQSxVQUFNcUQsWUFBWSxHQUFHbkMsTUFBTSxDQUFDb0MsSUFBUCxDQUFhQyxDQUFELElBQU9BLENBQUMsQ0FBQ2pOLEVBQUYsS0FBUzBELElBQUksQ0FBQ29DLFFBQWpDLENBQXJCOztBQUNBLFFBQUlpSCxZQUFKLEVBQWtCO0FBQ2hCbEMsc0JBQWdCLENBQUNrQyxZQUFELENBQWhCO0FBQ0Q7QUFDRixHQVBRLEVBT04sQ0FBQ2xELFFBQUQsRUFBV25HLElBQVgsQ0FQTSxDQUFUOztBQVNBLFFBQU13SixTQUFTLEdBQUcsTUFBTXZCLE9BQU8sQ0FBQyxJQUFELENBQS9COztBQUNBLHNCQUNFck0sNENBQUssQ0FBQ0MsYUFBTixDQUFvQkQsNENBQUssQ0FBQ3NDLFFBQTFCLEVBQW9DLElBQXBDLGVBQ0l0Qyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CNE4sNkNBQXBCLEVBQTRCO0FBQzVCQyxzQkFBa0IsRUFBRSxJQURRO0FBRTVCQyxpQkFBYSxFQUFFM0osSUFGYTtBQUc1QjJDLFlBQVEsRUFBRSxDQUFDaUgsT0FBRCxFQUFVQyxTQUFWLEtBQXdCO0FBQ2hDQSxlQUFTLENBQUNDLGFBQVYsQ0FBd0IsS0FBeEI7QUFDRCxLQUwyQjtBQU01QkMsb0JBQWdCLEVBQUUsSUFOVTtBQU81QkMsa0JBQWMsRUFBRSxJQVBZO0FBUTVCQyxtQkFBZSxFQUFFLElBUlc7QUFTNUJDLG9CQUFnQixFQUFFQywyRUFUVTtBQVU1QkMsWUFBUSxFQUFFL0IsT0FWa0I7QUFVVHZNLFVBQU0sRUFBRSxTQVZDO0FBVUtDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUVyQixZQUFYO0FBQXlCc0IsZ0JBQVUsRUFBRTtBQUFyQztBQVZmLEdBQTVCLEVBWUUsQ0FBQztBQUNEb08sZ0JBREM7QUFFRHZILFVBRkM7QUFHRHdILGlCQUhDO0FBSURDLGdCQUpDO0FBS0RDLFdBTEM7QUFNREMsVUFOQztBQU9EQyxjQVBDO0FBUURDO0FBUkMsR0FBRCxLQVNJO0FBQ0osd0JBQ0UvTyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CNkssYUFBcEIsRUFBbUM7QUFBQzVLLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFckIsWUFBWDtBQUF5QnNCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBbkMsRUFDSWtLLFFBQVEsSUFBSXBGLHdCQUFaLGdCQUNBbkYsNENBQUssQ0FBQ0MsYUFBTixDQUFvQitPLHVFQUFwQixFQUErQjtBQUM3QkMsa0JBQVksZUFDVmpQLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JpUCw0RUFBcEIsRUFBcUM7QUFDbkMzTSxXQUFHLEVBQUUsTUFEOEI7QUFFbkNDLFlBQUksRUFBRSxRQUY2QjtBQUduQ0MsZUFBTyxFQUFFLE1BQU1lLE9BQU8sQ0FBQzBGLE9BQVIsQ0FBZ0IsU0FBaEIsQ0FIb0I7QUFHUWhKLGNBQU0sRUFBRSxTQUhoQjtBQUdzQkMsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFckIsWUFBWDtBQUF5QnNCLG9CQUFVLEVBQUU7QUFBckM7QUFIaEMsT0FBckMsRUFJRSxNQUpGLENBRjJCO0FBVTdCOE8saUJBQVcsZUFBRW5QLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JrTCxTQUFwQixFQUErQjtBQUFFNUksV0FBRyxFQUFFLE1BQVA7QUFBZXJDLGNBQU0sRUFBRSxTQUF2QjtBQUE2QkMsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFckIsWUFBWDtBQUF5QnNCLG9CQUFVLEVBQUU7QUFBckM7QUFBdkMsT0FBL0IsRUFBa0hzTCxLQUFsSCxDQVZnQjtBQVc3QnlELG1CQUFhLGVBQ1hwUCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CZ0wsV0FBcEIsRUFBaUM7QUFBRUMsY0FBTSxFQUFFLENBQUNwRyxPQUFELEdBQVcsSUFBWCxHQUFrQixLQUE1QjtBQUFtQ3ZDLFdBQUcsRUFBRSxXQUF4QztBQUFxRHJDLGNBQU0sRUFBRSxTQUE3RDtBQUFtRUMsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFckIsWUFBWDtBQUF5QnNCLG9CQUFVLEVBQUU7QUFBckM7QUFBN0UsT0FBakMsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmlQLDRFQUFwQixFQUFxQztBQUNyQ0csaUJBQVMsRUFBRSxJQUQwQjtBQUVyQ0MsZ0JBQVEsRUFBRSxDQUFDcEosUUFGMEI7QUFHckMxRCxZQUFJLEVBQUUsUUFIK0I7QUFJckNDLGVBQU8sRUFBRSxNQUFNO0FBQ2I0SixpQkFBTyxDQUFDLFVBQUQsQ0FBUDtBQUNBN0ksaUJBQU8sQ0FBQzBGLE9BQVIsQ0FBZ0JoRCxRQUFoQjtBQUNELFNBUG9DO0FBT2xDaEcsY0FBTSxFQUFFLFNBUDBCO0FBT3BCQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUVyQixZQUFYO0FBQXlCc0Isb0JBQVUsRUFBRTtBQUFyQztBQVBVLE9BQXJDLEVBU0VrTixpQkFBaUIsSUFBSTdDLFNBQXJCLGdCQUFpQzFLLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JGLGtFQUFwQixFQUE2QjtBQUFDRyxjQUFNLEVBQUUsU0FBVDtBQUFlQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUVyQixZQUFYO0FBQXlCc0Isb0JBQVUsRUFBRTtBQUFyQztBQUF6QixPQUE3QixDQUFqQyxHQUF1SSxVQVR6SSxDQURKLEVBWUksQ0FBQ3lFLE9BQUQsaUJBQ0E5RSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CaUMsMEZBQXBCLEVBQW1DO0FBQ2pDOEIsYUFBSyxFQUFFQSxLQUQwQjtBQUVqQ0UsZUFBTyxFQUFFQSxPQUZ3QjtBQUdqQ0QsY0FBTSxFQUFFQSxNQUh5QjtBQUlqQ2xDLGVBQU8sRUFBRUEsT0FKd0I7QUFLakNGLHVCQUFlLEVBQUdzQixJQUFELElBQVU7QUFDekJ5SyxtQkFBUztBQUNUL0wseUJBQWUsQ0FBQ3NCLElBQUQsQ0FBZjtBQUNELFNBUmdDO0FBUTlCakQsY0FBTSxFQUFFLFNBUnNCO0FBUWhCQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUVyQixZQUFYO0FBQXlCc0Isb0JBQVUsRUFBRTtBQUFyQztBQVJNLE9BQW5DLENBYkosZUF3QklMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JzUCwwRUFBcEIsRUFBbUM7QUFDbkNGLGlCQUFTLEVBQUUsSUFEd0I7QUFFbkNDLGdCQUFRLEVBQUUsQ0FBQ3JKLElBRndCO0FBR25DekQsWUFBSSxFQUFFLFFBSDZCO0FBSW5DQyxlQUFPLEVBQUUsTUFBTTtBQUNiNEosaUJBQU8sQ0FBQyxNQUFELENBQVA7QUFDQTdJLGlCQUFPLENBQUMwRixPQUFSLENBQWdCakQsSUFBaEI7QUFDRCxTQVBrQztBQU9oQy9GLGNBQU0sRUFBRSxTQVB3QjtBQU9sQkMsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFckIsWUFBWDtBQUF5QnNCLG9CQUFVLEVBQUU7QUFBckM7QUFQUSxPQUFuQyxFQVNFbU4sYUFBYSxJQUFJOUMsU0FBakIsZ0JBQTZCMUssNENBQUssQ0FBQ0MsYUFBTixDQUFvQkYsa0VBQXBCLEVBQTZCO0FBQUNHLGNBQU0sRUFBRSxTQUFUO0FBQWVDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRXJCLFlBQVg7QUFBeUJzQixvQkFBVSxFQUFFO0FBQXJDO0FBQXpCLE9BQTdCLENBQTdCLEdBQW1JLE1BVHJJLENBeEJKLENBWjJCO0FBZ0QzQkgsWUFBTSxFQUFFLFNBaERtQjtBQWdEYkMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUVyQixZQUFYO0FBQXlCc0Isa0JBQVUsRUFBRTtBQUFyQztBQWhERyxLQUEvQixDQURBLGdCQW9EQUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQitPLHVFQUFwQixFQUErQjtBQUM3QkMsa0JBQVksZUFDVmpQLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JpUCw0RUFBcEIsRUFBcUM7QUFDbkMzTSxXQUFHLEVBQUUsTUFEOEI7QUFFbkNDLFlBQUksRUFBRSxRQUY2QjtBQUduQ0MsZUFBTyxFQUFFLE1BQU07QUFDYixjQUFJa0ssV0FBVyxJQUFJRixPQUFPLENBQUMrQyxPQUFSLENBQWdCQyxLQUFuQyxFQUEwQztBQUN4Q3pDLDJCQUFlO0FBQ2hCLFdBRkQsTUFFTztBQUNMeEosbUJBQU8sQ0FBQzBGLE9BQVIsQ0FBZ0J3QyxTQUFoQjtBQUNEO0FBQ0YsU0FUa0M7QUFTaEN4TCxjQUFNLEVBQUUsU0FUd0I7QUFTbEJDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRXJCLFlBQVg7QUFBeUJzQixvQkFBVSxFQUFFO0FBQXJDO0FBVFEsT0FBckMsRUFVRSxNQVZGLENBRjJCO0FBZ0I3QjhPLGlCQUFXLGVBQUVuUCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0wsU0FBcEIsRUFBK0I7QUFBRTVJLFdBQUcsRUFBRSxNQUFQO0FBQWVyQyxjQUFNLEVBQUUsU0FBdkI7QUFBNkJDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRXJCLFlBQVg7QUFBeUJzQixvQkFBVSxFQUFFO0FBQXJDO0FBQXZDLE9BQS9CLEVBQWtIc0wsS0FBbEgsQ0FoQmdCO0FBaUI3QnlELG1CQUFhLGVBQ1hwUCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CZ0wsV0FBcEIsRUFBaUM7QUFBQy9LLGNBQU0sRUFBRSxTQUFUO0FBQWVDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRXJCLFlBQVg7QUFBeUJzQixvQkFBVSxFQUFFO0FBQXJDO0FBQXpCLE9BQWpDLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JpUCw0RUFBcEIsRUFBcUM7QUFDckNHLGlCQUFTLEVBQUUsSUFEMEI7QUFFckNDLGdCQUFRLEVBQUV2RCxRQUFRLElBQUk0QyxZQUZlO0FBR3JDbk0sWUFBSSxFQUFFLFFBSCtCO0FBSXJDQyxlQUFPLEVBQUUsWUFBWTtBQUNuQjBKLG1CQUFTLENBQUMsSUFBRCxDQUFUO0FBQ0EsZ0JBQU05QyxNQUFNLENBQUNuQyxNQUFELENBQVo7QUFDQTBGLHdCQUFjLENBQUMsS0FBRCxDQUFkO0FBQ0FULG1CQUFTLENBQUMsS0FBRCxDQUFUO0FBQ0E0QyxzQkFBWSxDQUFDN0gsTUFBRCxDQUFaO0FBQ0QsU0FWb0M7QUFVbENoSCxjQUFNLEVBQUUsU0FWMEI7QUFVcEJDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRXJCLFlBQVg7QUFBeUJzQixvQkFBVSxFQUFFO0FBQXJDO0FBVlUsT0FBckMsRUFZRTZMLFFBQVEsZ0JBQUdsTSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CRixrRUFBcEIsRUFBNkI7QUFBQ0csY0FBTSxFQUFFLFNBQVQ7QUFBZUMsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFckIsWUFBWDtBQUF5QnNCLG9CQUFVLEVBQUU7QUFBckM7QUFBekIsT0FBN0IsQ0FBSCxHQUF5RyxNQVpuSCxDQURKLGVBZUlMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JzUCwwRUFBcEIsRUFBbUM7QUFDbkNGLGlCQUFTLEVBQUUsSUFEd0I7QUFFbkNDLGdCQUFRLEVBQUV2RCxRQUFRLElBQUk0QyxZQUFaLElBQTRCLENBQUNDLE9BRko7QUFHbkNwTSxZQUFJLEVBQUUsUUFINkI7QUFJbkNDLGVBQU8sRUFBRSxNQUFPd0UsQ0FBUCxJQUFhO0FBQ3BCZ0Ysc0JBQVksQ0FBQyxJQUFELENBQVo7QUFDQSxnQkFBTWxGLFFBQVEsQ0FBQ0UsQ0FBRCxFQUFJQyxNQUFKLEVBQVlsRCxLQUFaLENBQWQ7QUFDQWlJLHNCQUFZLENBQUMsS0FBRCxDQUFaO0FBQ0QsU0FSa0M7QUFRaEMvTCxjQUFNLEVBQUUsU0FSd0I7QUFRbEJDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRXJCLFlBQVg7QUFBeUJzQixvQkFBVSxFQUFFO0FBQXJDO0FBUlEsT0FBbkMsRUFVRTJMLFdBQVcsZ0JBQUdoTSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CRixrRUFBcEIsRUFBNkI7QUFBQ0csY0FBTSxFQUFFLFNBQVQ7QUFBZUMsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFckIsWUFBWDtBQUF5QnNCLG9CQUFVLEVBQUU7QUFBckM7QUFBekIsT0FBN0IsQ0FBSCxHQUF5RyxRQVZ0SCxDQWZKLENBbEIyQjtBQThDM0JILFlBQU0sRUFBRSxTQTlDbUI7QUE4Q2JDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFckIsWUFBWDtBQUF5QnNCLGtCQUFVLEVBQUU7QUFBckM7QUE5Q0csS0FBL0IsQ0FyREosZUFzR0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5UCxpREFBcEIsRUFBZ0M7QUFDaEMzSCxVQUFJLEVBQUUsTUFEMEI7QUFFaEM0SCxZQUFNLEVBQUUsbUJBQ04zUCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK0ssT0FBcEIsRUFBNkI7QUFBQzlLLGNBQU0sRUFBRSxTQUFUO0FBQWVDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRXJCLFlBQVg7QUFBeUJzQixvQkFBVSxFQUFFO0FBQXJDO0FBQXpCLE9BQTdCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IyUCxnREFBcEIsRUFBNkI7QUFDN0JwRyxjQUFNLEVBQUdyRyxJQUFELElBQVU7QUFDaEJ5SyxtQkFBUztBQUNUcEUsZ0JBQU0sQ0FBQ3JHLElBQUQsQ0FBTjtBQUNELFNBSjRCO0FBSzdCMEcsZ0JBQVEsRUFBRzFHLElBQUQsSUFBVTtBQUNsQnlLLG1CQUFTO0FBQ1QvRCxrQkFBUSxDQUFDMUcsSUFBRCxDQUFSO0FBQ0QsU0FSNEI7QUFTN0JxSSxrQkFBVSxFQUFFQSxVQVRpQjtBQVU3QnBILFlBQUksRUFBRUEsSUFWdUI7QUFXN0JpSCxhQUFLLEVBQUVBLEtBWHNCO0FBWTdCbEIsZ0JBQVEsRUFBRSxDQUFDMEYsUUFBRCxFQUFXQyxRQUFYLEtBQXdCO0FBQ2hDbEMsbUJBQVM7QUFDVHJCLDRCQUFrQixDQUFDO0FBQ2pCc0Qsb0JBRGlCO0FBRWpCQztBQUZpQixXQUFELENBQWxCOztBQUlBLGNBQUluRCxXQUFXLElBQUlGLE9BQU8sQ0FBQytDLE9BQVIsQ0FBZ0JDLEtBQW5DLEVBQTBDO0FBQ3hDcEMsK0JBQW1CO0FBQ3BCLFdBRkQsTUFFTztBQUNMbEQsb0JBQVEsQ0FBQzBGLFFBQUQsRUFBV0MsUUFBWCxDQUFSO0FBQ0Q7QUFDRixTQXZCNEI7QUF3QjdCNUwsZUFBTyxFQUFFQSxPQXhCb0I7QUF5QjdCRixhQUFLLEVBQUVBLEtBekJzQjtBQTBCN0JRLGdCQUFRLEVBQUVBLFFBMUJtQjtBQTJCN0IrRixnQkFBUSxFQUFFQSxRQTNCbUI7QUE0QjdCeEksZUFBTyxFQUFFQSxPQTVCb0I7QUE2QjdCNEosYUFBSyxFQUFFQSxLQTdCc0I7QUE2QmZ6TCxjQUFNLEVBQUUsU0E3Qk87QUE2QkRDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRXJCLFlBQVg7QUFBeUJzQixvQkFBVSxFQUFFO0FBQXJDO0FBN0JULE9BQTdCLENBREosZUFnQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsS0FBcEIsRUFBMkI7QUFBRThQLGFBQUssRUFBRTtBQUFDdFEsZUFBSyxFQUFFO0FBQVIsU0FBVDtBQUEwQlMsY0FBTSxFQUFFLFNBQWxDO0FBQXdDQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUVyQixZQUFYO0FBQXlCc0Isb0JBQVUsRUFBRTtBQUFyQztBQUFsRCxPQUEzQixFQUNFLEVBQ0NrSyxRQUFRLElBQUlpRCxhQUFaLElBQTZCOUMsU0FBOUIsSUFDQzZDLGlCQUFpQixJQUFJN0MsU0FGdEIsa0JBSUExSyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK1AsZ0VBQXBCLEVBQXlCO0FBQ3ZCQyxtQkFBVyxFQUFFLEtBRFU7QUFFdkJDLG1CQUFXLEVBQUUsS0FGVTtBQUd2QkMsbUJBQVcsRUFBRSxLQUhVO0FBSXZCdkUsZUFBTyxFQUFFQSxPQUpjO0FBSUwxTCxjQUFNLEVBQUUsU0FKSDtBQUlTQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUVyQixZQUFYO0FBQXlCc0Isb0JBQVUsRUFBRTtBQUFyQztBQUpuQixPQUF6QixFQU1JNkcsTUFBTSxDQUFDeEIsSUFBUCxDQUFZMEMsR0FBWixDQUFnQixDQUFDUixLQUFELEVBQVF3SSxHQUFSLEtBQWdCO0FBQ2hDLFlBQUlDLGNBQWMsR0FBRyxFQUFyQjs7QUFDQSxZQUFJeEIsTUFBTSxDQUFDbkosSUFBUCxJQUFlbUosTUFBTSxDQUFDbkosSUFBUCxDQUFZMEssR0FBWixNQUFxQnZOLFNBQXhDLEVBQW1EO0FBQ2pEd04sd0JBQWMsR0FBR3hCLE1BQU0sQ0FBQ25KLElBQVAsQ0FBWTBLLEdBQVosQ0FBakI7QUFDRDs7QUFDRCw0QkFDRXBRLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JxUSwwRUFBcEIsRUFBa0M7QUFDaEMvTixhQUFHLEVBQUVxRixLQUFLLENBQUNsSCxFQURxQjtBQUVoQyx1QkFBYWtILEtBQUssQ0FBQ2lFLE1BRmE7QUFHaEMwRSxlQUFLLEVBQUVILEdBSHlCO0FBSWhDNU4sY0FBSSxFQUFFb0YsS0FBSyxDQUFDcEYsSUFKb0I7QUFJZHRDLGdCQUFNLEVBQUUsU0FKTTtBQUlBQyxrQkFBUSxFQUFFO0FBQUNDLG9CQUFRLEVBQUVyQixZQUFYO0FBQXlCc0Isc0JBQVUsRUFBRTtBQUFyQztBQUpWLFNBQWxDLGVBTUlMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1USwyRUFBcEIsRUFBb0M7QUFDcEM5Qix1QkFBYSxFQUFFLENBQUMrQixLQUFELEVBQVEvSyxJQUFSLEtBQWlCO0FBQzlCa0gsMEJBQWMsQ0FBQyxJQUFELENBQWQ7QUFDQThCLHlCQUFhLENBQUMrQixLQUFELEVBQVEvSyxJQUFSLENBQWI7QUFDRCxXQUptQztBQUtwQ2tDLGVBQUssRUFBRUEsS0FMNkI7QUFNcENpSCxnQkFBTSxFQUFFd0IsY0FONEI7QUFPcEM1QixzQkFBWSxFQUFHeEgsQ0FBRCxJQUFPO0FBQ25CMkYsMEJBQWMsQ0FBQyxJQUFELENBQWQ7QUFDQTZCLHdCQUFZLENBQUN4SCxDQUFELENBQVo7QUFDRCxXQVZtQztBQVdwQzZILG9CQUFVLEVBQUVBLFVBWHdCO0FBWXBDeUIsZUFBSyxFQUFFSCxHQVo2QjtBQWFwQ00sbUJBQVMsRUFBRSxLQWJ5QjtBQWNwQ25HLGtCQUFRLEVBQUV3QixRQWQwQjtBQWNoQjdMLGdCQUFNLEVBQUUsU0FkUTtBQWNGQyxrQkFBUSxFQUFFO0FBQUNDLG9CQUFRLEVBQUVyQixZQUFYO0FBQXlCc0Isc0JBQVUsRUFBRTtBQUFyQztBQWRSLFNBQXBDLENBTkosQ0FERjtBQXlCRCxPQTlCQyxDQU5KLENBTEYsQ0FoQ0osRUE4RUl5TSxXQUFXLGVBQ1g5TSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMFEsNEVBQXBCLEVBQXVDO0FBQ3JDMUQsbUJBQVcsRUFBRUMsY0FEd0I7QUFFckMwRCxhQUFLLEVBQUcscUJBRjZCO0FBR3JDQyxtQkFBVyxFQUFHLGVBSHVCO0FBSXJDQyxlQUFPLEVBQUcsb0RBSjJCO0FBS3JDQyxpQkFBUyxFQUFFLE1BQU07QUFDZnZOLGlCQUFPLENBQUMwRixPQUFSLENBQWdCd0MsU0FBaEI7QUFDRCxTQVBvQztBQVFyQ3NGLGdCQUFRLEVBQUUsWUFBWTtBQUNwQjdFLG1CQUFTLENBQUMsSUFBRCxDQUFUO0FBQ0EsZ0JBQU05QyxNQUFNLENBQUNuQyxNQUFELENBQVo7QUFDQTBGLHdCQUFjLENBQUMsS0FBRCxDQUFkO0FBQ0FULG1CQUFTLENBQUMsS0FBRCxDQUFUO0FBQ0EzSSxpQkFBTyxDQUFDMEYsT0FBUixDQUFnQndDLFNBQWhCO0FBQ0QsU0Fkb0M7QUFjbEN4TCxjQUFNLEVBQUUsU0FkMEI7QUFjcEJDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRXJCLFlBQVg7QUFBeUJzQixvQkFBVSxFQUFFO0FBQXJDO0FBZFUsT0FBdkMsQ0FEVyxDQTlFZixFQWdHSStNLGVBQWUsZUFDZnBOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IwUSw0RUFBcEIsRUFBdUM7QUFDckMxRCxtQkFBVyxFQUFFSyxrQkFEd0I7QUFFckNzRCxhQUFLLEVBQUcseUJBRjZCO0FBR3JDQyxtQkFBVyxFQUFHLG1CQUh1QjtBQUlyQ0MsZUFBTyxFQUFHLG9EQUoyQjtBQUtyQ0MsaUJBQVMsRUFBRSxNQUFNO0FBQ2ZuRCxtQkFBUztBQUNUekQsa0JBQVEsQ0FBQ21DLGVBQWUsQ0FBQ3VELFFBQWpCLEVBQTJCdkQsZUFBZSxDQUFDd0QsUUFBM0MsQ0FBUjtBQUNBdkQsNEJBQWtCLENBQUMsSUFBRCxDQUFsQjtBQUNELFNBVG9DO0FBVXJDeUUsZ0JBQVEsRUFBRSxZQUFZO0FBQ3BCN0UsbUJBQVMsQ0FBQyxJQUFELENBQVQ7QUFDQSxnQkFBTTlDLE1BQU0sQ0FBQ25DLE1BQUQsQ0FBWjtBQUNBMEYsd0JBQWMsQ0FBQyxLQUFELENBQWQ7QUFDQVQsbUJBQVMsQ0FBQyxLQUFELENBQVQ7QUFDQXlCLG1CQUFTO0FBQ1R6RCxrQkFBUSxDQUFDbUMsZUFBZSxDQUFDdUQsUUFBakIsRUFBMkJ2RCxlQUFlLENBQUN3RCxRQUEzQyxDQUFSO0FBQ0QsU0FqQm9DO0FBaUJsQzVQLGNBQU0sRUFBRSxTQWpCMEI7QUFpQnBCQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUVyQixZQUFYO0FBQXlCc0Isb0JBQVUsRUFBRTtBQUFyQztBQWpCVSxPQUF2QyxDQURlLENBaEduQixDQUg4QjtBQXlIN0JILFlBQU0sRUFBRSxTQXpIcUI7QUF5SGZDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFckIsWUFBWDtBQUF5QnNCLGtCQUFVLEVBQUU7QUFBckM7QUF6SEssS0FBaEMsQ0F0R0osQ0FERjtBQW9PRCxHQTFQRCxDQURKLENBREY7QUFnUUQsQ0FwVUQ7O0FBc1VBLE1BQU1zSyxlQUFlLEdBQUl6RixLQUFELEtBQVk7QUFDbENtRyxPQUFLLEVBQUVuRyxLQUFLLENBQUNtRyxLQURxQjtBQUVsQ0MsUUFBTSxFQUFFcEcsS0FBSyxDQUFDb0csTUFBTixDQUFhQTtBQUZhLENBQVosQ0FBeEI7O0FBS0EsTUFBTTJGLGtCQUFrQixHQUFJdk4sUUFBRCxLQUFlO0FBQ3hDNkgsa0JBQWdCLEVBQUcyRixHQUFELElBQVN4TixRQUFRLENBQUN5Tiw2RUFBZ0IsQ0FBQzVGLGdCQUFqQixDQUFrQzJGLEdBQWxDLENBQUQ7QUFESyxDQUFmLENBQTNCOztBQUllckcsMEhBQU8sQ0FBQ0YsZUFBRCxFQUFrQnNHLGtCQUFsQixDQUFQLENBQTZDM0csSUFBN0MsQ0FBZixFOzs7Ozs7Ozs7Ozs7QUNuWkM7QUFBQTtBQUFBLFNBQVM1SCxjQUFULENBQXdCQyxHQUF4QixFQUE2QjtBQUFFLE1BQUlDLGFBQWEsR0FBR0MsU0FBcEI7QUFBK0IsTUFBSUMsS0FBSyxHQUFHSCxHQUFHLENBQUMsQ0FBRCxDQUFmO0FBQW9CLE1BQUlJLENBQUMsR0FBRyxDQUFSOztBQUFXLFNBQU9BLENBQUMsR0FBR0osR0FBRyxDQUFDSyxNQUFmLEVBQXVCO0FBQUUsVUFBTUMsRUFBRSxHQUFHTixHQUFHLENBQUNJLENBQUQsQ0FBZDtBQUFtQixVQUFNRyxFQUFFLEdBQUdQLEdBQUcsQ0FBQ0ksQ0FBQyxHQUFHLENBQUwsQ0FBZDtBQUF1QkEsS0FBQyxJQUFJLENBQUw7O0FBQVEsUUFBSSxDQUFDRSxFQUFFLEtBQUssZ0JBQVAsSUFBMkJBLEVBQUUsS0FBSyxjQUFuQyxLQUFzREgsS0FBSyxJQUFJLElBQW5FLEVBQXlFO0FBQUUsYUFBT0QsU0FBUDtBQUFtQjs7QUFBQyxRQUFJSSxFQUFFLEtBQUssUUFBUCxJQUFtQkEsRUFBRSxLQUFLLGdCQUE5QixFQUFnRDtBQUFFTCxtQkFBYSxHQUFHRSxLQUFoQjtBQUF1QkEsV0FBSyxHQUFHSSxFQUFFLENBQUNKLEtBQUQsQ0FBVjtBQUFvQixLQUE3RixNQUFtRyxJQUFJRyxFQUFFLEtBQUssTUFBUCxJQUFpQkEsRUFBRSxLQUFLLGNBQTVCLEVBQTRDO0FBQUVILFdBQUssR0FBR0ksRUFBRSxDQUFDLENBQUMsR0FBR0MsSUFBSixLQUFhTCxLQUFLLENBQUNNLElBQU4sQ0FBV1IsYUFBWCxFQUEwQixHQUFHTyxJQUE3QixDQUFkLENBQVY7QUFBNkRQLG1CQUFhLEdBQUdDLFNBQWhCO0FBQTRCO0FBQUU7O0FBQUMsU0FBT0MsS0FBUDtBQUFlOztBQUFBOztBQUVwZ0IsTUFBTXdFLFlBQVksR0FBSUosTUFBRCxJQUFZO0FBQy9CLE1BQUlrSyxNQUFKOztBQUVBLE1BQUlDLEtBQUssQ0FBQ0MsT0FBTixDQUFjcEssTUFBTSxDQUFDeEIsSUFBckIsQ0FBSixFQUFnQztBQUM5QjBMLFVBQU0sR0FBR2xLLE1BQU0sQ0FBQ3hCLElBQWhCO0FBQ0QsR0FGRCxNQUVPLElBQUkyTCxLQUFLLENBQUNDLE9BQU4sQ0FBY3BLLE1BQWQsQ0FBSixFQUEyQjtBQUNoQ2tLLFVBQU0sR0FBR2xLLE1BQVQ7QUFDRCxHQUZNLE1BRUE7QUFDTCxXQUFPQSxNQUFQO0FBQ0Q7O0FBRURrSyxRQUFNLENBQUNHLE1BQVAsQ0FBZUMsR0FBRCxJQUFTO0FBQ3JCLFFBQUlBLEdBQUcsQ0FBQzNKLG9FQUFVLENBQUM0Six3QkFBWixDQUFILEtBQTZDNU8sU0FBakQsRUFBNEQ7QUFDMURILG9CQUFjLENBQUMsQ0FBQzhPLEdBQUQsRUFBTSxRQUFOLEVBQWdCL0ssQ0FBQyxJQUFJQSxDQUFDLENBQUNvQixvRUFBVSxDQUFDNEosd0JBQVosQ0FBdEIsRUFBNkQsUUFBN0QsRUFBdUUvSyxFQUFFLElBQUlBLEVBQUUsQ0FBQ2dMLFFBQWhGLEVBQTBGLGdCQUExRixFQUE0Ry9LLEVBQUUsSUFBSUEsRUFBRSxDQUFDNEssTUFBckgsRUFBNkgsTUFBN0gsRUFBcUkxSyxFQUFFLElBQUlBLEVBQUUsQ0FBRThLLE1BQUQsSUFBWTtBQUN2SyxlQUFPQSxNQUFNLENBQUMxUSxLQUFkO0FBQ0EsZUFBTzBRLE1BQU0sQ0FBQ0MsSUFBZDtBQUNELE9BSDJKLENBQTdJLENBQUQsQ0FBZDtBQUlEOztBQUNELFFBQUlKLEdBQUcsQ0FBQzNKLG9FQUFVLENBQUNnSyxjQUFaLENBQUgsS0FBbUNoUCxTQUF2QyxFQUFrRDtBQUNoRCxVQUFJd08sS0FBSyxDQUFDQyxPQUFOLENBQWNFLEdBQUcsQ0FBQzNKLG9FQUFVLENBQUNnSyxjQUFaLENBQUgsQ0FBK0IvTyxLQUEvQixDQUFxQ2dQLE9BQW5ELENBQUosRUFBaUU7QUFDL0ROLFdBQUcsQ0FBQzNKLG9FQUFVLENBQUNnSyxjQUFaLENBQUgsQ0FBK0IvTyxLQUEvQixDQUFxQ2dQLE9BQXJDLENBQTZDUCxNQUE3QyxDQUFxREksTUFBRCxJQUFZO0FBQzlELGlCQUFPQSxNQUFNLENBQUMxUSxLQUFkO0FBQ0QsU0FGRDtBQUdEOztBQUNELFVBQUl1USxHQUFHLENBQUMzSixvRUFBVSxDQUFDZ0ssY0FBWixDQUFILENBQStCL08sS0FBL0IsQ0FBcUNpUCxLQUFyQyxLQUErQyxFQUFuRCxFQUF1RDtBQUNyRFAsV0FBRyxDQUFDM0osb0VBQVUsQ0FBQ2dLLGNBQVosQ0FBSCxDQUErQi9PLEtBQS9CLENBQXFDaVAsS0FBckMsR0FBNkMsSUFBN0M7QUFDRDtBQUNGOztBQUNELFdBQU9QLEdBQVA7QUFDRCxHQWxCRDtBQW1CQSxTQUFPdEssTUFBUDtBQUNELENBL0JEOztBQWlDZUksMkVBQWYsRTs7Ozs7Ozs7Ozs7QUNuQ0EsZSIsImZpbGUiOiJUYXNrUm9vdF83OWE2ZWRlNzc3MWI1YmVkMjQ4Mi5qcyIsInNvdXJjZXNDb250ZW50IjpbIiFmdW5jdGlvbih0LGUpe1wib2JqZWN0XCI9PXR5cGVvZiBleHBvcnRzJiZcInVuZGVmaW5lZFwiIT10eXBlb2YgbW9kdWxlP21vZHVsZS5leHBvcnRzPWUoKTpcImZ1bmN0aW9uXCI9PXR5cGVvZiBkZWZpbmUmJmRlZmluZS5hbWQ/ZGVmaW5lKGUpOnQuZGF5anM9ZSgpfSh0aGlzLGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dmFyIHQ9XCJtaWxsaXNlY29uZFwiLGU9XCJzZWNvbmRcIixuPVwibWludXRlXCIscj1cImhvdXJcIixpPVwiZGF5XCIscz1cIndlZWtcIix1PVwibW9udGhcIixhPVwicXVhcnRlclwiLG89XCJ5ZWFyXCIsZj1cImRhdGVcIixoPS9eKFxcZHs0fSlbLS9dPyhcXGR7MSwyfSk/Wy0vXT8oXFxkezAsMn0pW14wLTldKihcXGR7MSwyfSk/Oj8oXFxkezEsMn0pPzo/KFxcZHsxLDJ9KT9bLjpdPyhcXGQrKT8kLyxjPS9cXFsoW15cXF1dKyldfFl7MSw0fXxNezEsNH18RHsxLDJ9fGR7MSw0fXxIezEsMn18aHsxLDJ9fGF8QXxtezEsMn18c3sxLDJ9fFp7MSwyfXxTU1MvZyxkPXtuYW1lOlwiZW5cIix3ZWVrZGF5czpcIlN1bmRheV9Nb25kYXlfVHVlc2RheV9XZWRuZXNkYXlfVGh1cnNkYXlfRnJpZGF5X1NhdHVyZGF5XCIuc3BsaXQoXCJfXCIpLG1vbnRoczpcIkphbnVhcnlfRmVicnVhcnlfTWFyY2hfQXByaWxfTWF5X0p1bmVfSnVseV9BdWd1c3RfU2VwdGVtYmVyX09jdG9iZXJfTm92ZW1iZXJfRGVjZW1iZXJcIi5zcGxpdChcIl9cIil9LCQ9ZnVuY3Rpb24odCxlLG4pe3ZhciByPVN0cmluZyh0KTtyZXR1cm4hcnx8ci5sZW5ndGg+PWU/dDpcIlwiK0FycmF5KGUrMS1yLmxlbmd0aCkuam9pbihuKSt0fSxsPXtzOiQsejpmdW5jdGlvbih0KXt2YXIgZT0tdC51dGNPZmZzZXQoKSxuPU1hdGguYWJzKGUpLHI9TWF0aC5mbG9vcihuLzYwKSxpPW4lNjA7cmV0dXJuKGU8PTA/XCIrXCI6XCItXCIpKyQociwyLFwiMFwiKStcIjpcIiskKGksMixcIjBcIil9LG06ZnVuY3Rpb24gdChlLG4pe2lmKGUuZGF0ZSgpPG4uZGF0ZSgpKXJldHVybi10KG4sZSk7dmFyIHI9MTIqKG4ueWVhcigpLWUueWVhcigpKSsobi5tb250aCgpLWUubW9udGgoKSksaT1lLmNsb25lKCkuYWRkKHIsdSkscz1uLWk8MCxhPWUuY2xvbmUoKS5hZGQocisocz8tMToxKSx1KTtyZXR1cm4rKC0ocisobi1pKS8ocz9pLWE6YS1pKSl8fDApfSxhOmZ1bmN0aW9uKHQpe3JldHVybiB0PDA/TWF0aC5jZWlsKHQpfHwwOk1hdGguZmxvb3IodCl9LHA6ZnVuY3Rpb24oaCl7cmV0dXJue006dSx5Om8sdzpzLGQ6aSxEOmYsaDpyLG06bixzOmUsbXM6dCxROmF9W2hdfHxTdHJpbmcoaHx8XCJcIikudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9zJC8sXCJcIil9LHU6ZnVuY3Rpb24odCl7cmV0dXJuIHZvaWQgMD09PXR9fSx5PVwiZW5cIixNPXt9O01beV09ZDt2YXIgbT1mdW5jdGlvbih0KXtyZXR1cm4gdCBpbnN0YW5jZW9mIFN9LEQ9ZnVuY3Rpb24odCxlLG4pe3ZhciByO2lmKCF0KXJldHVybiB5O2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KU1bdF0mJihyPXQpLGUmJihNW3RdPWUscj10KTtlbHNle3ZhciBpPXQubmFtZTtNW2ldPXQscj1pfXJldHVybiFuJiZyJiYoeT1yKSxyfHwhbiYmeX0sdj1mdW5jdGlvbih0LGUpe2lmKG0odCkpcmV0dXJuIHQuY2xvbmUoKTt2YXIgbj1cIm9iamVjdFwiPT10eXBlb2YgZT9lOnt9O3JldHVybiBuLmRhdGU9dCxuLmFyZ3M9YXJndW1lbnRzLG5ldyBTKG4pfSxnPWw7Zy5sPUQsZy5pPW0sZy53PWZ1bmN0aW9uKHQsZSl7cmV0dXJuIHYodCx7bG9jYWxlOmUuJEwsdXRjOmUuJHUseDplLiR4LCRvZmZzZXQ6ZS4kb2Zmc2V0fSl9O3ZhciBTPWZ1bmN0aW9uKCl7ZnVuY3Rpb24gZCh0KXt0aGlzLiRMPUQodC5sb2NhbGUsbnVsbCwhMCksdGhpcy5wYXJzZSh0KX12YXIgJD1kLnByb3RvdHlwZTtyZXR1cm4gJC5wYXJzZT1mdW5jdGlvbih0KXt0aGlzLiRkPWZ1bmN0aW9uKHQpe3ZhciBlPXQuZGF0ZSxuPXQudXRjO2lmKG51bGw9PT1lKXJldHVybiBuZXcgRGF0ZShOYU4pO2lmKGcudShlKSlyZXR1cm4gbmV3IERhdGU7aWYoZSBpbnN0YW5jZW9mIERhdGUpcmV0dXJuIG5ldyBEYXRlKGUpO2lmKFwic3RyaW5nXCI9PXR5cGVvZiBlJiYhL1okL2kudGVzdChlKSl7dmFyIHI9ZS5tYXRjaChoKTtpZihyKXt2YXIgaT1yWzJdLTF8fDAscz0ocls3XXx8XCIwXCIpLnN1YnN0cmluZygwLDMpO3JldHVybiBuP25ldyBEYXRlKERhdGUuVVRDKHJbMV0saSxyWzNdfHwxLHJbNF18fDAscls1XXx8MCxyWzZdfHwwLHMpKTpuZXcgRGF0ZShyWzFdLGksclszXXx8MSxyWzRdfHwwLHJbNV18fDAscls2XXx8MCxzKX19cmV0dXJuIG5ldyBEYXRlKGUpfSh0KSx0aGlzLiR4PXQueHx8e30sdGhpcy5pbml0KCl9LCQuaW5pdD1mdW5jdGlvbigpe3ZhciB0PXRoaXMuJGQ7dGhpcy4keT10LmdldEZ1bGxZZWFyKCksdGhpcy4kTT10LmdldE1vbnRoKCksdGhpcy4kRD10LmdldERhdGUoKSx0aGlzLiRXPXQuZ2V0RGF5KCksdGhpcy4kSD10LmdldEhvdXJzKCksdGhpcy4kbT10LmdldE1pbnV0ZXMoKSx0aGlzLiRzPXQuZ2V0U2Vjb25kcygpLHRoaXMuJG1zPXQuZ2V0TWlsbGlzZWNvbmRzKCl9LCQuJHV0aWxzPWZ1bmN0aW9uKCl7cmV0dXJuIGd9LCQuaXNWYWxpZD1mdW5jdGlvbigpe3JldHVybiEoXCJJbnZhbGlkIERhdGVcIj09PXRoaXMuJGQudG9TdHJpbmcoKSl9LCQuaXNTYW1lPWZ1bmN0aW9uKHQsZSl7dmFyIG49dih0KTtyZXR1cm4gdGhpcy5zdGFydE9mKGUpPD1uJiZuPD10aGlzLmVuZE9mKGUpfSwkLmlzQWZ0ZXI9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdih0KTx0aGlzLnN0YXJ0T2YoZSl9LCQuaXNCZWZvcmU9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdGhpcy5lbmRPZihlKTx2KHQpfSwkLiRnPWZ1bmN0aW9uKHQsZSxuKXtyZXR1cm4gZy51KHQpP3RoaXNbZV06dGhpcy5zZXQobix0KX0sJC51bml4PWZ1bmN0aW9uKCl7cmV0dXJuIE1hdGguZmxvb3IodGhpcy52YWx1ZU9mKCkvMWUzKX0sJC52YWx1ZU9mPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuJGQuZ2V0VGltZSgpfSwkLnN0YXJ0T2Y9ZnVuY3Rpb24odCxhKXt2YXIgaD10aGlzLGM9ISFnLnUoYSl8fGEsZD1nLnAodCksJD1mdW5jdGlvbih0LGUpe3ZhciBuPWcudyhoLiR1P0RhdGUuVVRDKGguJHksZSx0KTpuZXcgRGF0ZShoLiR5LGUsdCksaCk7cmV0dXJuIGM/bjpuLmVuZE9mKGkpfSxsPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIGcudyhoLnRvRGF0ZSgpW3RdLmFwcGx5KGgudG9EYXRlKFwic1wiKSwoYz9bMCwwLDAsMF06WzIzLDU5LDU5LDk5OV0pLnNsaWNlKGUpKSxoKX0seT10aGlzLiRXLE09dGhpcy4kTSxtPXRoaXMuJEQsRD1cInNldFwiKyh0aGlzLiR1P1wiVVRDXCI6XCJcIik7c3dpdGNoKGQpe2Nhc2UgbzpyZXR1cm4gYz8kKDEsMCk6JCgzMSwxMSk7Y2FzZSB1OnJldHVybiBjPyQoMSxNKTokKDAsTSsxKTtjYXNlIHM6dmFyIHY9dGhpcy4kbG9jYWxlKCkud2Vla1N0YXJ0fHwwLFM9KHk8dj95Kzc6eSktdjtyZXR1cm4gJChjP20tUzptKyg2LVMpLE0pO2Nhc2UgaTpjYXNlIGY6cmV0dXJuIGwoRCtcIkhvdXJzXCIsMCk7Y2FzZSByOnJldHVybiBsKEQrXCJNaW51dGVzXCIsMSk7Y2FzZSBuOnJldHVybiBsKEQrXCJTZWNvbmRzXCIsMik7Y2FzZSBlOnJldHVybiBsKEQrXCJNaWxsaXNlY29uZHNcIiwzKTtkZWZhdWx0OnJldHVybiB0aGlzLmNsb25lKCl9fSwkLmVuZE9mPWZ1bmN0aW9uKHQpe3JldHVybiB0aGlzLnN0YXJ0T2YodCwhMSl9LCQuJHNldD1mdW5jdGlvbihzLGEpe3ZhciBoLGM9Zy5wKHMpLGQ9XCJzZXRcIisodGhpcy4kdT9cIlVUQ1wiOlwiXCIpLCQ9KGg9e30saFtpXT1kK1wiRGF0ZVwiLGhbZl09ZCtcIkRhdGVcIixoW3VdPWQrXCJNb250aFwiLGhbb109ZCtcIkZ1bGxZZWFyXCIsaFtyXT1kK1wiSG91cnNcIixoW25dPWQrXCJNaW51dGVzXCIsaFtlXT1kK1wiU2Vjb25kc1wiLGhbdF09ZCtcIk1pbGxpc2Vjb25kc1wiLGgpW2NdLGw9Yz09PWk/dGhpcy4kRCsoYS10aGlzLiRXKTphO2lmKGM9PT11fHxjPT09byl7dmFyIHk9dGhpcy5jbG9uZSgpLnNldChmLDEpO3kuJGRbJF0obCkseS5pbml0KCksdGhpcy4kZD15LnNldChmLE1hdGgubWluKHRoaXMuJEQseS5kYXlzSW5Nb250aCgpKSkuJGR9ZWxzZSAkJiZ0aGlzLiRkWyRdKGwpO3JldHVybiB0aGlzLmluaXQoKSx0aGlzfSwkLnNldD1mdW5jdGlvbih0LGUpe3JldHVybiB0aGlzLmNsb25lKCkuJHNldCh0LGUpfSwkLmdldD1mdW5jdGlvbih0KXtyZXR1cm4gdGhpc1tnLnAodCldKCl9LCQuYWRkPWZ1bmN0aW9uKHQsYSl7dmFyIGYsaD10aGlzO3Q9TnVtYmVyKHQpO3ZhciBjPWcucChhKSxkPWZ1bmN0aW9uKGUpe3ZhciBuPXYoaCk7cmV0dXJuIGcudyhuLmRhdGUobi5kYXRlKCkrTWF0aC5yb3VuZChlKnQpKSxoKX07aWYoYz09PXUpcmV0dXJuIHRoaXMuc2V0KHUsdGhpcy4kTSt0KTtpZihjPT09bylyZXR1cm4gdGhpcy5zZXQobyx0aGlzLiR5K3QpO2lmKGM9PT1pKXJldHVybiBkKDEpO2lmKGM9PT1zKXJldHVybiBkKDcpO3ZhciAkPShmPXt9LGZbbl09NmU0LGZbcl09MzZlNSxmW2VdPTFlMyxmKVtjXXx8MSxsPXRoaXMuJGQuZ2V0VGltZSgpK3QqJDtyZXR1cm4gZy53KGwsdGhpcyl9LCQuc3VidHJhY3Q9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdGhpcy5hZGQoLTEqdCxlKX0sJC5mb3JtYXQ9ZnVuY3Rpb24odCl7dmFyIGU9dGhpcztpZighdGhpcy5pc1ZhbGlkKCkpcmV0dXJuXCJJbnZhbGlkIERhdGVcIjt2YXIgbj10fHxcIllZWVktTU0tRERUSEg6bW06c3NaXCIscj1nLnoodGhpcyksaT10aGlzLiRsb2NhbGUoKSxzPXRoaXMuJEgsdT10aGlzLiRtLGE9dGhpcy4kTSxvPWkud2Vla2RheXMsZj1pLm1vbnRocyxoPWZ1bmN0aW9uKHQscixpLHMpe3JldHVybiB0JiYodFtyXXx8dChlLG4pKXx8aVtyXS5zdWJzdHIoMCxzKX0sZD1mdW5jdGlvbih0KXtyZXR1cm4gZy5zKHMlMTJ8fDEyLHQsXCIwXCIpfSwkPWkubWVyaWRpZW18fGZ1bmN0aW9uKHQsZSxuKXt2YXIgcj10PDEyP1wiQU1cIjpcIlBNXCI7cmV0dXJuIG4/ci50b0xvd2VyQ2FzZSgpOnJ9LGw9e1lZOlN0cmluZyh0aGlzLiR5KS5zbGljZSgtMiksWVlZWTp0aGlzLiR5LE06YSsxLE1NOmcucyhhKzEsMixcIjBcIiksTU1NOmgoaS5tb250aHNTaG9ydCxhLGYsMyksTU1NTTpoKGYsYSksRDp0aGlzLiRELEREOmcucyh0aGlzLiRELDIsXCIwXCIpLGQ6U3RyaW5nKHRoaXMuJFcpLGRkOmgoaS53ZWVrZGF5c01pbix0aGlzLiRXLG8sMiksZGRkOmgoaS53ZWVrZGF5c1Nob3J0LHRoaXMuJFcsbywzKSxkZGRkOm9bdGhpcy4kV10sSDpTdHJpbmcocyksSEg6Zy5zKHMsMixcIjBcIiksaDpkKDEpLGhoOmQoMiksYTokKHMsdSwhMCksQTokKHMsdSwhMSksbTpTdHJpbmcodSksbW06Zy5zKHUsMixcIjBcIiksczpTdHJpbmcodGhpcy4kcyksc3M6Zy5zKHRoaXMuJHMsMixcIjBcIiksU1NTOmcucyh0aGlzLiRtcywzLFwiMFwiKSxaOnJ9O3JldHVybiBuLnJlcGxhY2UoYyxmdW5jdGlvbih0LGUpe3JldHVybiBlfHxsW3RdfHxyLnJlcGxhY2UoXCI6XCIsXCJcIil9KX0sJC51dGNPZmZzZXQ9ZnVuY3Rpb24oKXtyZXR1cm4gMTUqLU1hdGgucm91bmQodGhpcy4kZC5nZXRUaW1lem9uZU9mZnNldCgpLzE1KX0sJC5kaWZmPWZ1bmN0aW9uKHQsZixoKXt2YXIgYyxkPWcucChmKSwkPXYodCksbD02ZTQqKCQudXRjT2Zmc2V0KCktdGhpcy51dGNPZmZzZXQoKSkseT10aGlzLSQsTT1nLm0odGhpcywkKTtyZXR1cm4gTT0oYz17fSxjW29dPU0vMTIsY1t1XT1NLGNbYV09TS8zLGNbc109KHktbCkvNjA0OGU1LGNbaV09KHktbCkvODY0ZTUsY1tyXT15LzM2ZTUsY1tuXT15LzZlNCxjW2VdPXkvMWUzLGMpW2RdfHx5LGg/TTpnLmEoTSl9LCQuZGF5c0luTW9udGg9ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy5lbmRPZih1KS4kRH0sJC4kbG9jYWxlPWZ1bmN0aW9uKCl7cmV0dXJuIE1bdGhpcy4kTF19LCQubG9jYWxlPWZ1bmN0aW9uKHQsZSl7aWYoIXQpcmV0dXJuIHRoaXMuJEw7dmFyIG49dGhpcy5jbG9uZSgpLHI9RCh0LGUsITApO3JldHVybiByJiYobi4kTD1yKSxufSwkLmNsb25lPWZ1bmN0aW9uKCl7cmV0dXJuIGcudyh0aGlzLiRkLHRoaXMpfSwkLnRvRGF0ZT1mdW5jdGlvbigpe3JldHVybiBuZXcgRGF0ZSh0aGlzLnZhbHVlT2YoKSl9LCQudG9KU09OPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuaXNWYWxpZCgpP3RoaXMudG9JU09TdHJpbmcoKTpudWxsfSwkLnRvSVNPU3RyaW5nPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuJGQudG9JU09TdHJpbmcoKX0sJC50b1N0cmluZz1mdW5jdGlvbigpe3JldHVybiB0aGlzLiRkLnRvVVRDU3RyaW5nKCl9LGR9KCkscD1TLnByb3RvdHlwZTtyZXR1cm4gdi5wcm90b3R5cGU9cCxbW1wiJG1zXCIsdF0sW1wiJHNcIixlXSxbXCIkbVwiLG5dLFtcIiRIXCIscl0sW1wiJFdcIixpXSxbXCIkTVwiLHVdLFtcIiR5XCIsb10sW1wiJERcIixmXV0uZm9yRWFjaChmdW5jdGlvbih0KXtwW3RbMV1dPWZ1bmN0aW9uKGUpe3JldHVybiB0aGlzLiRnKGUsdFswXSx0WzFdKX19KSx2LmV4dGVuZD1mdW5jdGlvbih0LGUpe3JldHVybiB0LiRpfHwodChlLFMsdiksdC4kaT0hMCksdn0sdi5sb2NhbGU9RCx2LmlzRGF5anM9bSx2LnVuaXg9ZnVuY3Rpb24odCl7cmV0dXJuIHYoMWUzKnQpfSx2LmVuPU1beV0sdi5Mcz1NLHYucD17fSx2fSk7XG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvY2xpZW50L2NvbXBvbmVudHMvU3Bpbm5lci50c3hcIjtpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQge2tleWZyYW1lc30gZnJvbSAnQGVtb3Rpb24vY29yZSdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICdzdHlsZXMvcGFsZXR0ZSdcblxuY29uc3Qga2V5ZnJhbWVzU3BpbiA9IGtleWZyYW1lc2BcbiAgMCUge1xuICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xuICB9XG4gIDEwMCUge1xuICAgIHRyYW5zZm9ybTogcm90YXRlKDM2MGRlZyk7XG4gIH1cbmBcblxuY29uc3QgTG9hZGVyID0gc3R5bGVkLmRpdih7XG4gIGJvcmRlcjogYDJweCBzb2xpZCAke1BBTEVUVEUuQk9SREVSX0dSQVl9YCxcbiAgYm9yZGVyUmFkaXVzOiAnNTAlJyxcbiAgYm9yZGVyVG9wOiBgMnB4IHNvbGlkICR7UEFMRVRURS5QUklNQVJZX01BSU59YCxcbiAgd2lkdGg6IDIwLFxuICBoZWlnaHQ6IDIwLFxuICBhbmltYXRpb25OYW1lOiBrZXlmcmFtZXNTcGluLnRvU3RyaW5nKCksXG4gIGFuaW1hdGlvbkR1cmF0aW9uOiAnMXMnLFxuICBhbmltYXRpb25JdGVyYXRpb25Db3VudDogJ2luZmluaXRlJ1xufSlcblxuY29uc3QgU3Bpbm5lciA9ICgpID0+IFJlYWN0LmNyZWF0ZUVsZW1lbnQoTG9hZGVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI2fX0gKVxuXG5leHBvcnQgZGVmYXVsdCBTcGlubmVyXG4iLCJpbXBvcnQge1NUQUZGX09SR19JRH0gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcblxuY29uc3QgaXNVc2VyU3RhZmYgPSAob3JnYW5pemF0aW9ucywgY3VycmVudF9vcmdhbml6YXRpb25faWQpID0+IHtcbiAgZm9yIChjb25zdCBvcmcgb2Ygb3JnYW5pemF0aW9ucykge1xuICAgIGlmIChvcmcuaWQgPT09IFNUQUZGX09SR19JRCAmJiBjdXJyZW50X29yZ2FuaXphdGlvbl9pZCA9PT0gU1RBRkZfT1JHX0lEKSByZXR1cm4gdHJ1ZVxuICB9XG5cbiAgcmV0dXJuIGZhbHNlXG59XG5leHBvcnQgZGVmYXVsdCBpc1VzZXJTdGFmZlxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9tb2R1bGVzL2F1ZGl0cy9jb21wb25lbnRzL0F1ZGl0RGVjaXNpb24udHN4XCI7aW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5pbXBvcnQgUGxhaW5CdXR0b24sIHt9IGZyb20gJ2NsaWVudC9jb21wb25lbnRzL1BsYWluQnV0dG9uJ1xuaW1wb3J0IFJlYWN0LCB7RnJhZ21lbnQsIHVzZUVmZmVjdCwgdXNlU3RhdGV9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICd1bml2ZXJzYWwvc3R5bGVzL3BhbGV0dGUnXG5pbXBvcnQgSWNvbiBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9JY29uJ1xuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cbmNvbnN0IERlY2lzaW9uQnV0dG9uID0gc3R5bGVkKFBsYWluQnV0dG9uKSgocHJvcHMpID0+IHtcbiAgY29uc3Qge2lzQXBwcm92ZSwgaXNBY3RpdmV9ID0gcHJvcHNcbiAgY29uc3QgY29sb3IgPSBpc0FwcHJvdmUgPyBQQUxFVFRFLlBSSU1BUllfR1JFRU4gOiBQQUxFVFRFLkVSUk9SX01BSU5cblxuICByZXR1cm4ge1xuICAgIHdpZHRoOiAnYXV0bycsXG4gICAgYmFja2dyb3VuZENvbG9yOiBpc0FjdGl2ZSA/IGNvbG9yIDogJ3doaXRlJyxcbiAgICBjb2xvcjogaXNBY3RpdmUgPyAnd2hpdGUnIDogY29sb3IsXG4gICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7aXNBY3RpdmUgPyAnd2hpdGUnIDogY29sb3J9YCxcbiAgICBmb250U2l6ZTogJzE0cHgnLFxuICAgIGZvbnRXZWlnaHQ6IDUwMCxcbiAgICBib3hTaGFkb3c6ICdyZ2JhKDE1LCAxNSwgMTUsIDAuMSkgMHB4IDBweCAwcHggMXB4IGluc2V0LCByZ2JhKDE1LCAxNSwgMTUsIDAuMSkgMHB4IDFweCAycHgnLFxuICAgIG91dGxpbmU6IDAsXG4gICAgdHJhbnNpdGlvbjogJ2FsbCAwLjI1cyBlYXNlLWluLW91dCcsXG4gICAgJzpob3Zlcic6IHtcbiAgICAgIGJveFNoYWRvdzogYDAgNHB4IDhweCAke2lzQXBwcm92ZSA/ICdyZ2JhKDAsMTczLDY5LDAuMDUpJyA6ICdyZ2JhKDI1NSw3NCwwLDAuMDUpJ31gXG4gICAgfSxcbiAgICAnOmFjdGl2ZSc6IHtcbiAgICAgIGJhY2tncm91bmRDb2xvcjogaXNBY3RpdmUgPyAnd2hpdGUnIDogY29sb3IsXG4gICAgICBjb2xvcjogaXNBY3RpdmUgPyBjb2xvciA6ICd3aGl0ZScsXG4gICAgICBib3JkZXI6IGAxcHggc29saWQgJHtpc0FjdGl2ZSA/IGNvbG9yIDogJ3doaXRlJ31gXG4gICAgfVxuICB9XG59KVxuXG5jb25zdCBTdHlsZWRJY29uID0gc3R5bGVkKEljb24pKHtcbiAgbWFyZ2luOiAwLFxuICBwYWRkaW5nOiAwLFxuICBmb250U2l6ZTogMTZcbn0pXG5cbi8qXG5LZXkgcGFyYW1ldGVyczpcbi0gZGVjaXNpb246IHRydWUgaWYgdGhlIGJ1dHRvbiBpcyBBcHByb3ZlLCBmYWxzZSBpZiB0aGUgYnV0dG9uIGlzIFJlamVjdFxuLSBjb3JyZWN0OiBjdXJyZW50IGF1ZGl0IGRlY2lzaW9uXG5cbldlIGZsaXAgdGhlIHN0YXRlIG9mIHRoZSBidXR0b24gYnkgY29tcGFyaW5nIGRlY2lzaW9uIGFuZCBjb3JyZWN0OiBpZSBpZiBkZWNpc2lvbiBpcyB0cnVlLCB0aGUgc3RhdGUgY2FuIG9ubHkgZmxpcCBiZXR3ZWVuIHRydWUgYW5kIG51bGwuXG5cblRoZSBzZXJ2ZXIgdGFrZXMgc29tZSB0aW1lIHRvIHJlc3BvbmQgKG9uQXVkaXREZWNpc2lvbikgd2hpY2ggcmVzdWx0cyBpbiBhIGZlZWRiYWNrIGRlbGF5LCBzbyB3ZSBjaGFuZ2UgaXRzIHN0YXRlIGRpcmVjdGx5IChzZXRDb3JyZWN0U3RhdGUpIG9uIGNsaWNrXG4qL1xuZnVuY3Rpb24gY2xpY2tIYW5kbGVyKFxuICBvbkF1ZGl0RGVjaXNpb24sXG4gIHNldENvcnJlY3RTdGF0ZSxcbiAgY29ycmVjdCxcbiAgZGVjaXNpb25cbikge1xuICBjb25zdCBuZXdEZWNpc2lvbiA9IGNvcnJlY3QgPT09IGRlY2lzaW9uID8gbnVsbCA6IGRlY2lzaW9uXG4gIHNldENvcnJlY3RTdGF0ZShuZXdEZWNpc2lvbilcbiAgb25BdWRpdERlY2lzaW9uKG5ld0RlY2lzaW9uKVxufVxuXG5jb25zdCBBdWRpdERlY2lzaW9uID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtjb3JyZWN0LCBvbkF1ZGl0RGVjaXNpb259ID0gcHJvcHNcbiAgY29uc3QgW2NvcnJlY3RTdGF0ZSwgc2V0Q29ycmVjdFN0YXRlXSA9IHVzZVN0YXRlKGNvcnJlY3QpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRDb3JyZWN0U3RhdGUoY29ycmVjdClcbiAgfSwgW2NvcnJlY3RdKVxuXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChGcmFnbWVudCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA4MH19XG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRGVjaXNpb25CdXR0b24sIHtcbiAgICAgICAga2V5OiBcImFwcHJvdmVcIixcbiAgICAgICAgdHlwZTogXCJidXR0b25cIixcbiAgICAgICAgb25DbGljazogKCkgPT4ge1xuICAgICAgICAgIGNsaWNrSGFuZGxlcihvbkF1ZGl0RGVjaXNpb24sIHNldENvcnJlY3RTdGF0ZSwgY29ycmVjdFN0YXRlLCB0cnVlKVxuICAgICAgICB9LFxuICAgICAgICBpc0FwcHJvdmU6IHRydWUsXG4gICAgICAgIGlzQWN0aXZlOiBjb3JyZWN0U3RhdGUgPT09IHRydWUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA4MX19XG4gICAgICBcbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZEljb24sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogOTB9fSwgXCJkb25lXCIpXG4gICAgICApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRGVjaXNpb25CdXR0b24sIHtcbiAgICAgICAga2V5OiBcInJlamVjdFwiLFxuICAgICAgICB0eXBlOiBcImJ1dHRvblwiLFxuICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgY2xpY2tIYW5kbGVyKG9uQXVkaXREZWNpc2lvbiwgc2V0Q29ycmVjdFN0YXRlLCBjb3JyZWN0U3RhdGUsIGZhbHNlKVxuICAgICAgICB9LFxuICAgICAgICBpc0FwcHJvdmU6IGZhbHNlLFxuICAgICAgICBpc0FjdGl2ZTogY29ycmVjdFN0YXRlID09PSBmYWxzZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDkyfX1cbiAgICAgIFxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3R5bGVkSWNvbiwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMDF9fSwgXCJjbG9zZVwiKVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBdWRpdERlY2lzaW9uXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL21vZHVsZXMvdGFzay9UYXNrUm9vdC50c3hcIjsgZnVuY3Rpb24gX29wdGlvbmFsQ2hhaW4ob3BzKSB7IGxldCBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyBsZXQgdmFsdWUgPSBvcHNbMF07IGxldCBpID0gMTsgd2hpbGUgKGkgPCBvcHMubGVuZ3RoKSB7IGNvbnN0IG9wID0gb3BzW2ldOyBjb25zdCBmbiA9IG9wc1tpICsgMV07IGkgKz0gMjsgaWYgKChvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQ2FsbCcpICYmIHZhbHVlID09IG51bGwpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfSBpZiAob3AgPT09ICdhY2Nlc3MnIHx8IG9wID09PSAnb3B0aW9uYWxBY2Nlc3MnKSB7IGxhc3RBY2Nlc3NMSFMgPSB2YWx1ZTsgdmFsdWUgPSBmbih2YWx1ZSk7IH0gZWxzZSBpZiAob3AgPT09ICdjYWxsJyB8fCBvcCA9PT0gJ29wdGlvbmFsQ2FsbCcpIHsgdmFsdWUgPSBmbigoLi4uYXJncykgPT4gdmFsdWUuY2FsbChsYXN0QWNjZXNzTEhTLCAuLi5hcmdzKSk7IGxhc3RBY2Nlc3NMSFMgPSB1bmRlZmluZWQ7IH0gfSByZXR1cm4gdmFsdWU7IH1pbXBvcnQgUmVhY3QsIHt1c2VFZmZlY3QsIHVzZVN0YXRlfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7Y29ubmVjdH0gZnJvbSAncmVhY3QtcmVkdXgnXG5pbXBvcnQge3VzZVBhcmFtc30gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7dXNlRGlzcGF0Y2h9IGZyb20gJ3JlYWN0LXJlZHV4J1xuaW1wb3J0IHFzIGZyb20gJ3FzJ1xuaW1wb3J0IFRhc2sgZnJvbSAnLi9jb21wb25lbnRzL1Rhc2snXG5cbmltcG9ydCB1c2VOZXR3b3JrZXIgZnJvbSAnY2xpZW50L2hvb2tzL3VzZU5ldHdvcmtlcidcblxuaW1wb3J0IHtzZWdtZW50VHJhY2t9IGZyb20gJ2NsaWVudC91dGlscy9zZWdtZW50SW8nXG5pbXBvcnQgdXNlUm91dGVyIGZyb20gJ2NsaWVudC9ob29rcy91c2VSb3V0ZXInXG5pbXBvcnQge1xuICBhZGRTdWNjZXNzTm90aWZpY2F0aW9uLFxuICBhZGRGYWlsdXJlTm90aWZpY2F0aW9uXG59IGZyb20gJ2NsaWVudC9tb2R1bGVzL25vdGlmaWNhdGlvblN5c3RlbS9kdWNrcy9ub3RpZmljYXRpb25TeXN0ZW1EdWNrJ1xuaW1wb3J0IHtCTE9DS19UWVBFfSBmcm9tICd1bml2ZXJzYWwvdXRpbHMvY29uc3RhbnRzJ1xuaW1wb3J0IGZvcm1hdFZhbHVlcyBmcm9tICd1bml2ZXJzYWwvdXRpbHMvZm9ybWF0VmFsdWVzJ1xuaW1wb3J0IGlzVXNlclN0YWZmIGZyb20gJ2NsaWVudC91dGlscy9pc1VzZXJTdGFmZidcbmltcG9ydCB7dHJhbnNmb3JtRGF0ZXN9IGZyb20gJ2NsaWVudC91dGlscy9kYXRlSGVscGVycydcblxuXG5cblxuXG5cbmNvbnN0IFRhc2tSb290ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IG5ldHdvcmtlciA9IHVzZU5ldHdvcmtlcigpXG4gIGNvbnN0IHtoaXN0b3J5fSA9IHVzZVJvdXRlcigpXG4gIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKVxuICBjb25zdCB7dXNlciwgYXVkaXRGaWx0ZXJzfSA9IHByb3BzXG4gIGNvbnN0IHtpZDogdXNlcklkLCBlbWFpbCwgb3JnSWR9ID0gdXNlciB8fCB7fVxuICBjb25zdCB7dGFza0lkLCBxdWV1ZUlkfSA9IHVzZVBhcmFtcygpXG4gIGNvbnN0IFt0YXNrLCBzZXRUYXNrXSA9IHVzZVN0YXRlKHt9KVxuICBjb25zdCBbdGFza0xvYWRpbmcsIHNldFRhc2tMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbYWN0aXZpdHksIHNldEFjdGl2aXR5XSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbYWN0aXZpdHlMb2FkaW5nLCBzZXRBY3Rpdml0eUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFt0YXNrTmF2LCBzZXRUYXNrTmF2XSA9IHVzZVN0YXRlKHt9KVxuICBjb25zdCBbaXNTdGFmZiwgc2V0SXNTdGFmZl0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCB7XG4gICAgbG9jYXRpb246IHtwYXRobmFtZSwgc3RhdGV9XG4gIH0gPSBoaXN0b3J5IHx8IHt9XG5cbiAgY29uc3QgaXNBdWRpdHNSZXF1ZXN0ZWRGcm9tVXJsID0gcGF0aG5hbWUuaW5jbHVkZXMoJ2F1ZGl0JylcblxuICBhc3luYyBmdW5jdGlvbiBnZXRUYXNrKCkge1xuICAgIGNvbnN0IHBheWxvYWQgPSB7bWV0aG9kOiAnR0VUJ30gXG4gICAgY29uc3QgdXJsID0gYC9vcmdzLyR7b3JnSWR9L3F1ZXVlcy8ke3F1ZXVlSWR9L3Rhc2tzLyR7dGFza0lkfWBcbiAgICBjb25zdCBhdWRpdHNVcmwgPSBgL29yZ3MvJHtvcmdJZH0vcXVldWVzL3Rhc2tzLyR7dGFza0lkfS9hdWRpdGBcbiAgICBzZXRUYXNrTG9hZGluZyh0cnVlKVxuICAgIGlmIChpc0F1ZGl0c1JlcXVlc3RlZEZyb21VcmwpIHtcbiAgICAgIGNvbnN0IHtkYXRhOiB0YXNrfSA9IGF3YWl0IG5ldHdvcmtlci5odHRwSGFuZGxlcihhdWRpdHNVcmwsIHtcbiAgICAgICAgcGFyYW1zOiBhdWRpdEZpbHRlcnMsXG4gICAgICAgIHBhcmFtc1NlcmlhbGl6ZXI6IChwYXJhbXMpID0+IHFzLnN0cmluZ2lmeShwYXJhbXMpLFxuICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICB9KVxuICAgICAgY29uc3Qge3Jlc3VsdCwgbmV4dCwgcHJldmlvdXN9ID0gdGFzayB8fCB7fVxuICAgICAgc2V0VGFzayhyZXN1bHQpXG4gICAgICBzZXRUYXNrTmF2KHtwcmV2aW91cywgbmV4dH0pXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHtkYXRhOiB0YXNrfSA9IGF3YWl0IG5ldHdvcmtlci5odHRwSGFuZGxlcih1cmwsIHBheWxvYWQpXG4gICAgICBzZXRUYXNrKHRhc2spXG4gICAgfVxuXG4gICAgY29uc3Qge2RhdGE6IG9yZ3N9ID0gYXdhaXQgbmV0d29ya2VyLmh0dHBIYW5kbGVyKGAvb3Jnc2AsIHttZXRob2Q6ICdHRVQnfSlcbiAgICBzZXRJc1N0YWZmKGlzVXNlclN0YWZmKG9yZ3MsIG9yZ0lkKSlcblxuICAgIHNldFRhc2tMb2FkaW5nKGZhbHNlKVxuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmcmVzaGVkVGFzaygpIHtcbiAgICBjb25zdCBwYXlsb2FkID0ge21ldGhvZDogJ0dFVCd9IFxuICAgIGNvbnN0IHVybCA9IGAvb3Jncy8ke29yZ0lkfS9xdWV1ZXMvJHtxdWV1ZUlkfS90YXNrcy8ke3Rhc2tJZH0vcmVmcmVzaGBcbiAgICBjb25zdCB7ZGF0YTogdGFza30gPSBhd2FpdCBuZXR3b3JrZXIuaHR0cEhhbmRsZXIodXJsLCBwYXlsb2FkKVxuICAgIGlmICghdGFzaykge1xuICAgICAgY29uc29sZS5lcnJvcignRVJST1IgRkVUQ0hJTkcgUkVGUkVTSEVEIFRBU0snKVxuICAgIH0gZWxzZSB7XG4gICAgICBzZXRUYXNrKHRhc2spXG4gICAgfVxuICB9XG5cbiAgY29uc3QgZ2V0QWN0aXZpdHkgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qge2lkOiB0YXNrSWQsIHF1ZXVlX2lkOiBxdWV1ZUlkfSA9IHRhc2sgfHwge31cbiAgICBpZiAodGFza0lkICYmIHF1ZXVlSWQpIHtcbiAgICAgIHNldEFjdGl2aXR5TG9hZGluZyh0cnVlKVxuICAgICAgY29uc3QgcGF5bG9hZCA9IHttZXRob2Q6ICdHRVQnfSBcbiAgICAgIGNvbnN0IHVybCA9IGAvb3Jncy8ke29yZ0lkfS9xdWV1ZXMvJHtxdWV1ZUlkfS90YXNrcy8ke3Rhc2tJZH0vYWN0aXZpdHlgXG4gICAgICBjb25zdCB7ZGF0YX0gPSBhd2FpdCBfb3B0aW9uYWxDaGFpbihbbmV0d29ya2VyLCAnb3B0aW9uYWxBY2Nlc3MnLCBfID0+IF8uaHR0cEhhbmRsZXIsICdjYWxsJywgXzIgPT4gXzIodXJsLCBwYXlsb2FkKV0pXG4gICAgICBpZiAoIWRhdGEpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignRVJST1IgRkVUQ0hJTkcgQUNUSVZJVFkgREFUQScpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRBY3Rpdml0eShkYXRhKVxuICAgICAgfVxuICAgIH1cbiAgICBzZXRBY3Rpdml0eUxvYWRpbmcoZmFsc2UpXG4gIH1cblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChfb3B0aW9uYWxDaGFpbihbc3RhdGUsICdvcHRpb25hbEFjY2VzcycsIF8zID0+IF8zLm5leHRUYXNrLCAnb3B0aW9uYWxBY2Nlc3MnLCBfNCA9PiBfNC5pZF0pKSB7XG4gICAgICBzZXRUYXNrKHN0YXRlLm5leHRUYXNrKVxuICAgIH0gZWxzZSBpZiAodGFza0lkICYmIG9yZ0lkKSB7XG4gICAgICBnZXRUYXNrKClcbiAgICB9XG4gIH0sIFt0YXNrSWQsIG9yZ0lkLCB1c2VyLCBxdWV1ZUlkXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHtpZCwgcXVldWVfaWQ6IHF1ZXVlSWR9ID0gdGFzayB8fCB7fVxuICAgIGlmIChpZCAmJiBxdWV1ZUlkKSB7XG4gICAgICBnZXRBY3Rpdml0eSgpXG4gICAgfVxuICB9LCBbdGFza0lkLCBfb3B0aW9uYWxDaGFpbihbdGFzaywgJ29wdGlvbmFsQWNjZXNzJywgXzUgPT4gXzUuaWRdKV0pXG5cbiAgY29uc3Qgb25TdWJtaXQgPSBSZWFjdC51c2VDYWxsYmFjayhhc3luYyAoZSwgdmFsdWVzLCBvcmdJZCkgPT4ge1xuICAgIGNvbnN0IHtpZDogdGFza0lkfSA9IHZhbHVlc1xuXG4gICAgbGV0IG5leHRVcmxcbiAgICBpZiAodGFza0lkICYmIG9yZ0lkKSB7XG4gICAgICBjb25zdCBjb25maWcgPSB7XG4gICAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgICAgZGF0YTogdHJhbnNmb3JtRGF0ZXMobnVsbCwgZm9ybWF0VmFsdWVzKHZhbHVlcykpXG4gICAgICB9IFxuICAgICAgY29uc3QgdXBkYXRlVXJsID0gYC9vcmdzLyR7b3JnSWR9L3F1ZXVlcy8ke3F1ZXVlSWR9L3Rhc2tzLyR7dGFza0lkfWBcbiAgICAgIGNvbnN0IG5leHRUYXNrVXJsID0gYC9vcmdzLyR7b3JnSWR9L3F1ZXVlcy8ke3F1ZXVlSWR9L3Rhc2tzL25leHRgXG5cbiAgICAgIGxldCByZXF1aXJlZFR5cGVcbiAgICAgIGxldCByZXF1aXJlZE5hbWVcbiAgICAgIGNvbnN0IHJlcXVpcmVkID0gKGJsb2NrKSA9PiB7XG4gICAgICAgIGlmICghQkxPQ0tfVFlQRS5GT1JNX1NFUVVFTkNFKSB7XG4gICAgICAgICAgY29uc3Qge3R5cGUsIG5hbWV9ID0gYmxvY2tcbiAgICAgICAgICBjb25zdCB7aXNfcmVxdWlyZWQ6IGlzUmVxdWlyZWQsIHZhbHVlOiBibG9ja1ZhbHVlfSA9IGJsb2NrW3R5cGVdXG4gICAgICAgICAgcmVxdWlyZWROYW1lID0gbmFtZVxuICAgICAgICAgIHJlcXVpcmVkVHlwZSA9IHR5cGVcbiAgICAgICAgICByZXR1cm4gKGlzUmVxdWlyZWQgJiYgYmxvY2tWYWx1ZSA9PT0gJycpIHx8IChpc1JlcXVpcmVkICYmICFibG9ja1ZhbHVlKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHJlcXVpcmVkRXJyb3IgPSBmb3JtYXRWYWx1ZXModmFsdWVzLmRhdGEpLm1hcCh0cmFuc2Zvcm1EYXRlcykuc29tZShyZXF1aXJlZClcbiAgICAgIGNvbnN0IHJlcXVpcmVkVmFsdWUgPVxuICAgICAgICByZXF1aXJlZFR5cGUgPT09IEJMT0NLX1RZUEUuVEVYVCB8fFxuICAgICAgICByZXF1aXJlZFR5cGUgPT09IEJMT0NLX1RZUEUuTlVNQkVSIHx8XG4gICAgICAgIHJlcXVpcmVkVHlwZSA9PT0gQkxPQ0tfVFlQRS5FTUFJTCB8fFxuICAgICAgICByZXF1aXJlZFR5cGUgPT09IEJMT0NLX1RZUEUuTElOS1xuICAgICAgICAgID8gJ3ZhbHVlJ1xuICAgICAgICAgIDogJ3NlbGVjdGlvbidcblxuICAgICAgaWYgKHJlcXVpcmVkRXJyb3IpIHtcbiAgICAgICAgZGlzcGF0Y2goYWRkRmFpbHVyZU5vdGlmaWNhdGlvbihgQSAke3JlcXVpcmVkVmFsdWV9IGlzIHJlcXVpcmVkIGZvciAke3JlcXVpcmVkTmFtZX1gKSlcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG5cbiAgICAgIC8vIFVwZGF0ZSB0YXNrXG4gICAgICBjb25zdCB7ZGF0YTogdXBkYXRlZFRhc2t9ID0gYXdhaXQgX29wdGlvbmFsQ2hhaW4oW25ldHdvcmtlciwgJ29wdGlvbmFsQWNjZXNzJywgXzYgPT4gXzYuaHR0cEhhbmRsZXIsICdjYWxsJywgXzcgPT4gXzcodXBkYXRlVXJsLCBjb25maWcpXSlcbiAgICAgIGlmICghdXBkYXRlZFRhc2spIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRVJST1IgVVBEQVRJTkcgVEFTS2ApXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZWdtZW50VHJhY2soJ1Rhc2sgQ29tcGxldGVkJywge3Rhc2tJZDogdGFza0lkLCBvcmdJZCwgdXNlcklkLCBlbWFpbCwgcXVldWVJZH0pXG4gICAgICAgIGNvbnN0IHtkYXRhOiBuZXh0VGFza30gPSBhd2FpdCBfb3B0aW9uYWxDaGFpbihbbmV0d29ya2VyLCAnb3B0aW9uYWxBY2Nlc3MnLCBfOCA9PiBfOC5odHRwSGFuZGxlciwgJ2NhbGwnLCBfOSA9PiBfOShuZXh0VGFza1VybCwge21ldGhvZDogJ0dFVCd9KV0pXG5cbiAgICAgICAgaWYgKCFuZXh0VGFzaykge1xuICAgICAgICAgIHJldHVybiBoaXN0b3J5LnJlcGxhY2UoYC9xdWV1ZXMvJHtxdWV1ZUlkfWApXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKG5leHRUYXNrLmlkKSB7XG4gICAgICAgICAgICBuZXh0VXJsID0gYC9xdWV1ZXMvJHtxdWV1ZUlkfS90YXNrcy8ke25leHRUYXNrLmlkfWBcbiAgICAgICAgICAgIHNlZ21lbnRUcmFjaygnVGFzayBGZXRjaGVkJywge3Rhc2tJZDogbmV4dFRhc2suaWQsIG9yZ0lkLCB1c2VySWQsIGVtYWlsLCBxdWV1ZUlkfSlcbiAgICAgICAgICAgIGhpc3RvcnkucHVzaCh7XG4gICAgICAgICAgICAgIHBhdGhuYW1lOiBuZXh0VXJsLFxuICAgICAgICAgICAgICBzdGF0ZToge25leHRUYXNrfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZGlzcGF0Y2goXG4gICAgICAgICAgICAgIGFkZFN1Y2Nlc3NOb3RpZmljYXRpb24oJ0NvbmdyYXR1bGF0aW9ucyEgWW91IGhhdmUgY29tcGxldGVkIGFsbCB0YXNrcyBpbiB0aGlzIHF1ZXVlLicpXG4gICAgICAgICAgICApXG4gICAgICAgICAgICBzZWdtZW50VHJhY2soJ0FsbCBUYXNrcyBDb21wbGV0ZWQnLCB7b3JnSWQsIHVzZXJJZCwgZW1haWwsIHF1ZXVlSWR9KVxuICAgICAgICAgICAgcmV0dXJuIGhpc3RvcnkucmVwbGFjZShgL3F1ZXVlcy8ke3F1ZXVlSWR9YClcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY29uc29sZS5lcnJvcignRkFJTEVEIFRPIFNVQk1JVCBUQVNLJylcbiAgICB9XG4gIH0sIFtdKVxuXG4gIGNvbnN0IG9uU2F2ZSA9IFJlYWN0LnVzZUNhbGxiYWNrKFxuICAgIGFzeW5jICh2YWx1ZXMpID0+IHtcbiAgICAgIGlmICh0YXNrLmlkKSB7XG4gICAgICAgIGNvbnN0IGNvbmZpZyA9IHtcbiAgICAgICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICAgICAgZGF0YTogdHJhbnNmb3JtRGF0ZXMobnVsbCwgZm9ybWF0VmFsdWVzKHZhbHVlcykpXG4gICAgICAgIH0gXG4gICAgICAgIGNvbnN0IHVybCA9IGAvb3Jncy8ke29yZ0lkfS9xdWV1ZXMvJHtxdWV1ZUlkfS90YXNrcy8ke3Rhc2suaWR9L3NhdmVgXG4gICAgICAgIGNvbnN0IHtkYXRhfSA9IGF3YWl0IF9vcHRpb25hbENoYWluKFtuZXR3b3JrZXIsICdvcHRpb25hbEFjY2VzcycsIF8xMCA9PiBfMTAuaHR0cEhhbmRsZXIsICdjYWxsJywgXzExID0+IF8xMSh1cmwsIGNvbmZpZyldKVxuICAgICAgICBpZiAoIWRhdGEpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKGBFUlJPUiBTQVZJTkcgVEFTS2ApXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZ2V0UmVmcmVzaGVkVGFzaygpXG4gICAgICAgICAgZ2V0QWN0aXZpdHkoKVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdJTlZBTElEIFRBU0snKVxuICAgICAgfVxuICAgIH0sXG4gICAgW3Rhc2ssIG9yZ0lkXVxuICApXG5cbiAgY29uc3Qgb25Qb3N0ID0gUmVhY3QudXNlQ2FsbGJhY2soXG4gICAgYXN5bmMgKGNvbW1lbnQpID0+IHtcbiAgICAgIGNvbnN0IHtpZDogdGFza0lkLCBxdWV1ZV9pZDogcXVldWVJZH0gPSB0YXNrIHx8IHt9XG4gICAgICBpZiAodGFza0lkICYmIHF1ZXVlSWQpIHtcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICBkYXRhOiB7YWN0aW9uOiAnY29tbWVudCcsIGNvbW1lbnQ6IGNvbW1lbnR9XG4gICAgICAgIH0gXG4gICAgICAgIGNvbnN0IHVybCA9IGAvb3Jncy8ke29yZ0lkfS9xdWV1ZXMvJHtxdWV1ZUlkfS90YXNrcy8ke3Rhc2tJZH0vYWN0aXZpdHlgXG4gICAgICAgIGF3YWl0IF9vcHRpb25hbENoYWluKFtuZXR3b3JrZXIsICdvcHRpb25hbEFjY2VzcycsIF8xMiA9PiBfMTIuaHR0cEhhbmRsZXIsICdjYWxsJywgXzEzID0+IF8xMyh1cmwsIHBheWxvYWQpXSlcbiAgICAgICAgZ2V0QWN0aXZpdHkoKVxuICAgICAgfVxuICAgIH0sXG4gICAgW3Rhc2ssIG9yZ0lkLCBxdWV1ZUlkXVxuICApXG5cbiAgY29uc3Qgb25EZWxldGUgPSBSZWFjdC51c2VDYWxsYmFjayhcbiAgICBhc3luYyAoZGVsZXRlSWQpID0+IHtcbiAgICAgIGNvbnN0IHtpZDogdGFza0lkLCBxdWV1ZV9pZDogcXVldWVJZH0gPSB0YXNrIHx8IHt9XG4gICAgICBpZiAodGFza0lkICYmIHF1ZXVlSWQpIHtcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgICAgICBtZXRob2Q6ICdERUxFVEUnXG4gICAgICAgIH0gXG4gICAgICAgIGNvbnN0IHVybCA9IGAvb3Jncy8ke29yZ0lkfS9xdWV1ZXMvJHtxdWV1ZUlkfS90YXNrcy8ke3Rhc2tJZH0vYWN0aXZpdHkvJHtkZWxldGVJZH1gXG4gICAgICAgIGF3YWl0IF9vcHRpb25hbENoYWluKFtuZXR3b3JrZXIsICdvcHRpb25hbEFjY2VzcycsIF8xNCA9PiBfMTQuaHR0cEhhbmRsZXIsICdjYWxsJywgXzE1ID0+IF8xNSh1cmwsIHBheWxvYWQpXSlcbiAgICAgICAgZ2V0QWN0aXZpdHkoKVxuICAgICAgfVxuICAgIH0sXG4gICAgW3Rhc2ssIG9yZ0lkLCBxdWV1ZUlkXVxuICApXG5cbiAgY29uc3Qgb25BdWRpdERlY2lzaW9uID0gUmVhY3QudXNlQ2FsbGJhY2soXG4gICAgYXN5bmMgKGNvcnJlY3QpID0+IHtcbiAgICAgIGNvbnN0IHtpZDogdGFza0lkfSA9IHRhc2sgfHwge31cbiAgICAgIGlmICh0YXNrSWQgJiYgb3JnSWQpIHtcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgICAgICBtZXRob2Q6ICdQVVQnLFxuICAgICAgICAgIGRhdGE6IHtjb3JyZWN0OiBjb3JyZWN0fVxuICAgICAgICB9IFxuICAgICAgICBjb25zdCB1cmwgPSBgL29yZ3MvJHtvcmdJZH0vcXVldWVzL3Rhc2tzLyR7dGFza0lkfS9hdWRpdGBcbiAgICAgICAgYXdhaXQgX29wdGlvbmFsQ2hhaW4oW25ldHdvcmtlciwgJ29wdGlvbmFsQWNjZXNzJywgXzE2ID0+IF8xNi5odHRwSGFuZGxlciwgJ2NhbGwnLCBfMTcgPT4gXzE3KHVybCwgcGF5bG9hZCldKVxuICAgICAgICBnZXRUYXNrKClcbiAgICAgICAgZ2V0QWN0aXZpdHkoKVxuICAgICAgfVxuICAgIH0sXG4gICAgW3Rhc2ssIG9yZ0lkLCBxdWV1ZUlkXVxuICApXG5cbiAgY29uc3Qgb25Bc3NpZ24gPSBSZWFjdC51c2VDYWxsYmFjayhcbiAgICBhc3luYyAodXNlcklkKSA9PiB7XG4gICAgICBjb25zdCBjb25maWcgPSB7bWV0aG9kOiAnUE9TVCcsIGRhdGE6IHthc3NpZ25lZF90bzogdXNlcklkfX0gXG4gICAgICBjb25zdCB1cmwgPSBgL29yZ3MvJHtvcmdJZH0vcXVldWVzLyR7cXVldWVJZH0vdGFza3MvJHt0YXNrLmlkfS9hc3NpZ25gXG4gICAgICBjb25zdCB7ZGF0YX0gPSBhd2FpdCBuZXR3b3JrZXIuaHR0cEhhbmRsZXIodXJsLCBjb25maWcpXG4gICAgICBpZiAoIWRhdGEpIHtcbiAgICAgICAgaWYgKHVzZXJJZCkge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEZBSUxFRCBUTyBBU1NJR04gVEFTS2ApXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihgRkFJTEVEIFRPIFVOQVNTSUdOIFRBU0tgKVxuICAgICAgICB9XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0VSUk9SIEFTU0lHTklORyBUQVNLJylcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGdldFJlZnJlc2hlZFRhc2soKVxuICAgICAgICBnZXRBY3Rpdml0eSgpXG4gICAgICB9XG4gICAgfSxcbiAgICBbdGFza11cbiAgKVxuXG4gIGlmICghX29wdGlvbmFsQ2hhaW4oW3Rhc2ssICdvcHRpb25hbEFjY2VzcycsIF8xOCA9PiBfMTguaWRdKSkgcmV0dXJuIG51bGxcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGFzaywge1xuICAgICAgdXNlcklkOiB1c2VySWQsXG4gICAgICBpc0F1ZGl0czogX29wdGlvbmFsQ2hhaW4oW3Rhc2ssICdvcHRpb25hbEFjY2VzcycsIF8xOSA9PiBfMTkuc3RhdHVzXSkgPT09ICdjb21wbGV0ZWQnLFxuICAgICAgdGFzazogdGFzayxcbiAgICAgIG9uU3VibWl0OiBvblN1Ym1pdCxcbiAgICAgIG9yZ0lkOiBvcmdJZCxcbiAgICAgIG9uU2F2ZTogb25TYXZlLFxuICAgICAgb25Qb3N0OiBvblBvc3QsXG4gICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICBvbkFzc2lnbjogb25Bc3NpZ24sXG4gICAgICB0YXNrTmF2OiB0YXNrTmF2LFxuICAgICAgYWN0aXZpdHk6IGFjdGl2aXR5LFxuICAgICAgaXNTdGFmZjogaXNTdGFmZixcbiAgICAgIG9uQXVkaXREZWNpc2lvbjogb25BdWRpdERlY2lzaW9uLFxuICAgICAgaXNMb2FkaW5nOiB0YXNrTG9hZGluZyB8fCBhY3Rpdml0eUxvYWRpbmcsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNzh9fVxuICAgIClcbiAgKVxufVxuXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSAoc3RhdGUpID0+ICh7XG4gIGF1ZGl0RmlsdGVyczogc3RhdGUuZmlsdGVycy5hdWRpdEZpbHRlcnNcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBudWxsKShUYXNrUm9vdClcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy91bml2ZXJzYWwvbW9kdWxlcy90YXNrL2NvbXBvbmVudHMvVGFzay50c3hcIjsgZnVuY3Rpb24gX29wdGlvbmFsQ2hhaW4ob3BzKSB7IGxldCBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyBsZXQgdmFsdWUgPSBvcHNbMF07IGxldCBpID0gMTsgd2hpbGUgKGkgPCBvcHMubGVuZ3RoKSB7IGNvbnN0IG9wID0gb3BzW2ldOyBjb25zdCBmbiA9IG9wc1tpICsgMV07IGkgKz0gMjsgaWYgKChvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQ2FsbCcpICYmIHZhbHVlID09IG51bGwpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfSBpZiAob3AgPT09ICdhY2Nlc3MnIHx8IG9wID09PSAnb3B0aW9uYWxBY2Nlc3MnKSB7IGxhc3RBY2Nlc3NMSFMgPSB2YWx1ZTsgdmFsdWUgPSBmbih2YWx1ZSk7IH0gZWxzZSBpZiAob3AgPT09ICdjYWxsJyB8fCBvcCA9PT0gJ29wdGlvbmFsQ2FsbCcpIHsgdmFsdWUgPSBmbigoLi4uYXJncykgPT4gdmFsdWUuY2FsbChsYXN0QWNjZXNzTEhTLCAuLi5hcmdzKSk7IGxhc3RBY2Nlc3NMSFMgPSB1bmRlZmluZWQ7IH0gfSByZXR1cm4gdmFsdWU7IH1pbXBvcnQgUmVhY3QsIHt1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VSZWZ9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtjb25uZWN0fSBmcm9tICdyZWFjdC1yZWR1eCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IHtGb3JtaWssIEZvcm0sIEZpZWxkQXJyYXl9IGZyb20gJ2Zvcm1paydcbmltcG9ydCBSR0wgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvUkdMJ1xuaW1wb3J0IEJsb2NrQ29tcG9uZW50IGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0Jsb2NrQ29tcG9uZW50J1xuXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3VuaXZlcnNhbC9zdHlsZXMvcGFsZXR0ZSdcbmltcG9ydCBQcmltYXJ5QnV0dG9uIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL1ByaW1hcnlCdXR0b24nXG5pbXBvcnQgU2Vjb25kYXJ5QnV0dG9uIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL1NlY29uZGFyeUJ1dHRvbidcbmltcG9ydCBTaWRlYmFyIGZyb20gJy4vU2lkZWJhcidcbmltcG9ydCB1c2VSb3V0ZXIgZnJvbSAnY2xpZW50L2hvb2tzL3VzZVJvdXRlcidcbmltcG9ydCBBcHBIZWFkZXIgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvQXBwSGVhZGVyJ1xuaW1wb3J0IEJsb2NrV3JhcHBlciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9CbG9ja1dyYXBwZXInXG5pbXBvcnQge3Rhc2tTY2hlbWF9IGZyb20gJ3VuaXZlcnNhbC92YWxpZGF0aW9ucy95dXBTY2hlbWEnXG5pbXBvcnQgQXVkaXREZWNpc2lvbiBmcm9tICd1bml2ZXJzYWwvbW9kdWxlcy9hdWRpdHMvY29tcG9uZW50cy9BdWRpdERlY2lzaW9uJ1xuaW1wb3J0IFNwaW5uZXIgZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvU3Bpbm5lcidcbmltcG9ydCB1c2VNb2RhbCBmcm9tICdjbGllbnQvaG9va3MvdXNlTW9kYWwnXG5pbXBvcnQgQ29uZmlybWF0aW9uTW9kYWwgZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvQ29uZmlybWF0aW9uTW9kYWwnXG5pbXBvcnQge3dvcmtmbGxvd0FjdGlvbnN9IGZyb20gJ2NsaWVudC9yZWR1eC9xdWV1ZXNSZWR1Y2VycydcblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5jb25zdCBGb3JtQ29udGFpbmVyID0gc3R5bGVkKEZvcm0pKHtcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBoZWlnaHQ6ICcxMDAlJyxcbiAgZmxleERpcmVjdGlvbjogJ2NvbHVtbidcbn0pXG5cbmNvbnN0IENvbnRlbnQgPSBzdHlsZWQuZGl2KHtcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBmbGV4RGlyZWN0aW9uOiAncm93JyxcbiAgd2lkdGg6ICcxMDAlJyxcbiAgaGVpZ2h0OiAnMTAwJScsXG4gIG92ZXJmbG93OiAnaGlkZGVuJ1xufSlcblxuY29uc3QgQWN0aW9uQmxvY2sgPSBzdHlsZWQuZGl2YFxuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiBtaW4tY29udGVudCAkeyhwcm9wcykgPT4gKHByb3BzLmF1ZGl0cyA/ICczNXB4IDM1cHgnIDogJycpfSBtaW4tY29udGVudDtcbiAgY29sdW1uLWdhcDogMjBweDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbmBcblxuY29uc3QgUXVldWVOYW1lID0gc3R5bGVkLmRpdih7XG4gIGZvbnRXZWlnaHQ6IDUwMCxcbiAgY29sb3I6IFBBTEVUVEUuVEVYVF9NQUlOXG59KVxuXG5jb25zdCBUYXNrID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBvbkRlbGV0ZSxcbiAgICBvblBvc3QsXG4gICAgdXNlcklkLFxuICAgIGFjdGl2aXR5LFxuICAgIHRhc2ssXG4gICAgb25TdWJtaXQsXG4gICAgdGFza05hdixcbiAgICBvcmdJZCxcbiAgICBvblNhdmUsXG4gICAgdXNlcnMsXG4gICAgb25Bc3NpZ24sXG4gICAgaXNBdWRpdHMsXG4gICAgb25BdWRpdERlY2lzaW9uLFxuICAgIGlzTG9hZGluZyxcbiAgICBpc1N0YWZmLFxuICAgIHF1ZXVlcyxcbiAgICBzZXRTZWxlY3RlZFF1ZXVlXG4gIH0gPSBwcm9wc1xuICBjb25zdCB7aWQ6IHRhc2tJZCwgcXVldWVfaWQ6IHF1ZXVlSWQsIGNvcnJlY3Q6IGNvcnJlY3R9ID0gdGFzayB8fCB7fVxuICBjb25zdCB7aGlzdG9yeX0gPSB1c2VSb3V0ZXIoKSBcbiAgY29uc3QgW2Fzc2lnbmVkVG8sIHNldEFzc2lnbmVkVG9dID0gdXNlU3RhdGUodGFza0lkKVxuICBjb25zdCB7bmV4dCwgcHJldmlvdXN9ID0gdGFza05hdiB8fCB7fVxuICBjb25zdCByZXR1cm5VcmwgPSBgL3F1ZXVlcy8ke3F1ZXVlSWR9YCB8fCAncXVldWVzJ1xuICBjb25zdCB7cXVldWV9ID0gdGFzayB8fCAnJ1xuICBjb25zdCBsYXlvdXRzID0gdGFzay5kYXRhLm1hcCgoYmxvY2spID0+IGJsb2NrLmxheW91dClcbiAgY29uc3QgaXNOb3RBc3NpZ25lZFRvTWUgPSBhc3NpZ25lZFRvICE9PSB1c2VySWRcbiAgbGV0IHJlYWRPbmx5ID0gaXNBdWRpdHMgfHwgaXNOb3RBc3NpZ25lZFRvTWVcbiAgaWYgKGlzU3RhZmYgJiYgaXNOb3RBc3NpZ25lZFRvTWUpIHtcbiAgICByZWFkT25seSA9IHRydWVcbiAgfVxuICBjb25zdCBbaXNTdWJtaXRpbmcsIHNldFN1Ym1pdGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2lzU2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFt2aWV3LCBzZXRWaWV3XSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFthc3NpZ25lZURldGFpbHMsIHNldEFzc2lnbmVlRGV0YWlsc10gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCB7XG4gICAgbG9jYXRpb246IHtwYXRobmFtZSwgc3RhdGU6IGxvY2F0aW9uU3RhdGV9XG4gIH0gPSBoaXN0b3J5IHx8IHt9XG4gIGNvbnN0IGZvcm1SZWYgPSB1c2VSZWYoKVxuXG4gIGNvbnN0IFt0YXNrQ2hhbmdlZCwgc2V0VGFza0NoYW5nZWRdID0gdXNlU3RhdGUoX29wdGlvbmFsQ2hhaW4oW2xvY2F0aW9uU3RhdGUsICdvcHRpb25hbEFjY2VzcycsIF8gPT4gXy50YXNrQ2hhbmdlZF0pIHx8IGZhbHNlKVxuXG4gIGNvbnN0IHtcbiAgICBtb2RhbFBvcnRhbDogY29uZmlybVRhc2ssXG4gICAgdG9nZ2xlUG9ydGFsOiB0b2dnbGVUYXNrTW9kYWwsXG4gICAgY2xvc2VQb3J0YWw6IGNsb3NlVGFza01vZGFsXG4gIH0gPSB1c2VNb2RhbCgpXG4gIGNvbnN0IHtcbiAgICBtb2RhbFBvcnRhbDogY29uZmlybUFzc2lnbmVlLFxuICAgIHRvZ2dsZVBvcnRhbDogdG9nZ2xlQXNzaWduZWVNb2RhbCxcbiAgICBjbG9zZVBvcnRhbDogY2xvc2VBc3NpZ25lZU1vZGFsXG4gIH0gPSB1c2VNb2RhbCgpXG5cbiAgY29uc3QgaXNBdWRpdHNSZXF1ZXN0ZWRGcm9tVXJsID0gcGF0aG5hbWUuaW5jbHVkZXMoJ2F1ZGl0JylcbiAgY29uc3QgaXNMb2FkaW5nUHJldmlvdXMgPSB2aWV3ID09PSAncHJldmlvdXMnXG4gIGNvbnN0IGlzTG9hZGluZ05leHQgPSB2aWV3ID09PSAnbmV4dCdcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHthc3NpZ25lZF90b30gPSB0YXNrIHx8IHt9XG4gICAgc2V0QXNzaWduZWRUbyhhc3NpZ25lZF90bylcbiAgICBjb25zdCBjdXJyZW50UXVldWUgPSBxdWV1ZXMuZmluZCgocSkgPT4gcS5pZCA9PT0gdGFzay5xdWV1ZV9pZClcbiAgICBpZiAoY3VycmVudFF1ZXVlKSB7XG4gICAgICBzZXRTZWxlY3RlZFF1ZXVlKGN1cnJlbnRRdWV1ZSlcbiAgICB9XG4gIH0sIFtpc0F1ZGl0cywgdGFza10pXG5cbiAgY29uc3QgcmVzZXRWaWV3ID0gKCkgPT4gc2V0VmlldyhudWxsKVxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGxcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChGb3JtaWssIHtcbiAgICAgICAgZW5hYmxlUmVpbml0aWFsaXplOiB0cnVlLFxuICAgICAgICBpbml0aWFsVmFsdWVzOiB0YXNrLFxuICAgICAgICBvblN1Ym1pdDogKF92YWx1ZXMsIGZvcm1pa0JhZykgPT4ge1xuICAgICAgICAgIGZvcm1pa0JhZy5zZXRTdWJtaXR0aW5nKGZhbHNlKVxuICAgICAgICB9LFxuICAgICAgICB2YWxpZGF0ZU9uQ2hhbmdlOiB0cnVlLFxuICAgICAgICB2YWxpZGF0ZU9uQmx1cjogdHJ1ZSxcbiAgICAgICAgdmFsaWRhdGVPbk1vdW50OiB0cnVlLFxuICAgICAgICB2YWxpZGF0aW9uU2NoZW1hOiB0YXNrU2NoZW1hLFxuICAgICAgICBpbm5lclJlZjogZm9ybVJlZiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEzOX19XG4gICAgICBcbiAgICAgICAgLCAoe1xuICAgICAgICAgIGhhbmRsZUNoYW5nZSxcbiAgICAgICAgICB2YWx1ZXMsXG4gICAgICAgICAgc2V0RmllbGRWYWx1ZSxcbiAgICAgICAgICBpc1N1Ym1pdHRpbmcsXG4gICAgICAgICAgaXNWYWxpZCxcbiAgICAgICAgICBlcnJvcnMsXG4gICAgICAgICAgaGFuZGxlQmx1cixcbiAgICAgICAgICB2YWxpZGF0ZUZvcm1cbiAgICAgICAgfSkgPT4ge1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEZvcm1Db250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTYyfX1cbiAgICAgICAgICAgICAgLCBpc0F1ZGl0cyAmJiBpc0F1ZGl0c1JlcXVlc3RlZEZyb21VcmwgPyAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChBcHBIZWFkZXIsIHtcbiAgICAgICAgICAgICAgICAgIGxlZnRCYXJJdGVtczogXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU2Vjb25kYXJ5QnV0dG9uLCB7XG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcImJhY2tcIixcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImJ1dHRvblwiLFxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IGhpc3RvcnkucmVwbGFjZSgnL2F1ZGl0cycpLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTY2fX1cbiAgICAgICAgICAgICAgICAgICAgLCBcIkJhY2tcIlxuXG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICxcbiAgICAgICAgICAgICAgICAgIG1pZEJhckl0ZW1zOiBSZWFjdC5jcmVhdGVFbGVtZW50KFF1ZXVlTmFtZSwgeyBrZXk6IFwibmFtZVwiLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTc0fX0sIHF1ZXVlKSxcbiAgICAgICAgICAgICAgICAgIHJpZ2h0QmFySXRlbXM6IFxuICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEFjdGlvbkJsb2NrLCB7IGF1ZGl0czogIWlzU3RhZmYgPyB0cnVlIDogZmFsc2UsIGtleTogXCJuYXZfYmxvY2tcIiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE3Nn19XG4gICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFNlY29uZGFyeUJ1dHRvbiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgaGlkZUZvY3VzOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ6ICFwcmV2aW91cyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFZpZXcoJ3ByZXZpb3VzJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGlzdG9yeS5yZXBsYWNlKHByZXZpb3VzKVxuICAgICAgICAgICAgICAgICAgICAgICAgfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE3N319XG4gICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAsIGlzTG9hZGluZ1ByZXZpb3VzICYmIGlzTG9hZGluZyA/IFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3Bpbm5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxODZ9fSApIDogYFByZXZpb3VzYFxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAsICFpc1N0YWZmICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQXVkaXREZWNpc2lvbiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBvcmdJZDogb3JnSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXVlSWQ6IHF1ZXVlSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRhc2tJZDogdGFza0lkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb3JyZWN0OiBjb3JyZWN0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkF1ZGl0RGVjaXNpb246IChhcmdzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzZXRWaWV3KClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkF1ZGl0RGVjaXNpb24oYXJncylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE4OX19XG4gICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChQcmltYXJ5QnV0dG9uLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBoaWRlRm9jdXM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZDogIW5leHQsXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImJ1dHRvblwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljazogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWaWV3KCduZXh0JylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGlzdG9yeS5yZXBsYWNlKG5leHQpXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjAwfX1cbiAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgICwgaXNMb2FkaW5nTmV4dCAmJiBpc0xvYWRpbmcgPyBSZWFjdC5jcmVhdGVFbGVtZW50KFNwaW5uZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjA5fX0gKSA6IGBOZXh0YFxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTY0fX1cbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChBcHBIZWFkZXIsIHtcbiAgICAgICAgICAgICAgICAgIGxlZnRCYXJJdGVtczogXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU2Vjb25kYXJ5QnV0dG9uLCB7XG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcImJhY2tcIixcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImJ1dHRvblwiLFxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0YXNrQ2hhbmdlZCAmJiBmb3JtUmVmLmN1cnJlbnQuZGlydHkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG9nZ2xlVGFza01vZGFsKClcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhpc3RvcnkucmVwbGFjZShyZXR1cm5VcmwpXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIxN319XG4gICAgICAgICAgICAgICAgICAgICwgXCJCYWNrXCJcblxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAsXG4gICAgICAgICAgICAgICAgICBtaWRCYXJJdGVtczogUmVhY3QuY3JlYXRlRWxlbWVudChRdWV1ZU5hbWUsIHsga2V5OiBcIm5hbWVcIiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIzMX19LCBxdWV1ZSksXG4gICAgICAgICAgICAgICAgICByaWdodEJhckl0ZW1zOiBcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChBY3Rpb25CbG9jaywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzN9fVxuICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTZWNvbmRhcnlCdXR0b24sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhpZGVGb2N1czogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkOiByZWFkT25seSB8fCBpc1N1Ym1pdHRpbmcsXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImJ1dHRvblwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljazogYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTYXZpbmcodHJ1ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgb25TYXZlKHZhbHVlcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGFza0NoYW5nZWQoZmFsc2UpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNhdmluZyhmYWxzZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdGVGb3JtKHZhbHVlcylcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzR9fVxuICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgLCBpc1NhdmluZyA/IFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3Bpbm5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNDZ9fSApIDogYFNhdmVgXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChQcmltYXJ5QnV0dG9uLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBoaWRlRm9jdXM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZDogcmVhZE9ubHkgfHwgaXNTdWJtaXR0aW5nIHx8ICFpc1ZhbGlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJzdWJtaXRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6IGFzeW5jIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFN1Ym1pdGluZyh0cnVlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBhd2FpdCBvblN1Ym1pdChlLCB2YWx1ZXMsIG9yZ0lkKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTdWJtaXRpbmcoZmFsc2UpXG4gICAgICAgICAgICAgICAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjQ4fX1cbiAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgICwgaXNTdWJtaXRpbmcgPyBSZWFjdC5jcmVhdGVFbGVtZW50KFNwaW5uZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjU4fX0gKSA6IGBTdWJtaXRgXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMTV9fVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRmllbGRBcnJheSwge1xuICAgICAgICAgICAgICAgIG5hbWU6IFwiZGF0YVwiLFxuICAgICAgICAgICAgICAgIHJlbmRlcjogKCkgPT4gKFxuICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb250ZW50LCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI2N319XG4gICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTaWRlYmFyLCB7XG4gICAgICAgICAgICAgICAgICAgICAgb25Qb3N0OiAoYXJncykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzZXRWaWV3KClcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uUG9zdChhcmdzKVxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgb25EZWxldGU6IChhcmdzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNldFZpZXcoKVxuICAgICAgICAgICAgICAgICAgICAgICAgb25EZWxldGUoYXJncylcbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgIGFzc2lnbmVkVG86IGFzc2lnbmVkVG8sXG4gICAgICAgICAgICAgICAgICAgICAgdGFzazogdGFzayxcbiAgICAgICAgICAgICAgICAgICAgICB1c2VyczogdXNlcnMsXG4gICAgICAgICAgICAgICAgICAgICAgb25Bc3NpZ246IChhc3NpZ25lZSwgYXNzaWdub3IpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc2V0VmlldygpXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBc3NpZ25lZURldGFpbHMoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICBhc3NpZ25lZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXNzaWdub3JcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGFza0NoYW5nZWQgJiYgZm9ybVJlZi5jdXJyZW50LmRpcnR5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvZ2dsZUFzc2lnbmVlTW9kYWwoKVxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25Bc3NpZ24oYXNzaWduZWUsIGFzc2lnbm9yKVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgcXVldWVJZDogcXVldWVJZCxcbiAgICAgICAgICAgICAgICAgICAgICBvcmdJZDogb3JnSWQsXG4gICAgICAgICAgICAgICAgICAgICAgYWN0aXZpdHk6IGFjdGl2aXR5LFxuICAgICAgICAgICAgICAgICAgICAgIGlzQXVkaXRzOiBpc0F1ZGl0cyxcbiAgICAgICAgICAgICAgICAgICAgICBjb3JyZWN0OiBjb3JyZWN0LFxuICAgICAgICAgICAgICAgICAgICAgIHF1ZXVlOiBxdWV1ZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI2OH19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdkaXYnLCB7IHN0eWxlOiB7d2lkdGg6ICcxMDAlJ30sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyOTl9fVxuICAgICAgICAgICAgICAgICAgICAgICwgIShcbiAgICAgICAgICAgICAgICAgICAgICAgIChpc0F1ZGl0cyAmJiBpc0xvYWRpbmdOZXh0ICYmIGlzTG9hZGluZykgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIChpc0xvYWRpbmdQcmV2aW91cyAmJiBpc0xvYWRpbmcpXG4gICAgICAgICAgICAgICAgICAgICAgKSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFJHTCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0RyYWdnYWJsZTogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzRHJvcHBhYmxlOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXNSZXNpemFibGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYXlvdXRzOiBsYXlvdXRzLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzA0fX1cbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAsIHZhbHVlcy5kYXRhLm1hcCgoYmxvY2ssIGlkeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlcnJvcnNGb3JCbG9jayA9IHt9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycm9ycy5kYXRhICYmIGVycm9ycy5kYXRhW2lkeF0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JzRm9yQmxvY2sgPSBlcnJvcnMuZGF0YVtpZHhdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJsb2NrV3JhcHBlciwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IGJsb2NrLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnZGF0YS1ncmlkJzogYmxvY2subGF5b3V0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleDogaWR4LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBibG9jay50eXBlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzE2fX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmxvY2tDb21wb25lbnQsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZFZhbHVlOiAoZmllbGQsIGRhdGEpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFRhc2tDaGFuZ2VkKHRydWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZFZhbHVlKGZpZWxkLCBkYXRhKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2s6IGJsb2NrLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yczogZXJyb3JzRm9yQmxvY2ssXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hhbmdlOiAoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGFza0NoYW5nZWQodHJ1ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoYW5nZShlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQmx1cjogaGFuZGxlQmx1cixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleDogaWR4LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRWRpdGluZzogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBdWRpdHM6IHJlYWRPbmx5LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzIyfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgIClcblxuICAgICAgICAgICAgICAgICAgICAsIGNvbmZpcm1UYXNrKFxuICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29uZmlybWF0aW9uTW9kYWwsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsb3NlUG9ydGFsOiBjbG9zZVRhc2tNb2RhbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBgRXhpdCB3aXRob3V0IHNhdmluZ2AsXG4gICAgICAgICAgICAgICAgICAgICAgICBjYW5jZWxMYWJlbDogYFNhdmUgYW5kIEV4aXRgLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogYFlvdSBoYXZlIG1hZGUgY2hhbmdlcyBidXQgdGhleSBoYXZlbid0IGJlZW4gc2F2ZWQuYCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybTogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBoaXN0b3J5LnJlcGxhY2UocmV0dXJuVXJsKVxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2FuY2VsOiBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNhdmluZyh0cnVlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBhd2FpdCBvblNhdmUodmFsdWVzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUYXNrQ2hhbmdlZChmYWxzZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2F2aW5nKGZhbHNlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBoaXN0b3J5LnJlcGxhY2UocmV0dXJuVXJsKVxuICAgICAgICAgICAgICAgICAgICAgICAgfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDM0Nn19XG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICwgY29uZmlybUFzc2lnbmVlKFxuICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29uZmlybWF0aW9uTW9kYWwsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsb3NlUG9ydGFsOiBjbG9zZUFzc2lnbmVlTW9kYWwsXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogYFJlYXNzaWduIHdpdGhvdXQgc2F2aW5nYCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbmNlbExhYmVsOiBgU2F2ZSBhbmQgUmVhc3NpZ25gLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogYFlvdSBoYXZlIG1hZGUgY2hhbmdlcyBidXQgdGhleSBoYXZlbid0IGJlZW4gc2F2ZWQuYCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybTogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXNldFZpZXcoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkFzc2lnbihhc3NpZ25lZURldGFpbHMuYXNzaWduZWUsIGFzc2lnbmVlRGV0YWlscy5hc3NpZ25vcilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QXNzaWduZWVEZXRhaWxzKG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgb25DYW5jZWw6IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2F2aW5nKHRydWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IG9uU2F2ZSh2YWx1ZXMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFRhc2tDaGFuZ2VkKGZhbHNlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTYXZpbmcoZmFsc2UpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlc2V0VmlldygpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQXNzaWduKGFzc2lnbmVlRGV0YWlscy5hc3NpZ25lZSwgYXNzaWduZWVEZXRhaWxzLmFzc2lnbm9yKVxuICAgICAgICAgICAgICAgICAgICAgICAgfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDM2NH19XG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgKSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI2NH19XG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgIClcbiAgICApXG4gIClcbn1cblxuY29uc3QgbWFwU3RhdGVUb1Byb3BzID0gKHN0YXRlKSA9PiAoe1xuICB1c2Vyczogc3RhdGUudXNlcnMsXG4gIHF1ZXVlczogc3RhdGUucXVldWVzLnF1ZXVlc1xufSlcblxuY29uc3QgbWFwRGlzcGF0Y2hUb1Byb3BzID0gKGRpc3BhdGNoKSA9PiAoe1xuICBzZXRTZWxlY3RlZFF1ZXVlOiAoYXJnKSA9PiBkaXNwYXRjaCh3b3JrZmxsb3dBY3Rpb25zLnNldFNlbGVjdGVkUXVldWUoYXJnKSlcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKFRhc2spXG4iLCIgZnVuY3Rpb24gX29wdGlvbmFsQ2hhaW4ob3BzKSB7IGxldCBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyBsZXQgdmFsdWUgPSBvcHNbMF07IGxldCBpID0gMTsgd2hpbGUgKGkgPCBvcHMubGVuZ3RoKSB7IGNvbnN0IG9wID0gb3BzW2ldOyBjb25zdCBmbiA9IG9wc1tpICsgMV07IGkgKz0gMjsgaWYgKChvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQ2FsbCcpICYmIHZhbHVlID09IG51bGwpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfSBpZiAob3AgPT09ICdhY2Nlc3MnIHx8IG9wID09PSAnb3B0aW9uYWxBY2Nlc3MnKSB7IGxhc3RBY2Nlc3NMSFMgPSB2YWx1ZTsgdmFsdWUgPSBmbih2YWx1ZSk7IH0gZWxzZSBpZiAob3AgPT09ICdjYWxsJyB8fCBvcCA9PT0gJ29wdGlvbmFsQ2FsbCcpIHsgdmFsdWUgPSBmbigoLi4uYXJncykgPT4gdmFsdWUuY2FsbChsYXN0QWNjZXNzTEhTLCAuLi5hcmdzKSk7IGxhc3RBY2Nlc3NMSFMgPSB1bmRlZmluZWQ7IH0gfSByZXR1cm4gdmFsdWU7IH1pbXBvcnQge0JMT0NLX1RZUEV9IGZyb20gJ3VuaXZlcnNhbC91dGlscy9jb25zdGFudHMnXG5cbmNvbnN0IGZvcm1hdFZhbHVlcyA9ICh2YWx1ZXMpID0+IHtcbiAgbGV0IGZpZWxkc1xuXG4gIGlmIChBcnJheS5pc0FycmF5KHZhbHVlcy5kYXRhKSkge1xuICAgIGZpZWxkcyA9IHZhbHVlcy5kYXRhXG4gIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZXMpKSB7XG4gICAgZmllbGRzID0gdmFsdWVzXG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHZhbHVlc1xuICB9XG5cbiAgZmllbGRzLmZpbHRlcigodmFsKSA9PiB7XG4gICAgaWYgKHZhbFtCTE9DS19UWVBFLk5BTUVEX0VOVElUWV9SRUNPR05JVElPTl0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgX29wdGlvbmFsQ2hhaW4oW3ZhbCwgJ2FjY2VzcycsIF8gPT4gX1tCTE9DS19UWVBFLk5BTUVEX0VOVElUWV9SRUNPR05JVElPTl0sICdhY2Nlc3MnLCBfMiA9PiBfMi5lbnRpdGllcywgJ29wdGlvbmFsQWNjZXNzJywgXzMgPT4gXzMuZmlsdGVyLCAnY2FsbCcsIF80ID0+IF80KChlbnRpdHkpID0+IHtcbiAgICAgICAgZGVsZXRlIGVudGl0eS5jb2xvclxuICAgICAgICBkZWxldGUgZW50aXR5LnRleHRcbiAgICAgIH0pXSlcbiAgICB9XG4gICAgaWYgKHZhbFtCTE9DS19UWVBFLkJPVU5ESU5HX0JPWEVTXSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWxbQkxPQ0tfVFlQRS5CT1VORElOR19CT1hFU10udmFsdWUub2JqZWN0cykpIHtcbiAgICAgICAgdmFsW0JMT0NLX1RZUEUuQk9VTkRJTkdfQk9YRVNdLnZhbHVlLm9iamVjdHMuZmlsdGVyKChlbnRpdHkpID0+IHtcbiAgICAgICAgICBkZWxldGUgZW50aXR5LmNvbG9yXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgICBpZiAodmFsW0JMT0NLX1RZUEUuQk9VTkRJTkdfQk9YRVNdLnZhbHVlLmltYWdlID09PSAnJykge1xuICAgICAgICB2YWxbQkxPQ0tfVFlQRS5CT1VORElOR19CT1hFU10udmFsdWUuaW1hZ2UgPSBudWxsXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB2YWxcbiAgfSlcbiAgcmV0dXJuIHZhbHVlc1xufVxuXG5leHBvcnQgZGVmYXVsdCBmb3JtYXRWYWx1ZXNcbiIsIi8qIChpZ25vcmVkKSAqLyJdLCJzb3VyY2VSb290IjoiIn0=