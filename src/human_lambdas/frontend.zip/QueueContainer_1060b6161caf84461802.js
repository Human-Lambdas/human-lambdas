(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["QueueContainer"],{

/***/ "./node_modules/dayjs/dayjs.min.js":
/*!*****************************************!*\
  !*** ./node_modules/dayjs/dayjs.min.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

!function(t,e){ true?module.exports=e():undefined}(this,function(){"use strict";var t="millisecond",e="second",n="minute",r="hour",i="day",s="week",u="month",a="quarter",o="year",f="date",h=/^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[^0-9]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,c=/\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,d={name:"en",weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_")},$=function(t,e,n){var r=String(t);return!r||r.length>=e?t:""+Array(e+1-r.length).join(n)+t},l={s:$,z:function(t){var e=-t.utcOffset(),n=Math.abs(e),r=Math.floor(n/60),i=n%60;return(e<=0?"+":"-")+$(r,2,"0")+":"+$(i,2,"0")},m:function t(e,n){if(e.date()<n.date())return-t(n,e);var r=12*(n.year()-e.year())+(n.month()-e.month()),i=e.clone().add(r,u),s=n-i<0,a=e.clone().add(r+(s?-1:1),u);return+(-(r+(n-i)/(s?i-a:a-i))||0)},a:function(t){return t<0?Math.ceil(t)||0:Math.floor(t)},p:function(h){return{M:u,y:o,w:s,d:i,D:f,h:r,m:n,s:e,ms:t,Q:a}[h]||String(h||"").toLowerCase().replace(/s$/,"")},u:function(t){return void 0===t}},y="en",M={};M[y]=d;var m=function(t){return t instanceof S},D=function(t,e,n){var r;if(!t)return y;if("string"==typeof t)M[t]&&(r=t),e&&(M[t]=e,r=t);else{var i=t.name;M[i]=t,r=i}return!n&&r&&(y=r),r||!n&&y},v=function(t,e){if(m(t))return t.clone();var n="object"==typeof e?e:{};return n.date=t,n.args=arguments,new S(n)},g=l;g.l=D,g.i=m,g.w=function(t,e){return v(t,{locale:e.$L,utc:e.$u,x:e.$x,$offset:e.$offset})};var S=function(){function d(t){this.$L=D(t.locale,null,!0),this.parse(t)}var $=d.prototype;return $.parse=function(t){this.$d=function(t){var e=t.date,n=t.utc;if(null===e)return new Date(NaN);if(g.u(e))return new Date;if(e instanceof Date)return new Date(e);if("string"==typeof e&&!/Z$/i.test(e)){var r=e.match(h);if(r){var i=r[2]-1||0,s=(r[7]||"0").substring(0,3);return n?new Date(Date.UTC(r[1],i,r[3]||1,r[4]||0,r[5]||0,r[6]||0,s)):new Date(r[1],i,r[3]||1,r[4]||0,r[5]||0,r[6]||0,s)}}return new Date(e)}(t),this.$x=t.x||{},this.init()},$.init=function(){var t=this.$d;this.$y=t.getFullYear(),this.$M=t.getMonth(),this.$D=t.getDate(),this.$W=t.getDay(),this.$H=t.getHours(),this.$m=t.getMinutes(),this.$s=t.getSeconds(),this.$ms=t.getMilliseconds()},$.$utils=function(){return g},$.isValid=function(){return!("Invalid Date"===this.$d.toString())},$.isSame=function(t,e){var n=v(t);return this.startOf(e)<=n&&n<=this.endOf(e)},$.isAfter=function(t,e){return v(t)<this.startOf(e)},$.isBefore=function(t,e){return this.endOf(e)<v(t)},$.$g=function(t,e,n){return g.u(t)?this[e]:this.set(n,t)},$.unix=function(){return Math.floor(this.valueOf()/1e3)},$.valueOf=function(){return this.$d.getTime()},$.startOf=function(t,a){var h=this,c=!!g.u(a)||a,d=g.p(t),$=function(t,e){var n=g.w(h.$u?Date.UTC(h.$y,e,t):new Date(h.$y,e,t),h);return c?n:n.endOf(i)},l=function(t,e){return g.w(h.toDate()[t].apply(h.toDate("s"),(c?[0,0,0,0]:[23,59,59,999]).slice(e)),h)},y=this.$W,M=this.$M,m=this.$D,D="set"+(this.$u?"UTC":"");switch(d){case o:return c?$(1,0):$(31,11);case u:return c?$(1,M):$(0,M+1);case s:var v=this.$locale().weekStart||0,S=(y<v?y+7:y)-v;return $(c?m-S:m+(6-S),M);case i:case f:return l(D+"Hours",0);case r:return l(D+"Minutes",1);case n:return l(D+"Seconds",2);case e:return l(D+"Milliseconds",3);default:return this.clone()}},$.endOf=function(t){return this.startOf(t,!1)},$.$set=function(s,a){var h,c=g.p(s),d="set"+(this.$u?"UTC":""),$=(h={},h[i]=d+"Date",h[f]=d+"Date",h[u]=d+"Month",h[o]=d+"FullYear",h[r]=d+"Hours",h[n]=d+"Minutes",h[e]=d+"Seconds",h[t]=d+"Milliseconds",h)[c],l=c===i?this.$D+(a-this.$W):a;if(c===u||c===o){var y=this.clone().set(f,1);y.$d[$](l),y.init(),this.$d=y.set(f,Math.min(this.$D,y.daysInMonth())).$d}else $&&this.$d[$](l);return this.init(),this},$.set=function(t,e){return this.clone().$set(t,e)},$.get=function(t){return this[g.p(t)]()},$.add=function(t,a){var f,h=this;t=Number(t);var c=g.p(a),d=function(e){var n=v(h);return g.w(n.date(n.date()+Math.round(e*t)),h)};if(c===u)return this.set(u,this.$M+t);if(c===o)return this.set(o,this.$y+t);if(c===i)return d(1);if(c===s)return d(7);var $=(f={},f[n]=6e4,f[r]=36e5,f[e]=1e3,f)[c]||1,l=this.$d.getTime()+t*$;return g.w(l,this)},$.subtract=function(t,e){return this.add(-1*t,e)},$.format=function(t){var e=this;if(!this.isValid())return"Invalid Date";var n=t||"YYYY-MM-DDTHH:mm:ssZ",r=g.z(this),i=this.$locale(),s=this.$H,u=this.$m,a=this.$M,o=i.weekdays,f=i.months,h=function(t,r,i,s){return t&&(t[r]||t(e,n))||i[r].substr(0,s)},d=function(t){return g.s(s%12||12,t,"0")},$=i.meridiem||function(t,e,n){var r=t<12?"AM":"PM";return n?r.toLowerCase():r},l={YY:String(this.$y).slice(-2),YYYY:this.$y,M:a+1,MM:g.s(a+1,2,"0"),MMM:h(i.monthsShort,a,f,3),MMMM:h(f,a),D:this.$D,DD:g.s(this.$D,2,"0"),d:String(this.$W),dd:h(i.weekdaysMin,this.$W,o,2),ddd:h(i.weekdaysShort,this.$W,o,3),dddd:o[this.$W],H:String(s),HH:g.s(s,2,"0"),h:d(1),hh:d(2),a:$(s,u,!0),A:$(s,u,!1),m:String(u),mm:g.s(u,2,"0"),s:String(this.$s),ss:g.s(this.$s,2,"0"),SSS:g.s(this.$ms,3,"0"),Z:r};return n.replace(c,function(t,e){return e||l[t]||r.replace(":","")})},$.utcOffset=function(){return 15*-Math.round(this.$d.getTimezoneOffset()/15)},$.diff=function(t,f,h){var c,d=g.p(f),$=v(t),l=6e4*($.utcOffset()-this.utcOffset()),y=this-$,M=g.m(this,$);return M=(c={},c[o]=M/12,c[u]=M,c[a]=M/3,c[s]=(y-l)/6048e5,c[i]=(y-l)/864e5,c[r]=y/36e5,c[n]=y/6e4,c[e]=y/1e3,c)[d]||y,h?M:g.a(M)},$.daysInMonth=function(){return this.endOf(u).$D},$.$locale=function(){return M[this.$L]},$.locale=function(t,e){if(!t)return this.$L;var n=this.clone(),r=D(t,e,!0);return r&&(n.$L=r),n},$.clone=function(){return g.w(this.$d,this)},$.toDate=function(){return new Date(this.valueOf())},$.toJSON=function(){return this.isValid()?this.toISOString():null},$.toISOString=function(){return this.$d.toISOString()},$.toString=function(){return this.$d.toUTCString()},d}(),p=S.prototype;return v.prototype=p,[["$ms",t],["$s",e],["$m",n],["$H",r],["$W",i],["$M",u],["$y",o],["$D",f]].forEach(function(t){p[t[1]]=function(e){return this.$g(e,t[0],t[1])}}),v.extend=function(t,e){return t.$i||(t(e,S,v),t.$i=!0),v},v.locale=D,v.isDayjs=m,v.unix=function(t){return v(1e3*t)},v.en=M[y],v.Ls=M,v.p={},v});


/***/ }),

/***/ "./node_modules/dayjs/plugin/relativeTime.js":
/*!***************************************************!*\
  !*** ./node_modules/dayjs/plugin/relativeTime.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

!function(r,t){ true?module.exports=t():undefined}(this,function(){"use strict";return function(r,t,e){r=r||{};var n=t.prototype,o={future:"in %s",past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"};function i(r,t,e,o){return n.fromToBase(r,t,e,o)}e.en.relativeTime=o,n.fromToBase=function(t,n,i,d,u){for(var a,f,s,l=i.$locale().relativeTime||o,h=r.thresholds||[{l:"s",r:44,d:"second"},{l:"m",r:89},{l:"mm",r:44,d:"minute"},{l:"h",r:89},{l:"hh",r:21,d:"hour"},{l:"d",r:35},{l:"dd",r:25,d:"day"},{l:"M",r:45},{l:"MM",r:10,d:"month"},{l:"y",r:17},{l:"yy",d:"year"}],m=h.length,c=0;c<m;c+=1){var y=h[c];y.d&&(a=d?e(t).diff(i,y.d,!0):i.diff(t,y.d,!0));var p=(r.rounding||Math.round)(Math.abs(a));if(s=a>0,p<=y.r||!y.r){p<=1&&c>0&&(y=h[c-1]);var v=l[y.l];u&&(p=u(""+p)),f="string"==typeof v?v.replace("%d",p):v(p,n,y.l,s);break}}if(n)return f;var M=s?l.future:l.past;return"function"==typeof M?M(f):M.replace("%s",f)},n.to=function(r,t){return i(r,t,this,!0)},n.from=function(r,t){return i(r,t,this)};var d=function(r){return r.$u?e.utc():e()};n.toNow=function(r){return this.to(d(this),r)},n.fromNow=function(r){return this.from(d(this),r)}}});


/***/ }),

/***/ "./src/client/components/ActionButton.tsx":
/*!************************************************!*\
  !*** ./src/client/components/ActionButton.tsx ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var _PlainButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PlainButton */ "./src/client/components/PlainButton.tsx");
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");




const ActionButton = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(_PlainButton__WEBPACK_IMPORTED_MODULE_1__["default"], {
  target: "e469vky0"
})(({
  waiting,
  disabled
}) => {
  //const {waiting, disabled} = props
  //const isDisabled = disabled || waiting
  return {
    height: 28,
    lineHeight: '22px',
    color: '#fff',
    backgroundColor: styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].PRIMARY_MAIN,
    fontWeight: 500,
    fontSize: 14,
    outline: 0,
    boxShadow: 'rgba(15, 15, 15, 0.1) 0px 0px 0px 1px inset, rgba(15, 15, 15, 0.1) 0px 1px 2px',
    margin: 0,
    borderRadius: 4,
    border: `1px solid transparent`,
    transition: 'all 0.25s ease-in-out',
    padding: '0 10px',
    ':hover': {
      backgroundColor: styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].PRIMARY_MAIN_DARK,
      border: `1px solid ${styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].PRIMARY_MAIN_DARK}`
    },
    ':focus, :active': {
      boxShadow: `0 0 0 3px ${styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].BOX_SHADOW_PRIMARY}`,
      backgroundColor: styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].PRIMARY_MAIN_DARK,
      border: `1px solid ${styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].PRIMARY_MAIN_DARK}`
    }
  };
});

/* harmony default export */ __webpack_exports__["default"] = (ActionButton);

/***/ }),

/***/ "./src/client/components/EmptyPage.tsx":
/*!*********************************************!*\
  !*** ./src/client/components/EmptyPage.tsx ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styles_typography__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styles/typography */ "./src/client/styles/typography.ts");
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/EmptyPage.tsx";




const Wrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1mrkvlm0"
})({
  backgroundColor: '#fff',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  height: '100%',
  width: '100%',
  fontFamily: styles_typography__WEBPACK_IMPORTED_MODULE_2__["FONT_FAMILY"].SANS_SERIF
});

const Title = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1mrkvlm1"
})({
  color: styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_MAIN,
  fontSize: 24,
  fontWeight: 500,
  margin: '20px 0 15px'
});

const SubTitle = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1mrkvlm2"
})({
  color: styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_MAIN,
  fontSize: 16,
  fontWeight: 400,
  margin: '0px 0 20px',
  '> div > a': {
    color: styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].PRIMARY_MAIN
  }
});

const EmptyPage = ({
  svg,
  header,
  subHeader,
  button
}) => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Wrapper, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    }
  }, svg, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Title, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }, header), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(SubTitle, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    }
  }, subHeader), button);
};

/* harmony default export */ __webpack_exports__["default"] = (EmptyPage);

/***/ }),

/***/ "./src/client/components/FlatButton.tsx":
/*!**********************************************!*\
  !*** ./src/client/components/FlatButton.tsx ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var _PlainButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PlainButton */ "./src/client/components/PlainButton.tsx");
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");




const FlatButton = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(_PlainButton__WEBPACK_IMPORTED_MODULE_1__["default"], {
  target: "ef4saif0"
})(props => {
  const {
    waiting,
    disabled
  } = props;
  const isDisabled = disabled || waiting;
  return {
    backgroundColor: styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].PRIMARY_MAIN,
    color: '#fff',
    borderRadius: 4,
    boxShadow: 'rgba(15, 15, 15, 0.1) 0px 0px 0px 1px inset, rgba(15, 15, 15, 0.1) 0px 1px 2px',
    outline: 0,
    ':hover': {
      backgroundColor: !isDisabled && styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].PRIMARY_MAIN_DARK
    },
    ':active, :focus': {
      boxShadow: `0 0 0 3px ${styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].BOX_SHADOW_PRIMARY}`,
      backgroundColor: !isDisabled && styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].PRIMARY_MAIN_LIGHTER
    }
  };
});

/* harmony default export */ __webpack_exports__["default"] = (FlatButton);

/***/ }),

/***/ "./src/client/components/QueueActionsMenu.tsx":
/*!****************************************************!*\
  !*** ./src/client/components/QueueActionsMenu.tsx ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _Menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Menu */ "./src/client/components/Menu.tsx");
/* harmony import */ var _MenuItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./MenuItem */ "./src/client/components/MenuItem.tsx");
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
/* harmony import */ var universal_components_Icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/components/Icon */ "./src/universal/components/Icon.tsx");
/* harmony import */ var hooks_useRouter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! hooks/useRouter */ "./src/client/hooks/useRouter.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/QueueActionsMenu.tsx";








const MenuContainer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "exa4tei0"
})({
  name: "1domaf0",
  styles: "width:200px;"
});

const StyledIcon = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_Icon__WEBPACK_IMPORTED_MODULE_6__["default"], {
  target: "exa4tei1"
})({
  display: 'block',
  color: styles_palette__WEBPACK_IMPORTED_MODULE_5__["PALETTE"].TEXT_GRAY,
  marginRight: 15,
  fontSize: 18
});

const Label = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "exa4tei2"
})({
  display: 'flex',
  flexDirection: 'row',
  fontSize: 15,
  fontWeight: 400,
  padding: '5px 15px',
  color: styles_palette__WEBPACK_IMPORTED_MODULE_5__["PALETTE"].TEXT_MAIN
});

const QueueActionsMenu = props => {
  const {
    menuProps,
    queueId,
    onDelete,
    onFlush,
    selectedQueue
  } = props;
  const {
    history
  } = Object(hooks_useRouter__WEBPACK_IMPORTED_MODULE_7__["default"])();
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(MenuContainer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Menu__WEBPACK_IMPORTED_MODULE_3__["default"], _objectSpread(_objectSpread({
    ariaLabel: 'Add queue tasks'
  }, menuProps), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_MenuItem__WEBPACK_IMPORTED_MODULE_4__["default"], {
    label: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 48
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 49
      }
    }, "edit"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('span', {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 50
      }
    }, "Edit queue")),
    onClick: () => history.push({
      pathname: `/queues/${queueId}/edit`,
      state: {
        prevRoute: history.location.pathname
      }
    }),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_MenuItem__WEBPACK_IMPORTED_MODULE_4__["default"], {
    label: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 62
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 63
      }
    }, "content_copy"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('span', {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 64
      }
    }, "Clone queue")),
    onClick: () => history.push({
      pathname: '/queues/new',
      state: {
        hasClone: true,
        clonedQueue: {
          data: selectedQueue.data,
          name: `${selectedQueue.name} Copy`,
          id: selectedQueue.id
        }
      }
    }),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_MenuItem__WEBPACK_IMPORTED_MODULE_4__["default"], {
    label: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 83
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 84
      }
    }, "undo"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('span', {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 85
      }
    }, "Delete all tasks")),
    onClick: onFlush,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 81
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_MenuItem__WEBPACK_IMPORTED_MODULE_4__["default"], {
    label: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 92
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 93
      }
    }, "delete"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('span', {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 94
      }
    }, "Delete queue")),
    onClick: onDelete,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 90
    }
  })));
};

const mapStateToProps = state => ({
  selectedQueue: state.queues.selectedQueue
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps, null)(QueueActionsMenu));

/***/ }),

/***/ "./src/client/components/QueueFilterColumnMenu.tsx":
/*!*********************************************************!*\
  !*** ./src/client/components/QueueFilterColumnMenu.tsx ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _Menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Menu */ "./src/client/components/Menu.tsx");
/* harmony import */ var _MenuItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./MenuItem */ "./src/client/components/MenuItem.tsx");
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
/* harmony import */ var universal_components_Icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/components/Icon */ "./src/universal/components/Icon.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/QueueFilterColumnMenu.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}









const MenuContainer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1fl7lhr0"
})({
  name: "1domaf0",
  styles: "width:200px;"
});

const StyledIcon = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_Icon__WEBPACK_IMPORTED_MODULE_6__["default"], {
  target: "e1fl7lhr1"
})({
  display: 'block',
  color: styles_palette__WEBPACK_IMPORTED_MODULE_5__["PALETTE"].TEXT_GRAY,
  marginRight: 15,
  fontSize: 18
});

const Label = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1fl7lhr2"
})({
  display: 'flex',
  flexDirection: 'row',
  fontSize: 15,
  fontWeight: 400,
  padding: '5px 5px',
  color: styles_palette__WEBPACK_IMPORTED_MODULE_5__["PALETTE"].TEXT_MAIN
});

const LabelText = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "e1fl7lhr3"
})({
  name: "1h2ruwl",
  styles: "white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"
});

const QueueFilterColumnMenu = props => {
  const {
    menuProps,
    queue,
    setPinnedBlock,
    activeBlockName
  } = props;

  if (!queue || !Array.isArray(queue.data)) {
    return null;
  }

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(MenuContainer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Menu__WEBPACK_IMPORTED_MODULE_3__["default"], _objectSpread(_objectSpread({
    ariaLabel: 'Filter queue tasks'
  }, menuProps), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    }
  }), queue.data.map((block, id) => {
    if (!universal_utils_constants__WEBPACK_IMPORTED_MODULE_7__["FILTER_BLOCK_TYPES"].includes(block.type)) {
      return null;
    } else return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_MenuItem__WEBPACK_IMPORTED_MODULE_4__["default"], {
      key: id,
      isActive: activeBlockName === block.name,
      label: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 64
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 65
        }
      }, _optionalChain([universal_utils_constants__WEBPACK_IMPORTED_MODULE_7__["BLOCKS"], 'access', _ => _.find, 'call', _2 => _2(b => b.type === block.type), 'optionalAccess', _3 => _3.icon])), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LabelText, {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 66
        }
      }, block.name)),
      onClick: () => {
        setPinnedBlock(block.id);
      },
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 60
      }
    });
  }), activeBlockName != '' && activeBlockName != null && activeBlockName != 'ID' && typeof activeBlockName !== 'undefined' && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_MenuItem__WEBPACK_IMPORTED_MODULE_4__["default"], {
    extraSpace: true,
    label: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 82
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 83
      }
    }, "refresh"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('span', {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 84
      }
    }, "Reset to ID")),
    onClick: () => {
      setPinnedBlock(null);
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 79
    }
  })));
};

const mapStateToProps = state => ({
  selectedQueue: state.queues.selectedQueue
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps, null)(QueueFilterColumnMenu));

/***/ }),

/***/ "./src/client/hooks/useDocumentTitle.ts":
/*!**********************************************!*\
  !*** ./src/client/hooks/useDocumentTitle.ts ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


const useDocumentTitle = title => {
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    document.title = title;
  }, [title]);
};

/* harmony default export */ __webpack_exports__["default"] = (useDocumentTitle);

/***/ }),

/***/ "./src/client/utils/capitalizeFirstLetter.ts":
/*!***************************************************!*\
  !*** ./src/client/utils/capitalizeFirstLetter.ts ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const capitalizeFirstLetter = str => str.charAt(0).toUpperCase() + str.slice(1);

/* harmony default export */ __webpack_exports__["default"] = (capitalizeFirstLetter);

/***/ }),

/***/ "./src/universal/components/Avatar.tsx":
/*!*********************************************!*\
  !*** ./src/universal/components/Avatar.tsx ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _client_styles_palette__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../client/styles/palette */ "./src/client/styles/palette.ts");
/* harmony import */ var universal_utils_getFirstLetter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/utils/getFirstLetter */ "./src/universal/utils/getFirstLetter.ts");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/Avatar.tsx";



const Avatar = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["forwardRef"])((props, ref) => {
  const {
    initials,
    color,
    onClick,
    style,
    trim = true
  } = props;
  const backgroundColor = color || _client_styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].PRIMARY_MAIN;

  const AvatarBlock = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
    target: "ebmair80"
  })({
    display: 'inline-flex',
    justifyContent: 'center',
    alignItems: 'center',
    testAlign: 'center',
    height: `20px`,
    width: `20px`,
    minWidth: `20px`,
    fontWeight: 700,
    fontSize: 11,
    color: '#fff',
    borderRadius: '100%',
    backgroundColor: backgroundColor,
    userSelect: 'none',
    margin: '0px 2px'
  });

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(AvatarBlock, {
    ref: ref,
    onClick: onClick,
    style: style,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    }
  }, trim ? Object(universal_utils_getFirstLetter__WEBPACK_IMPORTED_MODULE_3__["default"])(initials) : initials);
});
/* harmony default export */ __webpack_exports__["default"] = (Avatar);

/***/ }),

/***/ "./src/universal/components/NewTaskMenu.tsx":
/*!**************************************************!*\
  !*** ./src/universal/components/NewTaskMenu.tsx ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var client_utils_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! client/utils/constants */ "./src/client/utils/constants.ts");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/components/SecondaryButton */ "./src/universal/components/SecondaryButton.tsx");
/* harmony import */ var _client_components_FlatButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../client/components/FlatButton */ "./src/client/components/FlatButton.tsx");
/* harmony import */ var universal_components_BasicTextArea__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! universal/components/BasicTextArea */ "./src/universal/components/BasicTextArea.tsx");
/* harmony import */ var universal_components_InputField__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/components/InputField */ "./src/universal/components/InputField.tsx");
/* harmony import */ var client_utils_capitalizeFirstLetter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! client/utils/capitalizeFirstLetter */ "./src/client/utils/capitalizeFirstLetter.ts");
/* harmony import */ var universal_utils_cutOffString__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! universal/utils/cutOffString */ "./src/universal/utils/cutOffString.ts");
/* harmony import */ var universal_components_TaskRadio__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! universal/components/TaskRadio */ "./src/universal/components/TaskRadio.tsx");
/* harmony import */ var universal_components_TaskCheckbox__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! universal/components/TaskCheckbox */ "./src/universal/components/TaskCheckbox.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var universal_validations_yupSchema__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! universal/validations/yupSchema */ "./src/universal/validations/yupSchema.ts");
/* harmony import */ var universal_components_TextEditor__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! universal/components/TextEditor */ "./src/universal/components/TextEditor.tsx");
/* harmony import */ var universal_components_DatePicker__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! universal/components/DatePicker */ "./src/universal/components/DatePicker.tsx");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/NewTaskMenu.tsx";

















const ModalRoot = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ehbk6cg0"
})({
  display: 'flex',
  flexDirection: 'column',
  width: 500,
  borderRadius: 10,
  backgroundColor: '#fff',
  border: `1px solid ${universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].BORDER_MAIN_GRAY}`,
  boxShadow: client_utils_constants__WEBPACK_IMPORTED_MODULE_3__["BoxShadow"].MODAL
});

const MainTitle = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ehbk6cg1"
})({
  name: "1xxpbhg",
  styles: "font-size:22px;font-weight:600;display:flex;align-items:center;margin-bottom:35px;"
});

const FormContent = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(formik__WEBPACK_IMPORTED_MODULE_4__["Form"], {
  target: "ehbk6cg2"
})({
  name: "1yphs5z",
  styles: "padding:35px;"
});

const SubmissionSection = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ehbk6cg3"
})({
  name: "1htoikp",
  styles: "display:grid;grid-template-columns:repeat(2, auto);justify-content:space-between;padding-top:25px;"
});

const Input = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ehbk6cg4"
})({
  name: "1yqpl9u",
  styles: "display:grid;grid-gap:5px;align-items:center;margin-bottom:24px;"
});

const Label = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ehbk6cg5"
})({
  name: "r63kdz",
  styles: "font-weight:400;margin-right:20px;font-size:16px;width:100%;text-transform:capitalize;"
});

const Box = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ehbk6cg6"
})({
  name: "1r2f04i",
  styles: "margin-bottom:10px;"
});

const Options = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ehbk6cg7"
})({
  name: "32wkxh",
  styles: "max-height:62vh;overflow:auto;padding:8px 0px;"
});

const Question = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ehbk6cg8"
})({
  name: "1m2twwy",
  styles: "font-weight:500;font-size:16px;"
});

const NewTaskMenu = props => {
  const {
    closePortal,
    format,
    onSubmitHandler
  } = props;
  const initialValues = {
    data: {},
    required: {}
  };
  format.map(item => {
    if (initialValues.data[item.type]) {
      initialValues.data[item.type][item.id] = '';
    } else {
      initialValues.data[item.type] = {
        [item.id]: ''
      };
    }

    if (item.type === universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["BLOCK_TYPE"].BOUNDING_BOXES) {
      initialValues.data[item.type] = {
        [item.id]: {
          image: ''
        }
      };
    }

    if (item[item.type].is_required) {
      if (initialValues.required[item.type]) {
        initialValues.required[item.type][item.id] = true;
      } else {
        initialValues.required[item.type] = {
          [item.id]: true
        };
      }
    }
  });
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ModalRoot, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 115
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(formik__WEBPACK_IMPORTED_MODULE_4__["Formik"], {
    validationSchema: universal_validations_yupSchema__WEBPACK_IMPORTED_MODULE_14__["taskMenuSchema"],
    validateOnChange: true,
    validateOnBlur: true,
    validateOnMount: true,
    initialValues: initialValues,
    enableReinitialize: true,
    onSubmit: onSubmitHandler,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 116
    }
  }, ({
    touched,
    isSubmitting,
    isValid,
    handleChange,
    handleBlur,
    values,
    errors,
    setFieldValue
  }) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FormContent, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 135
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(MainTitle, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 136
    }
  }, "New Task"), format.map(input => {
    // this single and multiple selection code will currently never be invoked as the back end will not return these types
    return input.type === universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["BLOCK_TYPE"].SINGLE_SELECTION ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('div', {
      key: input.name,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 140
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Question, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 141
      }
    }, Object(universal_utils_cutOffString__WEBPACK_IMPORTED_MODULE_10__["default"])(Object(client_utils_capitalizeFirstLetter__WEBPACK_IMPORTED_MODULE_9__["default"])(input.name), 18)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Options, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 142
      }
    }, input[input.type].options.map((option, optionIndex) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Box, {
      key: optionIndex,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 144
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TaskRadio__WEBPACK_IMPORTED_MODULE_11__["default"], {
      name: input.id,
      id: optionIndex,
      value: option.id,
      label: option.name,
      onChange: handleChange,
      checked: option.id === values[input.id],
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 145
      }
    }))))) : input.type === universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["BLOCK_TYPE"].MULTIPLE_SELECTION ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('div', {
      key: input.name,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 158
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Question, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 159
      }
    }, Object(universal_utils_cutOffString__WEBPACK_IMPORTED_MODULE_10__["default"])(Object(client_utils_capitalizeFirstLetter__WEBPACK_IMPORTED_MODULE_9__["default"])(input.name), 18)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Options, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 160
      }
    }, input[input.type].options.map((option, optionIndex) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Box, {
      key: optionIndex,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 162
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TaskCheckbox__WEBPACK_IMPORTED_MODULE_12__["default"], {
      name: input.id,
      id: option.id,
      value: option.id,
      label: option.name,
      onChange: handleChange,
      checked: values[input.id] && values[input.id].includes(option.id),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 163
      }
    }))))) : input.type === universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Input, {
      key: input.name,
      type: input.type,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 176
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 177
      }
    }, input.name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BasicTextArea__WEBPACK_IMPORTED_MODULE_7__["default"], {
      value: values && values.data && values.data[input.type] ? values.data[input.type][input.id] : null,
      placeholder: input[input.type].placeholder ? input[input.type].placeholder : universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["SAMPLE_VALUES"][input.type],
      name: `data[${input.type}][${input.id}]`,
      error: touched && touched.data && touched.data[input.type] && touched.data[input.type][input.id] && errors && errors.data && errors.data[input.type] && errors.data[input.type][input.id],
      hideErrorMessage: true,
      onChange: handleChange,
      onBlur: handleBlur,
      maxRows: 3,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 178
      }
    })) : input.type === universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["BLOCK_TYPE"].BOUNDING_BOXES ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Input, {
      key: input.name,
      type: input.type,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 207
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 208
      }
    }, input.name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_InputField__WEBPACK_IMPORTED_MODULE_8__["default"], {
      value: values && values.data && values.data[input.type] && values.data[input.type][input.id] ? values.data[input.type][input.id]['image'] : 'bbb',
      placeholder: input[input.type].placeholder ? input[input.type].placeholder : universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["SAMPLE_VALUES"][input.type],
      type: input.type,
      format: values.data[input.type].format,
      name: `data[${input.type}][${input.id}][image]`,
      error: errors && errors.data && errors.data[input.type] ? errors.data[input.type][input.id] : '',
      hideErrorMessage: true,
      onChange: handleChange,
      onBlur: handleBlur,
      containerStyles: {
        width: '100%'
      },
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 209
      }
    })) : input.type === universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["BLOCK_TYPE"].RICH_TEXT ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Input, {
      key: input.name,
      type: input.type,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 238
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 239
      }
    }, input.name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TextEditor__WEBPACK_IMPORTED_MODULE_15__["default"], {
      isTaskMenu: true,
      value: values && values.data && values.data[input.type] ? values.data[input.type][input.id] : '',
      placeholder: input[input.type].placeholder ? input[input.type].placeholder : universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["SAMPLE_VALUES"][input.type],
      name: `data[${input.type}][${input.id}]`,
      format: input[input.type].format,
      error: errors && errors.data && errors.data[input.type] ? errors.data[input.type][input.id] : '',
      setFieldValue: setFieldValue,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 240
      }
    })) : input.type === universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["BLOCK_TYPE"].DATE ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Input, {
      key: input.name,
      type: input.type,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 263
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 264
      }
    }, input.name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_DatePicker__WEBPACK_IMPORTED_MODULE_16__["default"], {
      isTaskMenu: true,
      value: values && values.data && values.data[input.type] ? values.data[input.type][input.id] : '',
      placeholder: input[input.type].placeholder ? input[input.type].placeholder : universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["SAMPLE_VALUES"][input.type],
      name: `data[${input.type}][${input.id}]`,
      error: errors && errors.data && errors.data[input.type] ? errors.data[input.type][input.id] : '',
      setFieldValue: setFieldValue,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 265
      }
    })) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Input, {
      key: input.name,
      type: input.type,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 287
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 288
      }
    }, input.name), input.type !== universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["BLOCK_TYPE"].TEXT ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_InputField__WEBPACK_IMPORTED_MODULE_8__["default"], {
      value: values && values.data && values.data[input.type] ? values.data[input.type][input.id] : '',
      placeholder: input[input.type].placeholder ? input[input.type].placeholder : universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["SAMPLE_VALUES"][input.type],
      type: input.type === 'number' ? 'number' : 'text',
      format: values.data[input.type].format,
      name: `data[${input.type}][${input.id}]`,
      error: errors && errors.data && errors.data[input.type] ? errors.data[input.type][input.id] : '',
      hideErrorMessage: true,
      onChange: handleChange,
      onBlur: handleBlur,
      containerStyles: {
        width: '100%'
      },
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 290
      }
    }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BasicTextArea__WEBPACK_IMPORTED_MODULE_7__["default"], {
      value: values[input.id] || '',
      placeholder: input[input.type].placeholder ? input[input.type].placeholder : universal_utils_constants__WEBPACK_IMPORTED_MODULE_13__["SAMPLE_VALUES"][input.type],
      name: input.id,
      onChange: handleChange,
      onBlur: handleBlur,
      maxRows: 3,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 315
      }
    }));
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(SubmissionSection, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 331
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_5__["default"], {
    type: "button",
    onClick: closePortal,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 332
    }
  }, "Cancel"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_client_components_FlatButton__WEBPACK_IMPORTED_MODULE_6__["default"], {
    type: "submit",
    disabled: !isValid || isSubmitting,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 335
    }
  }, "Create")))));
};

/* harmony default export */ __webpack_exports__["default"] = (NewTaskMenu);

/***/ }),

/***/ "./src/universal/components/StatusTag.tsx":
/*!************************************************!*\
  !*** ./src/universal/components/StatusTag.tsx ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var universal_utils_getQueueStatus__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! universal/utils/getQueueStatus */ "./src/universal/utils/getQueueStatus.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/StatusTag.tsx";





const StatusTag = ({
  status,
  centered
}) => {
  let backgroundColor;

  switch (status) {
    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_3__["QUEUE_STATUS"].OPEN:
      backgroundColor = universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__["STATUS_PALETTE"].OPEN;
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_3__["QUEUE_STATUS"].IN_PROGRESS:
      backgroundColor = universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__["STATUS_PALETTE"].IN_PROGRESS;
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_3__["QUEUE_STATUS"].NEW:
      backgroundColor = universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__["STATUS_PALETTE"].NEW;
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_3__["QUEUE_STATUS"].COMPLETED:
      backgroundColor = universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__["STATUS_PALETTE"].COMPLETED;
      break;

    default:
      backgroundColor = universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__["STATUS_PALETTE"].IN_PROGRESS;
  }

  const Tag = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
    target: "e1ciaeyc0"
  })(_objectSpread({
    padding: '5px 15px',
    borderRadius: 5,
    display: 'inline-block',
    fontSize: 11,
    fontWeight: 600,
    textTransform: 'uppercase',
    color: '#fff',
    userSelect: 'none',
    backgroundColor
  }, centered && {
    margin: '0px auto'
  }));

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Tag, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }, Object(universal_utils_getQueueStatus__WEBPACK_IMPORTED_MODULE_4__["default"])(status));
};

/* harmony default export */ __webpack_exports__["default"] = (StatusTag);

/***/ }),

/***/ "./src/universal/modules/queue/components/Queue.tsx":
/*!**********************************************************!*\
  !*** ./src/universal/modules/queue/components/Queue.tsx ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var client_components_ActionButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! client/components/ActionButton */ "./src/client/components/ActionButton.tsx");
/* harmony import */ var client_styles_palette__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! client/styles/palette */ "./src/client/styles/palette.ts");
/* harmony import */ var client_hooks_useRouter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! client/hooks/useRouter */ "./src/client/hooks/useRouter.ts");
/* harmony import */ var universal_components_Avatar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/components/Avatar */ "./src/universal/components/Avatar.tsx");
/* harmony import */ var universal_utils_cutOffString__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/utils/cutOffString */ "./src/universal/utils/cutOffString.ts");
/* harmony import */ var client_utils_capitalizeFirstLetter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! client/utils/capitalizeFirstLetter */ "./src/client/utils/capitalizeFirstLetter.ts");
/* harmony import */ var universal_components_Icon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/components/Icon */ "./src/universal/components/Icon.tsx");
/* harmony import */ var client_hooks_useCoords__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! client/hooks/useCoords */ "./src/client/hooks/useCoords.ts");
/* harmony import */ var client_hooks_useMenu__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! client/hooks/useMenu */ "./src/client/hooks/useMenu.ts");
/* harmony import */ var client_components_QueueActionsMenu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! client/components/QueueActionsMenu */ "./src/client/components/QueueActionsMenu.tsx");
/* harmony import */ var client_components_QueueFilterColumnMenu__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! client/components/QueueFilterColumnMenu */ "./src/client/components/QueueFilterColumnMenu.tsx");
/* harmony import */ var client_components_EmptyPage__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! client/components/EmptyPage */ "./src/client/components/EmptyPage.tsx");
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! dayjs */ "./node_modules/dayjs/dayjs.min.js");
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var client_hooks_useModal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! client/hooks/useModal */ "./src/client/hooks/useModal.ts");
/* harmony import */ var client_components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! client/components/ConfirmationModal */ "./src/client/components/ConfirmationModal.tsx");
/* harmony import */ var universal_components_NewTaskMenu__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! universal/components/NewTaskMenu */ "./src/universal/components/NewTaskMenu.tsx");
/* harmony import */ var dayjs_plugin_relativeTime__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! dayjs/plugin/relativeTime */ "./node_modules/dayjs/plugin/relativeTime.js");
/* harmony import */ var dayjs_plugin_relativeTime__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(dayjs_plugin_relativeTime__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var client_hooks_useNetworker__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! client/hooks/useNetworker */ "./src/client/hooks/useNetworker.ts");
/* harmony import */ var universal_utils_getColor__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! universal/utils/getColor */ "./src/universal/utils/getColor.ts");
/* harmony import */ var universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! universal/components/SecondaryButton */ "./src/universal/components/SecondaryButton.tsx");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var universal_utils_formatValues__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! universal/utils/formatValues */ "./src/universal/utils/formatValues.ts");
/* harmony import */ var client_utils_dateHelpers__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! client/utils/dateHelpers */ "./src/client/utils/dateHelpers.ts");
/* harmony import */ var _QueueSettingsModal__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./QueueSettingsModal */ "./src/universal/modules/queue/components/QueueSettingsModal.tsx");
/* harmony import */ var client_redux_queuesReducers__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! client/redux/queuesReducers */ "./src/client/redux/queuesReducers.ts");
/* harmony import */ var client_modules_notificationSystem_ducks_notificationSystemDuck__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! client/modules/notificationSystem/ducks/notificationSystemDuck */ "./src/client/modules/notificationSystem/ducks/notificationSystemDuck.tsx");
/* harmony import */ var universal_components_StatusTag__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! universal/components/StatusTag */ "./src/universal/components/StatusTag.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/modules/queue/components/Queue.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}






























dayjs__WEBPACK_IMPORTED_MODULE_14___default.a.extend(dayjs_plugin_relativeTime__WEBPACK_IMPORTED_MODULE_18___default.a);

const Page = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg60"
})({
  name: "1rlocen",
  styles: "background:#fff;min-width:800px;padding:0 10% 0 10%;height:100%;"
});

const Header = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg61"
})({
  name: "1ainrib",
  styles: "display:flex;justify-content:space-between;padding:96px 0 70px 0;font-weight:600;font-size:24px;line-height:30px;"
});

const Buttons = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg62"
})({
  name: "gg4vpm",
  styles: "display:flex;justify-content:space-between;"
});

const PlayButton = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(client_components_ActionButton__WEBPACK_IMPORTED_MODULE_2__["default"], {
  target: "em4uhg63"
})({
  name: "15woith",
  styles: "width:100px;height:32px;font-size:14px;"
});

const TableHeader = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg64"
})({
  name: "erbukt",
  styles: "border:1px solid #E8ECEE;height:42px;border-radius:10px;display:flex;box-shadow:0px 20px 40px rgba(0, 0, 0, 0.02);margin-bottom:24px;padding:0px 15px;"
});

const TableItem = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg65"
})({
  name: "1h1cj0z",
  styles: "display:flex;flex-direction:column;justify-content:center;width:20%;"
});

const TableHeaderItem = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(TableItem, {
  target: "em4uhg66"
})({
  fontWeight: 600,
  fontSize: '14px',
  borderLeft: `1px solid ${client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].BORDER_GRAY}`,
  paddingLeft: 10
});

const IDHeaderItem = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(TableHeaderItem, {
  target: "em4uhg67"
})({
  name: "1ts6wgu",
  styles: "border-left:none;position:relative;"
});

const HeaderItemText = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg68"
})({
  name: "tjo5vg",
  styles: "padding-right:35px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"
});

const TasksContainer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg69"
})({
  border: `1px solid ${client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].BORDER_GRAY}`,
  height: 'calc(100% - 240px - 80px)',
  maxHeight: 470,
  display: 'flex',
  flexDirection: 'column',
  borderRadius: '10px'
});

const NavContainer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg610"
})({
  name: "ogrv91",
  styles: "display:flex;justify-content:center;padding:12px 0px;height:48px;background-color:#f8f8fa;border-top:1px solid #e8ecee;user-select:none;"
});

const Task = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg611"
})({
  height: 42,
  padding: '0 25px',
  borderBottom: `1px solid ${client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].BORDER_GRAY}`,
  display: 'flex',
  cursor: 'pointer',
  ':hover': {
    backgroundColor: '#f7f8f9'
  }
});

const GrayText = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg612"
})({
  fontSize: '14px',
  color: `${client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_GRAY}`,
  paddingLeft: 15,
  fontWeight: 500,
  display: 'flex',
  alignItems: 'center'
});

const ID = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "em4uhg613"
})({
  color: `${client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].PRIMARY_MAIN}`
});

const AssignedTo = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "em4uhg614"
})({
  name: "k008qs",
  styles: "display:flex;"
});

const Name = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "em4uhg615"
})({
  name: "1xt068c",
  styles: "margin-left:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"
});

const ColoredText = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "em4uhg616"
})({
  color: `${client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].PRIMARY_MAIN}`,
  fontSize: 16,
  textAlign: 'center',
  fontWeight: 600,
  marginTop: 1
});

const Tasks = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg617"
})({
  name: "ruyzf7",
  styles: "height:calc(100% - 48px);overflow-y:auto;"
});

const QueueTitle = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg618"
})({
  name: "k008qs",
  styles: "display:flex;"
});

const MenuButtonContainer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg619"
})({
  name: "1a3dugn",
  styles: "width:30px;height:30px;padding-top:2.5px;padding-left:5px;"
});

const FilterMenuButtonContainer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "em4uhg620"
})({
  name: "19hw8cp",
  styles: "width:30px;height:30px;position:absolute;right:10px;top:18px;"
});

const MenuButtonSecondary = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_21__["default"], {
  target: "em4uhg621"
})({
  name: "1ay9vb9",
  styles: "margin-right:16px;"
});

const StyledIcon = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_Icon__WEBPACK_IMPORTED_MODULE_8__["default"], {
  target: "em4uhg622"
})({
  name: "1xzpdvy",
  styles: "font-size:15px;align-items:center;margin:2px 0 0 5px;"
});

const StyledMenuIcon = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_Icon__WEBPACK_IMPORTED_MODULE_8__["default"], {
  target: "em4uhg623"
})({
  fontSize: 24,
  alignItems: 'center',
  margin: '-10px 0 0 5px',
  cursor: 'pointer',
  ':hover': {
    color: client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].PRIMARY_MAIN
  }
});

const Queue = props => {
  const {
    orgId,
    queue,
    startNextTask,
    queueId,
    deleteQueue,
    flushQueueTasks,
    format,
    tasks,
    taskPage,
    setTaskPage,
    user,
    isStaff,
    setQueue,
    setSelectedQueue,
    updateQueue
  } = props;
  const {
    is_running: isRunning,
    pinned_block: pinnedBlock
  } = queue;
  const [pinnedBlockId, setPinnedBlockId] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(pinnedBlock || '');
  const networker = Object(client_hooks_useNetworker__WEBPACK_IMPORTED_MODULE_19__["default"])();
  const {
    history
  } = Object(client_hooks_useRouter__WEBPACK_IMPORTED_MODULE_4__["default"])();
  const {
    menuPortal,
    originRef,
    menuProps,
    togglePortal
  } = Object(client_hooks_useMenu__WEBPACK_IMPORTED_MODULE_10__["default"])(client_hooks_useCoords__WEBPACK_IMPORTED_MODULE_9__["MenuPosition"].UPPER_LEFT, {
    isDropdown: true
  });
  const {
    modalPortal,
    togglePortal: newTaskTogglePortal,
    closePortal
  } = Object(client_hooks_useModal__WEBPACK_IMPORTED_MODULE_15__["default"])({
    overflow: 'auto'
  });
  const {
    modalPortal: queueSettingsPortal,
    togglePortal: toggleQueueSettingsModal,
    closePortal: closeQueueSettingsModal
  } = Object(client_hooks_useModal__WEBPACK_IMPORTED_MODULE_15__["default"])({});
  const {
    modalPortal: confirmModalPortal,
    togglePortal: confirmTogglePortal,
    closePortal: confirmClosePortal
  } = Object(client_hooks_useModal__WEBPACK_IMPORTED_MODULE_15__["default"])();
  const {
    modalPortal: confirmFlushModalPortal,
    togglePortal: confirmFlushTogglePortal,
    closePortal: confirmFlushClosePortal
  } = Object(client_hooks_useModal__WEBPACK_IMPORTED_MODULE_15__["default"])();
  const {
    menuPortal: filterMenuPortal,
    originRef: originFilterMenuRef,
    menuProps: filterMenuProps,
    togglePortal: toggleFilterMenuPortal
  } = Object(client_hooks_useMenu__WEBPACK_IMPORTED_MODULE_10__["default"])(client_hooks_useCoords__WEBPACK_IMPORTED_MODULE_9__["MenuPosition"].UPPER_RIGHT, {
    isDropdown: true
  });

  const onSubmitHandler = async values => {
    const returnData = [];
    format.forEach(({
      id,
      type,
      name
    }) => {
      let value = values[id];

      if (values.data && values.data[type] && values.data[type][id]) {
        value = values.data[type][id];
      }

      const returnObj = {
        id,
        type,
        name,
        [type]: {
          value
        }
      };
      returnData.push(returnObj);
    });
    const payload = {
      method: 'POST',
      data: {
        data: Object(universal_utils_formatValues__WEBPACK_IMPORTED_MODULE_23__["default"])(returnData).map(client_utils_dateHelpers__WEBPACK_IMPORTED_MODULE_24__["transformDates"])
      }
    };
    const res = await networker.httpHandler(`/orgs/${orgId}/queues/${queueId}/tasks/form`, payload);

    if (res.errors) {
      props.addFailureNotification('An error occurred');
    }

    res.errors && closePortal();
    const fetchTaskPayload = {
      method: 'GET'
    };
    const fetchTaskRes = await networker.httpHandler(`/orgs/${orgId}/queues/${queueId}/tasks/${res.data.id}`, fetchTaskPayload);
    const {
      data
    } = fetchTaskRes || {};
    const route = data.id ? `/queues/${queueId}/tasks/${data.id}` : `/queues/${queueId}/connections`;
    const taskState = data.id ? {
      hasChanged: false
    } : null;
    history.push({
      pathname: route,
      state: taskState
    });
    closePortal();
  };

  const runQueue = async values => {
    const updatedQueue = _objectSpread(_objectSpread({}, values), {}, {
      is_running: true
    });

    const payload = {
      method: 'PUT',
      data: updatedQueue
    };
    const res = await networker.httpHandler(`/orgs/${orgId}/queues/${queueId}`, payload);

    if (_optionalChain([res, 'optionalAccess', _ => _.errors])) {
      props.addFailureNotification('An error occurred');
    } else {
      setQueue(updatedQueue);
      setSelectedQueue(updatedQueue);
      updateQueue(updatedQueue);
      props.addSuccessNotification('This queue is now being executed by Human Lambdas');
    }

    closeQueueSettingsModal();
  };

  const finalPage = Math.floor((queue.n_tasks - 1) / 10) + 1 || 1;

  const BackNavIcon = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_Icon__WEBPACK_IMPORTED_MODULE_8__["default"], {
    target: "em4uhg624"
  })({
    color: taskPage === 1 ? client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_GRAY : client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].PRIMARY_MAIN,
    cursor: taskPage === 1 ? 'auto' : 'pointer',
    margin: '0px 12px'
  });

  const ForwardNavIcon = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_Icon__WEBPACK_IMPORTED_MODULE_8__["default"], {
    target: "em4uhg625"
  })({
    color: taskPage === finalPage ? `${client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_GRAY}` : `${client_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].PRIMARY_MAIN}`,
    cursor: taskPage === finalPage ? 'auto' : 'pointer',
    margin: '0px 12px'
  });

  const pauseQueue = async () => {
    const updatedQueue = _objectSpread(_objectSpread({}, queue), {}, {
      is_running: false
    });

    setQueue(updatedQueue);
    const payload = {
      method: 'PUT',
      data: updatedQueue
    };
    const res = await networker.httpHandler(`/orgs/${orgId}/queues/${queueId}`, payload);

    if (_optionalChain([res, 'optionalAccess', _2 => _2.errors])) {
      props.addFailureNotification('An error occurred');
    } else {
      props.addSuccessNotification('Queue execution has been successfully paused');
    }
  };

  const handleRunOrPause = Object(react__WEBPACK_IMPORTED_MODULE_1__["useCallback"])(() => {
    if (isRunning) {
      pauseQueue();
    } else {
      toggleQueueSettingsModal();
    }
  }, [queue]);
  let thereAreNonePinnedBlocks = true;

  if (queue.data && Array.isArray(queue.data)) {
    queue.data.map((block, id) => {
      if (universal_utils_constants__WEBPACK_IMPORTED_MODULE_29__["FILTER_BLOCK_TYPES"].includes(block.type)) {
        thereAreNonePinnedBlocks = false;
      }
    });
  }

  const setPinnedBlock = async id => {
    setPinnedBlockId(id);
    await networker.httpHandler(`/orgs/${orgId}/queues/${queueId}`, {
      method: 'PATCH',
      data: {
        pinned_block: id
      }
    });
  };

  const extractPinnedValue = (data, id) => {
    let pinnedValue = '#' + id;

    if (data && Array.isArray(data) && !thereAreNonePinnedBlocks && pinnedBlockId) {
      let theValueHasBeenAssigned = false;
      data.map(block => {
        if (block.id === pinnedBlockId) {
          pinnedValue = _optionalChain([block, 'access', _3 => _3[block.type], 'optionalAccess', _4 => _4.value]);
          theValueHasBeenAssigned = true;
        }

        if (!theValueHasBeenAssigned) {
          pinnedValue = "-";
        }
      });
    }

    return pinnedValue;
  };

  const extractPinnedTitle = queue => {
    let pinnedTitle = 'ID';

    if (queue.data && Array.isArray(queue.data) && pinnedBlockId) {
      queue.data.map(block => {
        if (block.id === pinnedBlockId) {
          pinnedTitle = block.name;
        }
      });
    }

    return pinnedTitle;
  };

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Page, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 450
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Header, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 451
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(QueueTitle, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 452
    }
  }, queue.name && Object(client_utils_capitalizeFirstLetter__WEBPACK_IMPORTED_MODULE_7__["default"])(Object(universal_utils_cutOffString__WEBPACK_IMPORTED_MODULE_6__["default"])(queue.name, 25)), _optionalChain([user, 'optionalAccess', _5 => _5.is_admin]) && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(MenuButtonContainer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 455
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledMenuIcon, {
    onClick: togglePortal,
    ref: originRef,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 456
    }
  }, "expand_more"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Buttons, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 462
    }
  }, _optionalChain([user, 'optionalAccess', _6 => _6.is_admin]) && !isStaff && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(MenuButtonSecondary, {
    onClick: () => {
      history.push(`/queues/${queueId}/connections`);
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 464
    }
  }, "Connections"), queue.data && queue.data.length > 0 && !isStaff && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(MenuButtonSecondary, {
    onClick: () => {
      format.length > 0 ? newTaskTogglePortal() : onSubmitHandler({});
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 473
    }
  }, "New Task"), (!_optionalChain([user, 'optionalAccess', _7 => _7.is_admin]) || isStaff) && queue.n_tasks > 0 ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(PlayButton, {
    onClick: startNextTask,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 482
    }
  }, "Play") : null, _optionalChain([user, 'optionalAccess', _8 => _8.is_admin]) && !isStaff && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(PlayButton, {
    onClick: handleRunOrPause,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 485
    }
  }, isRunning ? 'Pause' : 'Run'))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TableHeader, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 489
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(IDHeaderItem, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 490
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(HeaderItemText, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 491
    }
  }, extractPinnedTitle(queue)), _optionalChain([user, 'optionalAccess', _9 => _9.is_admin]) && !thereAreNonePinnedBlocks && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FilterMenuButtonContainer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 493
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledMenuIcon, {
    onClick: toggleFilterMenuPortal,
    ref: originFilterMenuRef,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 494
    }
  }, "expand_more"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TableHeaderItem, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 500
    }
  }, "Status"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TableHeaderItem, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 501
    }
  }, "Assigned To"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TableHeaderItem, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 502
    }
  }, "Comments"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TableHeaderItem, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 503
    }
  }, "Created At")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TasksContainer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 505
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Tasks, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 506
    }
  }, tasks.length > 0 ? tasks.map(task => {
    const {
      id,
      status,
      created_at,
      assigned_to,
      n_comments,
      data
    } = task;
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Task, {
      key: id,
      onClick: () => history.push(`/queues/${queueId}/tasks/${id}`),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 512
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TableItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 513
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ID, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 514
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(HeaderItemText, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 515
      }
    }, extractPinnedValue(data, id)))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TableItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 518
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('div', {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 519
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_StatusTag__WEBPACK_IMPORTED_MODULE_28__["default"], {
      status: status,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 520
      }
    }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TableItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 523
      }
    }, assigned_to && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(AssignedTo, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 525
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_Avatar__WEBPACK_IMPORTED_MODULE_5__["default"], {
      initials: assigned_to.charAt(0).toUpperCase(),
      color: Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_20__["colorFromString"])(assigned_to),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 526
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Name, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 530
      }
    }, assigned_to))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TableItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 534
      }
    }, n_comments > 0 && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(GrayText, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 536
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('div', {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 537
      }
    }, n_comments), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 538
      }
    }, "comment"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TableItem, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 542
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(GrayText, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 543
      }
    }, dayjs__WEBPACK_IMPORTED_MODULE_14___default()(created_at).fromNow())));
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_EmptyPage__WEBPACK_IMPORTED_MODULE_13__["default"], {
    header: 'This queue currently has no tasks',
    subHeader: "You can upload tasks at this queue's connections page",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 549
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(NavContainer, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 555
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(BackNavIcon, {
    onClick: () => setTaskPage(1),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 556
    }
  }, "first_page"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(BackNavIcon, {
    onClick: () => {
      if (taskPage > 1) setTaskPage(taskPage - 1);
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 557
    }
  }, "navigate_before"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ColoredText, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 564
    }
  }, taskPage), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ForwardNavIcon, {
    onClick: () => {
      if (taskPage !== finalPage) setTaskPage(taskPage + 1);
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 565
    }
  }, "navigate_next"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ForwardNavIcon, {
    onClick: () => {
      setTaskPage(finalPage);
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 572
    }
  }, "last_page"))), menuPortal( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_QueueActionsMenu__WEBPACK_IMPORTED_MODULE_11__["default"], {
    queueId: queueId,
    orgId: orgId,
    menuProps: menuProps,
    onDelete: confirmTogglePortal,
    onFlush: confirmFlushTogglePortal,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 582
    }
  })), modalPortal( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_NewTaskMenu__WEBPACK_IMPORTED_MODULE_17__["default"], {
    onSubmitHandler: onSubmitHandler,
    closePortal: closePortal,
    format: format,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 591
    }
  })), confirmModalPortal( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_16__["default"], {
    label: 'Delete',
    closePortal: confirmClosePortal,
    message: 'Are you sure you want to permanently delete this queue?',
    onConfirm: () => {
      deleteQueue();
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 594
    }
  })), confirmFlushModalPortal( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ConfirmationModal__WEBPACK_IMPORTED_MODULE_16__["default"], {
    label: 'Delete',
    closePortal: confirmFlushClosePortal,
    message: 'Are you sure you want to permanently delete all tasks from this queue?',
    onConfirm: () => {
      flushQueueTasks();
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 604
    }
  })), queueSettingsPortal( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_QueueSettingsModal__WEBPACK_IMPORTED_MODULE_25__["default"], {
    closePortal: closeQueueSettingsModal,
    runQueue: runQueue,
    queue: queue,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 614
    }
  })), filterMenuPortal( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_QueueFilterColumnMenu__WEBPACK_IMPORTED_MODULE_12__["default"], {
    queue: queue,
    activeBlockName: extractPinnedTitle(queue),
    menuProps: filterMenuProps,
    setPinnedBlock: setPinnedBlock,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 621
    }
  })));
};

const mapDispatchToProps = dispatch => {
  return {
    addFailureNotification: arg => dispatch(Object(client_modules_notificationSystem_ducks_notificationSystemDuck__WEBPACK_IMPORTED_MODULE_27__["addFailureNotification"])(arg)),
    addSuccessNotification: arg => dispatch(Object(client_modules_notificationSystem_ducks_notificationSystemDuck__WEBPACK_IMPORTED_MODULE_27__["addSuccessNotification"])(arg)),
    updateQueue: arg => dispatch(client_redux_queuesReducers__WEBPACK_IMPORTED_MODULE_26__["workfllowActions"].updateQueue(arg))
  };
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_22__["connect"])(null, mapDispatchToProps)(Queue));

/***/ }),

/***/ "./src/universal/modules/queue/components/QueueSettingsModal.tsx":
/*!***********************************************************************!*\
  !*** ./src/universal/modules/queue/components/QueueSettingsModal.tsx ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var _client_utils_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../client/utils/constants */ "./src/client/utils/constants.ts");
/* harmony import */ var universal_components_InputField__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/components/InputField */ "./src/universal/components/InputField.tsx");
/* harmony import */ var universal_components_PrimaryButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/components/PrimaryButton */ "./src/universal/components/PrimaryButton.tsx");
/* harmony import */ var universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! universal/components/SecondaryButton */ "./src/universal/components/SecondaryButton.tsx");
/* harmony import */ var client_components_TextArea__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! client/components/TextArea */ "./src/client/components/TextArea.tsx");
/* harmony import */ var universal_validations_yupSchema__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! universal/validations/yupSchema */ "./src/universal/validations/yupSchema.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/modules/queue/components/QueueSettingsModal.tsx";










const ModalRoot = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14z3qel0"
})({
  display: 'flex',
  flexDirection: 'column',
  maxWidth: 700,
  width: 700,
  borderRadius: 10,
  backgroundColor: '#fff',
  border: `1px solid ${universal_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].BORDER_MAIN_GRAY}`,
  boxShadow: _client_utils_constants__WEBPACK_IMPORTED_MODULE_4__["BoxShadow"].MODAL,
  paddingTop: 35,
  paddingBottom: 35,
  maxHeight: 'calc(100vh - 100px)'
});

const ModalWrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14z3qel1"
})({
  name: "mm2ghz",
  styles: "display:flex;flex-direction:row;width:100%;overflow:auto;"
});

const ModalHeader = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14z3qel2"
})({
  name: "1tg1vh9",
  styles: "font-weight:600;font-size:22px;line-height:27px;margin-bottom:10px;padding-left:35px;padding-right:35px;"
});

const ModalNote = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14z3qel3"
})({
  fontWeight: 500,
  fontSize: '18px',
  lineHeight: '20px',
  marginBottom: 25,
  paddingLeft: 35,
  paddingRight: 35,
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_DARKER_GRAY
});

const Label = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14z3qel4"
})({
  fontSize: 15,
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_MAIN,
  fontWeight: 400,
  marginBottom: 5
});

const Note = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "e14z3qel5"
})({
  fontSize: 12,
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_3__["PALETTE"].TEXT_GRAY,
  fontWeight: 400
});

const FieldWrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14z3qel6"
})({
  name: "1dy0fl1",
  styles: "display:grid;align-items:top;margin-bottom:5px;"
});

const FormContent = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(formik__WEBPACK_IMPORTED_MODULE_2__["Form"], {
  target: "e14z3qel7"
})({
  name: "y109xp",
  styles: "overflow:auto;position:relative;height:inherit;"
});

const QuotaInfoWrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14z3qel8"
})({
  name: "1q8ugqq",
  styles: "display:grid;align-items:top;margin-top:10px;grid-gap:10px;background-color:#fcfbff;padding:20px;border-radius:4px;"
});

const QuotaInfo = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "e14z3qel9"
})({
  name: "18bu3f0",
  styles: "font-size:12px;color:#846cf1;font-weight:400;"
});

const ContentBlock = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14z3qel10"
})({
  name: "9jmnaf",
  styles: "display:flex;flex-direction:column;margin-bottom:10px;"
});

const ModalFooter = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14z3qel11"
})({
  name: "1to1nwm",
  styles: "margin-top:10px;display:flex;flex-direction:row-reverse;align-items:center;justify-content:space-between;padding-left:35px;padding-right:35px;"
});

const ContentWrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14z3qel12"
})({
  name: "2lgtuc",
  styles: "background-color:#fff;width:100%;padding-left:35px;padding-right:35px;"
});

const SettingFields = () => {
  const [descriptionField, descriptionMeta, _descriptionHelper] = Object(formik__WEBPACK_IMPORTED_MODULE_2__["useField"])('task_description');
  const [guidelinesField, guidelinesMeta, _guidelinesHelper] = Object(formik__WEBPACK_IMPORTED_MODULE_2__["useField"])('guidelines_url');
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ContentBlock, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 129
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FieldWrapper, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 130
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 131
    }
  }, "Describe the goal of the task "), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_TextArea__WEBPACK_IMPORTED_MODULE_8__["default"], _objectSpread(_objectSpread({}, descriptionField), {}, {
    cacheMeasurements: true,
    error: descriptionMeta.error,
    placeholder: "Description",
    minRows: 4,
    maxRows: 8,
    positionErrorBelow: false,
    scrollable: true,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 132
    }
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FieldWrapper, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 143
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Note, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 144
    }
  }, "Required field. This will help us understand how tasks in this queue should be delivered."))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ContentBlock, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 150
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FieldWrapper, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 151
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 152
    }
  }, "Include a link to a guidelines document or instructional video"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_InputField__WEBPACK_IMPORTED_MODULE_5__["default"], _objectSpread(_objectSpread({}, guidelinesField), {}, {
    error: guidelinesMeta.error,
    type: "text",
    placeholder: "https://example.com/link-to-document",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 153
    }
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FieldWrapper, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 160
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Note, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 161
    }
  }, "Optional field with a URL to publicly accessible instructions. The more detailed context and examples, the higher the output quality we'll be able to provide."))));
};

const QueueSettingsModal = ({
  runQueue,
  queue,
  closePortal
}) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ModalRoot, {
  id: "queue-settings-modal",
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 172
  }
}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(formik__WEBPACK_IMPORTED_MODULE_2__["Formik"], {
  validationSchema: universal_validations_yupSchema__WEBPACK_IMPORTED_MODULE_9__["queueSettingsSchema"],
  validateOnChange: true,
  validateOnBlur: true,
  initialValues: queue,
  enableReinitialize: true,
  onSubmit: runQueue,
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 173
  }
}, ({
  isValid,
  isSubmitting
}) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FormContent, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 182
  }
}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ModalHeader, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 183
  }
}, "Automate your queue"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ModalNote, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 184
  }
}, "Tell us how this queue should be run and we'll handle it for you."), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ModalWrapper, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 185
  }
}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ContentWrapper, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 186
  }
}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(SettingFields, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 187
  }
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ContentBlock, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 188
  }
}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(QuotaInfoWrapper, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 189
  }
}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(QuotaInfo, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 190
  }
}, "Your account includes a", ' ', /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('b', {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 192
  }
}, "monthly quota of 100 tasks handled by us at no cost. "), "We will send you an email once you approach your limit."), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(QuotaInfo, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 195
  }
}, "If you are anticipating a large task load, have specific SLA requirements or want to ask additiional questions, don't hesitate to contact us at", ' ', /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('b', {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 198
  }
}, "contact@humanlambdas.com")))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ModalFooter, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 204
  }
}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_PrimaryButton__WEBPACK_IMPORTED_MODULE_6__["default"], {
  type: "submit",
  disabled: !isValid || isSubmitting,
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 205
  }
}, "Enable"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_7__["default"], {
  type: "button",
  onClick: () => closePortal(),
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 208
  }
}, "Cancel")))));

/* harmony default export */ __webpack_exports__["default"] = (QueueSettingsModal);

/***/ }),

/***/ "./src/universal/modules/queue/containers/QueueContainer.tsx":
/*!*******************************************************************!*\
  !*** ./src/universal/modules/queue/containers/QueueContainer.tsx ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var universal_modules_queue_components_Queue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! universal/modules/queue/components/Queue */ "./src/universal/modules/queue/components/Queue.tsx");
/* harmony import */ var client_components_LoadingPage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! client/components/LoadingPage */ "./src/client/components/LoadingPage.tsx");
/* harmony import */ var client_hooks_useDocumentTitle__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! client/hooks/useDocumentTitle */ "./src/client/hooks/useDocumentTitle.ts");
/* harmony import */ var client_hooks_useNetworker__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! client/hooks/useNetworker */ "./src/client/hooks/useNetworker.ts");
/* harmony import */ var client_hooks_useRouter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! client/hooks/useRouter */ "./src/client/hooks/useRouter.ts");
/* harmony import */ var client_modules_notificationSystem_ducks_notificationSystemDuck__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! client/modules/notificationSystem/ducks/notificationSystemDuck */ "./src/client/modules/notificationSystem/ducks/notificationSystemDuck.tsx");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var client_utils_segmentIo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! client/utils/segmentIo */ "./src/client/utils/segmentIo.ts");
/* harmony import */ var client_redux_queuesReducers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! client/redux/queuesReducers */ "./src/client/redux/queuesReducers.ts");
/* harmony import */ var client_utils_isUserStaff__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! client/utils/isUserStaff */ "./src/client/utils/isUserStaff.ts");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/modules/queue/containers/QueueContainer.tsx";












const QueueContainer = props => {
  const [queue, setQueue] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({});
  const [loading, setLoading] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const [format, setFormat] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [formatLoading, setFormatLoading] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const [tasks, setTasks] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [taskLoading, setTaskLoading] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const [taskPage, setTaskPage] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(1);
  const networker = Object(client_hooks_useNetworker__WEBPACK_IMPORTED_MODULE_4__["default"])();
  const {
    history
  } = Object(client_hooks_useRouter__WEBPACK_IMPORTED_MODULE_5__["default"])();
  const orgId = props.user.current_organization_id;
  const queueId = props.match.params.queueId;
  const organizations = props.organizations;
  const isStaff = Object(client_utils_isUserStaff__WEBPACK_IMPORTED_MODULE_10__["default"])(organizations, orgId);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    async function fetchQueue() {
      setLoading(true);
      const payload = {
        method: 'GET'
      };
      const {
        data
      } = (await networker.httpHandler(`/orgs/${orgId}/queues/${queueId}`, payload)) || {};

      if (data) {
        setQueue(data);
        props.setSelectedQueue(data);
      }

      setLoading(false);
    }

    fetchQueue();
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    async function fetchQueueFormat() {
      if (organizations.length > 0 && // If orgs aren't loaded isStaff may be incorrect
      !isStaff && Array.isArray(format) && format.length === 0) {
        setFormatLoading(true);
        const payload = {
          method: 'GET'
        };
        const {
          data
        } = (await networker.httpHandler(`/orgs/${orgId}/queues/${queueId}/tasks/form`, payload)) || {};

        if (data) {
          const {
            data: formatData
          } = data || {};
          setFormat(formatData);
        }

        setFormatLoading(false);
      }
    }

    fetchQueueFormat();
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    async function fetchTasks() {
      setTaskLoading(true);
      const payload = {
        method: 'GET'
      };
      const {
        data
      } = (await networker.httpHandler(`/orgs/${orgId}/queues/${queueId}/tasks/pending?limit=10&offset=${(taskPage - 1) * 10 || 0}`, payload)) || {};

      if (data) {
        setTasks(data.tasks);
      }

      setTaskLoading(false);
    }

    fetchTasks();
  }, [taskPage]);

  const deleteQueue = async () => {
    try {
      await networker.httpHandler(`/orgs/${orgId}/queues/${queueId}`, {
        method: 'PATCH',
        data: {
          disabled: true
        }
      });
      Object(client_utils_segmentIo__WEBPACK_IMPORTED_MODULE_8__["segmentTrack"])('Queue Deleted', {
        orgId,
        queueId,
        userId: props.user.id,
        name
      });
      props.addSuccessNotification('This queue has now been deleted');
      history.push(`/queues`);
    } catch (e) {
      console.error(e);
    }
  };

  const flushQueueTasks = async () => {
    try {
      await networker.httpHandler(`/orgs/${orgId}/queues/${queueId}/flush`, {
        method: 'PUT'
      });
      Object(client_utils_segmentIo__WEBPACK_IMPORTED_MODULE_8__["segmentTrack"])('Queue Tasks Deleted', {
        orgId,
        queueId,
        userId: props.user.id
      });
      props.addSuccessNotification(`The queue's tasks have now been deleted`);
      setTasks([]);
    } catch (e) {
      console.error(e);
    }
  };

  const startNextTask = async () => {
    const payload = {
      method: 'GET'
    };
    const res = await networker.httpHandler(`/orgs/${orgId}/queues/${queueId}/tasks/next`, payload);
    const {
      data
    } = res || {};
    const route = data.id ? `/queues/${queueId}/tasks/${data.id}` : `/queues/${queueId}/connections`;
    history.push(route);
  };

  let renderComp;

  if (loading || taskLoading || formatLoading || queue === undefined) {
    renderComp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(client_components_LoadingPage__WEBPACK_IMPORTED_MODULE_2__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 151
      }
    });
  } else {
    renderComp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_modules_queue_components_Queue__WEBPACK_IMPORTED_MODULE_1__["default"], {
      queue: queue,
      user: props.user,
      orgId: orgId,
      queueId: queueId,
      deleteQueue: deleteQueue,
      flushQueueTasks: flushQueueTasks,
      startNextTask: startNextTask,
      format: format,
      tasks: tasks,
      isStaff: isStaff,
      taskPage: taskPage,
      setTaskPage: setTaskPage,
      taskLoading: taskLoading,
      setQueue: setQueue,
      setSelectedQueue: props.setSelectedQueue,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 154
      }
    });
  }

  Object(client_hooks_useDocumentTitle__WEBPACK_IMPORTED_MODULE_3__["default"])(`Queue | Human Lambdas`);
  return renderComp;
};

const mapDispatchToProps = dispatch => ({
  addSuccessNotification: arg => dispatch(Object(client_modules_notificationSystem_ducks_notificationSystemDuck__WEBPACK_IMPORTED_MODULE_6__["addSuccessNotification"])(arg)),
  setSelectedQueue: arg => dispatch(client_redux_queuesReducers__WEBPACK_IMPORTED_MODULE_9__["workfllowActions"].setSelectedQueue(arg))
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_7__["connect"])(null, mapDispatchToProps)(QueueContainer));

/***/ }),

/***/ "./src/universal/utils/cutOffString.ts":
/*!*********************************************!*\
  !*** ./src/universal/utils/cutOffString.ts ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const cutOffString = (string, length) => string.length > length ? `${string.substring(0, length)}...` : string;

/* harmony default export */ __webpack_exports__["default"] = (cutOffString);

/***/ }),

/***/ "./src/universal/utils/formatValues.ts":
/*!*********************************************!*\
  !*** ./src/universal/utils/formatValues.ts ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}



const formatValues = values => {
  let fields;

  if (Array.isArray(values.data)) {
    fields = values.data;
  } else if (Array.isArray(values)) {
    fields = values;
  } else {
    return values;
  }

  fields.filter(val => {
    if (val[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION] !== undefined) {
      _optionalChain([val, 'access', _ => _[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION], 'access', _2 => _2.entities, 'optionalAccess', _3 => _3.filter, 'call', _4 => _4(entity => {
        delete entity.color;
        delete entity.text;
      })]);
    }

    if (val[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].BOUNDING_BOXES] !== undefined) {
      if (Array.isArray(val[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].BOUNDING_BOXES].value.objects)) {
        val[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].BOUNDING_BOXES].value.objects.filter(entity => {
          delete entity.color;
        });
      }

      if (val[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].BOUNDING_BOXES].value.image === '') {
        val[universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["BLOCK_TYPE"].BOUNDING_BOXES].value.image = null;
      }
    }

    return val;
  });
  return values;
};

/* harmony default export */ __webpack_exports__["default"] = (formatValues);

/***/ }),

/***/ "./src/universal/utils/getFirstLetter.ts":
/*!***********************************************!*\
  !*** ./src/universal/utils/getFirstLetter.ts ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const getFirstLetter = str => {
  let firstLetter = str;

  if (str && str.length > 1) {
    firstLetter = str.charAt(0).toUpperCase();
  }

  return firstLetter;
};

/* harmony default export */ __webpack_exports__["default"] = (getFirstLetter);

/***/ }),

/***/ "./src/universal/utils/getQueueStatus.ts":
/*!***********************************************!*\
  !*** ./src/universal/utils/getQueueStatus.ts ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");


const getQueueStatus = type => {
  let status = '';

  switch (type) {
    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["QUEUE_STATUS"].COMPLETED:
      status = 'COMPLETED';
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["QUEUE_STATUS"].NEW:
      status = 'NEW';
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["QUEUE_STATUS"].IN_PROGRESS:
      status = 'IN PROGRESS';
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_0__["QUEUE_STATUS"].OPEN:
      status = 'OPEN';
      break;

    default:
      break;
  }

  return status;
};

/* harmony default export */ __webpack_exports__["default"] = (getQueueStatus);

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvZGF5anMvZGF5anMubWluLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9kYXlqcy9wbHVnaW4vcmVsYXRpdmVUaW1lLmpzIiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvY29tcG9uZW50cy9BY3Rpb25CdXR0b24udHN4Iiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvY29tcG9uZW50cy9FbXB0eVBhZ2UudHN4Iiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvY29tcG9uZW50cy9GbGF0QnV0dG9uLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY2xpZW50L2NvbXBvbmVudHMvUXVldWVBY3Rpb25zTWVudS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NsaWVudC9jb21wb25lbnRzL1F1ZXVlRmlsdGVyQ29sdW1uTWVudS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NsaWVudC9ob29rcy91c2VEb2N1bWVudFRpdGxlLnRzIiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvdXRpbHMvY2FwaXRhbGl6ZUZpcnN0TGV0dGVyLnRzIiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9BdmF0YXIudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9OZXdUYXNrTWVudS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL1N0YXR1c1RhZy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9tb2R1bGVzL3F1ZXVlL2NvbXBvbmVudHMvUXVldWUudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvbW9kdWxlcy9xdWV1ZS9jb21wb25lbnRzL1F1ZXVlU2V0dGluZ3NNb2RhbC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9tb2R1bGVzL3F1ZXVlL2NvbnRhaW5lcnMvUXVldWVDb250YWluZXIudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvdXRpbHMvY3V0T2ZmU3RyaW5nLnRzIiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvdXRpbHMvZm9ybWF0VmFsdWVzLnRzIiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvdXRpbHMvZ2V0Rmlyc3RMZXR0ZXIudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC91dGlscy9nZXRRdWV1ZVN0YXR1cy50cyJdLCJuYW1lcyI6WyJBY3Rpb25CdXR0b24iLCJQbGFpbkJ1dHRvbiIsIndhaXRpbmciLCJkaXNhYmxlZCIsImhlaWdodCIsImxpbmVIZWlnaHQiLCJjb2xvciIsImJhY2tncm91bmRDb2xvciIsIlBBTEVUVEUiLCJQUklNQVJZX01BSU4iLCJmb250V2VpZ2h0IiwiZm9udFNpemUiLCJvdXRsaW5lIiwiYm94U2hhZG93IiwibWFyZ2luIiwiYm9yZGVyUmFkaXVzIiwiYm9yZGVyIiwidHJhbnNpdGlvbiIsInBhZGRpbmciLCJQUklNQVJZX01BSU5fREFSSyIsIkJPWF9TSEFET1dfUFJJTUFSWSIsIl9qc3hGaWxlTmFtZSIsIldyYXBwZXIiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsIndpZHRoIiwiZm9udEZhbWlseSIsIkZPTlRfRkFNSUxZIiwiU0FOU19TRVJJRiIsIlRpdGxlIiwiVEVYVF9NQUlOIiwiU3ViVGl0bGUiLCJFbXB0eVBhZ2UiLCJzdmciLCJoZWFkZXIiLCJzdWJIZWFkZXIiLCJidXR0b24iLCJSZWFjdCIsImNyZWF0ZUVsZW1lbnQiLCJfX3NlbGYiLCJfX3NvdXJjZSIsImZpbGVOYW1lIiwibGluZU51bWJlciIsIkZsYXRCdXR0b24iLCJwcm9wcyIsImlzRGlzYWJsZWQiLCJQUklNQVJZX01BSU5fTElHSFRFUiIsIk1lbnVDb250YWluZXIiLCJTdHlsZWRJY29uIiwiSWNvbiIsIlRFWFRfR1JBWSIsIm1hcmdpblJpZ2h0IiwiTGFiZWwiLCJRdWV1ZUFjdGlvbnNNZW51IiwibWVudVByb3BzIiwicXVldWVJZCIsIm9uRGVsZXRlIiwib25GbHVzaCIsInNlbGVjdGVkUXVldWUiLCJoaXN0b3J5IiwidXNlUm91dGVyIiwiTWVudSIsImFyaWFMYWJlbCIsIk1lbnVJdGVtIiwibGFiZWwiLCJvbkNsaWNrIiwicHVzaCIsInBhdGhuYW1lIiwic3RhdGUiLCJwcmV2Um91dGUiLCJsb2NhdGlvbiIsImhhc0Nsb25lIiwiY2xvbmVkUXVldWUiLCJkYXRhIiwibmFtZSIsImlkIiwibWFwU3RhdGVUb1Byb3BzIiwicXVldWVzIiwiY29ubmVjdCIsIl9vcHRpb25hbENoYWluIiwib3BzIiwibGFzdEFjY2Vzc0xIUyIsInVuZGVmaW5lZCIsInZhbHVlIiwiaSIsImxlbmd0aCIsIm9wIiwiZm4iLCJhcmdzIiwiY2FsbCIsIkxhYmVsVGV4dCIsIlF1ZXVlRmlsdGVyQ29sdW1uTWVudSIsInF1ZXVlIiwic2V0UGlubmVkQmxvY2siLCJhY3RpdmVCbG9ja05hbWUiLCJBcnJheSIsImlzQXJyYXkiLCJtYXAiLCJibG9jayIsIkZJTFRFUl9CTE9DS19UWVBFUyIsImluY2x1ZGVzIiwidHlwZSIsImtleSIsImlzQWN0aXZlIiwiQkxPQ0tTIiwiXyIsImZpbmQiLCJfMiIsImIiLCJfMyIsImljb24iLCJleHRyYVNwYWNlIiwidXNlRG9jdW1lbnRUaXRsZSIsInRpdGxlIiwidXNlRWZmZWN0IiwiZG9jdW1lbnQiLCJjYXBpdGFsaXplRmlyc3RMZXR0ZXIiLCJzdHIiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInNsaWNlIiwiQXZhdGFyIiwiZm9yd2FyZFJlZiIsInJlZiIsImluaXRpYWxzIiwic3R5bGUiLCJ0cmltIiwiQXZhdGFyQmxvY2siLCJ0ZXN0QWxpZ24iLCJtaW5XaWR0aCIsInVzZXJTZWxlY3QiLCJnZXRGaXJzdExldHRlciIsIk1vZGFsUm9vdCIsIkJPUkRFUl9NQUlOX0dSQVkiLCJCb3hTaGFkb3ciLCJNT0RBTCIsIk1haW5UaXRsZSIsIkZvcm1Db250ZW50IiwiRm9ybSIsIlN1Ym1pc3Npb25TZWN0aW9uIiwiSW5wdXQiLCJCb3giLCJPcHRpb25zIiwiUXVlc3Rpb24iLCJOZXdUYXNrTWVudSIsImNsb3NlUG9ydGFsIiwiZm9ybWF0Iiwib25TdWJtaXRIYW5kbGVyIiwiaW5pdGlhbFZhbHVlcyIsInJlcXVpcmVkIiwiaXRlbSIsIkJMT0NLX1RZUEUiLCJCT1VORElOR19CT1hFUyIsImltYWdlIiwiaXNfcmVxdWlyZWQiLCJGb3JtaWsiLCJ2YWxpZGF0aW9uU2NoZW1hIiwidGFza01lbnVTY2hlbWEiLCJ2YWxpZGF0ZU9uQ2hhbmdlIiwidmFsaWRhdGVPbkJsdXIiLCJ2YWxpZGF0ZU9uTW91bnQiLCJlbmFibGVSZWluaXRpYWxpemUiLCJvblN1Ym1pdCIsInRvdWNoZWQiLCJpc1N1Ym1pdHRpbmciLCJpc1ZhbGlkIiwiaGFuZGxlQ2hhbmdlIiwiaGFuZGxlQmx1ciIsInZhbHVlcyIsImVycm9ycyIsInNldEZpZWxkVmFsdWUiLCJpbnB1dCIsIlNJTkdMRV9TRUxFQ1RJT04iLCJjdXRPZmZTdHJpbmciLCJvcHRpb25zIiwib3B0aW9uIiwib3B0aW9uSW5kZXgiLCJUYXNrUmFkaW8iLCJvbkNoYW5nZSIsImNoZWNrZWQiLCJNVUxUSVBMRV9TRUxFQ1RJT04iLCJUYXNrQ2hlY2tib3giLCJOQU1FRF9FTlRJVFlfUkVDT0dOSVRJT04iLCJCYXNpY1RleHRBcmVhIiwicGxhY2Vob2xkZXIiLCJTQU1QTEVfVkFMVUVTIiwiZXJyb3IiLCJoaWRlRXJyb3JNZXNzYWdlIiwib25CbHVyIiwibWF4Um93cyIsIklucHV0RmllbGQiLCJjb250YWluZXJTdHlsZXMiLCJSSUNIX1RFWFQiLCJUZXh0RWRpdG9yIiwiaXNUYXNrTWVudSIsIkRBVEUiLCJEYXRlUGlja2VyIiwiVEVYVCIsIlNlY29uZGFyeUJ1dHRvbiIsIlN0YXR1c1RhZyIsInN0YXR1cyIsImNlbnRlcmVkIiwiUVVFVUVfU1RBVFVTIiwiT1BFTiIsIlNUQVRVU19QQUxFVFRFIiwiSU5fUFJPR1JFU1MiLCJORVciLCJDT01QTEVURUQiLCJUYWciLCJ0ZXh0VHJhbnNmb3JtIiwiZ2V0UXVldWVTdGF0dXMiLCJkYXlqcyIsImV4dGVuZCIsInJlbGF0aXZlVGltZSIsIlBhZ2UiLCJIZWFkZXIiLCJCdXR0b25zIiwiUGxheUJ1dHRvbiIsIlRhYmxlSGVhZGVyIiwiVGFibGVJdGVtIiwiVGFibGVIZWFkZXJJdGVtIiwiYm9yZGVyTGVmdCIsIkJPUkRFUl9HUkFZIiwicGFkZGluZ0xlZnQiLCJJREhlYWRlckl0ZW0iLCJIZWFkZXJJdGVtVGV4dCIsIlRhc2tzQ29udGFpbmVyIiwibWF4SGVpZ2h0IiwiTmF2Q29udGFpbmVyIiwiVGFzayIsImJvcmRlckJvdHRvbSIsImN1cnNvciIsIkdyYXlUZXh0IiwiSUQiLCJBc3NpZ25lZFRvIiwiTmFtZSIsIkNvbG9yZWRUZXh0IiwidGV4dEFsaWduIiwibWFyZ2luVG9wIiwiVGFza3MiLCJRdWV1ZVRpdGxlIiwiTWVudUJ1dHRvbkNvbnRhaW5lciIsIkZpbHRlck1lbnVCdXR0b25Db250YWluZXIiLCJNZW51QnV0dG9uU2Vjb25kYXJ5IiwiU3R5bGVkTWVudUljb24iLCJRdWV1ZSIsIm9yZ0lkIiwic3RhcnROZXh0VGFzayIsImRlbGV0ZVF1ZXVlIiwiZmx1c2hRdWV1ZVRhc2tzIiwidGFza3MiLCJ0YXNrUGFnZSIsInNldFRhc2tQYWdlIiwidXNlciIsImlzU3RhZmYiLCJzZXRRdWV1ZSIsInNldFNlbGVjdGVkUXVldWUiLCJ1cGRhdGVRdWV1ZSIsImlzX3J1bm5pbmciLCJpc1J1bm5pbmciLCJwaW5uZWRfYmxvY2siLCJwaW5uZWRCbG9jayIsInBpbm5lZEJsb2NrSWQiLCJzZXRQaW5uZWRCbG9ja0lkIiwidXNlU3RhdGUiLCJuZXR3b3JrZXIiLCJ1c2VOZXR3b3JrZXIiLCJtZW51UG9ydGFsIiwib3JpZ2luUmVmIiwidG9nZ2xlUG9ydGFsIiwidXNlTWVudSIsIk1lbnVQb3NpdGlvbiIsIlVQUEVSX0xFRlQiLCJpc0Ryb3Bkb3duIiwibW9kYWxQb3J0YWwiLCJuZXdUYXNrVG9nZ2xlUG9ydGFsIiwidXNlTW9kYWwiLCJvdmVyZmxvdyIsInF1ZXVlU2V0dGluZ3NQb3J0YWwiLCJ0b2dnbGVRdWV1ZVNldHRpbmdzTW9kYWwiLCJjbG9zZVF1ZXVlU2V0dGluZ3NNb2RhbCIsImNvbmZpcm1Nb2RhbFBvcnRhbCIsImNvbmZpcm1Ub2dnbGVQb3J0YWwiLCJjb25maXJtQ2xvc2VQb3J0YWwiLCJjb25maXJtRmx1c2hNb2RhbFBvcnRhbCIsImNvbmZpcm1GbHVzaFRvZ2dsZVBvcnRhbCIsImNvbmZpcm1GbHVzaENsb3NlUG9ydGFsIiwiZmlsdGVyTWVudVBvcnRhbCIsIm9yaWdpbkZpbHRlck1lbnVSZWYiLCJmaWx0ZXJNZW51UHJvcHMiLCJ0b2dnbGVGaWx0ZXJNZW51UG9ydGFsIiwiVVBQRVJfUklHSFQiLCJyZXR1cm5EYXRhIiwiZm9yRWFjaCIsInJldHVybk9iaiIsInBheWxvYWQiLCJtZXRob2QiLCJmb3JtYXRWYWx1ZXMiLCJ0cmFuc2Zvcm1EYXRlcyIsInJlcyIsImh0dHBIYW5kbGVyIiwiYWRkRmFpbHVyZU5vdGlmaWNhdGlvbiIsImZldGNoVGFza1BheWxvYWQiLCJmZXRjaFRhc2tSZXMiLCJyb3V0ZSIsInRhc2tTdGF0ZSIsImhhc0NoYW5nZWQiLCJydW5RdWV1ZSIsInVwZGF0ZWRRdWV1ZSIsImFkZFN1Y2Nlc3NOb3RpZmljYXRpb24iLCJmaW5hbFBhZ2UiLCJNYXRoIiwiZmxvb3IiLCJuX3Rhc2tzIiwiQmFja05hdkljb24iLCJGb3J3YXJkTmF2SWNvbiIsInBhdXNlUXVldWUiLCJoYW5kbGVSdW5PclBhdXNlIiwidXNlQ2FsbGJhY2siLCJ0aGVyZUFyZU5vbmVQaW5uZWRCbG9ja3MiLCJleHRyYWN0UGlubmVkVmFsdWUiLCJwaW5uZWRWYWx1ZSIsInRoZVZhbHVlSGFzQmVlbkFzc2lnbmVkIiwiXzQiLCJleHRyYWN0UGlubmVkVGl0bGUiLCJwaW5uZWRUaXRsZSIsIl81IiwiaXNfYWRtaW4iLCJfNiIsIl83IiwiXzgiLCJfOSIsInRhc2siLCJjcmVhdGVkX2F0IiwiYXNzaWduZWRfdG8iLCJuX2NvbW1lbnRzIiwiY29sb3JGcm9tU3RyaW5nIiwiZnJvbU5vdyIsIkNvbmZpcm1hdGlvbk1vZGFsIiwibWVzc2FnZSIsIm9uQ29uZmlybSIsIlF1ZXVlU2V0dGluZ3NNb2RhbCIsIm1hcERpc3BhdGNoVG9Qcm9wcyIsImRpc3BhdGNoIiwiYXJnIiwid29ya2ZsbG93QWN0aW9ucyIsIm1heFdpZHRoIiwicGFkZGluZ1RvcCIsInBhZGRpbmdCb3R0b20iLCJNb2RhbFdyYXBwZXIiLCJNb2RhbEhlYWRlciIsIk1vZGFsTm90ZSIsIm1hcmdpbkJvdHRvbSIsInBhZGRpbmdSaWdodCIsIlRFWFRfREFSS0VSX0dSQVkiLCJOb3RlIiwiRmllbGRXcmFwcGVyIiwiUXVvdGFJbmZvV3JhcHBlciIsIlF1b3RhSW5mbyIsIkNvbnRlbnRCbG9jayIsIk1vZGFsRm9vdGVyIiwiQ29udGVudFdyYXBwZXIiLCJTZXR0aW5nRmllbGRzIiwiZGVzY3JpcHRpb25GaWVsZCIsImRlc2NyaXB0aW9uTWV0YSIsIl9kZXNjcmlwdGlvbkhlbHBlciIsInVzZUZpZWxkIiwiZ3VpZGVsaW5lc0ZpZWxkIiwiZ3VpZGVsaW5lc01ldGEiLCJfZ3VpZGVsaW5lc0hlbHBlciIsIkZyYWdtZW50IiwiVGV4dEFyZWEiLCJjYWNoZU1lYXN1cmVtZW50cyIsIm1pblJvd3MiLCJwb3NpdGlvbkVycm9yQmVsb3ciLCJzY3JvbGxhYmxlIiwicXVldWVTZXR0aW5nc1NjaGVtYSIsIlByaW1hcnlCdXR0b24iLCJRdWV1ZUNvbnRhaW5lciIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic2V0Rm9ybWF0IiwiZm9ybWF0TG9hZGluZyIsInNldEZvcm1hdExvYWRpbmciLCJzZXRUYXNrcyIsInRhc2tMb2FkaW5nIiwic2V0VGFza0xvYWRpbmciLCJjdXJyZW50X29yZ2FuaXphdGlvbl9pZCIsIm1hdGNoIiwicGFyYW1zIiwib3JnYW5pemF0aW9ucyIsImlzVXNlclN0YWZmIiwiZmV0Y2hRdWV1ZSIsImZldGNoUXVldWVGb3JtYXQiLCJmb3JtYXREYXRhIiwiZmV0Y2hUYXNrcyIsInNlZ21lbnRUcmFjayIsInVzZXJJZCIsImUiLCJjb25zb2xlIiwicmVuZGVyQ29tcCIsIkxvYWRpbmdQYWdlIiwic3RyaW5nIiwic3Vic3RyaW5nIiwiZmllbGRzIiwiZmlsdGVyIiwidmFsIiwiZW50aXRpZXMiLCJlbnRpdHkiLCJ0ZXh0Iiwib2JqZWN0cyIsImZpcnN0TGV0dGVyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxlQUFlLEtBQW9ELG9CQUFvQixTQUEyRCxDQUFDLGlCQUFpQixhQUFhLG9IQUFvSCxFQUFFLFVBQVUsSUFBSSxXQUFXLElBQUksWUFBWSxJQUFJLFFBQVEsSUFBSSxRQUFRLElBQUksaUNBQWlDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxPQUFPLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxVQUFVLG1NQUFtTSxtQkFBbUIsZ0JBQWdCLHlEQUF5RCxJQUFJLGtCQUFrQiw2REFBNkQsK0NBQStDLG1CQUFtQixtQ0FBbUMsOEdBQThHLG1DQUFtQyxlQUFlLHlDQUF5QyxlQUFlLE9BQU8seUNBQXlDLGtEQUFrRCxlQUFlLG1CQUFtQixhQUFhLE9BQU8sa0JBQWtCLHNCQUFzQixtQkFBbUIsTUFBTSxlQUFlLGtEQUFrRCxLQUFLLGFBQWEsV0FBVyw0QkFBNEIsaUJBQWlCLHlCQUF5Qiw4QkFBOEIsMENBQTBDLEtBQUssOEJBQThCLFlBQVksOENBQThDLEdBQUcsaUJBQWlCLGNBQWMsMENBQTBDLGtCQUFrQiwyQkFBMkIsb0JBQW9CLHFCQUFxQixpQ0FBaUMsMEJBQTBCLHdDQUF3Qyx1Q0FBdUMsaUJBQWlCLE1BQU0sNkNBQTZDLDBIQUEwSCxtQkFBbUIsbUJBQW1CLGFBQWEsbUJBQW1CLGNBQWMsb0xBQW9MLHFCQUFxQixTQUFTLHNCQUFzQiw2Q0FBNkMsd0JBQXdCLFdBQVcsNENBQTRDLHlCQUF5Qiw0QkFBNEIsMEJBQTBCLDBCQUEwQixzQkFBc0Isb0NBQW9DLG1CQUFtQixzQ0FBc0Msc0JBQXNCLHlCQUF5Qix5QkFBeUIsa0RBQWtELHdEQUF3RCxzQkFBc0IsaUJBQWlCLHVGQUF1RiwwREFBMEQsVUFBVSxnQ0FBZ0MsZ0NBQWdDLHlEQUF5RCwwQkFBMEIsb0NBQW9DLCtCQUErQiwrQkFBK0Isb0NBQW9DLDZCQUE2QixxQkFBcUIsMEJBQTBCLHNCQUFzQixpREFBaUQseUtBQXlLLGlCQUFpQiw0QkFBNEIsMEVBQTBFLHNCQUFzQix3QkFBd0IscUJBQXFCLDhCQUE4QixtQkFBbUIsc0JBQXNCLHFCQUFxQixhQUFhLFlBQVksMkJBQTJCLFdBQVcsZ0RBQWdELHNDQUFzQyxzQ0FBc0MscUJBQXFCLHFCQUFxQixXQUFXLDhEQUE4RCxtQkFBbUIsMEJBQTBCLHdCQUF3QixzQkFBc0IsV0FBVyx3Q0FBd0MsdUlBQXVJLDJDQUEyQyxlQUFlLDJCQUEyQiwrQkFBK0IscUJBQXFCLDJCQUEyQixJQUFJLGtaQUFrWixpQ0FBaUMsa0NBQWtDLEVBQUUsd0JBQXdCLHNEQUFzRCx3QkFBd0Isb0ZBQW9GLGNBQWMsb0hBQW9ILDBCQUEwQix3QkFBd0Isc0JBQXNCLGtCQUFrQix3QkFBd0IscUJBQXFCLCtCQUErQixxQkFBcUIsb0JBQW9CLHlCQUF5QixxQkFBcUIsZ0NBQWdDLHFCQUFxQiw4Q0FBOEMsMEJBQTBCLDZCQUE2Qix1QkFBdUIsNkJBQTZCLEdBQUcsaUJBQWlCLG9IQUFvSCxvQkFBb0IsNkJBQTZCLHlCQUF5QixrQ0FBa0MsMkNBQTJDLGdCQUFnQix3QkFBd0IsR0FBRzs7Ozs7Ozs7Ozs7O0FDQXh4TSxlQUFlLEtBQW9ELG9CQUFvQixTQUErRSxDQUFDLGlCQUFpQixhQUFhLHVCQUF1QixRQUFRLHFCQUFxQixrTEFBa0wsb0JBQW9CLDZCQUE2QixxREFBcUQsOERBQThELHNCQUFzQixFQUFFLFdBQVcsRUFBRSx1QkFBdUIsRUFBRSxXQUFXLEVBQUUscUJBQXFCLEVBQUUsV0FBVyxFQUFFLG9CQUFvQixFQUFFLFdBQVcsRUFBRSxzQkFBc0IsRUFBRSxXQUFXLEVBQUUsZ0JBQWdCLGlCQUFpQixJQUFJLE1BQU0sV0FBVyxnREFBZ0QsNENBQTRDLHVCQUF1QixzQkFBc0IsYUFBYSxtRUFBbUUsT0FBTyxjQUFjLHdCQUF3QixrREFBa0Qsb0JBQW9CLHNCQUFzQixzQkFBc0Isb0JBQW9CLGtCQUFrQix5QkFBeUIsb0JBQW9CLDBCQUEwQix1QkFBdUIsOEJBQThCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNFdDFDO0FBQ0E7O0FBVUEsTUFBTUEsWUFBWSxHQUFHLGtGQUFPQyxvREFBUDtBQUFBO0FBQUEsR0FBb0IsQ0FBQztBQUFDQyxTQUFEO0FBQVVDO0FBQVYsQ0FBRCxLQUF5QjtBQUNoRTtBQUNBO0FBQ0EsU0FBTztBQUNMQyxVQUFNLEVBQUUsRUFESDtBQUVMQyxjQUFVLEVBQUUsTUFGUDtBQUdMQyxTQUFLLEVBQUUsTUFIRjtBQUlMQyxtQkFBZSxFQUFFQyxzREFBTyxDQUFDQyxZQUpwQjtBQUtMQyxjQUFVLEVBQUUsR0FMUDtBQU1MQyxZQUFRLEVBQUUsRUFOTDtBQU9MQyxXQUFPLEVBQUUsQ0FQSjtBQVFMQyxhQUFTLEVBQUUsZ0ZBUk47QUFTTEMsVUFBTSxFQUFFLENBVEg7QUFVTEMsZ0JBQVksRUFBRSxDQVZUO0FBV0xDLFVBQU0sRUFBRyx1QkFYSjtBQVlMQyxjQUFVLEVBQUUsdUJBWlA7QUFhTEMsV0FBTyxFQUFFLFFBYko7QUFjTCxjQUFVO0FBQ1JYLHFCQUFlLEVBQUVDLHNEQUFPLENBQUNXLGlCQURqQjtBQUVSSCxZQUFNLEVBQUcsYUFBWVIsc0RBQU8sQ0FBQ1csaUJBQWtCO0FBRnZDLEtBZEw7QUFrQkwsdUJBQW1CO0FBQ2pCTixlQUFTLEVBQUcsYUFBWUwsc0RBQU8sQ0FBQ1ksa0JBQW1CLEVBRGxDO0FBRWpCYixxQkFBZSxFQUFFQyxzREFBTyxDQUFDVyxpQkFGUjtBQUdqQkgsWUFBTSxFQUFHLGFBQVlSLHNEQUFPLENBQUNXLGlCQUFrQjtBQUg5QjtBQWxCZCxHQUFQO0FBd0JELENBM0JvQixDQUFyQjs7QUE2QmVuQiwyRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUNBLE1BQU1xQixZQUFZLEdBQUcsdUVBQXJCO0FBQTZGO0FBRTdGO0FBQ0E7O0FBU0EsTUFBTUMsT0FBTyxHQUFHO0FBQUE7QUFBQSxHQUFXO0FBQ3pCZixpQkFBZSxFQUFFLE1BRFE7QUFFekJnQixTQUFPLEVBQUUsTUFGZ0I7QUFHekJDLGVBQWEsRUFBRSxRQUhVO0FBSXpCQyxZQUFVLEVBQUUsUUFKYTtBQUt6QkMsZ0JBQWMsRUFBRSxRQUxTO0FBTXpCdEIsUUFBTSxFQUFFLE1BTmlCO0FBT3pCdUIsT0FBSyxFQUFFLE1BUGtCO0FBUXpCQyxZQUFVLEVBQUVDLDZEQUFXLENBQUNDO0FBUkMsQ0FBWCxDQUFoQjs7QUFXQSxNQUFNQyxLQUFLLEdBQUc7QUFBQTtBQUFBLEdBQVc7QUFDdkJ6QixPQUFLLEVBQUVFLHNEQUFPLENBQUN3QixTQURRO0FBRXZCckIsVUFBUSxFQUFFLEVBRmE7QUFHdkJELFlBQVUsRUFBRSxHQUhXO0FBSXZCSSxRQUFNLEVBQUU7QUFKZSxDQUFYLENBQWQ7O0FBT0EsTUFBTW1CLFFBQVEsR0FBRztBQUFBO0FBQUEsR0FBVztBQUMxQjNCLE9BQUssRUFBRUUsc0RBQU8sQ0FBQ3dCLFNBRFc7QUFFMUJyQixVQUFRLEVBQUUsRUFGZ0I7QUFHMUJELFlBQVUsRUFBRSxHQUhjO0FBSTFCSSxRQUFNLEVBQUUsWUFKa0I7QUFLMUIsZUFBYTtBQUNYUixTQUFLLEVBQUVFLHNEQUFPLENBQUNDO0FBREo7QUFMYSxDQUFYLENBQWpCOztBQVVBLE1BQU15QixTQUFTLEdBQUcsQ0FBQztBQUFDQyxLQUFEO0FBQU1DLFFBQU47QUFBY0MsV0FBZDtBQUF5QkM7QUFBekIsQ0FBRCxLQUFzQztBQUN0RCxzQkFDRUMsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmxCLE9BQXBCLEVBQTZCO0FBQUNtQixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBN0IsRUFDSVQsR0FESixlQUVJSSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CVCxLQUFwQixFQUEyQjtBQUFDVSxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBM0IsRUFBK0ZSLE1BQS9GLENBRkosZUFHSUcsNENBQUssQ0FBQ0MsYUFBTixDQUFvQlAsUUFBcEIsRUFBOEI7QUFBQ1EsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTlCLEVBQWtHUCxTQUFsRyxDQUhKLEVBSUlDLE1BSkosQ0FERjtBQVFELENBVEQ7O0FBV2VKLHdFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakRBO0FBQ0E7O0FBVUEsTUFBTVcsVUFBVSxHQUFHLGtGQUFPNUMsb0RBQVA7QUFBQTtBQUFBLEdBQXFCNkMsS0FBRCxJQUFXO0FBQ2hELFFBQU07QUFBQzVDLFdBQUQ7QUFBVUM7QUFBVixNQUFzQjJDLEtBQTVCO0FBQ0EsUUFBTUMsVUFBVSxHQUFHNUMsUUFBUSxJQUFJRCxPQUEvQjtBQUNBLFNBQU87QUFDTEssbUJBQWUsRUFBRUMsc0RBQU8sQ0FBQ0MsWUFEcEI7QUFFTEgsU0FBSyxFQUFFLE1BRkY7QUFHTFMsZ0JBQVksRUFBRSxDQUhUO0FBSUxGLGFBQVMsRUFBRSxnRkFKTjtBQUtMRCxXQUFPLEVBQUUsQ0FMSjtBQU1MLGNBQVU7QUFDUkwscUJBQWUsRUFBRSxDQUFDd0MsVUFBRCxJQUFldkMsc0RBQU8sQ0FBQ1c7QUFEaEMsS0FOTDtBQVNMLHVCQUFtQjtBQUNqQk4sZUFBUyxFQUFHLGFBQVlMLHNEQUFPLENBQUNZLGtCQUFtQixFQURsQztBQUVqQmIscUJBQWUsRUFBRSxDQUFDd0MsVUFBRCxJQUFldkMsc0RBQU8sQ0FBQ3dDO0FBRnZCO0FBVGQsR0FBUDtBQWNELENBakJrQixDQUFuQjs7QUFtQmVILHlFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hDQSxNQUFNeEIsWUFBWSxHQUFHLDhFQUFyQjtBQUFvRztBQUNwRztBQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBV0EsTUFBTTRCLGFBQWEsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBdEI7O0FBSUEsTUFBTUMsVUFBVSxHQUFHLGtGQUFPQyxpRUFBUDtBQUFBO0FBQUEsR0FBYTtBQUM5QjVCLFNBQU8sRUFBRSxPQURxQjtBQUU5QmpCLE9BQUssRUFBRUUsc0RBQU8sQ0FBQzRDLFNBRmU7QUFHOUJDLGFBQVcsRUFBRSxFQUhpQjtBQUk5QjFDLFVBQVEsRUFBRTtBQUpvQixDQUFiLENBQW5COztBQU9BLE1BQU0yQyxLQUFLLEdBQUc7QUFBQTtBQUFBLEdBQVc7QUFDdkIvQixTQUFPLEVBQUUsTUFEYztBQUV2QkMsZUFBYSxFQUFFLEtBRlE7QUFHdkJiLFVBQVEsRUFBRSxFQUhhO0FBSXZCRCxZQUFVLEVBQUUsR0FKVztBQUt2QlEsU0FBTyxFQUFFLFVBTGM7QUFNdkJaLE9BQUssRUFBRUUsc0RBQU8sQ0FBQ3dCO0FBTlEsQ0FBWCxDQUFkOztBQVNBLE1BQU11QixnQkFBZ0IsR0FBSVQsS0FBRCxJQUFXO0FBQ2xDLFFBQU07QUFBQ1UsYUFBRDtBQUFZQyxXQUFaO0FBQXFCQyxZQUFyQjtBQUErQkMsV0FBL0I7QUFBd0NDO0FBQXhDLE1BQXlEZCxLQUEvRDtBQUNBLFFBQU07QUFBQ2U7QUFBRCxNQUFZQywrREFBUyxFQUEzQjtBQUNBLHNCQUNFdkIsNENBQUssQ0FBQ0MsYUFBTixDQUFvQlMsYUFBcEIsRUFBbUM7QUFBQ1IsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQW5DLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1Qiw2Q0FBcEI7QUFBNEJDLGFBQVMsRUFBRTtBQUF2QyxLQUE2RFIsU0FBN0Q7QUFBd0VmLFVBQU0sRUFBRSxTQUFoRjtBQUFzRkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQWhHLG1CQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeUIsaURBQXBCLEVBQThCO0FBQzlCQyxTQUFLLGVBQ0gzQiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CYyxLQUFwQixFQUEyQjtBQUFDYixZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTNCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JVLFVBQXBCLEVBQWdDO0FBQUNULFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBaEMsRUFBb0csTUFBcEcsQ0FESixlQUVJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLE1BQXBCLEVBQTRCO0FBQUNDLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBNUIsRUFBZ0csWUFBaEcsQ0FGSixDQUY0QjtBQU85QnVCLFdBQU8sRUFBRSxNQUNQTixPQUFPLENBQUNPLElBQVIsQ0FBYTtBQUNYQyxjQUFRLEVBQUcsV0FBVVosT0FBUSxPQURsQjtBQUVYYSxXQUFLLEVBQUU7QUFBQ0MsaUJBQVMsRUFBRVYsT0FBTyxDQUFDVyxRQUFSLENBQWlCSDtBQUE3QjtBQUZJLEtBQWIsQ0FSNEI7QUFZNUI1QixVQUFNLEVBQUUsU0Fab0I7QUFZZEMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBWkksR0FBOUIsQ0FERixlQWVFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeUIsaURBQXBCLEVBQThCO0FBQzlCQyxTQUFLLGVBQ0gzQiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CYyxLQUFwQixFQUEyQjtBQUFDYixZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTNCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JVLFVBQXBCLEVBQWdDO0FBQUNULFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBaEMsRUFBb0csY0FBcEcsQ0FESixlQUVJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLE1BQXBCLEVBQTRCO0FBQUNDLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBNUIsRUFBZ0csYUFBaEcsQ0FGSixDQUY0QjtBQU85QnVCLFdBQU8sRUFBRSxNQUNQTixPQUFPLENBQUNPLElBQVIsQ0FBYTtBQUNYQyxjQUFRLEVBQUUsYUFEQztBQUVYQyxXQUFLLEVBQUU7QUFDTEcsZ0JBQVEsRUFBRSxJQURMO0FBRUxDLG1CQUFXLEVBQUU7QUFDWEMsY0FBSSxFQUFFZixhQUFhLENBQUNlLElBRFQ7QUFFWEMsY0FBSSxFQUFHLEdBQUVoQixhQUFhLENBQUNnQixJQUFLLE9BRmpCO0FBR1hDLFlBQUUsRUFBRWpCLGFBQWEsQ0FBQ2lCO0FBSFA7QUFGUjtBQUZJLEtBQWIsQ0FSNEI7QUFtQjVCcEMsVUFBTSxFQUFFLFNBbkJvQjtBQW1CZEMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBbkJJLEdBQTlCLENBZkYsZUFvQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5QixpREFBcEIsRUFBOEI7QUFDOUJDLFNBQUssZUFDSDNCLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JjLEtBQXBCLEVBQTJCO0FBQUNiLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBM0IsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQlUsVUFBcEIsRUFBZ0M7QUFBQ1QsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUFoQyxFQUFvRyxNQUFwRyxDQURKLGVBRUlMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsTUFBcEIsRUFBNEI7QUFBQ0MsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUE1QixFQUFnRyxrQkFBaEcsQ0FGSixDQUY0QjtBQU85QnVCLFdBQU8sRUFBRVIsT0FQcUI7QUFPWmxCLFVBQU0sRUFBRSxTQVBJO0FBT0VDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQVBaLEdBQTlCLENBcENGLGVBNkNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeUIsaURBQXBCLEVBQThCO0FBQzlCQyxTQUFLLGVBQ0gzQiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CYyxLQUFwQixFQUEyQjtBQUFDYixZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTNCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JVLFVBQXBCLEVBQWdDO0FBQUNULFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBaEMsRUFBb0csUUFBcEcsQ0FESixlQUVJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLE1BQXBCLEVBQTRCO0FBQUNDLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBNUIsRUFBZ0csY0FBaEcsQ0FGSixDQUY0QjtBQU85QnVCLFdBQU8sRUFBRVQsUUFQcUI7QUFPWGpCLFVBQU0sRUFBRSxTQVBHO0FBT0dDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQVBiLEdBQTlCLENBN0NGLENBREosQ0FERjtBQTJERCxDQTlERDs7QUFnRUEsTUFBTWtDLGVBQWUsR0FBSVIsS0FBRCxLQUFZO0FBQ2xDVixlQUFhLEVBQUVVLEtBQUssQ0FBQ1MsTUFBTixDQUFhbkI7QUFETSxDQUFaLENBQXhCOztBQUllb0IsMEhBQU8sQ0FBQ0YsZUFBRCxFQUFrQixJQUFsQixDQUFQLENBQStCdkIsZ0JBQS9CLENBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0dBLE1BQU1sQyxZQUFZLEdBQUcsbUZBQXJCOztBQUEwRyxTQUFTNEQsY0FBVCxDQUF3QkMsR0FBeEIsRUFBNkI7QUFBRSxNQUFJQyxhQUFhLEdBQUdDLFNBQXBCO0FBQStCLE1BQUlDLEtBQUssR0FBR0gsR0FBRyxDQUFDLENBQUQsQ0FBZjtBQUFvQixNQUFJSSxDQUFDLEdBQUcsQ0FBUjs7QUFBVyxTQUFPQSxDQUFDLEdBQUdKLEdBQUcsQ0FBQ0ssTUFBZixFQUF1QjtBQUFFLFVBQU1DLEVBQUUsR0FBR04sR0FBRyxDQUFDSSxDQUFELENBQWQ7QUFBbUIsVUFBTUcsRUFBRSxHQUFHUCxHQUFHLENBQUNJLENBQUMsR0FBRyxDQUFMLENBQWQ7QUFBdUJBLEtBQUMsSUFBSSxDQUFMOztBQUFRLFFBQUksQ0FBQ0UsRUFBRSxLQUFLLGdCQUFQLElBQTJCQSxFQUFFLEtBQUssY0FBbkMsS0FBc0RILEtBQUssSUFBSSxJQUFuRSxFQUF5RTtBQUFFLGFBQU9ELFNBQVA7QUFBbUI7O0FBQUMsUUFBSUksRUFBRSxLQUFLLFFBQVAsSUFBbUJBLEVBQUUsS0FBSyxnQkFBOUIsRUFBZ0Q7QUFBRUwsbUJBQWEsR0FBR0UsS0FBaEI7QUFBdUJBLFdBQUssR0FBR0ksRUFBRSxDQUFDSixLQUFELENBQVY7QUFBb0IsS0FBN0YsTUFBbUcsSUFBSUcsRUFBRSxLQUFLLE1BQVAsSUFBaUJBLEVBQUUsS0FBSyxjQUE1QixFQUE0QztBQUFFSCxXQUFLLEdBQUdJLEVBQUUsQ0FBQyxDQUFDLEdBQUdDLElBQUosS0FBYUwsS0FBSyxDQUFDTSxJQUFOLENBQVdSLGFBQVgsRUFBMEIsR0FBR08sSUFBN0IsQ0FBZCxDQUFWO0FBQTZEUCxtQkFBYSxHQUFHQyxTQUFoQjtBQUE0QjtBQUFFOztBQUFDLFNBQU9DLEtBQVA7QUFBZTs7QUFBQTtBQUM3bUI7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUVBOztBQVNBLE1BQU1wQyxhQUFhLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXRCOztBQUlBLE1BQU1DLFVBQVUsR0FBRyxrRkFBT0MsaUVBQVA7QUFBQTtBQUFBLEdBQWE7QUFDOUI1QixTQUFPLEVBQUUsT0FEcUI7QUFFOUJqQixPQUFLLEVBQUVFLHNEQUFPLENBQUM0QyxTQUZlO0FBRzlCQyxhQUFXLEVBQUUsRUFIaUI7QUFJOUIxQyxVQUFRLEVBQUU7QUFKb0IsQ0FBYixDQUFuQjs7QUFPQSxNQUFNMkMsS0FBSyxHQUFHO0FBQUE7QUFBQSxHQUFXO0FBQ3ZCL0IsU0FBTyxFQUFFLE1BRGM7QUFFdkJDLGVBQWEsRUFBRSxLQUZRO0FBR3ZCYixVQUFRLEVBQUUsRUFIYTtBQUl2QkQsWUFBVSxFQUFFLEdBSlc7QUFLdkJRLFNBQU8sRUFBRSxTQUxjO0FBTXZCWixPQUFLLEVBQUVFLHNEQUFPLENBQUN3QjtBQU5RLENBQVgsQ0FBZDs7QUFTQSxNQUFNNEQsU0FBUyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFsQjs7QUFNQSxNQUFNQyxxQkFBcUIsR0FBSS9DLEtBQUQsSUFBVztBQUN2QyxRQUFNO0FBQUNVLGFBQUQ7QUFBWXNDLFNBQVo7QUFBbUJDLGtCQUFuQjtBQUFtQ0M7QUFBbkMsTUFBc0RsRCxLQUE1RDs7QUFFQSxNQUFJLENBQUNnRCxLQUFELElBQVUsQ0FBQ0csS0FBSyxDQUFDQyxPQUFOLENBQWNKLEtBQUssQ0FBQ25CLElBQXBCLENBQWYsRUFBMEM7QUFDeEMsV0FBTyxJQUFQO0FBQ0Q7O0FBRUQsc0JBQ0VwQyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CUyxhQUFwQixFQUFtQztBQUFDUixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBbkMsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnVCLDZDQUFwQjtBQUE0QkMsYUFBUyxFQUFFO0FBQXZDLEtBQWdFUixTQUFoRTtBQUEyRWYsVUFBTSxFQUFFLFNBQW5GO0FBQXlGQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBbkcsTUFDRWtELEtBQUssQ0FBQ25CLElBQU4sQ0FBV3dCLEdBQVgsQ0FBZSxDQUFDQyxLQUFELEVBQVF2QixFQUFSLEtBQWU7QUFDOUIsUUFBSSxDQUFDd0IsNEVBQWtCLENBQUNDLFFBQW5CLENBQTRCRixLQUFLLENBQUNHLElBQWxDLENBQUwsRUFBOEM7QUFDNUMsYUFBTyxJQUFQO0FBQ0QsS0FGRCxNQUdFLG9CQUNFaEUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnlCLGlEQUFwQixFQUE4QjtBQUM1QnVDLFNBQUcsRUFBRTNCLEVBRHVCO0FBRTVCNEIsY0FBUSxFQUFFVCxlQUFlLEtBQUtJLEtBQUssQ0FBQ3hCLElBRlI7QUFHNUJWLFdBQUssZUFDSDNCLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JjLEtBQXBCLEVBQTJCO0FBQUNiLGNBQU0sRUFBRSxTQUFUO0FBQWVDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixvQkFBVSxFQUFFO0FBQXJDO0FBQXpCLE9BQTNCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JVLFVBQXBCLEVBQWdDO0FBQUNULGNBQU0sRUFBRSxTQUFUO0FBQWVDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixvQkFBVSxFQUFFO0FBQXJDO0FBQXpCLE9BQWhDLEVBQW9HcUMsY0FBYyxDQUFDLENBQUN5QixnRUFBRCxFQUFTLFFBQVQsRUFBbUJDLENBQUMsSUFBSUEsQ0FBQyxDQUFDQyxJQUExQixFQUFnQyxNQUFoQyxFQUF3Q0MsRUFBRSxJQUFJQSxFQUFFLENBQUVDLENBQUQsSUFBT0EsQ0FBQyxDQUFDUCxJQUFGLEtBQVdILEtBQUssQ0FBQ0csSUFBekIsQ0FBaEQsRUFBZ0YsZ0JBQWhGLEVBQWtHUSxFQUFFLElBQUlBLEVBQUUsQ0FBQ0MsSUFBM0csQ0FBRCxDQUFsSCxDQURKLGVBRUl6RSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cb0QsU0FBcEIsRUFBK0I7QUFBQ25ELGNBQU0sRUFBRSxTQUFUO0FBQWVDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixvQkFBVSxFQUFFO0FBQXJDO0FBQXpCLE9BQS9CLEVBQW1Hd0QsS0FBSyxDQUFDeEIsSUFBekcsQ0FGSixDQUowQjtBQVM1QlQsYUFBTyxFQUFFLE1BQU07QUFDYjRCLHNCQUFjLENBQUNLLEtBQUssQ0FBQ3ZCLEVBQVAsQ0FBZDtBQUNELE9BWDJCO0FBV3pCcEMsWUFBTSxFQUFFLFNBWGlCO0FBV1hDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFYQyxLQUE5QixDQURGO0FBZUgsR0FuQkMsQ0FERixFQXFCRW9ELGVBQWUsSUFBSSxFQUFuQixJQUNBQSxlQUFlLElBQUksSUFEbkIsSUFFQUEsZUFBZSxJQUFJLElBRm5CLElBR0EsT0FBT0EsZUFBUCxLQUEyQixXQUgzQixpQkFJRXpELDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5QixpREFBcEIsRUFBOEI7QUFDNUJnRCxjQUFVLEVBQUUsSUFEZ0I7QUFFNUIvQyxTQUFLLGVBQ0gzQiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CYyxLQUFwQixFQUEyQjtBQUFDYixZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTNCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JVLFVBQXBCLEVBQWdDO0FBQUNULFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBaEMsRUFBb0csU0FBcEcsQ0FESixlQUVJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLE1BQXBCLEVBQTRCO0FBQUNDLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBNUIsRUFBZ0csYUFBaEcsQ0FGSixDQUgwQjtBQVE1QnVCLFdBQU8sRUFBRSxNQUFNO0FBQ2I0QixvQkFBYyxDQUFDLElBQUQsQ0FBZDtBQUNELEtBVjJCO0FBVXpCdEQsVUFBTSxFQUFFLFNBVmlCO0FBVVhDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQVZDLEdBQTlCLENBekJKLENBREosQ0FERjtBQTJDRCxDQWxERDs7QUFvREEsTUFBTWtDLGVBQWUsR0FBSVIsS0FBRCxLQUFZO0FBQ2xDVixlQUFhLEVBQUVVLEtBQUssQ0FBQ1MsTUFBTixDQUFhbkI7QUFETSxDQUFaLENBQXhCOztBQUllb0IsMEhBQU8sQ0FBQ0YsZUFBRCxFQUFrQixJQUFsQixDQUFQLENBQStCZSxxQkFBL0IsQ0FBZixFOzs7Ozs7Ozs7Ozs7QUNwR0E7QUFBQTtBQUFBO0FBQUE7O0FBRUEsTUFBTXFCLGdCQUFnQixHQUFJQyxLQUFELElBQVc7QUFDbENDLHlEQUFTLENBQUMsTUFBTTtBQUNkQyxZQUFRLENBQUNGLEtBQVQsR0FBaUJBLEtBQWpCO0FBQ0QsR0FGUSxFQUVOLENBQUNBLEtBQUQsQ0FGTSxDQUFUO0FBR0QsQ0FKRDs7QUFNZUQsK0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDUkE7QUFBQSxNQUFNSSxxQkFBcUIsR0FBSUMsR0FBRCxJQUFTQSxHQUFHLENBQUNDLE1BQUosQ0FBVyxDQUFYLEVBQWNDLFdBQWQsS0FBOEJGLEdBQUcsQ0FBQ0csS0FBSixDQUFVLENBQVYsQ0FBckU7O0FBQ2VKLG9GQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEQSxNQUFNakcsWUFBWSxHQUFHLHVFQUFyQjtBQUE2RjtBQUU3RjtBQUNBO0FBV0EsTUFBTXNHLE1BQU0sZ0JBQUdDLHdEQUFVLENBQUMsQ0FBQzlFLEtBQUQsRUFBUStFLEdBQVIsS0FBZ0I7QUFDeEMsUUFBTTtBQUFDQyxZQUFEO0FBQVd4SCxTQUFYO0FBQWtCNkQsV0FBbEI7QUFBMkI0RCxTQUEzQjtBQUFrQ0MsUUFBSSxHQUFHO0FBQXpDLE1BQWlEbEYsS0FBdkQ7QUFFQSxRQUFNdkMsZUFBZSxHQUFHRCxLQUFLLElBQUlFLDhEQUFPLENBQUNDLFlBQXpDOztBQUVBLFFBQU13SCxXQUFXLEdBQUc7QUFBQTtBQUFBLEtBQVk7QUFDOUIxRyxXQUFPLEVBQUUsYUFEcUI7QUFFOUJHLGtCQUFjLEVBQUUsUUFGYztBQUc5QkQsY0FBVSxFQUFFLFFBSGtCO0FBSTlCeUcsYUFBUyxFQUFFLFFBSm1CO0FBSzlCOUgsVUFBTSxFQUFHLE1BTHFCO0FBTTlCdUIsU0FBSyxFQUFHLE1BTnNCO0FBTzlCd0csWUFBUSxFQUFHLE1BUG1CO0FBUTlCekgsY0FBVSxFQUFFLEdBUmtCO0FBUzlCQyxZQUFRLEVBQUUsRUFUb0I7QUFVOUJMLFNBQUssRUFBRSxNQVZ1QjtBQVc5QlMsZ0JBQVksRUFBRSxNQVhnQjtBQVk5QlIsbUJBQWUsRUFBRUEsZUFaYTtBQWE5QjZILGNBQVUsRUFBRSxNQWJrQjtBQWM5QnRILFVBQU0sRUFBRTtBQWRzQixHQUFaLENBQXBCOztBQWlCQSxzQkFDRXlCLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5RixXQUFwQixFQUFpQztBQUFFSixPQUFHLEVBQUVBLEdBQVA7QUFBWTFELFdBQU8sRUFBRUEsT0FBckI7QUFBOEI0RCxTQUFLLEVBQUVBLEtBQXJDO0FBQTRDdEYsVUFBTSxFQUFFLFNBQXBEO0FBQTBEQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBcEUsR0FBakMsRUFDSW9GLElBQUksR0FBR0ssOEVBQWMsQ0FBQ1AsUUFBRCxDQUFqQixHQUE4QkEsUUFEdEMsQ0FERjtBQUtELENBM0J3QixDQUF6QjtBQTZCZUgscUVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzQ0EsTUFBTXRHLFlBQVksR0FBRyw0RUFBckI7QUFBa0c7QUFDbEc7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQWNBLE1BQU1pSCxTQUFTLEdBQUc7QUFBQTtBQUFBLEdBQVc7QUFDM0IvRyxTQUFPLEVBQUUsTUFEa0I7QUFFM0JDLGVBQWEsRUFBRSxRQUZZO0FBRzNCRyxPQUFLLEVBQUUsR0FIb0I7QUFJM0JaLGNBQVksRUFBRSxFQUphO0FBSzNCUixpQkFBZSxFQUFFLE1BTFU7QUFNM0JTLFFBQU0sRUFBRyxhQUFZUixnRUFBTyxDQUFDK0gsZ0JBQWlCLEVBTm5CO0FBTzNCMUgsV0FBUyxFQUFFMkgsZ0VBQVMsQ0FBQ0M7QUFQTSxDQUFYLENBQWxCOztBQVVBLE1BQU1DLFNBQVMsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBbEI7O0FBUUEsTUFBTUMsV0FBVyxHQUFHLGtGQUFPQywyQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBcEI7O0FBSUEsTUFBTUMsaUJBQWlCLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQTFCOztBQU9BLE1BQU1DLEtBQUssR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBZDs7QUFPQSxNQUFNeEYsS0FBSyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFkOztBQVFBLE1BQU15RixHQUFHLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQVo7O0FBSUEsTUFBTUMsT0FBTyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFoQjs7QUFNQSxNQUFNQyxRQUFRLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQWpCOztBQUtBLE1BQU1DLFdBQVcsR0FBSXBHLEtBQUQsSUFBVztBQUM3QixRQUFNO0FBQUNxRyxlQUFEO0FBQWNDLFVBQWQ7QUFBc0JDO0FBQXRCLE1BQXlDdkcsS0FBL0M7QUFFQSxRQUFNd0csYUFBYSxHQUFHO0FBQUMzRSxRQUFJLEVBQUUsRUFBUDtBQUFXNEUsWUFBUSxFQUFFO0FBQXJCLEdBQXRCO0FBQ0FILFFBQU0sQ0FBQ2pELEdBQVAsQ0FBWXFELElBQUQsSUFBVTtBQUNuQixRQUFJRixhQUFhLENBQUMzRSxJQUFkLENBQW1CNkUsSUFBSSxDQUFDakQsSUFBeEIsQ0FBSixFQUFtQztBQUNqQytDLG1CQUFhLENBQUMzRSxJQUFkLENBQW1CNkUsSUFBSSxDQUFDakQsSUFBeEIsRUFBOEJpRCxJQUFJLENBQUMzRSxFQUFuQyxJQUF5QyxFQUF6QztBQUNELEtBRkQsTUFFTztBQUNMeUUsbUJBQWEsQ0FBQzNFLElBQWQsQ0FBbUI2RSxJQUFJLENBQUNqRCxJQUF4QixJQUFnQztBQUFDLFNBQUNpRCxJQUFJLENBQUMzRSxFQUFOLEdBQVc7QUFBWixPQUFoQztBQUNEOztBQUVELFFBQUkyRSxJQUFJLENBQUNqRCxJQUFMLEtBQWNrRCxxRUFBVSxDQUFDQyxjQUE3QixFQUE2QztBQUMzQ0osbUJBQWEsQ0FBQzNFLElBQWQsQ0FBbUI2RSxJQUFJLENBQUNqRCxJQUF4QixJQUFnQztBQUFDLFNBQUNpRCxJQUFJLENBQUMzRSxFQUFOLEdBQVc7QUFBQzhFLGVBQUssRUFBRTtBQUFSO0FBQVosT0FBaEM7QUFDRDs7QUFFRCxRQUFJSCxJQUFJLENBQUNBLElBQUksQ0FBQ2pELElBQU4sQ0FBSixDQUFnQnFELFdBQXBCLEVBQWlDO0FBQy9CLFVBQUlOLGFBQWEsQ0FBQ0MsUUFBZCxDQUF1QkMsSUFBSSxDQUFDakQsSUFBNUIsQ0FBSixFQUF1QztBQUNyQytDLHFCQUFhLENBQUNDLFFBQWQsQ0FBdUJDLElBQUksQ0FBQ2pELElBQTVCLEVBQWtDaUQsSUFBSSxDQUFDM0UsRUFBdkMsSUFBNkMsSUFBN0M7QUFDRCxPQUZELE1BRU87QUFDTHlFLHFCQUFhLENBQUNDLFFBQWQsQ0FBdUJDLElBQUksQ0FBQ2pELElBQTVCLElBQW9DO0FBQUMsV0FBQ2lELElBQUksQ0FBQzNFLEVBQU4sR0FBVztBQUFaLFNBQXBDO0FBQ0Q7QUFDRjtBQUNGLEdBbEJEO0FBb0JBLHNCQUNFdEMsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhGLFNBQXBCLEVBQStCO0FBQUM3RixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBL0IsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnFILDZDQUFwQixFQUE0QjtBQUM1QkMsb0JBQWdCLEVBQUVDLCtFQURVO0FBRTVCQyxvQkFBZ0IsRUFBRSxJQUZVO0FBRzVCQyxrQkFBYyxFQUFFLElBSFk7QUFJNUJDLG1CQUFlLEVBQUUsSUFKVztBQUs1QlosaUJBQWEsRUFBRUEsYUFMYTtBQU01QmEsc0JBQWtCLEVBQUUsSUFOUTtBQU81QkMsWUFBUSxFQUFFZixlQVBrQjtBQU9ENUcsVUFBTSxFQUFFLFNBUFA7QUFPYUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBUHZCLEdBQTVCLEVBU0UsQ0FBQztBQUNEeUgsV0FEQztBQUVEQyxnQkFGQztBQUdEQyxXQUhDO0FBSURDLGdCQUpDO0FBS0RDLGNBTEM7QUFNREMsVUFOQztBQU9EQyxVQVBDO0FBUURDO0FBUkMsR0FBRCxrQkFVQXJJLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JtRyxXQUFwQixFQUFpQztBQUFDbEcsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQWpDLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JrRyxTQUFwQixFQUErQjtBQUFDakcsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQS9CLEVBQW9HLFVBQXBHLENBREosRUFFSXdHLE1BQU0sQ0FBQ2pELEdBQVAsQ0FBWTBFLEtBQUQsSUFBVztBQUN0QjtBQUNBLFdBQU9BLEtBQUssQ0FBQ3RFLElBQU4sS0FBZWtELHFFQUFVLENBQUNxQixnQkFBMUIsZ0JBQ0x2SSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLEtBQXBCLEVBQTJCO0FBQUVnRSxTQUFHLEVBQUVxRSxLQUFLLENBQUNqRyxJQUFiO0FBQW1CbkMsWUFBTSxFQUFFLFNBQTNCO0FBQWlDQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQTNDLEtBQTNCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5RyxRQUFwQixFQUE4QjtBQUFDeEcsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUE5QixFQUFtR21JLDZFQUFZLENBQUN6RCxrRkFBcUIsQ0FBQ3VELEtBQUssQ0FBQ2pHLElBQVAsQ0FBdEIsRUFBb0MsRUFBcEMsQ0FBL0csQ0FESixlQUVJckMsNENBQUssQ0FBQ0MsYUFBTixDQUFvQndHLE9BQXBCLEVBQTZCO0FBQUN2RyxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTdCLEVBQ0VpSSxLQUFLLENBQUNBLEtBQUssQ0FBQ3RFLElBQVAsQ0FBTCxDQUFrQnlFLE9BQWxCLENBQTBCN0UsR0FBMUIsQ0FBOEIsQ0FBQzhFLE1BQUQsRUFBU0MsV0FBVCxrQkFDOUIzSSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CdUcsR0FBcEIsRUFBeUI7QUFBRXZDLFNBQUcsRUFBRTBFLFdBQVA7QUFBb0J6SSxZQUFNLEVBQUUsU0FBNUI7QUFBa0NDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBNUMsS0FBekIsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjJJLHVFQUFwQixFQUErQjtBQUMvQnZHLFVBQUksRUFBRWlHLEtBQUssQ0FBQ2hHLEVBRG1CO0FBRS9CQSxRQUFFLEVBQUVxRyxXQUYyQjtBQUcvQjdGLFdBQUssRUFBRTRGLE1BQU0sQ0FBQ3BHLEVBSGlCO0FBSS9CWCxXQUFLLEVBQUUrRyxNQUFNLENBQUNyRyxJQUppQjtBQUsvQndHLGNBQVEsRUFBRVosWUFMcUI7QUFNL0JhLGFBQU8sRUFBRUosTUFBTSxDQUFDcEcsRUFBUCxLQUFjNkYsTUFBTSxDQUFDRyxLQUFLLENBQUNoRyxFQUFQLENBTkU7QUFNVXBDLFlBQU0sRUFBRSxTQU5sQjtBQU13QkMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQU5sQyxLQUEvQixDQURKLENBREEsQ0FERixDQUZKLENBREssR0FrQkhpSSxLQUFLLENBQUN0RSxJQUFOLEtBQWVrRCxxRUFBVSxDQUFDNkIsa0JBQTFCLGdCQUNGL0ksNENBQUssQ0FBQ0MsYUFBTixDQUFvQixLQUFwQixFQUEyQjtBQUFFZ0UsU0FBRyxFQUFFcUUsS0FBSyxDQUFDakcsSUFBYjtBQUFtQm5DLFlBQU0sRUFBRSxTQUEzQjtBQUFpQ0MsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUEzQyxLQUEzQixlQUNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeUcsUUFBcEIsRUFBOEI7QUFBQ3hHLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBOUIsRUFBbUdtSSw2RUFBWSxDQUFDekQsa0ZBQXFCLENBQUN1RCxLQUFLLENBQUNqRyxJQUFQLENBQXRCLEVBQW9DLEVBQXBDLENBQS9HLENBREosZUFFSXJDLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J3RyxPQUFwQixFQUE2QjtBQUFDdkcsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUE3QixFQUNFaUksS0FBSyxDQUFDQSxLQUFLLENBQUN0RSxJQUFQLENBQUwsQ0FBa0J5RSxPQUFsQixDQUEwQjdFLEdBQTFCLENBQThCLENBQUM4RSxNQUFELEVBQVNDLFdBQVQsa0JBQzlCM0ksNENBQUssQ0FBQ0MsYUFBTixDQUFvQnVHLEdBQXBCLEVBQXlCO0FBQUV2QyxTQUFHLEVBQUUwRSxXQUFQO0FBQW9CekksWUFBTSxFQUFFLFNBQTVCO0FBQWtDQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQTVDLEtBQXpCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IrSSwwRUFBcEIsRUFBa0M7QUFDbEMzRyxVQUFJLEVBQUVpRyxLQUFLLENBQUNoRyxFQURzQjtBQUVsQ0EsUUFBRSxFQUFFb0csTUFBTSxDQUFDcEcsRUFGdUI7QUFHbENRLFdBQUssRUFBRTRGLE1BQU0sQ0FBQ3BHLEVBSG9CO0FBSWxDWCxXQUFLLEVBQUUrRyxNQUFNLENBQUNyRyxJQUpvQjtBQUtsQ3dHLGNBQVEsRUFBRVosWUFMd0I7QUFNbENhLGFBQU8sRUFBRVgsTUFBTSxDQUFDRyxLQUFLLENBQUNoRyxFQUFQLENBQU4sSUFBb0I2RixNQUFNLENBQUNHLEtBQUssQ0FBQ2hHLEVBQVAsQ0FBTixDQUFpQnlCLFFBQWpCLENBQTBCMkUsTUFBTSxDQUFDcEcsRUFBakMsQ0FOSztBQU1pQ3BDLFlBQU0sRUFBRSxTQU56QztBQU0rQ0MsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQU56RCxLQUFsQyxDQURKLENBREEsQ0FERixDQUZKLENBREUsR0FrQkFpSSxLQUFLLENBQUN0RSxJQUFOLEtBQWVrRCxxRUFBVSxDQUFDK0Isd0JBQTFCLGdCQUNGakosNENBQUssQ0FBQ0MsYUFBTixDQUFvQnNHLEtBQXBCLEVBQTJCO0FBQUV0QyxTQUFHLEVBQUVxRSxLQUFLLENBQUNqRyxJQUFiO0FBQW1CMkIsVUFBSSxFQUFFc0UsS0FBSyxDQUFDdEUsSUFBL0I7QUFBcUM5RCxZQUFNLEVBQUUsU0FBN0M7QUFBbURDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBN0QsS0FBM0IsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmMsS0FBcEIsRUFBMkI7QUFBQ2IsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUEzQixFQUFnR2lJLEtBQUssQ0FBQ2pHLElBQXRHLENBREosZUFFSXJDLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JpSiwwRUFBcEIsRUFBbUM7QUFDbkNwRyxXQUFLLEVBQ0hxRixNQUFNLElBQUlBLE1BQU0sQ0FBQy9GLElBQWpCLElBQXlCK0YsTUFBTSxDQUFDL0YsSUFBUCxDQUFZa0csS0FBSyxDQUFDdEUsSUFBbEIsQ0FBekIsR0FDSW1FLE1BQU0sQ0FBQy9GLElBQVAsQ0FBWWtHLEtBQUssQ0FBQ3RFLElBQWxCLEVBQXdCc0UsS0FBSyxDQUFDaEcsRUFBOUIsQ0FESixHQUVJLElBSjZCO0FBTW5DNkcsaUJBQVcsRUFDVGIsS0FBSyxDQUFDQSxLQUFLLENBQUN0RSxJQUFQLENBQUwsQ0FBa0JtRixXQUFsQixHQUNJYixLQUFLLENBQUNBLEtBQUssQ0FBQ3RFLElBQVAsQ0FBTCxDQUFrQm1GLFdBRHRCLEdBRUlDLHdFQUFhLENBQUNkLEtBQUssQ0FBQ3RFLElBQVAsQ0FUZ0I7QUFXbkMzQixVQUFJLEVBQUcsUUFBT2lHLEtBQUssQ0FBQ3RFLElBQUssS0FBSXNFLEtBQUssQ0FBQ2hHLEVBQUcsR0FYSDtBQVluQytHLFdBQUssRUFDSHZCLE9BQU8sSUFDUEEsT0FBTyxDQUFDMUYsSUFEUixJQUVBMEYsT0FBTyxDQUFDMUYsSUFBUixDQUFha0csS0FBSyxDQUFDdEUsSUFBbkIsQ0FGQSxJQUdBOEQsT0FBTyxDQUFDMUYsSUFBUixDQUFha0csS0FBSyxDQUFDdEUsSUFBbkIsRUFBeUJzRSxLQUFLLENBQUNoRyxFQUEvQixDQUhBLElBSUE4RixNQUpBLElBS0FBLE1BQU0sQ0FBQ2hHLElBTFAsSUFNQWdHLE1BQU0sQ0FBQ2hHLElBQVAsQ0FBWWtHLEtBQUssQ0FBQ3RFLElBQWxCLENBTkEsSUFPQW9FLE1BQU0sQ0FBQ2hHLElBQVAsQ0FBWWtHLEtBQUssQ0FBQ3RFLElBQWxCLEVBQXdCc0UsS0FBSyxDQUFDaEcsRUFBOUIsQ0FwQmlDO0FBc0JuQ2dILHNCQUFnQixFQUFFLElBdEJpQjtBQXVCbkNULGNBQVEsRUFBRVosWUF2QnlCO0FBd0JuQ3NCLFlBQU0sRUFBRXJCLFVBeEIyQjtBQXlCbkNzQixhQUFPLEVBQUUsQ0F6QjBCO0FBeUJ2QnRKLFlBQU0sRUFBRSxTQXpCZTtBQXlCVEMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQXpCRCxLQUFuQyxDQUZKLENBREUsR0ErQkFpSSxLQUFLLENBQUN0RSxJQUFOLEtBQWVrRCxxRUFBVSxDQUFDQyxjQUExQixnQkFDRm5ILDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JzRyxLQUFwQixFQUEyQjtBQUFFdEMsU0FBRyxFQUFFcUUsS0FBSyxDQUFDakcsSUFBYjtBQUFtQjJCLFVBQUksRUFBRXNFLEtBQUssQ0FBQ3RFLElBQS9CO0FBQXFDOUQsWUFBTSxFQUFFLFNBQTdDO0FBQW1EQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQTdELEtBQTNCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JjLEtBQXBCLEVBQTJCO0FBQUNiLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBM0IsRUFBZ0dpSSxLQUFLLENBQUNqRyxJQUF0RyxDQURKLGVBRUlyQyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd0osdUVBQXBCLEVBQWdDO0FBQ2hDM0csV0FBSyxFQUNIcUYsTUFBTSxJQUNOQSxNQUFNLENBQUMvRixJQURQLElBRUErRixNQUFNLENBQUMvRixJQUFQLENBQVlrRyxLQUFLLENBQUN0RSxJQUFsQixDQUZBLElBR0FtRSxNQUFNLENBQUMvRixJQUFQLENBQVlrRyxLQUFLLENBQUN0RSxJQUFsQixFQUF3QnNFLEtBQUssQ0FBQ2hHLEVBQTlCLENBSEEsR0FJSTZGLE1BQU0sQ0FBQy9GLElBQVAsQ0FBWWtHLEtBQUssQ0FBQ3RFLElBQWxCLEVBQXdCc0UsS0FBSyxDQUFDaEcsRUFBOUIsRUFBa0MsT0FBbEMsQ0FKSixHQUtJLEtBUDBCO0FBU2hDNkcsaUJBQVcsRUFDVGIsS0FBSyxDQUFDQSxLQUFLLENBQUN0RSxJQUFQLENBQUwsQ0FBa0JtRixXQUFsQixHQUNJYixLQUFLLENBQUNBLEtBQUssQ0FBQ3RFLElBQVAsQ0FBTCxDQUFrQm1GLFdBRHRCLEdBRUlDLHdFQUFhLENBQUNkLEtBQUssQ0FBQ3RFLElBQVAsQ0FaYTtBQWNoQ0EsVUFBSSxFQUFFc0UsS0FBSyxDQUFDdEUsSUFkb0I7QUFlaEM2QyxZQUFNLEVBQUVzQixNQUFNLENBQUMvRixJQUFQLENBQVlrRyxLQUFLLENBQUN0RSxJQUFsQixFQUF3QjZDLE1BZkE7QUFnQmhDeEUsVUFBSSxFQUFHLFFBQU9pRyxLQUFLLENBQUN0RSxJQUFLLEtBQUlzRSxLQUFLLENBQUNoRyxFQUFHLFVBaEJOO0FBaUJoQytHLFdBQUssRUFDSGpCLE1BQU0sSUFBSUEsTUFBTSxDQUFDaEcsSUFBakIsSUFBeUJnRyxNQUFNLENBQUNoRyxJQUFQLENBQVlrRyxLQUFLLENBQUN0RSxJQUFsQixDQUF6QixHQUNJb0UsTUFBTSxDQUFDaEcsSUFBUCxDQUFZa0csS0FBSyxDQUFDdEUsSUFBbEIsRUFBd0JzRSxLQUFLLENBQUNoRyxFQUE5QixDQURKLEdBRUksRUFwQjBCO0FBc0JoQ2dILHNCQUFnQixFQUFFLElBdEJjO0FBdUJoQ1QsY0FBUSxFQUFFWixZQXZCc0I7QUF3QmhDc0IsWUFBTSxFQUFFckIsVUF4QndCO0FBeUJoQ3dCLHFCQUFlLEVBQUU7QUFBQ3RLLGFBQUssRUFBRTtBQUFSLE9BekJlO0FBeUJFYyxZQUFNLEVBQUUsU0F6QlY7QUF5QmdCQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBekIxQixLQUFoQyxDQUZKLENBREUsR0ErQkFpSSxLQUFLLENBQUN0RSxJQUFOLEtBQWVrRCxxRUFBVSxDQUFDeUMsU0FBMUIsZ0JBQ0YzSiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc0csS0FBcEIsRUFBMkI7QUFBRXRDLFNBQUcsRUFBRXFFLEtBQUssQ0FBQ2pHLElBQWI7QUFBbUIyQixVQUFJLEVBQUVzRSxLQUFLLENBQUN0RSxJQUEvQjtBQUFxQzlELFlBQU0sRUFBRSxTQUE3QztBQUFtREMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUE3RCxLQUEzQixlQUNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CYyxLQUFwQixFQUEyQjtBQUFDYixZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTNCLEVBQWdHaUksS0FBSyxDQUFDakcsSUFBdEcsQ0FESixlQUVJckMsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjJKLHdFQUFwQixFQUFnQztBQUNoQ0MsZ0JBQVUsRUFBRSxJQURvQjtBQUVoQy9HLFdBQUssRUFDSHFGLE1BQU0sSUFBSUEsTUFBTSxDQUFDL0YsSUFBakIsSUFBeUIrRixNQUFNLENBQUMvRixJQUFQLENBQVlrRyxLQUFLLENBQUN0RSxJQUFsQixDQUF6QixHQUNJbUUsTUFBTSxDQUFDL0YsSUFBUCxDQUFZa0csS0FBSyxDQUFDdEUsSUFBbEIsRUFBd0JzRSxLQUFLLENBQUNoRyxFQUE5QixDQURKLEdBRUksRUFMMEI7QUFPaEM2RyxpQkFBVyxFQUNUYixLQUFLLENBQUNBLEtBQUssQ0FBQ3RFLElBQVAsQ0FBTCxDQUFrQm1GLFdBQWxCLEdBQ0liLEtBQUssQ0FBQ0EsS0FBSyxDQUFDdEUsSUFBUCxDQUFMLENBQWtCbUYsV0FEdEIsR0FFSUMsd0VBQWEsQ0FBQ2QsS0FBSyxDQUFDdEUsSUFBUCxDQVZhO0FBWWhDM0IsVUFBSSxFQUFHLFFBQU9pRyxLQUFLLENBQUN0RSxJQUFLLEtBQUlzRSxLQUFLLENBQUNoRyxFQUFHLEdBWk47QUFhaEN1RSxZQUFNLEVBQUV5QixLQUFLLENBQUNBLEtBQUssQ0FBQ3RFLElBQVAsQ0FBTCxDQUFrQjZDLE1BYk07QUFjaEN3QyxXQUFLLEVBQ0hqQixNQUFNLElBQUlBLE1BQU0sQ0FBQ2hHLElBQWpCLElBQXlCZ0csTUFBTSxDQUFDaEcsSUFBUCxDQUFZa0csS0FBSyxDQUFDdEUsSUFBbEIsQ0FBekIsR0FDSW9FLE1BQU0sQ0FBQ2hHLElBQVAsQ0FBWWtHLEtBQUssQ0FBQ3RFLElBQWxCLEVBQXdCc0UsS0FBSyxDQUFDaEcsRUFBOUIsQ0FESixHQUVJLEVBakIwQjtBQW1CaEMrRixtQkFBYSxFQUFFQSxhQW5CaUI7QUFtQkZuSSxZQUFNLEVBQUUsU0FuQk47QUFtQllDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFuQnRCLEtBQWhDLENBRkosQ0FERSxHQXlCQWlJLEtBQUssQ0FBQ3RFLElBQU4sS0FBZWtELHFFQUFVLENBQUM0QyxJQUExQixnQkFDRjlKLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JzRyxLQUFwQixFQUEyQjtBQUFFdEMsU0FBRyxFQUFFcUUsS0FBSyxDQUFDakcsSUFBYjtBQUFtQjJCLFVBQUksRUFBRXNFLEtBQUssQ0FBQ3RFLElBQS9CO0FBQXFDOUQsWUFBTSxFQUFFLFNBQTdDO0FBQW1EQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQTdELEtBQTNCLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JjLEtBQXBCLEVBQTJCO0FBQUNiLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBM0IsRUFBZ0dpSSxLQUFLLENBQUNqRyxJQUF0RyxDQURKLGVBRUlyQyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9COEosd0VBQXBCLEVBQWdDO0FBQ2hDRixnQkFBVSxFQUFFLElBRG9CO0FBRWhDL0csV0FBSyxFQUNIcUYsTUFBTSxJQUFJQSxNQUFNLENBQUMvRixJQUFqQixJQUF5QitGLE1BQU0sQ0FBQy9GLElBQVAsQ0FBWWtHLEtBQUssQ0FBQ3RFLElBQWxCLENBQXpCLEdBQ0ltRSxNQUFNLENBQUMvRixJQUFQLENBQVlrRyxLQUFLLENBQUN0RSxJQUFsQixFQUF3QnNFLEtBQUssQ0FBQ2hHLEVBQTlCLENBREosR0FFSSxFQUwwQjtBQU9oQzZHLGlCQUFXLEVBQ1RiLEtBQUssQ0FBQ0EsS0FBSyxDQUFDdEUsSUFBUCxDQUFMLENBQWtCbUYsV0FBbEIsR0FDSWIsS0FBSyxDQUFDQSxLQUFLLENBQUN0RSxJQUFQLENBQUwsQ0FBa0JtRixXQUR0QixHQUVJQyx3RUFBYSxDQUFDZCxLQUFLLENBQUN0RSxJQUFQLENBVmE7QUFZaEMzQixVQUFJLEVBQUcsUUFBT2lHLEtBQUssQ0FBQ3RFLElBQUssS0FBSXNFLEtBQUssQ0FBQ2hHLEVBQUcsR0FaTjtBQWFoQytHLFdBQUssRUFDSGpCLE1BQU0sSUFBSUEsTUFBTSxDQUFDaEcsSUFBakIsSUFBeUJnRyxNQUFNLENBQUNoRyxJQUFQLENBQVlrRyxLQUFLLENBQUN0RSxJQUFsQixDQUF6QixHQUNJb0UsTUFBTSxDQUFDaEcsSUFBUCxDQUFZa0csS0FBSyxDQUFDdEUsSUFBbEIsRUFBd0JzRSxLQUFLLENBQUNoRyxFQUE5QixDQURKLEdBRUksRUFoQjBCO0FBa0JoQytGLG1CQUFhLEVBQUVBLGFBbEJpQjtBQWtCRm5JLFlBQU0sRUFBRSxTQWxCTjtBQWtCWUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQWxCdEIsS0FBaEMsQ0FGSixDQURFLGdCQXlCRkwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnNHLEtBQXBCLEVBQTJCO0FBQUV0QyxTQUFHLEVBQUVxRSxLQUFLLENBQUNqRyxJQUFiO0FBQW1CMkIsVUFBSSxFQUFFc0UsS0FBSyxDQUFDdEUsSUFBL0I7QUFBcUM5RCxZQUFNLEVBQUUsU0FBN0M7QUFBbURDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBN0QsS0FBM0IsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmMsS0FBcEIsRUFBMkI7QUFBQ2IsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUEzQixFQUFnR2lJLEtBQUssQ0FBQ2pHLElBQXRHLENBREosRUFFSWlHLEtBQUssQ0FBQ3RFLElBQU4sS0FBZWtELHFFQUFVLENBQUM4QyxJQUExQixnQkFDQWhLLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J3Six1RUFBcEIsRUFBZ0M7QUFDOUIzRyxXQUFLLEVBQ0hxRixNQUFNLElBQUlBLE1BQU0sQ0FBQy9GLElBQWpCLElBQXlCK0YsTUFBTSxDQUFDL0YsSUFBUCxDQUFZa0csS0FBSyxDQUFDdEUsSUFBbEIsQ0FBekIsR0FDSW1FLE1BQU0sQ0FBQy9GLElBQVAsQ0FBWWtHLEtBQUssQ0FBQ3RFLElBQWxCLEVBQXdCc0UsS0FBSyxDQUFDaEcsRUFBOUIsQ0FESixHQUVJLEVBSndCO0FBTTlCNkcsaUJBQVcsRUFDVGIsS0FBSyxDQUFDQSxLQUFLLENBQUN0RSxJQUFQLENBQUwsQ0FBa0JtRixXQUFsQixHQUNJYixLQUFLLENBQUNBLEtBQUssQ0FBQ3RFLElBQVAsQ0FBTCxDQUFrQm1GLFdBRHRCLEdBRUlDLHdFQUFhLENBQUNkLEtBQUssQ0FBQ3RFLElBQVAsQ0FUVztBQVc5QkEsVUFBSSxFQUFFc0UsS0FBSyxDQUFDdEUsSUFBTixLQUFlLFFBQWYsR0FBMEIsUUFBMUIsR0FBcUMsTUFYYjtBQVk5QjZDLFlBQU0sRUFBRXNCLE1BQU0sQ0FBQy9GLElBQVAsQ0FBWWtHLEtBQUssQ0FBQ3RFLElBQWxCLEVBQXdCNkMsTUFaRjtBQWE5QnhFLFVBQUksRUFBRyxRQUFPaUcsS0FBSyxDQUFDdEUsSUFBSyxLQUFJc0UsS0FBSyxDQUFDaEcsRUFBRyxHQWJSO0FBYzlCK0csV0FBSyxFQUNIakIsTUFBTSxJQUFJQSxNQUFNLENBQUNoRyxJQUFqQixJQUF5QmdHLE1BQU0sQ0FBQ2hHLElBQVAsQ0FBWWtHLEtBQUssQ0FBQ3RFLElBQWxCLENBQXpCLEdBQ0lvRSxNQUFNLENBQUNoRyxJQUFQLENBQVlrRyxLQUFLLENBQUN0RSxJQUFsQixFQUF3QnNFLEtBQUssQ0FBQ2hHLEVBQTlCLENBREosR0FFSSxFQWpCd0I7QUFtQjlCZ0gsc0JBQWdCLEVBQUUsSUFuQlk7QUFvQjlCVCxjQUFRLEVBQUVaLFlBcEJvQjtBQXFCOUJzQixZQUFNLEVBQUVyQixVQXJCc0I7QUFzQjlCd0IscUJBQWUsRUFBRTtBQUFDdEssYUFBSyxFQUFFO0FBQVIsT0F0QmE7QUFzQkljLFlBQU0sRUFBRSxTQXRCWjtBQXNCa0JDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUF0QjVCLEtBQWhDLENBREEsZ0JBMEJBTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CaUosMEVBQXBCLEVBQW1DO0FBQ2pDcEcsV0FBSyxFQUFFcUYsTUFBTSxDQUFDRyxLQUFLLENBQUNoRyxFQUFQLENBQU4sSUFBb0IsRUFETTtBQUVqQzZHLGlCQUFXLEVBQ1RiLEtBQUssQ0FBQ0EsS0FBSyxDQUFDdEUsSUFBUCxDQUFMLENBQWtCbUYsV0FBbEIsR0FDSWIsS0FBSyxDQUFDQSxLQUFLLENBQUN0RSxJQUFQLENBQUwsQ0FBa0JtRixXQUR0QixHQUVJQyx3RUFBYSxDQUFDZCxLQUFLLENBQUN0RSxJQUFQLENBTGM7QUFPakMzQixVQUFJLEVBQUVpRyxLQUFLLENBQUNoRyxFQVBxQjtBQVFqQ3VHLGNBQVEsRUFBRVosWUFSdUI7QUFTakNzQixZQUFNLEVBQUVyQixVQVR5QjtBQVVqQ3NCLGFBQU8sRUFBRSxDQVZ3QjtBQVVyQnRKLFlBQU0sRUFBRSxTQVZhO0FBVVBDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFWSCxLQUFuQyxDQTVCSixDQXBKRjtBQStMRCxHQWpNQyxDQUZKLGVBb01JTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CcUcsaUJBQXBCLEVBQXVDO0FBQUNwRyxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBdkMsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmdLLDRFQUFwQixFQUFxQztBQUFFakcsUUFBSSxFQUFFLFFBQVI7QUFBa0JwQyxXQUFPLEVBQUVnRixXQUEzQjtBQUF3QzFHLFVBQU0sRUFBRSxTQUFoRDtBQUFzREMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQWhFLEdBQXJDLEVBQWlKLFFBQWpKLENBREYsZUFJRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQksscUVBQXBCLEVBQWdDO0FBQUUwRCxRQUFJLEVBQUUsUUFBUjtBQUFrQnBHLFlBQVEsRUFBRSxDQUFDb0ssT0FBRCxJQUFZRCxZQUF4QztBQUFzRDdILFVBQU0sRUFBRSxTQUE5RDtBQUFvRUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQTlFLEdBQWhDLEVBQTBKLFFBQTFKLENBSkYsQ0FwTUosQ0FuQkYsQ0FESixDQURGO0FBc09ELENBOVBEOztBQWdRZXNHLDBFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pWQSxNQUFNN0gsWUFBWSxHQUFHLDBFQUFyQjtBQUFnRztBQUVoRztBQUNBO0FBQ0E7O0FBT0EsTUFBTW9MLFNBQVMsR0FBRyxDQUFDO0FBQUNDLFFBQUQ7QUFBU0M7QUFBVCxDQUFELEtBQXdCO0FBQ3hDLE1BQUlwTSxlQUFKOztBQUVBLFVBQVFtTSxNQUFSO0FBQ0UsU0FBS0Usc0VBQVksQ0FBQ0MsSUFBbEI7QUFDRXRNLHFCQUFlLEdBQUd1TSx1RUFBYyxDQUFDRCxJQUFqQztBQUNBOztBQUNGLFNBQUtELHNFQUFZLENBQUNHLFdBQWxCO0FBQ0V4TSxxQkFBZSxHQUFHdU0sdUVBQWMsQ0FBQ0MsV0FBakM7QUFDQTs7QUFDRixTQUFLSCxzRUFBWSxDQUFDSSxHQUFsQjtBQUNFek0scUJBQWUsR0FBR3VNLHVFQUFjLENBQUNFLEdBQWpDO0FBQ0E7O0FBQ0YsU0FBS0osc0VBQVksQ0FBQ0ssU0FBbEI7QUFDRTFNLHFCQUFlLEdBQUd1TSx1RUFBYyxDQUFDRyxTQUFqQztBQUNBOztBQUNGO0FBQ0UxTSxxQkFBZSxHQUFHdU0sdUVBQWMsQ0FBQ0MsV0FBakM7QUFkSjs7QUFpQkEsUUFBTUcsR0FBRyxHQUFHO0FBQUE7QUFBQTtBQUNWaE0sV0FBTyxFQUFFLFVBREM7QUFFVkgsZ0JBQVksRUFBRSxDQUZKO0FBR1ZRLFdBQU8sRUFBRSxjQUhDO0FBSVZaLFlBQVEsRUFBRSxFQUpBO0FBS1ZELGNBQVUsRUFBRSxHQUxGO0FBTVZ5TSxpQkFBYSxFQUFFLFdBTkw7QUFPVjdNLFNBQUssRUFBRSxNQVBHO0FBUVY4SCxjQUFVLEVBQUUsTUFSRjtBQVNWN0g7QUFUVSxLQVVOb00sUUFBUSxJQUFJO0FBQUM3TCxVQUFNLEVBQUU7QUFBVCxHQVZOLEVBQVo7O0FBYUEsc0JBQU95Qiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMEssR0FBcEIsRUFBeUI7QUFBQ3pLLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUF6QixFQUE2RndLLDhFQUFjLENBQUNWLE1BQUQsQ0FBM0csQ0FBUDtBQUNELENBbENEOztBQW9DZUQsd0VBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0NBLE1BQU1wTCxZQUFZLEdBQUcsb0ZBQXJCOztBQUEyRyxTQUFTNEQsY0FBVCxDQUF3QkMsR0FBeEIsRUFBNkI7QUFBRSxNQUFJQyxhQUFhLEdBQUdDLFNBQXBCO0FBQStCLE1BQUlDLEtBQUssR0FBR0gsR0FBRyxDQUFDLENBQUQsQ0FBZjtBQUFvQixNQUFJSSxDQUFDLEdBQUcsQ0FBUjs7QUFBVyxTQUFPQSxDQUFDLEdBQUdKLEdBQUcsQ0FBQ0ssTUFBZixFQUF1QjtBQUFFLFVBQU1DLEVBQUUsR0FBR04sR0FBRyxDQUFDSSxDQUFELENBQWQ7QUFBbUIsVUFBTUcsRUFBRSxHQUFHUCxHQUFHLENBQUNJLENBQUMsR0FBRyxDQUFMLENBQWQ7QUFBdUJBLEtBQUMsSUFBSSxDQUFMOztBQUFRLFFBQUksQ0FBQ0UsRUFBRSxLQUFLLGdCQUFQLElBQTJCQSxFQUFFLEtBQUssY0FBbkMsS0FBc0RILEtBQUssSUFBSSxJQUFuRSxFQUF5RTtBQUFFLGFBQU9ELFNBQVA7QUFBbUI7O0FBQUMsUUFBSUksRUFBRSxLQUFLLFFBQVAsSUFBbUJBLEVBQUUsS0FBSyxnQkFBOUIsRUFBZ0Q7QUFBRUwsbUJBQWEsR0FBR0UsS0FBaEI7QUFBdUJBLFdBQUssR0FBR0ksRUFBRSxDQUFDSixLQUFELENBQVY7QUFBb0IsS0FBN0YsTUFBbUcsSUFBSUcsRUFBRSxLQUFLLE1BQVAsSUFBaUJBLEVBQUUsS0FBSyxjQUE1QixFQUE0QztBQUFFSCxXQUFLLEdBQUdJLEVBQUUsQ0FBQyxDQUFDLEdBQUdDLElBQUosS0FBYUwsS0FBSyxDQUFDTSxJQUFOLENBQVdSLGFBQVgsRUFBMEIsR0FBR08sSUFBN0IsQ0FBZCxDQUFWO0FBQTZEUCxtQkFBYSxHQUFHQyxTQUFoQjtBQUE0QjtBQUFFOztBQUFDLFNBQU9DLEtBQVA7QUFBZTs7QUFBQTtBQUU5bUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBQ0E7QUFDQWdJLDZDQUFLLENBQUNDLE1BQU4sQ0FBYUMsaUVBQWI7O0FBNEJBLE1BQU1DLElBQUksR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBYjs7QUFPQSxNQUFNQyxNQUFNLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQWY7O0FBU0EsTUFBTUMsT0FBTyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFoQjs7QUFLQSxNQUFNQyxVQUFVLEdBQUcsa0ZBQU8zTixzRUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBbkI7O0FBTUEsTUFBTTROLFdBQVcsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBcEI7O0FBVUEsTUFBTUMsU0FBUyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFsQjs7QUFPQSxNQUFNQyxlQUFlLEdBQUcsa0ZBQU9ELFNBQVA7QUFBQTtBQUFBLEdBQWtCO0FBQ3hDbk4sWUFBVSxFQUFFLEdBRDRCO0FBRXhDQyxVQUFRLEVBQUUsTUFGOEI7QUFHeENvTixZQUFVLEVBQUcsYUFBWXZOLDZEQUFPLENBQUN3TixXQUFZLEVBSEw7QUFJeENDLGFBQVcsRUFBRTtBQUoyQixDQUFsQixDQUF4Qjs7QUFPQSxNQUFNQyxZQUFZLEdBQUcsa0ZBQU9KLGVBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXJCOztBQUtBLE1BQU1LLGNBQWMsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBdkI7O0FBT0EsTUFBTUMsY0FBYyxHQUFHO0FBQUE7QUFBQSxHQUFXO0FBQ2hDcE4sUUFBTSxFQUFHLGFBQVlSLDZEQUFPLENBQUN3TixXQUFZLEVBRFQ7QUFFaEM1TixRQUFNLEVBQUUsMkJBRndCO0FBR2hDaU8sV0FBUyxFQUFFLEdBSHFCO0FBSWhDOU0sU0FBTyxFQUFFLE1BSnVCO0FBS2hDQyxlQUFhLEVBQUUsUUFMaUI7QUFNaENULGNBQVksRUFBRTtBQU5rQixDQUFYLENBQXZCOztBQVNBLE1BQU11TixZQUFZLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXJCOztBQVVBLE1BQU1DLElBQUksR0FBRztBQUFBO0FBQUEsR0FBVztBQUN0Qm5PLFFBQU0sRUFBRSxFQURjO0FBRXRCYyxTQUFPLEVBQUUsUUFGYTtBQUd0QnNOLGNBQVksRUFBRyxhQUFZaE8sNkRBQU8sQ0FBQ3dOLFdBQVksRUFIekI7QUFJdEJ6TSxTQUFPLEVBQUUsTUFKYTtBQUt0QmtOLFFBQU0sRUFBRSxTQUxjO0FBTXRCLFlBQVU7QUFDUmxPLG1CQUFlLEVBQUU7QUFEVDtBQU5ZLENBQVgsQ0FBYjs7QUFXQSxNQUFNbU8sUUFBUSxHQUFHO0FBQUE7QUFBQSxHQUFXO0FBQzFCL04sVUFBUSxFQUFFLE1BRGdCO0FBRTFCTCxPQUFLLEVBQUcsR0FBRUUsNkRBQU8sQ0FBQzRDLFNBQVUsRUFGRjtBQUcxQjZLLGFBQVcsRUFBRSxFQUhhO0FBSTFCdk4sWUFBVSxFQUFFLEdBSmM7QUFLMUJhLFNBQU8sRUFBRSxNQUxpQjtBQU0xQkUsWUFBVSxFQUFFO0FBTmMsQ0FBWCxDQUFqQjs7QUFTQSxNQUFNa04sRUFBRSxHQUFHO0FBQUE7QUFBQSxHQUFZO0FBQ3JCck8sT0FBSyxFQUFHLEdBQUVFLDZEQUFPLENBQUNDLFlBQWE7QUFEVixDQUFaLENBQVg7O0FBSUEsTUFBTW1PLFVBQVUsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBbkI7O0FBSUEsTUFBTUMsSUFBSSxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFiOztBQU9BLE1BQU1DLFdBQVcsR0FBRztBQUFBO0FBQUEsR0FBWTtBQUM5QnhPLE9BQUssRUFBRyxHQUFFRSw2REFBTyxDQUFDQyxZQUFhLEVBREQ7QUFFOUJFLFVBQVEsRUFBRSxFQUZvQjtBQUc5Qm9PLFdBQVMsRUFBRSxRQUhtQjtBQUk5QnJPLFlBQVUsRUFBRSxHQUprQjtBQUs5QnNPLFdBQVMsRUFBRTtBQUxtQixDQUFaLENBQXBCOztBQVFBLE1BQU1DLEtBQUssR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBZDs7QUFLQSxNQUFNQyxVQUFVLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQW5COztBQUlBLE1BQU1DLG1CQUFtQixHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUE1Qjs7QUFPQSxNQUFNQyx5QkFBeUIsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBbEM7O0FBUUEsTUFBTUMsbUJBQW1CLEdBQUcsa0ZBQU83Qyw2RUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBNUI7O0FBSUEsTUFBTXRKLFVBQVUsR0FBRyxrRkFBT0MsaUVBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQW5COztBQU1BLE1BQU1tTSxjQUFjLEdBQUcsa0ZBQU9uTSxpRUFBUDtBQUFBO0FBQUEsR0FBYTtBQUNsQ3hDLFVBQVEsRUFBRSxFQUR3QjtBQUVsQ2MsWUFBVSxFQUFFLFFBRnNCO0FBR2xDWCxRQUFNLEVBQUUsZUFIMEI7QUFJbEMyTixRQUFNLEVBQUUsU0FKMEI7QUFLbEMsWUFBVTtBQUNSbk8sU0FBSyxFQUFFRSw2REFBTyxDQUFDQztBQURQO0FBTHdCLENBQWIsQ0FBdkI7O0FBVUEsTUFBTThPLEtBQUssR0FBSXpNLEtBQUQsSUFBVztBQUN2QixRQUFNO0FBQ0owTSxTQURJO0FBRUoxSixTQUZJO0FBR0oySixpQkFISTtBQUlKaE0sV0FKSTtBQUtKaU0sZUFMSTtBQU1KQyxtQkFOSTtBQU9KdkcsVUFQSTtBQVFKd0csU0FSSTtBQVNKQyxZQVRJO0FBVUpDLGVBVkk7QUFXSkMsUUFYSTtBQVlKQyxXQVpJO0FBYUpDLFlBYkk7QUFjSkMsb0JBZEk7QUFlSkM7QUFmSSxNQWdCRnJOLEtBaEJKO0FBa0JBLFFBQU07QUFBQ3NOLGNBQVUsRUFBRUMsU0FBYjtBQUF3QkMsZ0JBQVksRUFBRUM7QUFBdEMsTUFBcUR6SyxLQUEzRDtBQUVBLFFBQU0sQ0FBQzBLLGFBQUQsRUFBZ0JDLGdCQUFoQixJQUFvQ0Msc0RBQVEsQ0FBQ0gsV0FBVyxJQUFJLEVBQWhCLENBQWxEO0FBRUEsUUFBTUksU0FBUyxHQUFHQywwRUFBWSxFQUE5QjtBQUNBLFFBQU07QUFBQy9NO0FBQUQsTUFBWUMsc0VBQVMsRUFBM0I7QUFDQSxRQUFNO0FBQUMrTSxjQUFEO0FBQWFDLGFBQWI7QUFBd0J0TixhQUF4QjtBQUFtQ3VOO0FBQW5DLE1BQW1EQyxxRUFBTyxDQUFDQyxtRUFBWSxDQUFDQyxVQUFkLEVBQTBCO0FBQ3hGQyxjQUFVLEVBQUU7QUFENEUsR0FBMUIsQ0FBaEU7QUFHQSxRQUFNO0FBQUNDLGVBQUQ7QUFBY0wsZ0JBQVksRUFBRU0sbUJBQTVCO0FBQWlEbEk7QUFBakQsTUFBZ0VtSSxzRUFBUSxDQUFDO0FBQUNDLFlBQVEsRUFBRTtBQUFYLEdBQUQsQ0FBOUU7QUFDQSxRQUFNO0FBQ0pILGVBQVcsRUFBRUksbUJBRFQ7QUFFSlQsZ0JBQVksRUFBRVUsd0JBRlY7QUFHSnRJLGVBQVcsRUFBRXVJO0FBSFQsTUFJRkosc0VBQVEsQ0FBQyxFQUFELENBSlo7QUFLQSxRQUFNO0FBQ0pGLGVBQVcsRUFBRU8sa0JBRFQ7QUFFSlosZ0JBQVksRUFBRWEsbUJBRlY7QUFHSnpJLGVBQVcsRUFBRTBJO0FBSFQsTUFJRlAsc0VBQVEsRUFKWjtBQU1BLFFBQU07QUFDSkYsZUFBVyxFQUFFVSx1QkFEVDtBQUVKZixnQkFBWSxFQUFFZ0Isd0JBRlY7QUFHSjVJLGVBQVcsRUFBRTZJO0FBSFQsTUFJRlYsc0VBQVEsRUFKWjtBQU1BLFFBQU07QUFDSlQsY0FBVSxFQUFFb0IsZ0JBRFI7QUFFSm5CLGFBQVMsRUFBRW9CLG1CQUZQO0FBR0oxTyxhQUFTLEVBQUUyTyxlQUhQO0FBSUpwQixnQkFBWSxFQUFFcUI7QUFKVixNQUtGcEIscUVBQU8sQ0FBQ0MsbUVBQVksQ0FBQ29CLFdBQWQsRUFBMkI7QUFDcENsQixjQUFVLEVBQUU7QUFEd0IsR0FBM0IsQ0FMWDs7QUFTQSxRQUFNOUgsZUFBZSxHQUFHLE1BQU9xQixNQUFQLElBQWtCO0FBQ3hDLFVBQU00SCxVQUFVLEdBQUcsRUFBbkI7QUFDQWxKLFVBQU0sQ0FBQ21KLE9BQVAsQ0FBZSxDQUFDO0FBQUMxTixRQUFEO0FBQUswQixVQUFMO0FBQVczQjtBQUFYLEtBQUQsS0FBc0I7QUFDbkMsVUFBSVMsS0FBSyxHQUFHcUYsTUFBTSxDQUFDN0YsRUFBRCxDQUFsQjs7QUFDQSxVQUFJNkYsTUFBTSxDQUFDL0YsSUFBUCxJQUFlK0YsTUFBTSxDQUFDL0YsSUFBUCxDQUFZNEIsSUFBWixDQUFmLElBQW9DbUUsTUFBTSxDQUFDL0YsSUFBUCxDQUFZNEIsSUFBWixFQUFrQjFCLEVBQWxCLENBQXhDLEVBQStEO0FBQzdEUSxhQUFLLEdBQUdxRixNQUFNLENBQUMvRixJQUFQLENBQVk0QixJQUFaLEVBQWtCMUIsRUFBbEIsQ0FBUjtBQUNEOztBQUVELFlBQU0yTixTQUFTLEdBQUc7QUFBQzNOLFVBQUQ7QUFBSzBCLFlBQUw7QUFBVzNCLFlBQVg7QUFBaUIsU0FBQzJCLElBQUQsR0FBUTtBQUFDbEI7QUFBRDtBQUF6QixPQUFsQjtBQUNBaU4sZ0JBQVUsQ0FBQ2xPLElBQVgsQ0FBZ0JvTyxTQUFoQjtBQUNELEtBUkQ7QUFVQSxVQUFNQyxPQUFPLEdBQUc7QUFDZEMsWUFBTSxFQUFFLE1BRE07QUFFZC9OLFVBQUksRUFBRTtBQUFDQSxZQUFJLEVBQUVnTyw2RUFBWSxDQUFDTCxVQUFELENBQVosQ0FBeUJuTSxHQUF6QixDQUE2QnlNLHdFQUE3QjtBQUFQO0FBRlEsS0FBaEI7QUFLQSxVQUFNQyxHQUFHLEdBQUcsTUFBTWxDLFNBQVMsQ0FBQ21DLFdBQVYsQ0FBdUIsU0FBUXRELEtBQU0sV0FBVS9MLE9BQVEsYUFBdkQsRUFBcUVnUCxPQUFyRSxDQUFsQjs7QUFFQSxRQUFJSSxHQUFHLENBQUNsSSxNQUFSLEVBQWdCO0FBQ2Q3SCxXQUFLLENBQUNpUSxzQkFBTixDQUE2QixtQkFBN0I7QUFDRDs7QUFFREYsT0FBRyxDQUFDbEksTUFBSixJQUFjeEIsV0FBVyxFQUF6QjtBQUVBLFVBQU02SixnQkFBZ0IsR0FBRztBQUN2Qk4sWUFBTSxFQUFFO0FBRGUsS0FBekI7QUFJQSxVQUFNTyxZQUFZLEdBQUcsTUFBTXRDLFNBQVMsQ0FBQ21DLFdBQVYsQ0FDeEIsU0FBUXRELEtBQU0sV0FBVS9MLE9BQVEsVUFBU29QLEdBQUcsQ0FBQ2xPLElBQUosQ0FBU0UsRUFBRyxFQUQ3QixFQUV6Qm1PLGdCQUZ5QixDQUEzQjtBQUtBLFVBQU07QUFBQ3JPO0FBQUQsUUFBU3NPLFlBQVksSUFBSSxFQUEvQjtBQUVBLFVBQU1DLEtBQUssR0FBR3ZPLElBQUksQ0FBQ0UsRUFBTCxHQUFXLFdBQVVwQixPQUFRLFVBQVNrQixJQUFJLENBQUNFLEVBQUcsRUFBOUMsR0FBbUQsV0FBVXBCLE9BQVEsY0FBbkY7QUFDQSxVQUFNMFAsU0FBUyxHQUFHeE8sSUFBSSxDQUFDRSxFQUFMLEdBQVU7QUFBQ3VPLGdCQUFVLEVBQUU7QUFBYixLQUFWLEdBQWdDLElBQWxEO0FBRUF2UCxXQUFPLENBQUNPLElBQVIsQ0FBYTtBQUNYQyxjQUFRLEVBQUU2TyxLQURDO0FBRVg1TyxXQUFLLEVBQUU2TztBQUZJLEtBQWI7QUFLQWhLLGVBQVc7QUFDWixHQTdDRDs7QUErQ0EsUUFBTWtLLFFBQVEsR0FBRyxNQUFPM0ksTUFBUCxJQUFrQjtBQUNqQyxVQUFNNEksWUFBWSxtQ0FDYjVJLE1BRGE7QUFFaEIwRixnQkFBVSxFQUFFO0FBRkksTUFBbEI7O0FBSUEsVUFBTXFDLE9BQU8sR0FBRztBQUNkQyxZQUFNLEVBQUUsS0FETTtBQUVkL04sVUFBSSxFQUFFMk87QUFGUSxLQUFoQjtBQUtBLFVBQU1ULEdBQUcsR0FBRyxNQUFNbEMsU0FBUyxDQUFDbUMsV0FBVixDQUF1QixTQUFRdEQsS0FBTSxXQUFVL0wsT0FBUSxFQUF2RCxFQUEwRGdQLE9BQTFELENBQWxCOztBQUNBLFFBQUl4TixjQUFjLENBQUMsQ0FBQzROLEdBQUQsRUFBTSxnQkFBTixFQUF3QmxNLENBQUMsSUFBSUEsQ0FBQyxDQUFDZ0UsTUFBL0IsQ0FBRCxDQUFsQixFQUE0RDtBQUMxRDdILFdBQUssQ0FBQ2lRLHNCQUFOLENBQTZCLG1CQUE3QjtBQUNELEtBRkQsTUFFTztBQUNMOUMsY0FBUSxDQUFDcUQsWUFBRCxDQUFSO0FBQ0FwRCxzQkFBZ0IsQ0FBQ29ELFlBQUQsQ0FBaEI7QUFDQW5ELGlCQUFXLENBQUNtRCxZQUFELENBQVg7QUFDQXhRLFdBQUssQ0FBQ3lRLHNCQUFOLENBQTZCLG1EQUE3QjtBQUNEOztBQUNEN0IsMkJBQXVCO0FBQ3hCLEdBcEJEOztBQXNCQSxRQUFNOEIsU0FBUyxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBVyxDQUFDNU4sS0FBSyxDQUFDNk4sT0FBTixHQUFnQixDQUFqQixJQUFzQixFQUFqQyxJQUF1QyxDQUF2QyxJQUE0QyxDQUE5RDs7QUFFQSxRQUFNQyxXQUFXLEdBQUcsa0ZBQU96USxpRUFBUDtBQUFBO0FBQUEsS0FBYTtBQUMvQjdDLFNBQUssRUFBRXVQLFFBQVEsS0FBSyxDQUFiLEdBQWlCclAsNkRBQU8sQ0FBQzRDLFNBQXpCLEdBQXFDNUMsNkRBQU8sQ0FBQ0MsWUFEckI7QUFFL0JnTyxVQUFNLEVBQUVvQixRQUFRLEtBQUssQ0FBYixHQUFpQixNQUFqQixHQUEwQixTQUZIO0FBRy9CL08sVUFBTSxFQUFFO0FBSHVCLEdBQWIsQ0FBcEI7O0FBTUEsUUFBTStTLGNBQWMsR0FBRyxrRkFBTzFRLGlFQUFQO0FBQUE7QUFBQSxLQUFhO0FBQ2xDN0MsU0FBSyxFQUFFdVAsUUFBUSxLQUFLMkQsU0FBYixHQUEwQixHQUFFaFQsNkRBQU8sQ0FBQzRDLFNBQVUsRUFBOUMsR0FBbUQsR0FBRTVDLDZEQUFPLENBQUNDLFlBQWEsRUFEL0M7QUFFbENnTyxVQUFNLEVBQUVvQixRQUFRLEtBQUsyRCxTQUFiLEdBQXlCLE1BQXpCLEdBQWtDLFNBRlI7QUFHbEMxUyxVQUFNLEVBQUU7QUFIMEIsR0FBYixDQUF2Qjs7QUFNQSxRQUFNZ1QsVUFBVSxHQUFHLFlBQVk7QUFDN0IsVUFBTVIsWUFBWSxtQ0FDYnhOLEtBRGE7QUFFaEJzSyxnQkFBVSxFQUFFO0FBRkksTUFBbEI7O0FBSUFILFlBQVEsQ0FBQ3FELFlBQUQsQ0FBUjtBQUNBLFVBQU1iLE9BQU8sR0FBRztBQUNkQyxZQUFNLEVBQUUsS0FETTtBQUVkL04sVUFBSSxFQUFFMk87QUFGUSxLQUFoQjtBQUtBLFVBQU1ULEdBQUcsR0FBRyxNQUFNbEMsU0FBUyxDQUFDbUMsV0FBVixDQUF1QixTQUFRdEQsS0FBTSxXQUFVL0wsT0FBUSxFQUF2RCxFQUEwRGdQLE9BQTFELENBQWxCOztBQUNBLFFBQUl4TixjQUFjLENBQUMsQ0FBQzROLEdBQUQsRUFBTSxnQkFBTixFQUF3QmhNLEVBQUUsSUFBSUEsRUFBRSxDQUFDOEQsTUFBakMsQ0FBRCxDQUFsQixFQUE4RDtBQUM1RDdILFdBQUssQ0FBQ2lRLHNCQUFOLENBQTZCLG1CQUE3QjtBQUNELEtBRkQsTUFFTztBQUNMalEsV0FBSyxDQUFDeVEsc0JBQU4sQ0FBNkIsOENBQTdCO0FBQ0Q7QUFDRixHQWpCRDs7QUFtQkEsUUFBTVEsZ0JBQWdCLEdBQUdDLHlEQUFXLENBQUMsTUFBTTtBQUN6QyxRQUFJM0QsU0FBSixFQUFlO0FBQ2J5RCxnQkFBVTtBQUNYLEtBRkQsTUFFTztBQUNMckMsOEJBQXdCO0FBQ3pCO0FBQ0YsR0FObUMsRUFNakMsQ0FBQzNMLEtBQUQsQ0FOaUMsQ0FBcEM7QUFRQSxNQUFJbU8sd0JBQXdCLEdBQUcsSUFBL0I7O0FBRUEsTUFBSW5PLEtBQUssQ0FBQ25CLElBQU4sSUFBY3NCLEtBQUssQ0FBQ0MsT0FBTixDQUFjSixLQUFLLENBQUNuQixJQUFwQixDQUFsQixFQUE2QztBQUMzQ21CLFNBQUssQ0FBQ25CLElBQU4sQ0FBV3dCLEdBQVgsQ0FBZSxDQUFDQyxLQUFELEVBQVF2QixFQUFSLEtBQWU7QUFDNUIsVUFBSXdCLDZFQUFrQixDQUFDQyxRQUFuQixDQUE0QkYsS0FBSyxDQUFDRyxJQUFsQyxDQUFKLEVBQTZDO0FBQzNDME4sZ0NBQXdCLEdBQUcsS0FBM0I7QUFDRDtBQUNGLEtBSkQ7QUFLRDs7QUFFRCxRQUFNbE8sY0FBYyxHQUFHLE1BQU9sQixFQUFQLElBQWM7QUFDbkM0TCxvQkFBZ0IsQ0FBQzVMLEVBQUQsQ0FBaEI7QUFFQSxVQUFNOEwsU0FBUyxDQUFDbUMsV0FBVixDQUF1QixTQUFRdEQsS0FBTSxXQUFVL0wsT0FBUSxFQUF2RCxFQUEwRDtBQUM5RGlQLFlBQU0sRUFBRSxPQURzRDtBQUU5RC9OLFVBQUksRUFBRTtBQUFDMkwsb0JBQVksRUFBRXpMO0FBQWY7QUFGd0QsS0FBMUQsQ0FBTjtBQUlELEdBUEQ7O0FBU0EsUUFBTXFQLGtCQUFrQixHQUFHLENBQUN2UCxJQUFELEVBQU9FLEVBQVAsS0FBYztBQUN2QyxRQUFJc1AsV0FBVyxHQUFHLE1BQU10UCxFQUF4Qjs7QUFDQSxRQUFJRixJQUFJLElBQUlzQixLQUFLLENBQUNDLE9BQU4sQ0FBY3ZCLElBQWQsQ0FBUixJQUErQixDQUFDc1Asd0JBQWhDLElBQTREekQsYUFBaEUsRUFBK0U7QUFDN0UsVUFBSTRELHVCQUF1QixHQUFHLEtBQTlCO0FBQ0F6UCxVQUFJLENBQUN3QixHQUFMLENBQVVDLEtBQUQsSUFBVztBQUVsQixZQUFJQSxLQUFLLENBQUN2QixFQUFOLEtBQWEyTCxhQUFqQixFQUFnQztBQUM5QjJELHFCQUFXLEdBQUdsUCxjQUFjLENBQUMsQ0FBQ21CLEtBQUQsRUFBUSxRQUFSLEVBQWtCVyxFQUFFLElBQUlBLEVBQUUsQ0FBQ1gsS0FBSyxDQUFDRyxJQUFQLENBQTFCLEVBQXdDLGdCQUF4QyxFQUEwRDhOLEVBQUUsSUFBSUEsRUFBRSxDQUFDaFAsS0FBbkUsQ0FBRCxDQUE1QjtBQUNBK08saUNBQXVCLEdBQUcsSUFBMUI7QUFDRDs7QUFDRCxZQUFJLENBQUNBLHVCQUFMLEVBQThCO0FBQzVCRCxxQkFBVyxHQUFHLEdBQWQ7QUFDRDtBQUNGLE9BVEQ7QUFVRDs7QUFFRCxXQUFPQSxXQUFQO0FBQ0QsR0FqQkQ7O0FBbUJBLFFBQU1HLGtCQUFrQixHQUFJeE8sS0FBRCxJQUFXO0FBQ3BDLFFBQUl5TyxXQUFXLEdBQUcsSUFBbEI7O0FBRUEsUUFBSXpPLEtBQUssQ0FBQ25CLElBQU4sSUFBY3NCLEtBQUssQ0FBQ0MsT0FBTixDQUFjSixLQUFLLENBQUNuQixJQUFwQixDQUFkLElBQTJDNkwsYUFBL0MsRUFBOEQ7QUFDNUQxSyxXQUFLLENBQUNuQixJQUFOLENBQVd3QixHQUFYLENBQWdCQyxLQUFELElBQVc7QUFDeEIsWUFBSUEsS0FBSyxDQUFDdkIsRUFBTixLQUFhMkwsYUFBakIsRUFBZ0M7QUFDOUIrRCxxQkFBVyxHQUFHbk8sS0FBSyxDQUFDeEIsSUFBcEI7QUFDRDtBQUNGLE9BSkQ7QUFLRDs7QUFFRCxXQUFPMlAsV0FBUDtBQUNELEdBWkQ7O0FBY0Esc0JBQ0VoUyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CZ0wsSUFBcEIsRUFBMEI7QUFBQy9LLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUExQixlQUNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CaUwsTUFBcEIsRUFBNEI7QUFBQ2hMLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUE1QixlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CME0sVUFBcEIsRUFBZ0M7QUFBQ3pNLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFoQyxFQUNFa0QsS0FBSyxDQUFDbEIsSUFBTixJQUFjMEMsa0ZBQXFCLENBQUN5RCw0RUFBWSxDQUFDakYsS0FBSyxDQUFDbEIsSUFBUCxFQUFhLEVBQWIsQ0FBYixDQURyQyxFQUVFSyxjQUFjLENBQUMsQ0FBQzhLLElBQUQsRUFBTyxnQkFBUCxFQUF5QnlFLEVBQUUsSUFBSUEsRUFBRSxDQUFDQyxRQUFsQyxDQUFELENBQWQsaUJBQ0FsUyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMk0sbUJBQXBCLEVBQXlDO0FBQUMxTSxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBekMsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhNLGNBQXBCLEVBQW9DO0FBQUVuTCxXQUFPLEVBQUU0TSxZQUFYO0FBQXlCbEosT0FBRyxFQUFFaUosU0FBOUI7QUFBeUNyTyxVQUFNLEVBQUUsU0FBakQ7QUFBdURDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUFqRSxHQUFwQyxFQUFpSixhQUFqSixDQURKLENBSEYsQ0FERixlQVdFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0wsT0FBcEIsRUFBNkI7QUFBQ2pMLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUE3QixFQUNFcUMsY0FBYyxDQUFDLENBQUM4SyxJQUFELEVBQU8sZ0JBQVAsRUFBeUIyRSxFQUFFLElBQUlBLEVBQUUsQ0FBQ0QsUUFBbEMsQ0FBRCxDQUFkLElBQStELENBQUN6RSxPQUFoRSxpQkFDQXpOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I2TSxtQkFBcEIsRUFBeUM7QUFDdkNsTCxXQUFPLEVBQUUsTUFBTTtBQUNiTixhQUFPLENBQUNPLElBQVIsQ0FBYyxXQUFVWCxPQUFRLGNBQWhDO0FBQ0QsS0FIc0M7QUFHcENoQixVQUFNLEVBQUUsU0FINEI7QUFHdEJDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUhZLEdBQXpDLEVBSUUsYUFKRixDQUZGLEVBVUVrRCxLQUFLLENBQUNuQixJQUFOLElBQWNtQixLQUFLLENBQUNuQixJQUFOLENBQVdZLE1BQVgsR0FBb0IsQ0FBbEMsSUFBdUMsQ0FBQ3lLLE9BQXhDLGlCQUNBek4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjZNLG1CQUFwQixFQUF5QztBQUN2Q2xMLFdBQU8sRUFBRSxNQUFNO0FBQ2JpRixZQUFNLENBQUM3RCxNQUFQLEdBQWdCLENBQWhCLEdBQW9COEwsbUJBQW1CLEVBQXZDLEdBQTRDaEksZUFBZSxDQUFDLEVBQUQsQ0FBM0Q7QUFDRCxLQUhzQztBQUdwQzVHLFVBQU0sRUFBRSxTQUg0QjtBQUd0QkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBSFksR0FBekMsRUFJRSxVQUpGLENBWEYsRUFtQkUsQ0FBQyxDQUFDcUMsY0FBYyxDQUFDLENBQUM4SyxJQUFELEVBQU8sZ0JBQVAsRUFBeUI0RSxFQUFFLElBQUlBLEVBQUUsQ0FBQ0YsUUFBbEMsQ0FBRCxDQUFmLElBQWdFekUsT0FBakUsS0FBNkVsSyxLQUFLLENBQUM2TixPQUFOLEdBQWdCLENBQTdGLGdCQUNBcFIsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm1MLFVBQXBCLEVBQWdDO0FBQUV4SixXQUFPLEVBQUVzTCxhQUFYO0FBQTBCaE4sVUFBTSxFQUFFLFNBQWxDO0FBQXdDQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBbEQsR0FBaEMsRUFBOEgsTUFBOUgsQ0FEQSxHQUVFLElBckJKLEVBc0JFcUMsY0FBYyxDQUFDLENBQUM4SyxJQUFELEVBQU8sZ0JBQVAsRUFBeUI2RSxFQUFFLElBQUlBLEVBQUUsQ0FBQ0gsUUFBbEMsQ0FBRCxDQUFkLElBQStELENBQUN6RSxPQUFoRSxpQkFDQXpOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JtTCxVQUFwQixFQUFnQztBQUFFeEosV0FBTyxFQUFFNFAsZ0JBQVg7QUFBNkJ0UixVQUFNLEVBQUUsU0FBckM7QUFBMkNDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUFyRCxHQUFoQyxFQUFpSXlOLFNBQVMsR0FBRyxPQUFILEdBQWEsS0FBdkosQ0F2QkYsQ0FYRixDQURKLGVBdUNJOU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQm9MLFdBQXBCLEVBQWlDO0FBQUNuTCxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBakMsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjBMLFlBQXBCLEVBQWtDO0FBQUN6TCxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBbEMsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjJMLGNBQXBCLEVBQW9DO0FBQUMxTCxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBcEMsRUFBeUcwUixrQkFBa0IsQ0FBQ3hPLEtBQUQsQ0FBM0gsQ0FERixFQUVFYixjQUFjLENBQUMsQ0FBQzhLLElBQUQsRUFBTyxnQkFBUCxFQUF5QjhFLEVBQUUsSUFBSUEsRUFBRSxDQUFDSixRQUFsQyxDQUFELENBQWQsSUFBK0QsQ0FBQ1Isd0JBQWhFLGlCQUNBMVIsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjRNLHlCQUFwQixFQUErQztBQUFDM00sVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQS9DLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I4TSxjQUFwQixFQUFvQztBQUFFbkwsV0FBTyxFQUFFaU8sc0JBQVg7QUFBbUN2SyxPQUFHLEVBQUVxSyxtQkFBeEM7QUFBNkR6UCxVQUFNLEVBQUUsU0FBckU7QUFBMkVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUFyRixHQUFwQyxFQUFxSyxhQUFySyxDQURKLENBSEYsQ0FERixlQVdFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc0wsZUFBcEIsRUFBcUM7QUFBQ3JMLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFyQyxFQUEwRyxRQUExRyxDQVhGLGVBWUVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JzTCxlQUFwQixFQUFxQztBQUFDckwsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQXJDLEVBQTBHLGFBQTFHLENBWkYsZUFhRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnNMLGVBQXBCLEVBQXFDO0FBQUNyTCxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBckMsRUFBMEcsVUFBMUcsQ0FiRixlQWNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc0wsZUFBcEIsRUFBcUM7QUFBQ3JMLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFyQyxFQUEwRyxZQUExRyxDQWRGLENBdkNKLGVBdURJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CNEwsY0FBcEIsRUFBb0M7QUFBQzNMLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFwQyxlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeU0sS0FBcEIsRUFBMkI7QUFBQ3hNLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEzQixFQUNFZ04sS0FBSyxDQUFDckssTUFBTixHQUFlLENBQWYsR0FDQXFLLEtBQUssQ0FBQ3pKLEdBQU4sQ0FBVzJPLElBQUQsSUFBVTtBQUNsQixVQUFNO0FBQUNqUSxRQUFEO0FBQUs2SCxZQUFMO0FBQWFxSSxnQkFBYjtBQUF5QkMsaUJBQXpCO0FBQXNDQyxnQkFBdEM7QUFBa0R0UTtBQUFsRCxRQUEwRG1RLElBQWhFO0FBRUEsd0JBQ0V2Uyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK0wsSUFBcEIsRUFBMEI7QUFBRS9ILFNBQUcsRUFBRTNCLEVBQVA7QUFBV1YsYUFBTyxFQUFFLE1BQU1OLE9BQU8sQ0FBQ08sSUFBUixDQUFjLFdBQVVYLE9BQVEsVUFBU29CLEVBQUcsRUFBNUMsQ0FBMUI7QUFBMEVwQyxZQUFNLEVBQUUsU0FBbEY7QUFBd0ZDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBbEcsS0FBMUIsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnFMLFNBQXBCLEVBQStCO0FBQUNwTCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQS9CLGVBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JtTSxFQUFwQixFQUF3QjtBQUFDbE0sWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUF4QixlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMkwsY0FBcEIsRUFBb0M7QUFBQzFMLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBcEMsRUFBeUdzUixrQkFBa0IsQ0FBQ3ZQLElBQUQsRUFBT0UsRUFBUCxDQUEzSCxDQURGLENBREYsQ0FESixlQU1JdEMsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnFMLFNBQXBCLEVBQStCO0FBQUNwTCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQS9CLGVBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsS0FBcEIsRUFBMkI7QUFBQ0MsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUEzQixlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CaUssdUVBQXBCLEVBQStCO0FBQUVDLFlBQU0sRUFBRUEsTUFBVjtBQUFrQmpLLFlBQU0sRUFBRSxTQUExQjtBQUFnQ0MsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUExQyxLQUEvQixDQURGLENBREYsQ0FOSixlQVdJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CcUwsU0FBcEIsRUFBK0I7QUFBQ3BMLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBL0IsRUFDRW9TLFdBQVcsaUJBQ1h6Uyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cb00sVUFBcEIsRUFBZ0M7QUFBQ25NLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBaEMsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm1GLG1FQUFwQixFQUE0QjtBQUM1QkcsY0FBUSxFQUFFa04sV0FBVyxDQUFDeE4sTUFBWixDQUFtQixDQUFuQixFQUFzQkMsV0FBdEIsRUFEa0I7QUFFNUJuSCxXQUFLLEVBQUU0VSxpRkFBZSxDQUFDRixXQUFELENBRk07QUFFU3ZTLFlBQU0sRUFBRSxTQUZqQjtBQUV1QkMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUZqQyxLQUE1QixDQURKLGVBS0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JxTSxJQUFwQixFQUEwQjtBQUFDcE0sWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUExQixFQUErRm9TLFdBQS9GLENBTEosQ0FGRixDQVhKLGVBc0JJelMsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnFMLFNBQXBCLEVBQStCO0FBQUNwTCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQS9CLEVBQ0VxUyxVQUFVLEdBQUcsQ0FBYixpQkFDQTFTLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JrTSxRQUFwQixFQUE4QjtBQUFDak0sWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUE5QixlQUNJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLEtBQXBCLEVBQTJCO0FBQUNDLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBM0IsRUFBZ0dxUyxVQUFoRyxDQURKLGVBRUkxUyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CVSxVQUFwQixFQUFnQztBQUFDVCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQWhDLEVBQXFHLFNBQXJHLENBRkosQ0FGRixDQXRCSixlQThCSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnFMLFNBQXBCLEVBQStCO0FBQUNwTCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQS9CLGVBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JrTSxRQUFwQixFQUE4QjtBQUFDak0sWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUE5QixFQUFtR3lLLDZDQUFLLENBQUMwSCxVQUFELENBQUwsQ0FBa0JJLE9BQWxCLEVBQW5HLENBREYsQ0E5QkosQ0FERjtBQW9DRCxHQXZDRCxDQURBLGdCQTBDQTVTLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JOLG9FQUFwQixFQUErQjtBQUM3QkUsVUFBTSxFQUFFLG1DQURxQjtBQUU3QkMsYUFBUyxFQUFFLHVEQUZrQjtBQUV1Q0ksVUFBTSxFQUFFLFNBRi9DO0FBRXFEQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFGL0QsR0FBL0IsQ0EzQ0YsQ0FERixlQWtERUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhMLFlBQXBCLEVBQWtDO0FBQUM3TCxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBbEMsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm9SLFdBQXBCLEVBQWlDO0FBQUV6UCxXQUFPLEVBQUUsTUFBTTJMLFdBQVcsQ0FBQyxDQUFELENBQTVCO0FBQWlDck4sVUFBTSxFQUFFLFNBQXpDO0FBQStDQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekQsR0FBakMsRUFBc0ksWUFBdEksQ0FERixlQUVFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cb1IsV0FBcEIsRUFBaUM7QUFDakN6UCxXQUFPLEVBQUUsTUFBTTtBQUNiLFVBQUkwTCxRQUFRLEdBQUcsQ0FBZixFQUFrQkMsV0FBVyxDQUFDRCxRQUFRLEdBQUcsQ0FBWixDQUFYO0FBQ25CLEtBSGdDO0FBRzlCcE4sVUFBTSxFQUFFLFNBSHNCO0FBR2hCQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFITSxHQUFqQyxFQUlBLGlCQUpBLENBRkYsZUFTRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnNNLFdBQXBCLEVBQWlDO0FBQUNyTSxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBakMsRUFBc0dpTixRQUF0RyxDQVRGLGVBVUV0Tiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CcVIsY0FBcEIsRUFBb0M7QUFDcEMxUCxXQUFPLEVBQUUsTUFBTTtBQUNiLFVBQUkwTCxRQUFRLEtBQUsyRCxTQUFqQixFQUE0QjFELFdBQVcsQ0FBQ0QsUUFBUSxHQUFHLENBQVosQ0FBWDtBQUM3QixLQUhtQztBQUdqQ3BOLFVBQU0sRUFBRSxTQUh5QjtBQUduQkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBSFMsR0FBcEMsRUFJQSxlQUpBLENBVkYsZUFpQkVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JxUixjQUFwQixFQUFvQztBQUNwQzFQLFdBQU8sRUFBRSxNQUFNO0FBQ2IyTCxpQkFBVyxDQUFDMEQsU0FBRCxDQUFYO0FBQ0QsS0FIbUM7QUFHakMvUSxVQUFNLEVBQUUsU0FIeUI7QUFHbkJDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUhTLEdBQXBDLEVBSUEsV0FKQSxDQWpCRixDQWxERixDQXZESixFQW1JSWlPLFVBQVUsZUFDVnRPLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JlLDJFQUFwQixFQUFzQztBQUNwQ0UsV0FBTyxFQUFFQSxPQUQyQjtBQUVwQytMLFNBQUssRUFBRUEsS0FGNkI7QUFHcENoTSxhQUFTLEVBQUVBLFNBSHlCO0FBSXBDRSxZQUFRLEVBQUVrTyxtQkFKMEI7QUFLcENqTyxXQUFPLEVBQUVvTyx3QkFMMkI7QUFLRHRQLFVBQU0sRUFBRSxTQUxQO0FBS2FDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUx2QixHQUF0QyxDQURVLENBbklkLEVBNElJd08sV0FBVyxlQUNYN08sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjBHLHlFQUFwQixFQUFpQztBQUFFRyxtQkFBZSxFQUFFQSxlQUFuQjtBQUFvQ0YsZUFBVyxFQUFFQSxXQUFqRDtBQUE4REMsVUFBTSxFQUFFQSxNQUF0RTtBQUE4RTNHLFVBQU0sRUFBRSxTQUF0RjtBQUE0RkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQXRHLEdBQWpDLENBRFcsQ0E1SWYsRUErSUkrTyxrQkFBa0IsZUFDbEJwUCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CNFMsNEVBQXBCLEVBQXVDO0FBQ3JDbFIsU0FBSyxFQUFFLFFBRDhCO0FBRXJDaUYsZUFBVyxFQUFFMEksa0JBRndCO0FBR3JDd0QsV0FBTyxFQUFFLHlEQUg0QjtBQUlyQ0MsYUFBUyxFQUFFLE1BQU07QUFDZjVGLGlCQUFXO0FBQ1osS0FOb0M7QUFNbENqTixVQUFNLEVBQUUsU0FOMEI7QUFNcEJDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQU5VLEdBQXZDLENBRGtCLENBL0l0QixFQXlKSWtQLHVCQUF1QixlQUN2QnZQLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I0Uyw0RUFBcEIsRUFBdUM7QUFDckNsUixTQUFLLEVBQUUsUUFEOEI7QUFFckNpRixlQUFXLEVBQUU2SSx1QkFGd0I7QUFHckNxRCxXQUFPLEVBQUUsd0VBSDRCO0FBSXJDQyxhQUFTLEVBQUUsTUFBTTtBQUNmM0YscUJBQWU7QUFDaEIsS0FOb0M7QUFNbENsTixVQUFNLEVBQUUsU0FOMEI7QUFNcEJDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQU5VLEdBQXZDLENBRHVCLENBekozQixFQW1LSTRPLG1CQUFtQixlQUNuQmpQLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IrUyw0REFBcEIsRUFBd0M7QUFDdENwTSxlQUFXLEVBQUV1SSx1QkFEeUI7QUFFdEMyQixZQUFRLEVBQUVBLFFBRjRCO0FBR3RDdk4sU0FBSyxFQUFFQSxLQUgrQjtBQUd4QnJELFVBQU0sRUFBRSxTQUhnQjtBQUdWQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFIQSxHQUF4QyxDQURtQixDQW5LdkIsRUEwS0lxUCxnQkFBZ0IsZUFDaEIxUCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CcUQsZ0ZBQXBCLEVBQTJDO0FBQ3pDQyxTQUFLLEVBQUVBLEtBRGtDO0FBRXpDRSxtQkFBZSxFQUFFc08sa0JBQWtCLENBQUN4TyxLQUFELENBRk07QUFHekN0QyxhQUFTLEVBQUUyTyxlQUg4QjtBQUl6Q3BNLGtCQUFjLEVBQUVBLGNBSnlCO0FBSVR0RCxVQUFNLEVBQUUsU0FKQztBQUlLQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFKZixHQUEzQyxDQURnQixDQTFLcEIsQ0FERjtBQXFMRCxDQTlZRDs7QUFnWkEsTUFBTTRTLGtCQUFrQixHQUFJQyxRQUFELElBQWM7QUFDdkMsU0FBTztBQUNMMUMsMEJBQXNCLEVBQUcyQyxHQUFELElBQVNELFFBQVEsQ0FBQzFDLDhIQUFzQixDQUFDMkMsR0FBRCxDQUF2QixDQURwQztBQUVMbkMsMEJBQXNCLEVBQUdtQyxHQUFELElBQVNELFFBQVEsQ0FBQ2xDLDhIQUFzQixDQUFDbUMsR0FBRCxDQUF2QixDQUZwQztBQUdMdkYsZUFBVyxFQUFHdUYsR0FBRCxJQUFTRCxRQUFRLENBQUNFLDZFQUFnQixDQUFDeEYsV0FBakIsQ0FBNkJ1RixHQUE3QixDQUFEO0FBSHpCLEdBQVA7QUFLRCxDQU5EOztBQVFlMVEsMkhBQU8sQ0FBQyxJQUFELEVBQU93USxrQkFBUCxDQUFQLENBQWtDakcsS0FBbEMsQ0FBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9uQkEsTUFBTWxPLFlBQVksR0FBRyxpR0FBckI7QUFBdUg7QUFDdkg7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFRQSxNQUFNaUgsU0FBUyxHQUFHO0FBQUE7QUFBQSxHQUFXO0FBQzNCL0csU0FBTyxFQUFFLE1BRGtCO0FBRTNCQyxlQUFhLEVBQUUsUUFGWTtBQUczQm9VLFVBQVEsRUFBRSxHQUhpQjtBQUkzQmpVLE9BQUssRUFBRSxHQUpvQjtBQUszQlosY0FBWSxFQUFFLEVBTGE7QUFNM0JSLGlCQUFlLEVBQUUsTUFOVTtBQU8zQlMsUUFBTSxFQUFHLGFBQVlSLGdFQUFPLENBQUMrSCxnQkFBaUIsRUFQbkI7QUFRM0IxSCxXQUFTLEVBQUUySCxpRUFBUyxDQUFDQyxLQVJNO0FBUzNCb04sWUFBVSxFQUFFLEVBVGU7QUFVM0JDLGVBQWEsRUFBRSxFQVZZO0FBVzNCekgsV0FBUyxFQUFFO0FBWGdCLENBQVgsQ0FBbEI7O0FBY0EsTUFBTTBILFlBQVksR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBckI7O0FBT0EsTUFBTUMsV0FBVyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFwQjs7QUFTQSxNQUFNQyxTQUFTLEdBQUc7QUFBQTtBQUFBLEdBQVc7QUFDM0J2VixZQUFVLEVBQUUsR0FEZTtBQUUzQkMsVUFBUSxFQUFFLE1BRmlCO0FBRzNCTixZQUFVLEVBQUUsTUFIZTtBQUkzQjZWLGNBQVksRUFBRSxFQUphO0FBSzNCakksYUFBVyxFQUFFLEVBTGM7QUFNM0JrSSxjQUFZLEVBQUUsRUFOYTtBQU8zQjdWLE9BQUssRUFBRUUsZ0VBQU8sQ0FBQzRWO0FBUFksQ0FBWCxDQUFsQjs7QUFVQSxNQUFNOVMsS0FBSyxHQUFHO0FBQUE7QUFBQSxHQUFXO0FBQ3ZCM0MsVUFBUSxFQUFFLEVBRGE7QUFFdkJMLE9BQUssRUFBRUUsZ0VBQU8sQ0FBQ3dCLFNBRlE7QUFHdkJ0QixZQUFVLEVBQUUsR0FIVztBQUl2QndWLGNBQVksRUFBRTtBQUpTLENBQVgsQ0FBZDs7QUFPQSxNQUFNRyxJQUFJLEdBQUc7QUFBQTtBQUFBLEdBQVk7QUFDdkIxVixVQUFRLEVBQUUsRUFEYTtBQUV2QkwsT0FBSyxFQUFFRSxnRUFBTyxDQUFDNEMsU0FGUTtBQUd2QjFDLFlBQVUsRUFBRTtBQUhXLENBQVosQ0FBYjs7QUFNQSxNQUFNNFYsWUFBWSxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFyQjs7QUFNQSxNQUFNM04sV0FBVyxHQUFHLGtGQUFPQywyQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBcEI7O0FBTUEsTUFBTTJOLGdCQUFnQixHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUF6Qjs7QUFVQSxNQUFNQyxTQUFTLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQWxCOztBQU1BLE1BQU1DLFlBQVksR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBckI7O0FBTUEsTUFBTUMsV0FBVyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFwQjs7QUFVQSxNQUFNQyxjQUFjLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXZCOztBQU9BLE1BQU1DLGFBQWEsR0FBRyxNQUFNO0FBQzFCLFFBQU0sQ0FBQ0MsZ0JBQUQsRUFBbUJDLGVBQW5CLEVBQW9DQyxrQkFBcEMsSUFBMERDLHVEQUFRLENBQUMsa0JBQUQsQ0FBeEU7QUFDQSxRQUFNLENBQUNDLGVBQUQsRUFBa0JDLGNBQWxCLEVBQWtDQyxpQkFBbEMsSUFBdURILHVEQUFRLENBQUMsZ0JBQUQsQ0FBckU7QUFFQSxzQkFDRXpVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JELDRDQUFLLENBQUM2VSxRQUExQixFQUFvQyxJQUFwQyxlQUNJN1UsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmlVLFlBQXBCLEVBQWtDO0FBQUNoVSxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBbEMsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhULFlBQXBCLEVBQWtDO0FBQUM3VCxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBbEMsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmMsS0FBcEIsRUFBMkI7QUFBQ2IsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTNCLEVBQWdHLGdDQUFoRyxDQURGLGVBRUVMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I2VSxrRUFBcEIsa0NBQ0dSLGdCQURIO0FBRUFTLHFCQUFpQixFQUFFLElBRm5CO0FBR0ExTCxTQUFLLEVBQUVrTCxlQUFlLENBQUNsTCxLQUh2QjtBQUlBRixlQUFXLEVBQUUsYUFKYjtBQUtBNkwsV0FBTyxFQUFFLENBTFQ7QUFNQXhMLFdBQU8sRUFBRSxDQU5UO0FBT0F5TCxzQkFBa0IsRUFBRSxLQVBwQjtBQVFBQyxjQUFVLEVBQUUsSUFSWjtBQVFrQmhWLFVBQU0sRUFBRSxTQVIxQjtBQVFnQ0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBUjFDLEtBRkYsQ0FERixlQWNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9COFQsWUFBcEIsRUFBa0M7QUFBQzdULFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFsQyxlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CNlQsSUFBcEIsRUFBMEI7QUFBQzVULFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUExQixFQUErRiwyRkFBL0YsQ0FERixDQWRGLENBREosZUFzQklMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JpVSxZQUFwQixFQUFrQztBQUFDaFUsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQWxDLGVBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I4VCxZQUFwQixFQUFrQztBQUFDN1QsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQWxDLGVBQ0VMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JjLEtBQXBCLEVBQTJCO0FBQUNiLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEzQixFQUFnRyxnRUFBaEcsQ0FERixlQUVFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd0osdUVBQXBCLGtDQUNHaUwsZUFESDtBQUVBckwsU0FBSyxFQUFFc0wsY0FBYyxDQUFDdEwsS0FGdEI7QUFHQXJGLFFBQUksRUFBRSxNQUhOO0FBSUFtRixlQUFXLEVBQUUsc0NBSmI7QUFJcURqSixVQUFNLEVBQUUsU0FKN0Q7QUFJbUVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsZ0JBQVUsRUFBRTtBQUFyQztBQUo3RSxLQUZGLENBREYsZUFVRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhULFlBQXBCLEVBQWtDO0FBQUM3VCxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBbEMsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjZULElBQXBCLEVBQTBCO0FBQUM1VCxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBMUIsRUFBK0YsZ0tBQS9GLENBREYsQ0FWRixDQXRCSixDQURGO0FBMENELENBOUNEOztBQWdEQSxNQUFNMlMsa0JBQWtCLEdBQUcsQ0FBQztBQUFDbEMsVUFBRDtBQUFXdk4sT0FBWDtBQUFrQnFEO0FBQWxCLENBQUQsa0JBQ3pCNUcsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhGLFNBQXBCLEVBQStCO0FBQUV6RCxJQUFFLEVBQUUsc0JBQU47QUFBOEJwQyxRQUFNLEVBQUUsU0FBdEM7QUFBNENDLFVBQVEsRUFBRTtBQUFDQyxZQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsY0FBVSxFQUFFO0FBQXJDO0FBQXRELENBQS9CLGVBQ0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JxSCw2Q0FBcEIsRUFBNEI7QUFDNUJDLGtCQUFnQixFQUFFNE4sbUZBRFU7QUFFNUIxTixrQkFBZ0IsRUFBRSxJQUZVO0FBRzVCQyxnQkFBYyxFQUFFLElBSFk7QUFJNUJYLGVBQWEsRUFBRXhELEtBSmE7QUFLNUJxRSxvQkFBa0IsRUFBRSxJQUxRO0FBTTVCQyxVQUFRLEVBQUVpSixRQU5rQjtBQU1SNVEsUUFBTSxFQUFFLFNBTkE7QUFNTUMsVUFBUSxFQUFFO0FBQUNDLFlBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixjQUFVLEVBQUU7QUFBckM7QUFOaEIsQ0FBNUIsRUFRRSxDQUFDO0FBQUMySCxTQUFEO0FBQVVEO0FBQVYsQ0FBRCxrQkFDQS9ILDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JtRyxXQUFwQixFQUFpQztBQUFDbEcsUUFBTSxFQUFFLFNBQVQ7QUFBZUMsVUFBUSxFQUFFO0FBQUNDLFlBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixjQUFVLEVBQUU7QUFBckM7QUFBekIsQ0FBakMsZUFDSUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQndULFdBQXBCLEVBQWlDO0FBQUN2VCxRQUFNLEVBQUUsU0FBVDtBQUFlQyxVQUFRLEVBQUU7QUFBQ0MsWUFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGNBQVUsRUFBRTtBQUFyQztBQUF6QixDQUFqQyxFQUFzRyxxQkFBdEcsQ0FESixlQUVJTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeVQsU0FBcEIsRUFBK0I7QUFBQ3hULFFBQU0sRUFBRSxTQUFUO0FBQWVDLFVBQVEsRUFBRTtBQUFDQyxZQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsY0FBVSxFQUFFO0FBQXJDO0FBQXpCLENBQS9CLEVBQW9HLG1FQUFwRyxDQUZKLGVBR0lMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1VCxZQUFwQixFQUFrQztBQUFDdFQsUUFBTSxFQUFFLFNBQVQ7QUFBZUMsVUFBUSxFQUFFO0FBQUNDLFlBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixjQUFVLEVBQUU7QUFBckM7QUFBekIsQ0FBbEMsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm1VLGNBQXBCLEVBQW9DO0FBQUNsVSxRQUFNLEVBQUUsU0FBVDtBQUFlQyxVQUFRLEVBQUU7QUFBQ0MsWUFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGNBQVUsRUFBRTtBQUFyQztBQUF6QixDQUFwQyxlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cb1UsYUFBcEIsRUFBbUM7QUFBQ25VLFFBQU0sRUFBRSxTQUFUO0FBQWVDLFVBQVEsRUFBRTtBQUFDQyxZQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsY0FBVSxFQUFFO0FBQXJDO0FBQXpCLENBQW5DLENBREYsZUFFRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmlVLFlBQXBCLEVBQWtDO0FBQUNoVSxRQUFNLEVBQUUsU0FBVDtBQUFlQyxVQUFRLEVBQUU7QUFBQ0MsWUFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGNBQVUsRUFBRTtBQUFyQztBQUF6QixDQUFsQyxlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK1QsZ0JBQXBCLEVBQXNDO0FBQUM5VCxRQUFNLEVBQUUsU0FBVDtBQUFlQyxVQUFRLEVBQUU7QUFBQ0MsWUFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGNBQVUsRUFBRTtBQUFyQztBQUF6QixDQUF0QyxlQUNFTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CZ1UsU0FBcEIsRUFBK0I7QUFBQy9ULFFBQU0sRUFBRSxTQUFUO0FBQWVDLFVBQVEsRUFBRTtBQUFDQyxZQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsY0FBVSxFQUFFO0FBQXJDO0FBQXpCLENBQS9CLEVBQW9HLHlCQUFwRyxFQUNLLEdBREwsZUFFRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixHQUFwQixFQUF5QjtBQUFDQyxRQUFNLEVBQUUsU0FBVDtBQUFlQyxVQUFRLEVBQUU7QUFBQ0MsWUFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGNBQVUsRUFBRTtBQUFyQztBQUF6QixDQUF6QixFQUE4Rix1REFBOUYsQ0FGRixFQUVxSyx5REFGckssQ0FERixlQU1FTCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CZ1UsU0FBcEIsRUFBK0I7QUFBQy9ULFFBQU0sRUFBRSxTQUFUO0FBQWVDLFVBQVEsRUFBRTtBQUFDQyxZQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsY0FBVSxFQUFFO0FBQXJDO0FBQXpCLENBQS9CLEVBQW9HLGlKQUFwRyxFQUVZLEdBRlosZUFHRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixHQUFwQixFQUF5QjtBQUFDQyxRQUFNLEVBQUUsU0FBVDtBQUFlQyxVQUFRLEVBQUU7QUFBQ0MsWUFBUSxFQUFFdEIsWUFBWDtBQUF5QnVCLGNBQVUsRUFBRTtBQUFyQztBQUF6QixDQUF6QixFQUE4RiwwQkFBOUYsQ0FIRixDQU5GLENBREYsQ0FGRixDQURGLENBSEosZUFzQklMLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JrVSxXQUFwQixFQUFpQztBQUFDalUsUUFBTSxFQUFFLFNBQVQ7QUFBZUMsVUFBUSxFQUFFO0FBQUNDLFlBQVEsRUFBRXRCLFlBQVg7QUFBeUJ1QixjQUFVLEVBQUU7QUFBckM7QUFBekIsQ0FBakMsZUFDRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm1WLDBFQUFwQixFQUFtQztBQUFFcFIsTUFBSSxFQUFFLFFBQVI7QUFBa0JwRyxVQUFRLEVBQUUsQ0FBQ29LLE9BQUQsSUFBWUQsWUFBeEM7QUFBc0Q3SCxRQUFNLEVBQUUsU0FBOUQ7QUFBb0VDLFVBQVEsRUFBRTtBQUFDQyxZQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsY0FBVSxFQUFFO0FBQXJDO0FBQTlFLENBQW5DLEVBQTZKLFFBQTdKLENBREYsZUFJRUwsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmdLLDRFQUFwQixFQUFxQztBQUFFakcsTUFBSSxFQUFFLFFBQVI7QUFBa0JwQyxTQUFPLEVBQUUsTUFBTWdGLFdBQVcsRUFBNUM7QUFBZ0QxRyxRQUFNLEVBQUUsU0FBeEQ7QUFBOERDLFVBQVEsRUFBRTtBQUFDQyxZQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsY0FBVSxFQUFFO0FBQXJDO0FBQXhFLENBQXJDLEVBQXlKLFFBQXpKLENBSkYsQ0F0QkosQ0FURixDQURKLENBREY7O0FBK0NlMlMsaUZBQWYsRTs7Ozs7Ozs7Ozs7O0FDek5BO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBTWxVLFlBQVksR0FBRyw2RkFBckI7QUFBbUg7QUFDbkg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBUUEsTUFBTXVXLGNBQWMsR0FBSTlVLEtBQUQsSUFBVztBQUNoQyxRQUFNLENBQUNnRCxLQUFELEVBQVFtSyxRQUFSLElBQW9CUyxzREFBUSxDQUFDLEVBQUQsQ0FBbEM7QUFDQSxRQUFNLENBQUNtSCxPQUFELEVBQVVDLFVBQVYsSUFBd0JwSCxzREFBUSxDQUFDLEtBQUQsQ0FBdEM7QUFDQSxRQUFNLENBQUN0SCxNQUFELEVBQVMyTyxTQUFULElBQXNCckgsc0RBQVEsQ0FBQyxFQUFELENBQXBDO0FBQ0EsUUFBTSxDQUFDc0gsYUFBRCxFQUFnQkMsZ0JBQWhCLElBQW9Ddkgsc0RBQVEsQ0FBQyxLQUFELENBQWxEO0FBQ0EsUUFBTSxDQUFDZCxLQUFELEVBQVFzSSxRQUFSLElBQW9CeEgsc0RBQVEsQ0FBQyxFQUFELENBQWxDO0FBQ0EsUUFBTSxDQUFDeUgsV0FBRCxFQUFjQyxjQUFkLElBQWdDMUgsc0RBQVEsQ0FBQyxLQUFELENBQTlDO0FBQ0EsUUFBTSxDQUFDYixRQUFELEVBQVdDLFdBQVgsSUFBMEJZLHNEQUFRLENBQUMsQ0FBRCxDQUF4QztBQUNBLFFBQU1DLFNBQVMsR0FBR0MseUVBQVksRUFBOUI7QUFDQSxRQUFNO0FBQUMvTTtBQUFELE1BQVlDLHNFQUFTLEVBQTNCO0FBRUEsUUFBTTBMLEtBQUssR0FBRzFNLEtBQUssQ0FBQ2lOLElBQU4sQ0FBV3NJLHVCQUF6QjtBQUNBLFFBQU01VSxPQUFPLEdBQUdYLEtBQUssQ0FBQ3dWLEtBQU4sQ0FBWUMsTUFBWixDQUFtQjlVLE9BQW5DO0FBQ0EsUUFBTStVLGFBQWEsR0FBRzFWLEtBQUssQ0FBQzBWLGFBQTVCO0FBQ0EsUUFBTXhJLE9BQU8sR0FBR3lJLHlFQUFXLENBQUNELGFBQUQsRUFBZ0JoSixLQUFoQixDQUEzQjtBQUVBcEkseURBQVMsQ0FBQyxNQUFNO0FBQ2QsbUJBQWVzUixVQUFmLEdBQTRCO0FBQzFCWixnQkFBVSxDQUFDLElBQUQsQ0FBVjtBQUNBLFlBQU1yRixPQUFPLEdBQUc7QUFDZEMsY0FBTSxFQUFFO0FBRE0sT0FBaEI7QUFHQSxZQUFNO0FBQUMvTjtBQUFELFVBQ0osQ0FBQyxNQUFNZ00sU0FBUyxDQUFDbUMsV0FBVixDQUF1QixTQUFRdEQsS0FBTSxXQUFVL0wsT0FBUSxFQUF2RCxFQUEwRGdQLE9BQTFELENBQVAsS0FBOEUsRUFEaEY7O0FBRUEsVUFBSTlOLElBQUosRUFBVTtBQUNSc0wsZ0JBQVEsQ0FBQ3RMLElBQUQsQ0FBUjtBQUNBN0IsYUFBSyxDQUFDb04sZ0JBQU4sQ0FBdUJ2TCxJQUF2QjtBQUNEOztBQUNEbVQsZ0JBQVUsQ0FBQyxLQUFELENBQVY7QUFDRDs7QUFFRFksY0FBVTtBQUNYLEdBaEJRLEVBZ0JOLEVBaEJNLENBQVQ7QUFrQkF0Uix5REFBUyxDQUFDLE1BQU07QUFDZCxtQkFBZXVSLGdCQUFmLEdBQWtDO0FBQ2hDLFVBQ0VILGFBQWEsQ0FBQ2pULE1BQWQsR0FBdUIsQ0FBdkIsSUFBNEI7QUFDNUIsT0FBQ3lLLE9BREQsSUFFQS9KLEtBQUssQ0FBQ0MsT0FBTixDQUFja0QsTUFBZCxDQUZBLElBR0FBLE1BQU0sQ0FBQzdELE1BQVAsS0FBa0IsQ0FKcEIsRUFLRTtBQUNBMFMsd0JBQWdCLENBQUMsSUFBRCxDQUFoQjtBQUNBLGNBQU14RixPQUFPLEdBQUc7QUFDZEMsZ0JBQU0sRUFBRTtBQURNLFNBQWhCO0FBR0EsY0FBTTtBQUFDL047QUFBRCxZQUNKLENBQUMsTUFBTWdNLFNBQVMsQ0FBQ21DLFdBQVYsQ0FBdUIsU0FBUXRELEtBQU0sV0FBVS9MLE9BQVEsYUFBdkQsRUFBcUVnUCxPQUFyRSxDQUFQLEtBQ0EsRUFGRjs7QUFHQSxZQUFJOU4sSUFBSixFQUFVO0FBQ1IsZ0JBQU07QUFBQ0EsZ0JBQUksRUFBRWlVO0FBQVAsY0FBcUJqVSxJQUFJLElBQUksRUFBbkM7QUFDQW9ULG1CQUFTLENBQUNhLFVBQUQsQ0FBVDtBQUNEOztBQUNEWCx3QkFBZ0IsQ0FBQyxLQUFELENBQWhCO0FBQ0Q7QUFDRjs7QUFFRFUsb0JBQWdCO0FBQ2pCLEdBeEJRLEVBd0JOLEVBeEJNLENBQVQ7QUEwQkF2Uix5REFBUyxDQUFDLE1BQU07QUFDZCxtQkFBZXlSLFVBQWYsR0FBNEI7QUFDMUJULG9CQUFjLENBQUMsSUFBRCxDQUFkO0FBQ0EsWUFBTTNGLE9BQU8sR0FBRztBQUNkQyxjQUFNLEVBQUU7QUFETSxPQUFoQjtBQUdBLFlBQU07QUFBQy9OO0FBQUQsVUFDSixDQUFDLE1BQU1nTSxTQUFTLENBQUNtQyxXQUFWLENBQ0osU0FBUXRELEtBQU0sV0FBVS9MLE9BQVEsa0NBQy9CLENBQUNvTSxRQUFRLEdBQUcsQ0FBWixJQUFpQixFQUFqQixJQUF1QixDQUN4QixFQUhJLEVBSUw0QyxPQUpLLENBQVAsS0FLTSxFQU5SOztBQU9BLFVBQUk5TixJQUFKLEVBQVU7QUFDUnVULGdCQUFRLENBQUN2VCxJQUFJLENBQUNpTCxLQUFOLENBQVI7QUFDRDs7QUFDRHdJLG9CQUFjLENBQUMsS0FBRCxDQUFkO0FBQ0Q7O0FBRURTLGNBQVU7QUFDWCxHQXBCUSxFQW9CTixDQUFDaEosUUFBRCxDQXBCTSxDQUFUOztBQXNCQSxRQUFNSCxXQUFXLEdBQUcsWUFBWTtBQUM5QixRQUFJO0FBQ0YsWUFBTWlCLFNBQVMsQ0FBQ21DLFdBQVYsQ0FBdUIsU0FBUXRELEtBQU0sV0FBVS9MLE9BQVEsRUFBdkQsRUFBMEQ7QUFDOURpUCxjQUFNLEVBQUUsT0FEc0Q7QUFFOUQvTixZQUFJLEVBQUU7QUFBQ3hFLGtCQUFRLEVBQUU7QUFBWDtBQUZ3RCxPQUExRCxDQUFOO0FBSUEyWSxpRkFBWSxDQUFDLGVBQUQsRUFBa0I7QUFDNUJ0SixhQUQ0QjtBQUU1Qi9MLGVBRjRCO0FBRzVCc1YsY0FBTSxFQUFFalcsS0FBSyxDQUFDaU4sSUFBTixDQUFXbEwsRUFIUztBQUk1QkQ7QUFKNEIsT0FBbEIsQ0FBWjtBQU1BOUIsV0FBSyxDQUFDeVEsc0JBQU4sQ0FBNkIsaUNBQTdCO0FBQ0ExUCxhQUFPLENBQUNPLElBQVIsQ0FBYyxTQUFkO0FBQ0QsS0FiRCxDQWFFLE9BQU80VSxDQUFQLEVBQVU7QUFDVkMsYUFBTyxDQUFDck4sS0FBUixDQUFjb04sQ0FBZDtBQUNEO0FBQ0YsR0FqQkQ7O0FBbUJBLFFBQU1ySixlQUFlLEdBQUcsWUFBWTtBQUNsQyxRQUFJO0FBQ0YsWUFBTWdCLFNBQVMsQ0FBQ21DLFdBQVYsQ0FBdUIsU0FBUXRELEtBQU0sV0FBVS9MLE9BQVEsUUFBdkQsRUFBZ0U7QUFDcEVpUCxjQUFNLEVBQUU7QUFENEQsT0FBaEUsQ0FBTjtBQUdBb0csaUZBQVksQ0FBQyxxQkFBRCxFQUF3QjtBQUNsQ3RKLGFBRGtDO0FBRWxDL0wsZUFGa0M7QUFHbENzVixjQUFNLEVBQUVqVyxLQUFLLENBQUNpTixJQUFOLENBQVdsTDtBQUhlLE9BQXhCLENBQVo7QUFLQS9CLFdBQUssQ0FBQ3lRLHNCQUFOLENBQThCLHlDQUE5QjtBQUNBMkUsY0FBUSxDQUFDLEVBQUQsQ0FBUjtBQUNELEtBWEQsQ0FXRSxPQUFPYyxDQUFQLEVBQVU7QUFDVkMsYUFBTyxDQUFDck4sS0FBUixDQUFjb04sQ0FBZDtBQUNEO0FBQ0YsR0FmRDs7QUFpQkEsUUFBTXZKLGFBQWEsR0FBRyxZQUFZO0FBQ2hDLFVBQU1nRCxPQUFPLEdBQUc7QUFDZEMsWUFBTSxFQUFFO0FBRE0sS0FBaEI7QUFHQSxVQUFNRyxHQUFHLEdBQUcsTUFBTWxDLFNBQVMsQ0FBQ21DLFdBQVYsQ0FBdUIsU0FBUXRELEtBQU0sV0FBVS9MLE9BQVEsYUFBdkQsRUFBcUVnUCxPQUFyRSxDQUFsQjtBQUNBLFVBQU07QUFBQzlOO0FBQUQsUUFBU2tPLEdBQUcsSUFBSSxFQUF0QjtBQUNBLFVBQU1LLEtBQUssR0FBR3ZPLElBQUksQ0FBQ0UsRUFBTCxHQUFXLFdBQVVwQixPQUFRLFVBQVNrQixJQUFJLENBQUNFLEVBQUcsRUFBOUMsR0FBbUQsV0FBVXBCLE9BQVEsY0FBbkY7QUFDQUksV0FBTyxDQUFDTyxJQUFSLENBQWE4TyxLQUFiO0FBQ0QsR0FSRDs7QUFVQSxNQUFJZ0csVUFBSjs7QUFFQSxNQUFJckIsT0FBTyxJQUFJTSxXQUFYLElBQTBCSCxhQUExQixJQUEyQ2xTLEtBQUssS0FBS1YsU0FBekQsRUFBb0U7QUFDbEU4VCxjQUFVLGdCQUFHM1csNENBQUssQ0FBQ0MsYUFBTixDQUFvQjJXLHFFQUFwQixFQUFpQztBQUFDMVcsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUFqQyxDQUFiO0FBQ0QsR0FGRCxNQUVPO0FBQ0xzVyxjQUFVLGdCQUNSM1csNENBQUssQ0FBQ0MsYUFBTixDQUFvQitNLGdGQUFwQixFQUEyQjtBQUN6QnpKLFdBQUssRUFBRUEsS0FEa0I7QUFFekJpSyxVQUFJLEVBQUVqTixLQUFLLENBQUNpTixJQUZhO0FBR3pCUCxXQUFLLEVBQUVBLEtBSGtCO0FBSXpCL0wsYUFBTyxFQUFFQSxPQUpnQjtBQUt6QmlNLGlCQUFXLEVBQUVBLFdBTFk7QUFNekJDLHFCQUFlLEVBQUVBLGVBTlE7QUFPekJGLG1CQUFhLEVBQUVBLGFBUFU7QUFRekJyRyxZQUFNLEVBQUVBLE1BUmlCO0FBU3pCd0csV0FBSyxFQUFFQSxLQVRrQjtBQVV6QkksYUFBTyxFQUFFQSxPQVZnQjtBQVd6QkgsY0FBUSxFQUFFQSxRQVhlO0FBWXpCQyxpQkFBVyxFQUFFQSxXQVpZO0FBYXpCcUksaUJBQVcsRUFBRUEsV0FiWTtBQWN6QmxJLGNBQVEsRUFBRUEsUUFkZTtBQWV6QkMsc0JBQWdCLEVBQUVwTixLQUFLLENBQUNvTixnQkFmQztBQWVpQnpOLFlBQU0sRUFBRSxTQWZ6QjtBQWUrQkMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUV0QixZQUFYO0FBQXlCdUIsa0JBQVUsRUFBRTtBQUFyQztBQWZ6QyxLQUEzQixDQURGO0FBbUJEOztBQUVEc0UsK0VBQWdCLENBQUUsdUJBQUYsQ0FBaEI7QUFFQSxTQUFPZ1MsVUFBUDtBQUNELENBN0pEOztBQStKQSxNQUFNMUQsa0JBQWtCLEdBQUlDLFFBQUQsS0FBZTtBQUN4Q2xDLHdCQUFzQixFQUFHbUMsR0FBRCxJQUFTRCxRQUFRLENBQUNsQyw2SEFBc0IsQ0FBQ21DLEdBQUQsQ0FBdkIsQ0FERDtBQUV4Q3hGLGtCQUFnQixFQUFHd0YsR0FBRCxJQUFTRCxRQUFRLENBQUNFLDRFQUFnQixDQUFDekYsZ0JBQWpCLENBQWtDd0YsR0FBbEMsQ0FBRDtBQUZLLENBQWYsQ0FBM0I7O0FBS2UxUSwwSEFBTyxDQUFDLElBQUQsRUFBT3dRLGtCQUFQLENBQVAsQ0FBa0NvQyxjQUFsQyxDQUFmLEU7Ozs7Ozs7Ozs7OztBQ3ZMQTtBQUFBLE1BQU03TSxZQUFZLEdBQUcsQ0FBQ3FPLE1BQUQsRUFBUzdULE1BQVQsS0FDbkI2VCxNQUFNLENBQUM3VCxNQUFQLEdBQWdCQSxNQUFoQixHQUEwQixHQUFFNlQsTUFBTSxDQUFDQyxTQUFQLENBQWlCLENBQWpCLEVBQW9COVQsTUFBcEIsQ0FBNEIsS0FBeEQsR0FBK0Q2VCxNQURqRTs7QUFFZXJPLDJFQUFmLEU7Ozs7Ozs7Ozs7OztBQ0ZDO0FBQUE7QUFBQSxTQUFTOUYsY0FBVCxDQUF3QkMsR0FBeEIsRUFBNkI7QUFBRSxNQUFJQyxhQUFhLEdBQUdDLFNBQXBCO0FBQStCLE1BQUlDLEtBQUssR0FBR0gsR0FBRyxDQUFDLENBQUQsQ0FBZjtBQUFvQixNQUFJSSxDQUFDLEdBQUcsQ0FBUjs7QUFBVyxTQUFPQSxDQUFDLEdBQUdKLEdBQUcsQ0FBQ0ssTUFBZixFQUF1QjtBQUFFLFVBQU1DLEVBQUUsR0FBR04sR0FBRyxDQUFDSSxDQUFELENBQWQ7QUFBbUIsVUFBTUcsRUFBRSxHQUFHUCxHQUFHLENBQUNJLENBQUMsR0FBRyxDQUFMLENBQWQ7QUFBdUJBLEtBQUMsSUFBSSxDQUFMOztBQUFRLFFBQUksQ0FBQ0UsRUFBRSxLQUFLLGdCQUFQLElBQTJCQSxFQUFFLEtBQUssY0FBbkMsS0FBc0RILEtBQUssSUFBSSxJQUFuRSxFQUF5RTtBQUFFLGFBQU9ELFNBQVA7QUFBbUI7O0FBQUMsUUFBSUksRUFBRSxLQUFLLFFBQVAsSUFBbUJBLEVBQUUsS0FBSyxnQkFBOUIsRUFBZ0Q7QUFBRUwsbUJBQWEsR0FBR0UsS0FBaEI7QUFBdUJBLFdBQUssR0FBR0ksRUFBRSxDQUFDSixLQUFELENBQVY7QUFBb0IsS0FBN0YsTUFBbUcsSUFBSUcsRUFBRSxLQUFLLE1BQVAsSUFBaUJBLEVBQUUsS0FBSyxjQUE1QixFQUE0QztBQUFFSCxXQUFLLEdBQUdJLEVBQUUsQ0FBQyxDQUFDLEdBQUdDLElBQUosS0FBYUwsS0FBSyxDQUFDTSxJQUFOLENBQVdSLGFBQVgsRUFBMEIsR0FBR08sSUFBN0IsQ0FBZCxDQUFWO0FBQTZEUCxtQkFBYSxHQUFHQyxTQUFoQjtBQUE0QjtBQUFFOztBQUFDLFNBQU9DLEtBQVA7QUFBZTs7QUFBQTs7QUFFcGdCLE1BQU1zTixZQUFZLEdBQUlqSSxNQUFELElBQVk7QUFDL0IsTUFBSTRPLE1BQUo7O0FBRUEsTUFBSXJULEtBQUssQ0FBQ0MsT0FBTixDQUFjd0UsTUFBTSxDQUFDL0YsSUFBckIsQ0FBSixFQUFnQztBQUM5QjJVLFVBQU0sR0FBRzVPLE1BQU0sQ0FBQy9GLElBQWhCO0FBQ0QsR0FGRCxNQUVPLElBQUlzQixLQUFLLENBQUNDLE9BQU4sQ0FBY3dFLE1BQWQsQ0FBSixFQUEyQjtBQUNoQzRPLFVBQU0sR0FBRzVPLE1BQVQ7QUFDRCxHQUZNLE1BRUE7QUFDTCxXQUFPQSxNQUFQO0FBQ0Q7O0FBRUQ0TyxRQUFNLENBQUNDLE1BQVAsQ0FBZUMsR0FBRCxJQUFTO0FBQ3JCLFFBQUlBLEdBQUcsQ0FBQy9QLG9FQUFVLENBQUMrQix3QkFBWixDQUFILEtBQTZDcEcsU0FBakQsRUFBNEQ7QUFDMURILG9CQUFjLENBQUMsQ0FBQ3VVLEdBQUQsRUFBTSxRQUFOLEVBQWdCN1MsQ0FBQyxJQUFJQSxDQUFDLENBQUM4QyxvRUFBVSxDQUFDK0Isd0JBQVosQ0FBdEIsRUFBNkQsUUFBN0QsRUFBdUUzRSxFQUFFLElBQUlBLEVBQUUsQ0FBQzRTLFFBQWhGLEVBQTBGLGdCQUExRixFQUE0RzFTLEVBQUUsSUFBSUEsRUFBRSxDQUFDd1MsTUFBckgsRUFBNkgsTUFBN0gsRUFBcUlsRixFQUFFLElBQUlBLEVBQUUsQ0FBRXFGLE1BQUQsSUFBWTtBQUN2SyxlQUFPQSxNQUFNLENBQUNwWixLQUFkO0FBQ0EsZUFBT29aLE1BQU0sQ0FBQ0MsSUFBZDtBQUNELE9BSDJKLENBQTdJLENBQUQsQ0FBZDtBQUlEOztBQUNELFFBQUlILEdBQUcsQ0FBQy9QLG9FQUFVLENBQUNDLGNBQVosQ0FBSCxLQUFtQ3RFLFNBQXZDLEVBQWtEO0FBQ2hELFVBQUlhLEtBQUssQ0FBQ0MsT0FBTixDQUFjc1QsR0FBRyxDQUFDL1Asb0VBQVUsQ0FBQ0MsY0FBWixDQUFILENBQStCckUsS0FBL0IsQ0FBcUN1VSxPQUFuRCxDQUFKLEVBQWlFO0FBQy9ESixXQUFHLENBQUMvUCxvRUFBVSxDQUFDQyxjQUFaLENBQUgsQ0FBK0JyRSxLQUEvQixDQUFxQ3VVLE9BQXJDLENBQTZDTCxNQUE3QyxDQUFxREcsTUFBRCxJQUFZO0FBQzlELGlCQUFPQSxNQUFNLENBQUNwWixLQUFkO0FBQ0QsU0FGRDtBQUdEOztBQUNELFVBQUlrWixHQUFHLENBQUMvUCxvRUFBVSxDQUFDQyxjQUFaLENBQUgsQ0FBK0JyRSxLQUEvQixDQUFxQ3NFLEtBQXJDLEtBQStDLEVBQW5ELEVBQXVEO0FBQ3JENlAsV0FBRyxDQUFDL1Asb0VBQVUsQ0FBQ0MsY0FBWixDQUFILENBQStCckUsS0FBL0IsQ0FBcUNzRSxLQUFyQyxHQUE2QyxJQUE3QztBQUNEO0FBQ0Y7O0FBQ0QsV0FBTzZQLEdBQVA7QUFDRCxHQWxCRDtBQW1CQSxTQUFPOU8sTUFBUDtBQUNELENBL0JEOztBQWlDZWlJLDJFQUFmLEU7Ozs7Ozs7Ozs7OztBQ25DQTtBQUFBLE1BQU10SyxjQUFjLEdBQUlkLEdBQUQsSUFBUztBQUM5QixNQUFJc1MsV0FBVyxHQUFHdFMsR0FBbEI7O0FBRUEsTUFBSUEsR0FBRyxJQUFJQSxHQUFHLENBQUNoQyxNQUFKLEdBQWEsQ0FBeEIsRUFBMkI7QUFDekJzVSxlQUFXLEdBQUd0UyxHQUFHLENBQUNDLE1BQUosQ0FBVyxDQUFYLEVBQWNDLFdBQWQsRUFBZDtBQUNEOztBQUVELFNBQU9vUyxXQUFQO0FBQ0QsQ0FSRDs7QUFVZXhSLDZFQUFmLEU7Ozs7Ozs7Ozs7OztBQ1ZBO0FBQUE7QUFBQTs7QUFFQSxNQUFNK0UsY0FBYyxHQUFJN0csSUFBRCxJQUFVO0FBQy9CLE1BQUltRyxNQUFNLEdBQUcsRUFBYjs7QUFDQSxVQUFRbkcsSUFBUjtBQUNFLFNBQUtxRyxzRUFBWSxDQUFDSyxTQUFsQjtBQUNFUCxZQUFNLEdBQUcsV0FBVDtBQUNBOztBQUNGLFNBQUtFLHNFQUFZLENBQUNJLEdBQWxCO0FBQ0VOLFlBQU0sR0FBRyxLQUFUO0FBQ0E7O0FBQ0YsU0FBS0Usc0VBQVksQ0FBQ0csV0FBbEI7QUFDRUwsWUFBTSxHQUFHLGFBQVQ7QUFDQTs7QUFDRixTQUFLRSxzRUFBWSxDQUFDQyxJQUFsQjtBQUNFSCxZQUFNLEdBQUcsTUFBVDtBQUNBOztBQUNGO0FBQ0U7QUFkSjs7QUFnQkEsU0FBT0EsTUFBUDtBQUNELENBbkJEOztBQXFCZVUsNkVBQWYsRSIsImZpbGUiOiJRdWV1ZUNvbnRhaW5lcl8xMDYwYjYxNjFjYWY4NDQ2MTgwMi5qcyIsInNvdXJjZXNDb250ZW50IjpbIiFmdW5jdGlvbih0LGUpe1wib2JqZWN0XCI9PXR5cGVvZiBleHBvcnRzJiZcInVuZGVmaW5lZFwiIT10eXBlb2YgbW9kdWxlP21vZHVsZS5leHBvcnRzPWUoKTpcImZ1bmN0aW9uXCI9PXR5cGVvZiBkZWZpbmUmJmRlZmluZS5hbWQ/ZGVmaW5lKGUpOnQuZGF5anM9ZSgpfSh0aGlzLGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dmFyIHQ9XCJtaWxsaXNlY29uZFwiLGU9XCJzZWNvbmRcIixuPVwibWludXRlXCIscj1cImhvdXJcIixpPVwiZGF5XCIscz1cIndlZWtcIix1PVwibW9udGhcIixhPVwicXVhcnRlclwiLG89XCJ5ZWFyXCIsZj1cImRhdGVcIixoPS9eKFxcZHs0fSlbLS9dPyhcXGR7MSwyfSk/Wy0vXT8oXFxkezAsMn0pW14wLTldKihcXGR7MSwyfSk/Oj8oXFxkezEsMn0pPzo/KFxcZHsxLDJ9KT9bLjpdPyhcXGQrKT8kLyxjPS9cXFsoW15cXF1dKyldfFl7MSw0fXxNezEsNH18RHsxLDJ9fGR7MSw0fXxIezEsMn18aHsxLDJ9fGF8QXxtezEsMn18c3sxLDJ9fFp7MSwyfXxTU1MvZyxkPXtuYW1lOlwiZW5cIix3ZWVrZGF5czpcIlN1bmRheV9Nb25kYXlfVHVlc2RheV9XZWRuZXNkYXlfVGh1cnNkYXlfRnJpZGF5X1NhdHVyZGF5XCIuc3BsaXQoXCJfXCIpLG1vbnRoczpcIkphbnVhcnlfRmVicnVhcnlfTWFyY2hfQXByaWxfTWF5X0p1bmVfSnVseV9BdWd1c3RfU2VwdGVtYmVyX09jdG9iZXJfTm92ZW1iZXJfRGVjZW1iZXJcIi5zcGxpdChcIl9cIil9LCQ9ZnVuY3Rpb24odCxlLG4pe3ZhciByPVN0cmluZyh0KTtyZXR1cm4hcnx8ci5sZW5ndGg+PWU/dDpcIlwiK0FycmF5KGUrMS1yLmxlbmd0aCkuam9pbihuKSt0fSxsPXtzOiQsejpmdW5jdGlvbih0KXt2YXIgZT0tdC51dGNPZmZzZXQoKSxuPU1hdGguYWJzKGUpLHI9TWF0aC5mbG9vcihuLzYwKSxpPW4lNjA7cmV0dXJuKGU8PTA/XCIrXCI6XCItXCIpKyQociwyLFwiMFwiKStcIjpcIiskKGksMixcIjBcIil9LG06ZnVuY3Rpb24gdChlLG4pe2lmKGUuZGF0ZSgpPG4uZGF0ZSgpKXJldHVybi10KG4sZSk7dmFyIHI9MTIqKG4ueWVhcigpLWUueWVhcigpKSsobi5tb250aCgpLWUubW9udGgoKSksaT1lLmNsb25lKCkuYWRkKHIsdSkscz1uLWk8MCxhPWUuY2xvbmUoKS5hZGQocisocz8tMToxKSx1KTtyZXR1cm4rKC0ocisobi1pKS8ocz9pLWE6YS1pKSl8fDApfSxhOmZ1bmN0aW9uKHQpe3JldHVybiB0PDA/TWF0aC5jZWlsKHQpfHwwOk1hdGguZmxvb3IodCl9LHA6ZnVuY3Rpb24oaCl7cmV0dXJue006dSx5Om8sdzpzLGQ6aSxEOmYsaDpyLG06bixzOmUsbXM6dCxROmF9W2hdfHxTdHJpbmcoaHx8XCJcIikudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9zJC8sXCJcIil9LHU6ZnVuY3Rpb24odCl7cmV0dXJuIHZvaWQgMD09PXR9fSx5PVwiZW5cIixNPXt9O01beV09ZDt2YXIgbT1mdW5jdGlvbih0KXtyZXR1cm4gdCBpbnN0YW5jZW9mIFN9LEQ9ZnVuY3Rpb24odCxlLG4pe3ZhciByO2lmKCF0KXJldHVybiB5O2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KU1bdF0mJihyPXQpLGUmJihNW3RdPWUscj10KTtlbHNle3ZhciBpPXQubmFtZTtNW2ldPXQscj1pfXJldHVybiFuJiZyJiYoeT1yKSxyfHwhbiYmeX0sdj1mdW5jdGlvbih0LGUpe2lmKG0odCkpcmV0dXJuIHQuY2xvbmUoKTt2YXIgbj1cIm9iamVjdFwiPT10eXBlb2YgZT9lOnt9O3JldHVybiBuLmRhdGU9dCxuLmFyZ3M9YXJndW1lbnRzLG5ldyBTKG4pfSxnPWw7Zy5sPUQsZy5pPW0sZy53PWZ1bmN0aW9uKHQsZSl7cmV0dXJuIHYodCx7bG9jYWxlOmUuJEwsdXRjOmUuJHUseDplLiR4LCRvZmZzZXQ6ZS4kb2Zmc2V0fSl9O3ZhciBTPWZ1bmN0aW9uKCl7ZnVuY3Rpb24gZCh0KXt0aGlzLiRMPUQodC5sb2NhbGUsbnVsbCwhMCksdGhpcy5wYXJzZSh0KX12YXIgJD1kLnByb3RvdHlwZTtyZXR1cm4gJC5wYXJzZT1mdW5jdGlvbih0KXt0aGlzLiRkPWZ1bmN0aW9uKHQpe3ZhciBlPXQuZGF0ZSxuPXQudXRjO2lmKG51bGw9PT1lKXJldHVybiBuZXcgRGF0ZShOYU4pO2lmKGcudShlKSlyZXR1cm4gbmV3IERhdGU7aWYoZSBpbnN0YW5jZW9mIERhdGUpcmV0dXJuIG5ldyBEYXRlKGUpO2lmKFwic3RyaW5nXCI9PXR5cGVvZiBlJiYhL1okL2kudGVzdChlKSl7dmFyIHI9ZS5tYXRjaChoKTtpZihyKXt2YXIgaT1yWzJdLTF8fDAscz0ocls3XXx8XCIwXCIpLnN1YnN0cmluZygwLDMpO3JldHVybiBuP25ldyBEYXRlKERhdGUuVVRDKHJbMV0saSxyWzNdfHwxLHJbNF18fDAscls1XXx8MCxyWzZdfHwwLHMpKTpuZXcgRGF0ZShyWzFdLGksclszXXx8MSxyWzRdfHwwLHJbNV18fDAscls2XXx8MCxzKX19cmV0dXJuIG5ldyBEYXRlKGUpfSh0KSx0aGlzLiR4PXQueHx8e30sdGhpcy5pbml0KCl9LCQuaW5pdD1mdW5jdGlvbigpe3ZhciB0PXRoaXMuJGQ7dGhpcy4keT10LmdldEZ1bGxZZWFyKCksdGhpcy4kTT10LmdldE1vbnRoKCksdGhpcy4kRD10LmdldERhdGUoKSx0aGlzLiRXPXQuZ2V0RGF5KCksdGhpcy4kSD10LmdldEhvdXJzKCksdGhpcy4kbT10LmdldE1pbnV0ZXMoKSx0aGlzLiRzPXQuZ2V0U2Vjb25kcygpLHRoaXMuJG1zPXQuZ2V0TWlsbGlzZWNvbmRzKCl9LCQuJHV0aWxzPWZ1bmN0aW9uKCl7cmV0dXJuIGd9LCQuaXNWYWxpZD1mdW5jdGlvbigpe3JldHVybiEoXCJJbnZhbGlkIERhdGVcIj09PXRoaXMuJGQudG9TdHJpbmcoKSl9LCQuaXNTYW1lPWZ1bmN0aW9uKHQsZSl7dmFyIG49dih0KTtyZXR1cm4gdGhpcy5zdGFydE9mKGUpPD1uJiZuPD10aGlzLmVuZE9mKGUpfSwkLmlzQWZ0ZXI9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdih0KTx0aGlzLnN0YXJ0T2YoZSl9LCQuaXNCZWZvcmU9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdGhpcy5lbmRPZihlKTx2KHQpfSwkLiRnPWZ1bmN0aW9uKHQsZSxuKXtyZXR1cm4gZy51KHQpP3RoaXNbZV06dGhpcy5zZXQobix0KX0sJC51bml4PWZ1bmN0aW9uKCl7cmV0dXJuIE1hdGguZmxvb3IodGhpcy52YWx1ZU9mKCkvMWUzKX0sJC52YWx1ZU9mPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuJGQuZ2V0VGltZSgpfSwkLnN0YXJ0T2Y9ZnVuY3Rpb24odCxhKXt2YXIgaD10aGlzLGM9ISFnLnUoYSl8fGEsZD1nLnAodCksJD1mdW5jdGlvbih0LGUpe3ZhciBuPWcudyhoLiR1P0RhdGUuVVRDKGguJHksZSx0KTpuZXcgRGF0ZShoLiR5LGUsdCksaCk7cmV0dXJuIGM/bjpuLmVuZE9mKGkpfSxsPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIGcudyhoLnRvRGF0ZSgpW3RdLmFwcGx5KGgudG9EYXRlKFwic1wiKSwoYz9bMCwwLDAsMF06WzIzLDU5LDU5LDk5OV0pLnNsaWNlKGUpKSxoKX0seT10aGlzLiRXLE09dGhpcy4kTSxtPXRoaXMuJEQsRD1cInNldFwiKyh0aGlzLiR1P1wiVVRDXCI6XCJcIik7c3dpdGNoKGQpe2Nhc2UgbzpyZXR1cm4gYz8kKDEsMCk6JCgzMSwxMSk7Y2FzZSB1OnJldHVybiBjPyQoMSxNKTokKDAsTSsxKTtjYXNlIHM6dmFyIHY9dGhpcy4kbG9jYWxlKCkud2Vla1N0YXJ0fHwwLFM9KHk8dj95Kzc6eSktdjtyZXR1cm4gJChjP20tUzptKyg2LVMpLE0pO2Nhc2UgaTpjYXNlIGY6cmV0dXJuIGwoRCtcIkhvdXJzXCIsMCk7Y2FzZSByOnJldHVybiBsKEQrXCJNaW51dGVzXCIsMSk7Y2FzZSBuOnJldHVybiBsKEQrXCJTZWNvbmRzXCIsMik7Y2FzZSBlOnJldHVybiBsKEQrXCJNaWxsaXNlY29uZHNcIiwzKTtkZWZhdWx0OnJldHVybiB0aGlzLmNsb25lKCl9fSwkLmVuZE9mPWZ1bmN0aW9uKHQpe3JldHVybiB0aGlzLnN0YXJ0T2YodCwhMSl9LCQuJHNldD1mdW5jdGlvbihzLGEpe3ZhciBoLGM9Zy5wKHMpLGQ9XCJzZXRcIisodGhpcy4kdT9cIlVUQ1wiOlwiXCIpLCQ9KGg9e30saFtpXT1kK1wiRGF0ZVwiLGhbZl09ZCtcIkRhdGVcIixoW3VdPWQrXCJNb250aFwiLGhbb109ZCtcIkZ1bGxZZWFyXCIsaFtyXT1kK1wiSG91cnNcIixoW25dPWQrXCJNaW51dGVzXCIsaFtlXT1kK1wiU2Vjb25kc1wiLGhbdF09ZCtcIk1pbGxpc2Vjb25kc1wiLGgpW2NdLGw9Yz09PWk/dGhpcy4kRCsoYS10aGlzLiRXKTphO2lmKGM9PT11fHxjPT09byl7dmFyIHk9dGhpcy5jbG9uZSgpLnNldChmLDEpO3kuJGRbJF0obCkseS5pbml0KCksdGhpcy4kZD15LnNldChmLE1hdGgubWluKHRoaXMuJEQseS5kYXlzSW5Nb250aCgpKSkuJGR9ZWxzZSAkJiZ0aGlzLiRkWyRdKGwpO3JldHVybiB0aGlzLmluaXQoKSx0aGlzfSwkLnNldD1mdW5jdGlvbih0LGUpe3JldHVybiB0aGlzLmNsb25lKCkuJHNldCh0LGUpfSwkLmdldD1mdW5jdGlvbih0KXtyZXR1cm4gdGhpc1tnLnAodCldKCl9LCQuYWRkPWZ1bmN0aW9uKHQsYSl7dmFyIGYsaD10aGlzO3Q9TnVtYmVyKHQpO3ZhciBjPWcucChhKSxkPWZ1bmN0aW9uKGUpe3ZhciBuPXYoaCk7cmV0dXJuIGcudyhuLmRhdGUobi5kYXRlKCkrTWF0aC5yb3VuZChlKnQpKSxoKX07aWYoYz09PXUpcmV0dXJuIHRoaXMuc2V0KHUsdGhpcy4kTSt0KTtpZihjPT09bylyZXR1cm4gdGhpcy5zZXQobyx0aGlzLiR5K3QpO2lmKGM9PT1pKXJldHVybiBkKDEpO2lmKGM9PT1zKXJldHVybiBkKDcpO3ZhciAkPShmPXt9LGZbbl09NmU0LGZbcl09MzZlNSxmW2VdPTFlMyxmKVtjXXx8MSxsPXRoaXMuJGQuZ2V0VGltZSgpK3QqJDtyZXR1cm4gZy53KGwsdGhpcyl9LCQuc3VidHJhY3Q9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdGhpcy5hZGQoLTEqdCxlKX0sJC5mb3JtYXQ9ZnVuY3Rpb24odCl7dmFyIGU9dGhpcztpZighdGhpcy5pc1ZhbGlkKCkpcmV0dXJuXCJJbnZhbGlkIERhdGVcIjt2YXIgbj10fHxcIllZWVktTU0tRERUSEg6bW06c3NaXCIscj1nLnoodGhpcyksaT10aGlzLiRsb2NhbGUoKSxzPXRoaXMuJEgsdT10aGlzLiRtLGE9dGhpcy4kTSxvPWkud2Vla2RheXMsZj1pLm1vbnRocyxoPWZ1bmN0aW9uKHQscixpLHMpe3JldHVybiB0JiYodFtyXXx8dChlLG4pKXx8aVtyXS5zdWJzdHIoMCxzKX0sZD1mdW5jdGlvbih0KXtyZXR1cm4gZy5zKHMlMTJ8fDEyLHQsXCIwXCIpfSwkPWkubWVyaWRpZW18fGZ1bmN0aW9uKHQsZSxuKXt2YXIgcj10PDEyP1wiQU1cIjpcIlBNXCI7cmV0dXJuIG4/ci50b0xvd2VyQ2FzZSgpOnJ9LGw9e1lZOlN0cmluZyh0aGlzLiR5KS5zbGljZSgtMiksWVlZWTp0aGlzLiR5LE06YSsxLE1NOmcucyhhKzEsMixcIjBcIiksTU1NOmgoaS5tb250aHNTaG9ydCxhLGYsMyksTU1NTTpoKGYsYSksRDp0aGlzLiRELEREOmcucyh0aGlzLiRELDIsXCIwXCIpLGQ6U3RyaW5nKHRoaXMuJFcpLGRkOmgoaS53ZWVrZGF5c01pbix0aGlzLiRXLG8sMiksZGRkOmgoaS53ZWVrZGF5c1Nob3J0LHRoaXMuJFcsbywzKSxkZGRkOm9bdGhpcy4kV10sSDpTdHJpbmcocyksSEg6Zy5zKHMsMixcIjBcIiksaDpkKDEpLGhoOmQoMiksYTokKHMsdSwhMCksQTokKHMsdSwhMSksbTpTdHJpbmcodSksbW06Zy5zKHUsMixcIjBcIiksczpTdHJpbmcodGhpcy4kcyksc3M6Zy5zKHRoaXMuJHMsMixcIjBcIiksU1NTOmcucyh0aGlzLiRtcywzLFwiMFwiKSxaOnJ9O3JldHVybiBuLnJlcGxhY2UoYyxmdW5jdGlvbih0LGUpe3JldHVybiBlfHxsW3RdfHxyLnJlcGxhY2UoXCI6XCIsXCJcIil9KX0sJC51dGNPZmZzZXQ9ZnVuY3Rpb24oKXtyZXR1cm4gMTUqLU1hdGgucm91bmQodGhpcy4kZC5nZXRUaW1lem9uZU9mZnNldCgpLzE1KX0sJC5kaWZmPWZ1bmN0aW9uKHQsZixoKXt2YXIgYyxkPWcucChmKSwkPXYodCksbD02ZTQqKCQudXRjT2Zmc2V0KCktdGhpcy51dGNPZmZzZXQoKSkseT10aGlzLSQsTT1nLm0odGhpcywkKTtyZXR1cm4gTT0oYz17fSxjW29dPU0vMTIsY1t1XT1NLGNbYV09TS8zLGNbc109KHktbCkvNjA0OGU1LGNbaV09KHktbCkvODY0ZTUsY1tyXT15LzM2ZTUsY1tuXT15LzZlNCxjW2VdPXkvMWUzLGMpW2RdfHx5LGg/TTpnLmEoTSl9LCQuZGF5c0luTW9udGg9ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy5lbmRPZih1KS4kRH0sJC4kbG9jYWxlPWZ1bmN0aW9uKCl7cmV0dXJuIE1bdGhpcy4kTF19LCQubG9jYWxlPWZ1bmN0aW9uKHQsZSl7aWYoIXQpcmV0dXJuIHRoaXMuJEw7dmFyIG49dGhpcy5jbG9uZSgpLHI9RCh0LGUsITApO3JldHVybiByJiYobi4kTD1yKSxufSwkLmNsb25lPWZ1bmN0aW9uKCl7cmV0dXJuIGcudyh0aGlzLiRkLHRoaXMpfSwkLnRvRGF0ZT1mdW5jdGlvbigpe3JldHVybiBuZXcgRGF0ZSh0aGlzLnZhbHVlT2YoKSl9LCQudG9KU09OPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuaXNWYWxpZCgpP3RoaXMudG9JU09TdHJpbmcoKTpudWxsfSwkLnRvSVNPU3RyaW5nPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuJGQudG9JU09TdHJpbmcoKX0sJC50b1N0cmluZz1mdW5jdGlvbigpe3JldHVybiB0aGlzLiRkLnRvVVRDU3RyaW5nKCl9LGR9KCkscD1TLnByb3RvdHlwZTtyZXR1cm4gdi5wcm90b3R5cGU9cCxbW1wiJG1zXCIsdF0sW1wiJHNcIixlXSxbXCIkbVwiLG5dLFtcIiRIXCIscl0sW1wiJFdcIixpXSxbXCIkTVwiLHVdLFtcIiR5XCIsb10sW1wiJERcIixmXV0uZm9yRWFjaChmdW5jdGlvbih0KXtwW3RbMV1dPWZ1bmN0aW9uKGUpe3JldHVybiB0aGlzLiRnKGUsdFswXSx0WzFdKX19KSx2LmV4dGVuZD1mdW5jdGlvbih0LGUpe3JldHVybiB0LiRpfHwodChlLFMsdiksdC4kaT0hMCksdn0sdi5sb2NhbGU9RCx2LmlzRGF5anM9bSx2LnVuaXg9ZnVuY3Rpb24odCl7cmV0dXJuIHYoMWUzKnQpfSx2LmVuPU1beV0sdi5Mcz1NLHYucD17fSx2fSk7XG4iLCIhZnVuY3Rpb24ocix0KXtcIm9iamVjdFwiPT10eXBlb2YgZXhwb3J0cyYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIG1vZHVsZT9tb2R1bGUuZXhwb3J0cz10KCk6XCJmdW5jdGlvblwiPT10eXBlb2YgZGVmaW5lJiZkZWZpbmUuYW1kP2RlZmluZSh0KTpyLmRheWpzX3BsdWdpbl9yZWxhdGl2ZVRpbWU9dCgpfSh0aGlzLGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7cmV0dXJuIGZ1bmN0aW9uKHIsdCxlKXtyPXJ8fHt9O3ZhciBuPXQucHJvdG90eXBlLG89e2Z1dHVyZTpcImluICVzXCIscGFzdDpcIiVzIGFnb1wiLHM6XCJhIGZldyBzZWNvbmRzXCIsbTpcImEgbWludXRlXCIsbW06XCIlZCBtaW51dGVzXCIsaDpcImFuIGhvdXJcIixoaDpcIiVkIGhvdXJzXCIsZDpcImEgZGF5XCIsZGQ6XCIlZCBkYXlzXCIsTTpcImEgbW9udGhcIixNTTpcIiVkIG1vbnRoc1wiLHk6XCJhIHllYXJcIix5eTpcIiVkIHllYXJzXCJ9O2Z1bmN0aW9uIGkocix0LGUsbyl7cmV0dXJuIG4uZnJvbVRvQmFzZShyLHQsZSxvKX1lLmVuLnJlbGF0aXZlVGltZT1vLG4uZnJvbVRvQmFzZT1mdW5jdGlvbih0LG4saSxkLHUpe2Zvcih2YXIgYSxmLHMsbD1pLiRsb2NhbGUoKS5yZWxhdGl2ZVRpbWV8fG8saD1yLnRocmVzaG9sZHN8fFt7bDpcInNcIixyOjQ0LGQ6XCJzZWNvbmRcIn0se2w6XCJtXCIscjo4OX0se2w6XCJtbVwiLHI6NDQsZDpcIm1pbnV0ZVwifSx7bDpcImhcIixyOjg5fSx7bDpcImhoXCIscjoyMSxkOlwiaG91clwifSx7bDpcImRcIixyOjM1fSx7bDpcImRkXCIscjoyNSxkOlwiZGF5XCJ9LHtsOlwiTVwiLHI6NDV9LHtsOlwiTU1cIixyOjEwLGQ6XCJtb250aFwifSx7bDpcInlcIixyOjE3fSx7bDpcInl5XCIsZDpcInllYXJcIn1dLG09aC5sZW5ndGgsYz0wO2M8bTtjKz0xKXt2YXIgeT1oW2NdO3kuZCYmKGE9ZD9lKHQpLmRpZmYoaSx5LmQsITApOmkuZGlmZih0LHkuZCwhMCkpO3ZhciBwPShyLnJvdW5kaW5nfHxNYXRoLnJvdW5kKShNYXRoLmFicyhhKSk7aWYocz1hPjAscDw9eS5yfHwheS5yKXtwPD0xJiZjPjAmJih5PWhbYy0xXSk7dmFyIHY9bFt5LmxdO3UmJihwPXUoXCJcIitwKSksZj1cInN0cmluZ1wiPT10eXBlb2Ygdj92LnJlcGxhY2UoXCIlZFwiLHApOnYocCxuLHkubCxzKTticmVha319aWYobilyZXR1cm4gZjt2YXIgTT1zP2wuZnV0dXJlOmwucGFzdDtyZXR1cm5cImZ1bmN0aW9uXCI9PXR5cGVvZiBNP00oZik6TS5yZXBsYWNlKFwiJXNcIixmKX0sbi50bz1mdW5jdGlvbihyLHQpe3JldHVybiBpKHIsdCx0aGlzLCEwKX0sbi5mcm9tPWZ1bmN0aW9uKHIsdCl7cmV0dXJuIGkocix0LHRoaXMpfTt2YXIgZD1mdW5jdGlvbihyKXtyZXR1cm4gci4kdT9lLnV0YygpOmUoKX07bi50b05vdz1mdW5jdGlvbihyKXtyZXR1cm4gdGhpcy50byhkKHRoaXMpLHIpfSxuLmZyb21Ob3c9ZnVuY3Rpb24ocil7cmV0dXJuIHRoaXMuZnJvbShkKHRoaXMpLHIpfX19KTtcbiIsIlxuaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5pbXBvcnQgUGxhaW5CdXR0b24sIHt9IGZyb20gJy4vUGxhaW5CdXR0b24nXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3N0eWxlcy9wYWxldHRlJ1xuXG5cblxuXG5cblxuXG5cblxuY29uc3QgQWN0aW9uQnV0dG9uID0gc3R5bGVkKFBsYWluQnV0dG9uKSgoe3dhaXRpbmcsIGRpc2FibGVkfSkgPT4ge1xuICAvL2NvbnN0IHt3YWl0aW5nLCBkaXNhYmxlZH0gPSBwcm9wc1xuICAvL2NvbnN0IGlzRGlzYWJsZWQgPSBkaXNhYmxlZCB8fCB3YWl0aW5nXG4gIHJldHVybiB7XG4gICAgaGVpZ2h0OiAyOCxcbiAgICBsaW5lSGVpZ2h0OiAnMjJweCcsXG4gICAgY29sb3I6ICcjZmZmJyxcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IFBBTEVUVEUuUFJJTUFSWV9NQUlOLFxuICAgIGZvbnRXZWlnaHQ6IDUwMCxcbiAgICBmb250U2l6ZTogMTQsXG4gICAgb3V0bGluZTogMCxcbiAgICBib3hTaGFkb3c6ICdyZ2JhKDE1LCAxNSwgMTUsIDAuMSkgMHB4IDBweCAwcHggMXB4IGluc2V0LCByZ2JhKDE1LCAxNSwgMTUsIDAuMSkgMHB4IDFweCAycHgnLFxuICAgIG1hcmdpbjogMCxcbiAgICBib3JkZXJSYWRpdXM6IDQsXG4gICAgYm9yZGVyOiBgMXB4IHNvbGlkIHRyYW5zcGFyZW50YCxcbiAgICB0cmFuc2l0aW9uOiAnYWxsIDAuMjVzIGVhc2UtaW4tb3V0JyxcbiAgICBwYWRkaW5nOiAnMCAxMHB4JyxcbiAgICAnOmhvdmVyJzoge1xuICAgICAgYmFja2dyb3VuZENvbG9yOiBQQUxFVFRFLlBSSU1BUllfTUFJTl9EQVJLLFxuICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7UEFMRVRURS5QUklNQVJZX01BSU5fREFSS31gXG4gICAgfSxcbiAgICAnOmZvY3VzLCA6YWN0aXZlJzoge1xuICAgICAgYm94U2hhZG93OiBgMCAwIDAgM3B4ICR7UEFMRVRURS5CT1hfU0hBRE9XX1BSSU1BUll9YCxcbiAgICAgIGJhY2tncm91bmRDb2xvcjogUEFMRVRURS5QUklNQVJZX01BSU5fREFSSyxcbiAgICAgIGJvcmRlcjogYDFweCBzb2xpZCAke1BBTEVUVEUuUFJJTUFSWV9NQUlOX0RBUkt9YFxuICAgIH1cbiAgfVxufSlcblxuZXhwb3J0IGRlZmF1bHQgQWN0aW9uQnV0dG9uXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvY2xpZW50L2NvbXBvbmVudHMvRW1wdHlQYWdlLnRzeFwiO2ltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IHtGT05UX0ZBTUlMWX0gZnJvbSAnc3R5bGVzL3R5cG9ncmFwaHknXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3N0eWxlcy9wYWxldHRlJ1xuXG5cblxuXG5cblxuXG5cbmNvbnN0IFdyYXBwZXIgPSBzdHlsZWQuZGl2KHtcbiAgYmFja2dyb3VuZENvbG9yOiAnI2ZmZicsXG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXG4gIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gIGhlaWdodDogJzEwMCUnLFxuICB3aWR0aDogJzEwMCUnLFxuICBmb250RmFtaWx5OiBGT05UX0ZBTUlMWS5TQU5TX1NFUklGXG59KVxuXG5jb25zdCBUaXRsZSA9IHN0eWxlZC5kaXYoe1xuICBjb2xvcjogUEFMRVRURS5URVhUX01BSU4sXG4gIGZvbnRTaXplOiAyNCxcbiAgZm9udFdlaWdodDogNTAwLFxuICBtYXJnaW46ICcyMHB4IDAgMTVweCdcbn0pXG5cbmNvbnN0IFN1YlRpdGxlID0gc3R5bGVkLmRpdih7XG4gIGNvbG9yOiBQQUxFVFRFLlRFWFRfTUFJTixcbiAgZm9udFNpemU6IDE2LFxuICBmb250V2VpZ2h0OiA0MDAsXG4gIG1hcmdpbjogJzBweCAwIDIwcHgnLFxuICAnPiBkaXYgPiBhJzoge1xuICAgIGNvbG9yOiBQQUxFVFRFLlBSSU1BUllfTUFJTlxuICB9XG59KVxuXG5jb25zdCBFbXB0eVBhZ2UgPSAoe3N2ZywgaGVhZGVyLCBzdWJIZWFkZXIsIGJ1dHRvbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFdyYXBwZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDN9fVxuICAgICAgLCBzdmdcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChUaXRsZSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0NX19LCBoZWFkZXIpXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3ViVGl0bGUsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDZ9fSwgc3ViSGVhZGVyKVxuICAgICAgLCBidXR0b25cbiAgICApXG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgRW1wdHlQYWdlXG4iLCJcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IFBsYWluQnV0dG9uLCB7fSBmcm9tICcuL1BsYWluQnV0dG9uJ1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICdzdHlsZXMvcGFsZXR0ZSdcblxuXG5cblxuXG5cblxuXG5cbmNvbnN0IEZsYXRCdXR0b24gPSBzdHlsZWQoUGxhaW5CdXR0b24pKChwcm9wcykgPT4ge1xuICBjb25zdCB7d2FpdGluZywgZGlzYWJsZWR9ID0gcHJvcHNcbiAgY29uc3QgaXNEaXNhYmxlZCA9IGRpc2FibGVkIHx8IHdhaXRpbmdcbiAgcmV0dXJuIHtcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IFBBTEVUVEUuUFJJTUFSWV9NQUlOLFxuICAgIGNvbG9yOiAnI2ZmZicsXG4gICAgYm9yZGVyUmFkaXVzOiA0LFxuICAgIGJveFNoYWRvdzogJ3JnYmEoMTUsIDE1LCAxNSwgMC4xKSAwcHggMHB4IDBweCAxcHggaW5zZXQsIHJnYmEoMTUsIDE1LCAxNSwgMC4xKSAwcHggMXB4IDJweCcsXG4gICAgb3V0bGluZTogMCxcbiAgICAnOmhvdmVyJzoge1xuICAgICAgYmFja2dyb3VuZENvbG9yOiAhaXNEaXNhYmxlZCAmJiBQQUxFVFRFLlBSSU1BUllfTUFJTl9EQVJLXG4gICAgfSxcbiAgICAnOmFjdGl2ZSwgOmZvY3VzJzoge1xuICAgICAgYm94U2hhZG93OiBgMCAwIDAgM3B4ICR7UEFMRVRURS5CT1hfU0hBRE9XX1BSSU1BUll9YCxcbiAgICAgIGJhY2tncm91bmRDb2xvcjogIWlzRGlzYWJsZWQgJiYgUEFMRVRURS5QUklNQVJZX01BSU5fTElHSFRFUlxuICAgIH1cbiAgfVxufSlcblxuZXhwb3J0IGRlZmF1bHQgRmxhdEJ1dHRvblxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL2NsaWVudC9jb21wb25lbnRzL1F1ZXVlQWN0aW9uc01lbnUudHN4XCI7aW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtjb25uZWN0fSBmcm9tICdyZWFjdC1yZWR1eCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IE1lbnUgZnJvbSAnLi9NZW51J1xuXG5pbXBvcnQgTWVudUl0ZW0gZnJvbSAnLi9NZW51SXRlbSdcbmltcG9ydCB7UEFMRVRURX0gZnJvbSAnc3R5bGVzL3BhbGV0dGUnXG5pbXBvcnQgSWNvbiBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9JY29uJ1xuaW1wb3J0IHVzZVJvdXRlciBmcm9tICdob29rcy91c2VSb3V0ZXInXG5cblxuXG5cblxuXG5cblxuXG5cbmNvbnN0IE1lbnVDb250YWluZXIgPSBzdHlsZWQuZGl2KHtcbiAgd2lkdGg6IDIwMFxufSlcblxuY29uc3QgU3R5bGVkSWNvbiA9IHN0eWxlZChJY29uKSh7XG4gIGRpc3BsYXk6ICdibG9jaycsXG4gIGNvbG9yOiBQQUxFVFRFLlRFWFRfR1JBWSxcbiAgbWFyZ2luUmlnaHQ6IDE1LFxuICBmb250U2l6ZTogMThcbn0pXG5cbmNvbnN0IExhYmVsID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgZmxleERpcmVjdGlvbjogJ3JvdycsXG4gIGZvbnRTaXplOiAxNSxcbiAgZm9udFdlaWdodDogNDAwLFxuICBwYWRkaW5nOiAnNXB4IDE1cHgnLFxuICBjb2xvcjogUEFMRVRURS5URVhUX01BSU5cbn0pXG5cbmNvbnN0IFF1ZXVlQWN0aW9uc01lbnUgPSAocHJvcHMpID0+IHtcbiAgY29uc3Qge21lbnVQcm9wcywgcXVldWVJZCwgb25EZWxldGUsIG9uRmx1c2gsIHNlbGVjdGVkUXVldWV9ID0gcHJvcHNcbiAgY29uc3Qge2hpc3Rvcnl9ID0gdXNlUm91dGVyKCkgXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChNZW51Q29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ0fX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChNZW51LCB7IGFyaWFMYWJlbDogJ0FkZCBxdWV1ZSB0YXNrcycsIC4uLm1lbnVQcm9wcywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ1fX1cbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KE1lbnVJdGVtLCB7XG4gICAgICAgICAgbGFiZWw6IFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0OH19XG4gICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTdHlsZWRJY29uLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ5fX0sIFwiZWRpdFwiKVxuICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUwfX0sIFwiRWRpdCBxdWV1ZVwiIClcbiAgICAgICAgICAgIClcbiAgICAgICAgICAsXG4gICAgICAgICAgb25DbGljazogKCkgPT5cbiAgICAgICAgICAgIGhpc3RvcnkucHVzaCh7XG4gICAgICAgICAgICAgIHBhdGhuYW1lOiBgL3F1ZXVlcy8ke3F1ZXVlSWR9L2VkaXRgLFxuICAgICAgICAgICAgICBzdGF0ZToge3ByZXZSb3V0ZTogaGlzdG9yeS5sb2NhdGlvbi5wYXRobmFtZX1cbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDZ9fVxuICAgICAgICApXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChNZW51SXRlbSwge1xuICAgICAgICAgIGxhYmVsOiBcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNjJ9fVxuICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3R5bGVkSWNvbiwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2M319LCBcImNvbnRlbnRfY29weVwiKVxuICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDY0fX0sIFwiQ2xvbmUgcXVldWVcIiApXG4gICAgICAgICAgICApXG4gICAgICAgICAgLFxuICAgICAgICAgIG9uQ2xpY2s6ICgpID0+XG4gICAgICAgICAgICBoaXN0b3J5LnB1c2goe1xuICAgICAgICAgICAgICBwYXRobmFtZTogJy9xdWV1ZXMvbmV3JyxcbiAgICAgICAgICAgICAgc3RhdGU6IHtcbiAgICAgICAgICAgICAgICBoYXNDbG9uZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBjbG9uZWRRdWV1ZToge1xuICAgICAgICAgICAgICAgICAgZGF0YTogc2VsZWN0ZWRRdWV1ZS5kYXRhLFxuICAgICAgICAgICAgICAgICAgbmFtZTogYCR7c2VsZWN0ZWRRdWV1ZS5uYW1lfSBDb3B5YCxcbiAgICAgICAgICAgICAgICAgIGlkOiBzZWxlY3RlZFF1ZXVlLmlkXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDYwfX1cbiAgICAgICAgKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTWVudUl0ZW0sIHtcbiAgICAgICAgICBsYWJlbDogXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDgzfX1cbiAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZEljb24sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogODR9fSwgXCJ1bmRvXCIpXG4gICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgnc3BhbicsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogODV9fSwgXCJEZWxldGUgYWxsIHRhc2tzXCIgIClcbiAgICAgICAgICAgIClcbiAgICAgICAgICAsXG4gICAgICAgICAgb25DbGljazogb25GbHVzaCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDgxfX1cbiAgICAgICAgKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTWVudUl0ZW0sIHtcbiAgICAgICAgICBsYWJlbDogXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDkyfX1cbiAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZEljb24sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogOTN9fSwgXCJkZWxldGVcIilcbiAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdzcGFuJywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA5NH19LCBcIkRlbGV0ZSBxdWV1ZVwiIClcbiAgICAgICAgICAgIClcbiAgICAgICAgICAsXG4gICAgICAgICAgb25DbGljazogb25EZWxldGUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA5MH19XG4gICAgICAgIClcbiAgICAgIClcbiAgICApXG4gIClcbn1cblxuY29uc3QgbWFwU3RhdGVUb1Byb3BzID0gKHN0YXRlKSA9PiAoe1xuICBzZWxlY3RlZFF1ZXVlOiBzdGF0ZS5xdWV1ZXMuc2VsZWN0ZWRRdWV1ZVxufSlcblxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMsIG51bGwpKFF1ZXVlQWN0aW9uc01lbnUpXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvY2xpZW50L2NvbXBvbmVudHMvUXVldWVGaWx0ZXJDb2x1bW5NZW51LnRzeFwiOyBmdW5jdGlvbiBfb3B0aW9uYWxDaGFpbihvcHMpIHsgbGV0IGxhc3RBY2Nlc3NMSFMgPSB1bmRlZmluZWQ7IGxldCB2YWx1ZSA9IG9wc1swXTsgbGV0IGkgPSAxOyB3aGlsZSAoaSA8IG9wcy5sZW5ndGgpIHsgY29uc3Qgb3AgPSBvcHNbaV07IGNvbnN0IGZuID0gb3BzW2kgKyAxXTsgaSArPSAyOyBpZiAoKG9wID09PSAnb3B0aW9uYWxBY2Nlc3MnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgJiYgdmFsdWUgPT0gbnVsbCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9IGlmIChvcCA9PT0gJ2FjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbEFjY2VzcycpIHsgbGFzdEFjY2Vzc0xIUyA9IHZhbHVlOyB2YWx1ZSA9IGZuKHZhbHVlKTsgfSBlbHNlIGlmIChvcCA9PT0gJ2NhbGwnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgeyB2YWx1ZSA9IGZuKCguLi5hcmdzKSA9PiB2YWx1ZS5jYWxsKGxhc3RBY2Nlc3NMSFMsIC4uLmFyZ3MpKTsgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgfSB9IHJldHVybiB2YWx1ZTsgfWltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCB7Y29ubmVjdH0gZnJvbSAncmVhY3QtcmVkdXgnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcbmltcG9ydCBNZW51IGZyb20gJy4vTWVudSdcblxuaW1wb3J0IE1lbnVJdGVtIGZyb20gJy4vTWVudUl0ZW0nXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3N0eWxlcy9wYWxldHRlJ1xuaW1wb3J0IEljb24gZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvSWNvbidcblxuaW1wb3J0IHtCTE9DS1MsIEZJTFRFUl9CTE9DS19UWVBFU30gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcblxuXG5cblxuXG5cblxuXG5jb25zdCBNZW51Q29udGFpbmVyID0gc3R5bGVkLmRpdih7XG4gIHdpZHRoOiAyMDBcbn0pXG5cbmNvbnN0IFN0eWxlZEljb24gPSBzdHlsZWQoSWNvbikoe1xuICBkaXNwbGF5OiAnYmxvY2snLFxuICBjb2xvcjogUEFMRVRURS5URVhUX0dSQVksXG4gIG1hcmdpblJpZ2h0OiAxNSxcbiAgZm9udFNpemU6IDE4XG59KVxuXG5jb25zdCBMYWJlbCA9IHN0eWxlZC5kaXYoe1xuICBkaXNwbGF5OiAnZmxleCcsXG4gIGZsZXhEaXJlY3Rpb246ICdyb3cnLFxuICBmb250U2l6ZTogMTUsXG4gIGZvbnRXZWlnaHQ6IDQwMCxcbiAgcGFkZGluZzogJzVweCA1cHgnLFxuICBjb2xvcjogUEFMRVRURS5URVhUX01BSU5cbn0pXG5cbmNvbnN0IExhYmVsVGV4dCA9IHN0eWxlZC5zcGFuKHtcbiAgd2hpdGVTcGFjZTogJ25vd3JhcCcsXG4gIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgdGV4dE92ZXJmbG93OiAnZWxsaXBzaXMnXG59KVxuXG5jb25zdCBRdWV1ZUZpbHRlckNvbHVtbk1lbnUgPSAocHJvcHMpID0+IHtcbiAgY29uc3Qge21lbnVQcm9wcywgcXVldWUsIHNldFBpbm5lZEJsb2NrLCBhY3RpdmVCbG9ja05hbWV9ID0gcHJvcHNcblxuICBpZiAoIXF1ZXVlIHx8ICFBcnJheS5pc0FycmF5KHF1ZXVlLmRhdGEpKSB7XG4gICAgcmV0dXJuIG51bGxcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChNZW51Q29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUzfX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChNZW51LCB7IGFyaWFMYWJlbDogJ0ZpbHRlciBxdWV1ZSB0YXNrcycsIC4uLm1lbnVQcm9wcywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDU0fX1cbiAgICAgICAgLCBxdWV1ZS5kYXRhLm1hcCgoYmxvY2ssIGlkKSA9PiB7XG4gICAgICAgICAgaWYgKCFGSUxURVJfQkxPQ0tfVFlQRVMuaW5jbHVkZXMoYmxvY2sudHlwZSkpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsXG4gICAgICAgICAgfSBlbHNlXG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KE1lbnVJdGVtLCB7XG4gICAgICAgICAgICAgICAga2V5OiBpZCxcbiAgICAgICAgICAgICAgICBpc0FjdGl2ZTogYWN0aXZlQmxvY2tOYW1lID09PSBibG9jay5uYW1lLFxuICAgICAgICAgICAgICAgIGxhYmVsOiBcbiAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNjR9fVxuICAgICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3R5bGVkSWNvbiwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2NX19LCBfb3B0aW9uYWxDaGFpbihbQkxPQ0tTLCAnYWNjZXNzJywgXyA9PiBfLmZpbmQsICdjYWxsJywgXzIgPT4gXzIoKGIpID0+IGIudHlwZSA9PT0gYmxvY2sudHlwZSksICdvcHRpb25hbEFjY2VzcycsIF8zID0+IF8zLmljb25dKSlcbiAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsVGV4dCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2Nn19LCBibG9jay5uYW1lKVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICxcbiAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRQaW5uZWRCbG9jayhibG9jay5pZClcbiAgICAgICAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNjB9fVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApXG4gICAgICAgIH0pXG4gICAgICAgICwgYWN0aXZlQmxvY2tOYW1lICE9ICcnICYmXG4gICAgICAgICAgYWN0aXZlQmxvY2tOYW1lICE9IG51bGwgJiZcbiAgICAgICAgICBhY3RpdmVCbG9ja05hbWUgIT0gJ0lEJyAmJlxuICAgICAgICAgIHR5cGVvZiBhY3RpdmVCbG9ja05hbWUgIT09ICd1bmRlZmluZWQnICYmIChcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTWVudUl0ZW0sIHtcbiAgICAgICAgICAgICAgZXh0cmFTcGFjZTogdHJ1ZSxcbiAgICAgICAgICAgICAgbGFiZWw6IFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogODJ9fVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZEljb24sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogODN9fSwgXCJyZWZyZXNoXCIpXG4gICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDg0fX0sIFwiUmVzZXQgdG8gSURcIiAgKVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgLFxuICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0UGlubmVkQmxvY2sobnVsbClcbiAgICAgICAgICAgICAgfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDc5fX1cbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG4gICAgICApXG4gICAgKVxuICApXG59XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IChzdGF0ZSkgPT4gKHtcbiAgc2VsZWN0ZWRRdWV1ZTogc3RhdGUucXVldWVzLnNlbGVjdGVkUXVldWVcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBudWxsKShRdWV1ZUZpbHRlckNvbHVtbk1lbnUpXG4iLCJpbXBvcnQge3VzZUVmZmVjdH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IHVzZURvY3VtZW50VGl0bGUgPSAodGl0bGUpID0+IHtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBkb2N1bWVudC50aXRsZSA9IHRpdGxlXG4gIH0sIFt0aXRsZV0pXG59XG5cbmV4cG9ydCBkZWZhdWx0IHVzZURvY3VtZW50VGl0bGVcbiIsImNvbnN0IGNhcGl0YWxpemVGaXJzdExldHRlciA9IChzdHIpID0+IHN0ci5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIHN0ci5zbGljZSgxKVxuZXhwb3J0IGRlZmF1bHQgY2FwaXRhbGl6ZUZpcnN0TGV0dGVyXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvQXZhdGFyLnRzeFwiO2ltcG9ydCBSZWFjdCwge2ZvcndhcmRSZWZ9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJy4uLy4uL2NsaWVudC9zdHlsZXMvcGFsZXR0ZSdcbmltcG9ydCBnZXRGaXJzdExldHRlciBmcm9tICd1bml2ZXJzYWwvdXRpbHMvZ2V0Rmlyc3RMZXR0ZXInXG5cblxuXG5cblxuXG5cblxuXG5cbmNvbnN0IEF2YXRhciA9IGZvcndhcmRSZWYoKHByb3BzLCByZWYpID0+IHtcbiAgY29uc3Qge2luaXRpYWxzLCBjb2xvciwgb25DbGljaywgc3R5bGUsIHRyaW0gPSB0cnVlfSA9IHByb3BzXG5cbiAgY29uc3QgYmFja2dyb3VuZENvbG9yID0gY29sb3IgfHwgUEFMRVRURS5QUklNQVJZX01BSU5cblxuICBjb25zdCBBdmF0YXJCbG9jayA9IHN0eWxlZC5zcGFuKHtcbiAgICBkaXNwbGF5OiAnaW5saW5lLWZsZXgnLFxuICAgIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcbiAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICB0ZXN0QWxpZ246ICdjZW50ZXInLFxuICAgIGhlaWdodDogYDIwcHhgLFxuICAgIHdpZHRoOiBgMjBweGAsXG4gICAgbWluV2lkdGg6IGAyMHB4YCxcbiAgICBmb250V2VpZ2h0OiA3MDAsXG4gICAgZm9udFNpemU6IDExLFxuICAgIGNvbG9yOiAnI2ZmZicsXG4gICAgYm9yZGVyUmFkaXVzOiAnMTAwJScsXG4gICAgYmFja2dyb3VuZENvbG9yOiBiYWNrZ3JvdW5kQ29sb3IsXG4gICAgdXNlclNlbGVjdDogJ25vbmUnLFxuICAgIG1hcmdpbjogJzBweCAycHgnXG4gIH0pXG5cbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEF2YXRhckJsb2NrLCB7IHJlZjogcmVmLCBvbkNsaWNrOiBvbkNsaWNrLCBzdHlsZTogc3R5bGUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzOH19XG4gICAgICAsIHRyaW0gPyBnZXRGaXJzdExldHRlcihpbml0aWFscykgOiBpbml0aWFsc1xuICAgIClcbiAgKVxufSlcblxuZXhwb3J0IGRlZmF1bHQgQXZhdGFyXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvTmV3VGFza01lbnUudHN4XCI7aW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICd1bml2ZXJzYWwvc3R5bGVzL3BhbGV0dGUnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcbmltcG9ydCB7Qm94U2hhZG93fSBmcm9tICdjbGllbnQvdXRpbHMvY29uc3RhbnRzJ1xuaW1wb3J0IHtGb3JtaWssIEZvcm19IGZyb20gJ2Zvcm1paydcbmltcG9ydCBTZWNvbmRhcnlCdXR0b24gZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvU2Vjb25kYXJ5QnV0dG9uJ1xuaW1wb3J0IEZsYXRCdXR0b24gZnJvbSAnLi4vLi4vY2xpZW50L2NvbXBvbmVudHMvRmxhdEJ1dHRvbidcbmltcG9ydCBCYXNpY1RleHRBcmVhIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0Jhc2ljVGV4dEFyZWEnXG5pbXBvcnQgSW5wdXRGaWVsZCBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9JbnB1dEZpZWxkJ1xuaW1wb3J0IGNhcGl0YWxpemVGaXJzdExldHRlciBmcm9tICdjbGllbnQvdXRpbHMvY2FwaXRhbGl6ZUZpcnN0TGV0dGVyJ1xuaW1wb3J0IGN1dE9mZlN0cmluZyBmcm9tICd1bml2ZXJzYWwvdXRpbHMvY3V0T2ZmU3RyaW5nJ1xuaW1wb3J0IFRhc2tSYWRpbyBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9UYXNrUmFkaW8nXG5pbXBvcnQgVGFza0NoZWNrYm94IGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL1Rhc2tDaGVja2JveCdcbmltcG9ydCB7QkxPQ0tfVFlQRSwgU0FNUExFX1ZBTFVFU30gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcbmltcG9ydCB7dGFza01lbnVTY2hlbWF9IGZyb20gJ3VuaXZlcnNhbC92YWxpZGF0aW9ucy95dXBTY2hlbWEnXG5pbXBvcnQgVGV4dEVkaXRvciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9UZXh0RWRpdG9yJ1xuaW1wb3J0IERhdGVQaWNrZXIgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvRGF0ZVBpY2tlcidcblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuY29uc3QgTW9kYWxSb290ID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXG4gIHdpZHRoOiA1MDAsXG4gIGJvcmRlclJhZGl1czogMTAsXG4gIGJhY2tncm91bmRDb2xvcjogJyNmZmYnLFxuICBib3JkZXI6IGAxcHggc29saWQgJHtQQUxFVFRFLkJPUkRFUl9NQUlOX0dSQVl9YCxcbiAgYm94U2hhZG93OiBCb3hTaGFkb3cuTU9EQUxcbn0pXG5cbmNvbnN0IE1haW5UaXRsZSA9IHN0eWxlZC5kaXYoe1xuICBmb250U2l6ZTogMjIsXG4gIGZvbnRXZWlnaHQ6IDYwMCxcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgbWFyZ2luQm90dG9tOiAzNVxufSlcblxuY29uc3QgRm9ybUNvbnRlbnQgPSBzdHlsZWQoRm9ybSkoe1xuICBwYWRkaW5nOiAnMzVweCdcbn0pXG5cbmNvbnN0IFN1Ym1pc3Npb25TZWN0aW9uID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdncmlkJyxcbiAgZ3JpZFRlbXBsYXRlQ29sdW1uczogJ3JlcGVhdCgyLCBhdXRvKScsXG4gIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsXG4gIHBhZGRpbmdUb3A6ICcyNXB4J1xufSlcblxuY29uc3QgSW5wdXQgPSBzdHlsZWQuZGl2KHtcbiAgZGlzcGxheTogJ2dyaWQnLFxuICBncmlkR2FwOiA1LFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgbWFyZ2luQm90dG9tOiAyNFxufSlcblxuY29uc3QgTGFiZWwgPSBzdHlsZWQuZGl2KHtcbiAgZm9udFdlaWdodDogNDAwLFxuICBtYXJnaW5SaWdodDogMjAsXG4gIGZvbnRTaXplOiAxNixcbiAgd2lkdGg6ICcxMDAlJyxcbiAgdGV4dFRyYW5zZm9ybTogJ2NhcGl0YWxpemUnXG59KVxuXG5jb25zdCBCb3ggPSBzdHlsZWQuZGl2KHtcbiAgbWFyZ2luQm90dG9tOiAxMFxufSlcblxuY29uc3QgT3B0aW9ucyA9IHN0eWxlZC5kaXYoe1xuICBtYXhIZWlnaHQ6ICc2MnZoJyxcbiAgb3ZlcmZsb3c6ICdhdXRvJyxcbiAgcGFkZGluZzogJzhweCAwcHgnXG59KVxuXG5jb25zdCBRdWVzdGlvbiA9IHN0eWxlZC5kaXYoe1xuICBmb250V2VpZ2h0OiA1MDAsXG4gIGZvbnRTaXplOiAxNlxufSlcblxuY29uc3QgTmV3VGFza01lbnUgPSAocHJvcHMpID0+IHtcbiAgY29uc3Qge2Nsb3NlUG9ydGFsLCBmb3JtYXQsIG9uU3VibWl0SGFuZGxlcn0gPSBwcm9wc1xuXG4gIGNvbnN0IGluaXRpYWxWYWx1ZXMgPSB7ZGF0YToge30sIHJlcXVpcmVkOiB7fX1cbiAgZm9ybWF0Lm1hcCgoaXRlbSkgPT4ge1xuICAgIGlmIChpbml0aWFsVmFsdWVzLmRhdGFbaXRlbS50eXBlXSkge1xuICAgICAgaW5pdGlhbFZhbHVlcy5kYXRhW2l0ZW0udHlwZV1baXRlbS5pZF0gPSAnJ1xuICAgIH0gZWxzZSB7XG4gICAgICBpbml0aWFsVmFsdWVzLmRhdGFbaXRlbS50eXBlXSA9IHtbaXRlbS5pZF06ICcnfVxuICAgIH1cblxuICAgIGlmIChpdGVtLnR5cGUgPT09IEJMT0NLX1RZUEUuQk9VTkRJTkdfQk9YRVMpIHtcbiAgICAgIGluaXRpYWxWYWx1ZXMuZGF0YVtpdGVtLnR5cGVdID0ge1tpdGVtLmlkXToge2ltYWdlOiAnJ319XG4gICAgfVxuXG4gICAgaWYgKGl0ZW1baXRlbS50eXBlXS5pc19yZXF1aXJlZCkge1xuICAgICAgaWYgKGluaXRpYWxWYWx1ZXMucmVxdWlyZWRbaXRlbS50eXBlXSkge1xuICAgICAgICBpbml0aWFsVmFsdWVzLnJlcXVpcmVkW2l0ZW0udHlwZV1baXRlbS5pZF0gPSB0cnVlXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpbml0aWFsVmFsdWVzLnJlcXVpcmVkW2l0ZW0udHlwZV0gPSB7W2l0ZW0uaWRdOiB0cnVlfVxuICAgICAgfVxuICAgIH1cbiAgfSlcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTW9kYWxSb290LCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDExNX19XG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRm9ybWlrLCB7XG4gICAgICAgIHZhbGlkYXRpb25TY2hlbWE6IHRhc2tNZW51U2NoZW1hLFxuICAgICAgICB2YWxpZGF0ZU9uQ2hhbmdlOiB0cnVlLFxuICAgICAgICB2YWxpZGF0ZU9uQmx1cjogdHJ1ZSxcbiAgICAgICAgdmFsaWRhdGVPbk1vdW50OiB0cnVlLFxuICAgICAgICBpbml0aWFsVmFsdWVzOiBpbml0aWFsVmFsdWVzLFxuICAgICAgICBlbmFibGVSZWluaXRpYWxpemU6IHRydWUsXG4gICAgICAgIG9uU3VibWl0OiBvblN1Ym1pdEhhbmRsZXIsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMTZ9fVxuICAgICAgXG4gICAgICAgICwgKHtcbiAgICAgICAgICB0b3VjaGVkLFxuICAgICAgICAgIGlzU3VibWl0dGluZyxcbiAgICAgICAgICBpc1ZhbGlkLFxuICAgICAgICAgIGhhbmRsZUNoYW5nZSxcbiAgICAgICAgICBoYW5kbGVCbHVyLFxuICAgICAgICAgIHZhbHVlcyxcbiAgICAgICAgICBlcnJvcnMsXG4gICAgICAgICAgc2V0RmllbGRWYWx1ZVxuICAgICAgICB9KSA9PiAoXG4gICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChGb3JtQ29udGVudCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMzV9fVxuICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KE1haW5UaXRsZSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMzZ9fSwgXCJOZXcgVGFza1wiIClcbiAgICAgICAgICAgICwgZm9ybWF0Lm1hcCgoaW5wdXQpID0+IHtcbiAgICAgICAgICAgICAgLy8gdGhpcyBzaW5nbGUgYW5kIG11bHRpcGxlIHNlbGVjdGlvbiBjb2RlIHdpbGwgY3VycmVudGx5IG5ldmVyIGJlIGludm9rZWQgYXMgdGhlIGJhY2sgZW5kIHdpbGwgbm90IHJldHVybiB0aGVzZSB0eXBlc1xuICAgICAgICAgICAgICByZXR1cm4gaW5wdXQudHlwZSA9PT0gQkxPQ0tfVFlQRS5TSU5HTEVfU0VMRUNUSU9OID8gKFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ2RpdicsIHsga2V5OiBpbnB1dC5uYW1lLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTQwfX1cbiAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChRdWVzdGlvbiwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNDF9fSwgY3V0T2ZmU3RyaW5nKGNhcGl0YWxpemVGaXJzdExldHRlcihpbnB1dC5uYW1lKSwgMTgpKVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KE9wdGlvbnMsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTQyfX1cbiAgICAgICAgICAgICAgICAgICAgLCBpbnB1dFtpbnB1dC50eXBlXS5vcHRpb25zLm1hcCgob3B0aW9uLCBvcHRpb25JbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQm94LCB7IGtleTogb3B0aW9uSW5kZXgsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNDR9fVxuICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRhc2tSYWRpbywge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBpbnB1dC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IG9wdGlvbkluZGV4LFxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogb3B0aW9uLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogb3B0aW9uLm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ6IG9wdGlvbi5pZCA9PT0gdmFsdWVzW2lucHV0LmlkXSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE0NX19XG4gICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgKSA6IGlucHV0LnR5cGUgPT09IEJMT0NLX1RZUEUuTVVMVElQTEVfU0VMRUNUSU9OID8gKFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ2RpdicsIHsga2V5OiBpbnB1dC5uYW1lLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTU4fX1cbiAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChRdWVzdGlvbiwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNTl9fSwgY3V0T2ZmU3RyaW5nKGNhcGl0YWxpemVGaXJzdExldHRlcihpbnB1dC5uYW1lKSwgMTgpKVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KE9wdGlvbnMsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTYwfX1cbiAgICAgICAgICAgICAgICAgICAgLCBpbnB1dFtpbnB1dC50eXBlXS5vcHRpb25zLm1hcCgob3B0aW9uLCBvcHRpb25JbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQm94LCB7IGtleTogb3B0aW9uSW5kZXgsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNjJ9fVxuICAgICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRhc2tDaGVja2JveCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBpbnB1dC5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IG9wdGlvbi5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IG9wdGlvbi5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IG9wdGlvbi5uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkOiB2YWx1ZXNbaW5wdXQuaWRdICYmIHZhbHVlc1tpbnB1dC5pZF0uaW5jbHVkZXMob3B0aW9uLmlkKSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE2M319XG4gICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgKSA6IGlucHV0LnR5cGUgPT09IEJMT0NLX1RZUEUuTkFNRURfRU5USVRZX1JFQ09HTklUSU9OID8gKFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSW5wdXQsIHsga2V5OiBpbnB1dC5uYW1lLCB0eXBlOiBpbnB1dC50eXBlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTc2fX1cbiAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNzd9fSwgaW5wdXQubmFtZSlcbiAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChCYXNpY1RleHRBcmVhLCB7XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlOiBcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZXMgJiYgdmFsdWVzLmRhdGEgJiYgdmFsdWVzLmRhdGFbaW5wdXQudHlwZV1cbiAgICAgICAgICAgICAgICAgICAgICAgID8gdmFsdWVzLmRhdGFbaW5wdXQudHlwZV1baW5wdXQuaWRdXG4gICAgICAgICAgICAgICAgICAgICAgICA6IG51bGxcbiAgICAgICAgICAgICAgICAgICAgLFxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcjogXG4gICAgICAgICAgICAgICAgICAgICAgaW5wdXRbaW5wdXQudHlwZV0ucGxhY2Vob2xkZXJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gaW5wdXRbaW5wdXQudHlwZV0ucGxhY2Vob2xkZXJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogU0FNUExFX1ZBTFVFU1tpbnB1dC50eXBlXVxuICAgICAgICAgICAgICAgICAgICAsXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IGBkYXRhWyR7aW5wdXQudHlwZX1dWyR7aW5wdXQuaWR9XWAsXG4gICAgICAgICAgICAgICAgICAgIGVycm9yOiBcbiAgICAgICAgICAgICAgICAgICAgICB0b3VjaGVkICYmXG4gICAgICAgICAgICAgICAgICAgICAgdG91Y2hlZC5kYXRhICYmXG4gICAgICAgICAgICAgICAgICAgICAgdG91Y2hlZC5kYXRhW2lucHV0LnR5cGVdICYmXG4gICAgICAgICAgICAgICAgICAgICAgdG91Y2hlZC5kYXRhW2lucHV0LnR5cGVdW2lucHV0LmlkXSAmJlxuICAgICAgICAgICAgICAgICAgICAgIGVycm9ycyAmJlxuICAgICAgICAgICAgICAgICAgICAgIGVycm9ycy5kYXRhICYmXG4gICAgICAgICAgICAgICAgICAgICAgZXJyb3JzLmRhdGFbaW5wdXQudHlwZV0gJiZcbiAgICAgICAgICAgICAgICAgICAgICBlcnJvcnMuZGF0YVtpbnB1dC50eXBlXVtpbnB1dC5pZF1cbiAgICAgICAgICAgICAgICAgICAgLFxuICAgICAgICAgICAgICAgICAgICBoaWRlRXJyb3JNZXNzYWdlOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgICAgICAgICAgICBvbkJsdXI6IGhhbmRsZUJsdXIsXG4gICAgICAgICAgICAgICAgICAgIG1heFJvd3M6IDMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNzh9fVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgKSA6IGlucHV0LnR5cGUgPT09IEJMT0NLX1RZUEUuQk9VTkRJTkdfQk9YRVMgPyAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJbnB1dCwgeyBrZXk6IGlucHV0Lm5hbWUsIHR5cGU6IGlucHV0LnR5cGUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMDd9fVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIwOH19LCBpbnB1dC5uYW1lKVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KElucHV0RmllbGQsIHtcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6IFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlcyAmJlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlcy5kYXRhICYmXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWVzLmRhdGFbaW5wdXQudHlwZV0gJiZcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZXMuZGF0YVtpbnB1dC50eXBlXVtpbnB1dC5pZF1cbiAgICAgICAgICAgICAgICAgICAgICAgID8gdmFsdWVzLmRhdGFbaW5wdXQudHlwZV1baW5wdXQuaWRdWydpbWFnZSddXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiYmInXG4gICAgICAgICAgICAgICAgICAgICxcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI6IFxuICAgICAgICAgICAgICAgICAgICAgIGlucHV0W2lucHV0LnR5cGVdLnBsYWNlaG9sZGVyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGlucHV0W2lucHV0LnR5cGVdLnBsYWNlaG9sZGVyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFNBTVBMRV9WQUxVRVNbaW5wdXQudHlwZV1cbiAgICAgICAgICAgICAgICAgICAgLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBpbnB1dC50eXBlLFxuICAgICAgICAgICAgICAgICAgICBmb3JtYXQ6IHZhbHVlcy5kYXRhW2lucHV0LnR5cGVdLmZvcm1hdCxcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogYGRhdGFbJHtpbnB1dC50eXBlfV1bJHtpbnB1dC5pZH1dW2ltYWdlXWAsXG4gICAgICAgICAgICAgICAgICAgIGVycm9yOiBcbiAgICAgICAgICAgICAgICAgICAgICBlcnJvcnMgJiYgZXJyb3JzLmRhdGEgJiYgZXJyb3JzLmRhdGFbaW5wdXQudHlwZV1cbiAgICAgICAgICAgICAgICAgICAgICAgID8gZXJyb3JzLmRhdGFbaW5wdXQudHlwZV1baW5wdXQuaWRdXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICcnXG4gICAgICAgICAgICAgICAgICAgICxcbiAgICAgICAgICAgICAgICAgICAgaGlkZUVycm9yTWVzc2FnZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSxcbiAgICAgICAgICAgICAgICAgICAgb25CbHVyOiBoYW5kbGVCbHVyLFxuICAgICAgICAgICAgICAgICAgICBjb250YWluZXJTdHlsZXM6IHt3aWR0aDogJzEwMCUnfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIwOX19XG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICApIDogaW5wdXQudHlwZSA9PT0gQkxPQ0tfVFlQRS5SSUNIX1RFWFQgPyAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJbnB1dCwgeyBrZXk6IGlucHV0Lm5hbWUsIHR5cGU6IGlucHV0LnR5cGUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzh9fVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIzOX19LCBpbnB1dC5uYW1lKVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRFZGl0b3IsIHtcbiAgICAgICAgICAgICAgICAgICAgaXNUYXNrTWVudTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6IFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlcyAmJiB2YWx1ZXMuZGF0YSAmJiB2YWx1ZXMuZGF0YVtpbnB1dC50eXBlXVxuICAgICAgICAgICAgICAgICAgICAgICAgPyB2YWx1ZXMuZGF0YVtpbnB1dC50eXBlXVtpbnB1dC5pZF1cbiAgICAgICAgICAgICAgICAgICAgICAgIDogJydcbiAgICAgICAgICAgICAgICAgICAgLFxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcjogXG4gICAgICAgICAgICAgICAgICAgICAgaW5wdXRbaW5wdXQudHlwZV0ucGxhY2Vob2xkZXJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gaW5wdXRbaW5wdXQudHlwZV0ucGxhY2Vob2xkZXJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogU0FNUExFX1ZBTFVFU1tpbnB1dC50eXBlXVxuICAgICAgICAgICAgICAgICAgICAsXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IGBkYXRhWyR7aW5wdXQudHlwZX1dWyR7aW5wdXQuaWR9XWAsXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdDogaW5wdXRbaW5wdXQudHlwZV0uZm9ybWF0LFxuICAgICAgICAgICAgICAgICAgICBlcnJvcjogXG4gICAgICAgICAgICAgICAgICAgICAgZXJyb3JzICYmIGVycm9ycy5kYXRhICYmIGVycm9ycy5kYXRhW2lucHV0LnR5cGVdXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGVycm9ycy5kYXRhW2lucHV0LnR5cGVdW2lucHV0LmlkXVxuICAgICAgICAgICAgICAgICAgICAgICAgOiAnJ1xuICAgICAgICAgICAgICAgICAgICAsXG4gICAgICAgICAgICAgICAgICAgIHNldEZpZWxkVmFsdWU6IHNldEZpZWxkVmFsdWUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNDB9fVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgKSA6IGlucHV0LnR5cGUgPT09IEJMT0NLX1RZUEUuREFURSA/IChcbiAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KElucHV0LCB7IGtleTogaW5wdXQubmFtZSwgdHlwZTogaW5wdXQudHlwZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI2M319XG4gICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjY0fX0sIGlucHV0Lm5hbWUpXG4gICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRGF0ZVBpY2tlciwge1xuICAgICAgICAgICAgICAgICAgICBpc1Rhc2tNZW51OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZTogXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWVzICYmIHZhbHVlcy5kYXRhICYmIHZhbHVlcy5kYXRhW2lucHV0LnR5cGVdXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHZhbHVlcy5kYXRhW2lucHV0LnR5cGVdW2lucHV0LmlkXVxuICAgICAgICAgICAgICAgICAgICAgICAgOiAnJ1xuICAgICAgICAgICAgICAgICAgICAsXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyOiBcbiAgICAgICAgICAgICAgICAgICAgICBpbnB1dFtpbnB1dC50eXBlXS5wbGFjZWhvbGRlclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBpbnB1dFtpbnB1dC50eXBlXS5wbGFjZWhvbGRlclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBTQU1QTEVfVkFMVUVTW2lucHV0LnR5cGVdXG4gICAgICAgICAgICAgICAgICAgICxcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogYGRhdGFbJHtpbnB1dC50eXBlfV1bJHtpbnB1dC5pZH1dYCxcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I6IFxuICAgICAgICAgICAgICAgICAgICAgIGVycm9ycyAmJiBlcnJvcnMuZGF0YSAmJiBlcnJvcnMuZGF0YVtpbnB1dC50eXBlXVxuICAgICAgICAgICAgICAgICAgICAgICAgPyBlcnJvcnMuZGF0YVtpbnB1dC50eXBlXVtpbnB1dC5pZF1cbiAgICAgICAgICAgICAgICAgICAgICAgIDogJydcbiAgICAgICAgICAgICAgICAgICAgLFxuICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZFZhbHVlOiBzZXRGaWVsZFZhbHVlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjY1fX1cbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJbnB1dCwgeyBrZXk6IGlucHV0Lm5hbWUsIHR5cGU6IGlucHV0LnR5cGUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyODd9fVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI4OH19LCBpbnB1dC5uYW1lKVxuICAgICAgICAgICAgICAgICAgLCBpbnB1dC50eXBlICE9PSBCTE9DS19UWVBFLlRFWFQgPyAoXG4gICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSW5wdXRGaWVsZCwge1xuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlcyAmJiB2YWx1ZXMuZGF0YSAmJiB2YWx1ZXMuZGF0YVtpbnB1dC50eXBlXVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IHZhbHVlcy5kYXRhW2lucHV0LnR5cGVdW2lucHV0LmlkXVxuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICcnXG4gICAgICAgICAgICAgICAgICAgICAgLFxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyOiBcbiAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0W2lucHV0LnR5cGVdLnBsYWNlaG9sZGVyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gaW5wdXRbaW5wdXQudHlwZV0ucGxhY2Vob2xkZXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBTQU1QTEVfVkFMVUVTW2lucHV0LnR5cGVdXG4gICAgICAgICAgICAgICAgICAgICAgLFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IGlucHV0LnR5cGUgPT09ICdudW1iZXInID8gJ251bWJlcicgOiAndGV4dCcsXG4gICAgICAgICAgICAgICAgICAgICAgZm9ybWF0OiB2YWx1ZXMuZGF0YVtpbnB1dC50eXBlXS5mb3JtYXQsXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZTogYGRhdGFbJHtpbnB1dC50eXBlfV1bJHtpbnB1dC5pZH1dYCxcbiAgICAgICAgICAgICAgICAgICAgICBlcnJvcjogXG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvcnMgJiYgZXJyb3JzLmRhdGEgJiYgZXJyb3JzLmRhdGFbaW5wdXQudHlwZV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBlcnJvcnMuZGF0YVtpbnB1dC50eXBlXVtpbnB1dC5pZF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnJ1xuICAgICAgICAgICAgICAgICAgICAgICxcbiAgICAgICAgICAgICAgICAgICAgICBoaWRlRXJyb3JNZXNzYWdlOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsXG4gICAgICAgICAgICAgICAgICAgICAgb25CbHVyOiBoYW5kbGVCbHVyLFxuICAgICAgICAgICAgICAgICAgICAgIGNvbnRhaW5lclN0eWxlczoge3dpZHRoOiAnMTAwJSd9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjkwfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChCYXNpY1RleHRBcmVhLCB7XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHZhbHVlc1tpbnB1dC5pZF0gfHwgJycsXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI6IFxuICAgICAgICAgICAgICAgICAgICAgICAgaW5wdXRbaW5wdXQudHlwZV0ucGxhY2Vob2xkZXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBpbnB1dFtpbnB1dC50eXBlXS5wbGFjZWhvbGRlclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFNBTVBMRV9WQUxVRVNbaW5wdXQudHlwZV1cbiAgICAgICAgICAgICAgICAgICAgICAsXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZTogaW5wdXQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSxcbiAgICAgICAgICAgICAgICAgICAgICBvbkJsdXI6IGhhbmRsZUJsdXIsXG4gICAgICAgICAgICAgICAgICAgICAgbWF4Um93czogMywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDMxNX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3VibWlzc2lvblNlY3Rpb24sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzMxfX1cbiAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFNlY29uZGFyeUJ1dHRvbiwgeyB0eXBlOiBcImJ1dHRvblwiLCBvbkNsaWNrOiBjbG9zZVBvcnRhbCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDMzMn19LCBcIkNhbmNlbFwiXG5cbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRmxhdEJ1dHRvbiwgeyB0eXBlOiBcInN1Ym1pdFwiLCBkaXNhYmxlZDogIWlzVmFsaWQgfHwgaXNTdWJtaXR0aW5nLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzM1fX0sIFwiQ3JlYXRlXCJcblxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICApXG4gICAgKVxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE5ld1Rhc2tNZW51XG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvU3RhdHVzVGFnLnRzeFwiO2ltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IHtTVEFUVVNfUEFMRVRURX0gZnJvbSAndW5pdmVyc2FsL3N0eWxlcy9wYWxldHRlJ1xuaW1wb3J0IHtRVUVVRV9TVEFUVVN9IGZyb20gJ3VuaXZlcnNhbC91dGlscy9jb25zdGFudHMnXG5pbXBvcnQgZ2V0UXVldWVTdGF0dXMgZnJvbSAndW5pdmVyc2FsL3V0aWxzL2dldFF1ZXVlU3RhdHVzJ1xuXG5cblxuXG5cblxuY29uc3QgU3RhdHVzVGFnID0gKHtzdGF0dXMsIGNlbnRlcmVkfSkgPT4ge1xuICBsZXQgYmFja2dyb3VuZENvbG9yXG5cbiAgc3dpdGNoIChzdGF0dXMpIHtcbiAgICBjYXNlIFFVRVVFX1NUQVRVUy5PUEVOOlxuICAgICAgYmFja2dyb3VuZENvbG9yID0gU1RBVFVTX1BBTEVUVEUuT1BFTlxuICAgICAgYnJlYWtcbiAgICBjYXNlIFFVRVVFX1NUQVRVUy5JTl9QUk9HUkVTUzpcbiAgICAgIGJhY2tncm91bmRDb2xvciA9IFNUQVRVU19QQUxFVFRFLklOX1BST0dSRVNTXG4gICAgICBicmVha1xuICAgIGNhc2UgUVVFVUVfU1RBVFVTLk5FVzpcbiAgICAgIGJhY2tncm91bmRDb2xvciA9IFNUQVRVU19QQUxFVFRFLk5FV1xuICAgICAgYnJlYWtcbiAgICBjYXNlIFFVRVVFX1NUQVRVUy5DT01QTEVURUQ6XG4gICAgICBiYWNrZ3JvdW5kQ29sb3IgPSBTVEFUVVNfUEFMRVRURS5DT01QTEVURURcbiAgICAgIGJyZWFrXG4gICAgZGVmYXVsdDpcbiAgICAgIGJhY2tncm91bmRDb2xvciA9IFNUQVRVU19QQUxFVFRFLklOX1BST0dSRVNTXG4gIH1cblxuICBjb25zdCBUYWcgPSBzdHlsZWQuZGl2KHtcbiAgICBwYWRkaW5nOiAnNXB4IDE1cHgnLFxuICAgIGJvcmRlclJhZGl1czogNSxcbiAgICBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJyxcbiAgICBmb250U2l6ZTogMTEsXG4gICAgZm9udFdlaWdodDogNjAwLFxuICAgIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnLFxuICAgIGNvbG9yOiAnI2ZmZicsXG4gICAgdXNlclNlbGVjdDogJ25vbmUnLFxuICAgIGJhY2tncm91bmRDb2xvcixcbiAgICAuLi4oY2VudGVyZWQgJiYge21hcmdpbjogJzBweCBhdXRvJ30pXG4gIH0pXG5cbiAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGFnLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ1fX0sIGdldFF1ZXVlU3RhdHVzKHN0YXR1cykpXG59XG5cbmV4cG9ydCBkZWZhdWx0IFN0YXR1c1RhZ1xuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9tb2R1bGVzL3F1ZXVlL2NvbXBvbmVudHMvUXVldWUudHN4XCI7IGZ1bmN0aW9uIF9vcHRpb25hbENoYWluKG9wcykgeyBsZXQgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgbGV0IHZhbHVlID0gb3BzWzBdOyBsZXQgaSA9IDE7IHdoaWxlIChpIDwgb3BzLmxlbmd0aCkgeyBjb25zdCBvcCA9IG9wc1tpXTsgY29uc3QgZm4gPSBvcHNbaSArIDFdOyBpICs9IDI7IGlmICgob3AgPT09ICdvcHRpb25hbEFjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSAmJiB2YWx1ZSA9PSBudWxsKSB7IHJldHVybiB1bmRlZmluZWQ7IH0gaWYgKG9wID09PSAnYWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJykgeyBsYXN0QWNjZXNzTEhTID0gdmFsdWU7IHZhbHVlID0gZm4odmFsdWUpOyB9IGVsc2UgaWYgKG9wID09PSAnY2FsbCcgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSB7IHZhbHVlID0gZm4oKC4uLmFyZ3MpID0+IHZhbHVlLmNhbGwobGFzdEFjY2Vzc0xIUywgLi4uYXJncykpOyBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyB9IH0gcmV0dXJuIHZhbHVlOyB9aW1wb3J0IFJlYWN0LCB7dXNlQ2FsbGJhY2ssIHVzZVN0YXRlfSBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IEFjdGlvbkJ1dHRvbiBmcm9tICdjbGllbnQvY29tcG9uZW50cy9BY3Rpb25CdXR0b24nXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ2NsaWVudC9zdHlsZXMvcGFsZXR0ZSdcbmltcG9ydCB1c2VSb3V0ZXIgZnJvbSAnY2xpZW50L2hvb2tzL3VzZVJvdXRlcidcbmltcG9ydCBBdmF0YXIgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvQXZhdGFyJ1xuaW1wb3J0IGN1dE9mZlN0cmluZyBmcm9tICd1bml2ZXJzYWwvdXRpbHMvY3V0T2ZmU3RyaW5nJ1xuaW1wb3J0IGNhcGl0YWxpemVGaXJzdExldHRlciBmcm9tICdjbGllbnQvdXRpbHMvY2FwaXRhbGl6ZUZpcnN0TGV0dGVyJ1xuaW1wb3J0IEljb24gZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvSWNvbidcbmltcG9ydCB7TWVudVBvc2l0aW9ufSBmcm9tICdjbGllbnQvaG9va3MvdXNlQ29vcmRzJ1xuaW1wb3J0IHVzZU1lbnUgZnJvbSAnY2xpZW50L2hvb2tzL3VzZU1lbnUnXG5pbXBvcnQgUXVldWVBY3Rpb25zTWVudSBmcm9tICdjbGllbnQvY29tcG9uZW50cy9RdWV1ZUFjdGlvbnNNZW51J1xuaW1wb3J0IFF1ZXVlRmlsdGVyQ29sdW1uTWVudSBmcm9tICdjbGllbnQvY29tcG9uZW50cy9RdWV1ZUZpbHRlckNvbHVtbk1lbnUnXG5pbXBvcnQgRW1wdHlQYWdlIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0VtcHR5UGFnZSdcbmltcG9ydCBkYXlqcyBmcm9tICdkYXlqcydcbmltcG9ydCB1c2VNb2RhbCBmcm9tICdjbGllbnQvaG9va3MvdXNlTW9kYWwnXG5pbXBvcnQgQ29uZmlybWF0aW9uTW9kYWwgZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvQ29uZmlybWF0aW9uTW9kYWwnXG5pbXBvcnQgTmV3VGFza01lbnUgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvTmV3VGFza01lbnUnXG5pbXBvcnQgcmVsYXRpdmVUaW1lIGZyb20gJ2RheWpzL3BsdWdpbi9yZWxhdGl2ZVRpbWUnXG5cbmltcG9ydCB1c2VOZXR3b3JrZXIgZnJvbSAnY2xpZW50L2hvb2tzL3VzZU5ldHdvcmtlcidcbmltcG9ydCB7Y29sb3JGcm9tU3RyaW5nfSBmcm9tICd1bml2ZXJzYWwvdXRpbHMvZ2V0Q29sb3InXG5pbXBvcnQgU2Vjb25kYXJ5QnV0dG9uIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL1NlY29uZGFyeUJ1dHRvbidcbmltcG9ydCB7Y29ubmVjdH0gZnJvbSAncmVhY3QtcmVkdXgnXG5pbXBvcnQgZm9ybWF0VmFsdWVzIGZyb20gJ3VuaXZlcnNhbC91dGlscy9mb3JtYXRWYWx1ZXMnXG5pbXBvcnQge3RyYW5zZm9ybURhdGVzfSBmcm9tICdjbGllbnQvdXRpbHMvZGF0ZUhlbHBlcnMnXG5pbXBvcnQgUXVldWVTZXR0aW5nc01vZGFsIGZyb20gJy4vUXVldWVTZXR0aW5nc01vZGFsJ1xuaW1wb3J0IHt3b3JrZmxsb3dBY3Rpb25zfSBmcm9tICdjbGllbnQvcmVkdXgvcXVldWVzUmVkdWNlcnMnXG5pbXBvcnQge1xuICBhZGRGYWlsdXJlTm90aWZpY2F0aW9uLFxuICBhZGRTdWNjZXNzTm90aWZpY2F0aW9uXG59IGZyb20gJ2NsaWVudC9tb2R1bGVzL25vdGlmaWNhdGlvblN5c3RlbS9kdWNrcy9ub3RpZmljYXRpb25TeXN0ZW1EdWNrJ1xuaW1wb3J0IFN0YXR1c1RhZyBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9TdGF0dXNUYWcnXG5pbXBvcnQge0ZJTFRFUl9CTE9DS19UWVBFU30gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcbmRheWpzLmV4dGVuZChyZWxhdGl2ZVRpbWUpXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5jb25zdCBQYWdlID0gc3R5bGVkLmRpdih7XG4gIGJhY2tncm91bmQ6ICcjZmZmJyxcbiAgbWluV2lkdGg6IDgwMCxcbiAgcGFkZGluZzogJzAgMTAlIDAgMTAlJyxcbiAgaGVpZ2h0OiAnMTAwJSdcbn0pXG5cbmNvbnN0IEhlYWRlciA9IHN0eWxlZC5kaXYoe1xuICBkaXNwbGF5OiAnZmxleCcsXG4gIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsXG4gIHBhZGRpbmc6ICc5NnB4IDAgNzBweCAwJyxcbiAgZm9udFdlaWdodDogNjAwLFxuICBmb250U2l6ZTogJzI0cHgnLFxuICBsaW5lSGVpZ2h0OiAnMzBweCdcbn0pXG5cbmNvbnN0IEJ1dHRvbnMgPSBzdHlsZWQuZGl2KHtcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nXG59KVxuXG5jb25zdCBQbGF5QnV0dG9uID0gc3R5bGVkKEFjdGlvbkJ1dHRvbikoe1xuICB3aWR0aDogMTAwLFxuICBoZWlnaHQ6IDMyLFxuICBmb250U2l6ZTogJzE0cHgnXG59KVxuXG5jb25zdCBUYWJsZUhlYWRlciA9IHN0eWxlZC5kaXYoe1xuICBib3JkZXI6ICcxcHggc29saWQgI0U4RUNFRScsXG4gIGhlaWdodDogNDIsXG4gIGJvcmRlclJhZGl1czogJzEwcHgnLFxuICBkaXNwbGF5OiAnZmxleCcsXG4gIGJveFNoYWRvdzogJzBweCAyMHB4IDQwcHggcmdiYSgwLCAwLCAwLCAwLjAyKScsXG4gIG1hcmdpbkJvdHRvbTogMjQsXG4gIHBhZGRpbmc6ICcwcHggMTVweCdcbn0pXG5cbmNvbnN0IFRhYmxlSXRlbSA9IHN0eWxlZC5kaXYoe1xuICBkaXNwbGF5OiAnZmxleCcsXG4gIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLFxuICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gIHdpZHRoOiAnMjAlJ1xufSlcblxuY29uc3QgVGFibGVIZWFkZXJJdGVtID0gc3R5bGVkKFRhYmxlSXRlbSkoe1xuICBmb250V2VpZ2h0OiA2MDAsXG4gIGZvbnRTaXplOiAnMTRweCcsXG4gIGJvcmRlckxlZnQ6IGAxcHggc29saWQgJHtQQUxFVFRFLkJPUkRFUl9HUkFZfWAsXG4gIHBhZGRpbmdMZWZ0OiAxMFxufSlcblxuY29uc3QgSURIZWFkZXJJdGVtID0gc3R5bGVkKFRhYmxlSGVhZGVySXRlbSkoe1xuICBib3JkZXJMZWZ0OiAnbm9uZScsXG4gIHBvc2l0aW9uOiAncmVsYXRpdmUnXG59KVxuXG5jb25zdCBIZWFkZXJJdGVtVGV4dCA9IHN0eWxlZC5kaXYoe1xuICBwYWRkaW5nUmlnaHQ6IDM1LFxuICB3aGl0ZVNwYWNlOiAnbm93cmFwJyxcbiAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICB0ZXh0T3ZlcmZsb3c6ICdlbGxpcHNpcydcbn0pXG5cbmNvbnN0IFRhc2tzQ29udGFpbmVyID0gc3R5bGVkLmRpdih7XG4gIGJvcmRlcjogYDFweCBzb2xpZCAke1BBTEVUVEUuQk9SREVSX0dSQVl9YCxcbiAgaGVpZ2h0OiAnY2FsYygxMDAlIC0gMjQwcHggLSA4MHB4KScsXG4gIG1heEhlaWdodDogNDcwLFxuICBkaXNwbGF5OiAnZmxleCcsXG4gIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLFxuICBib3JkZXJSYWRpdXM6ICcxMHB4J1xufSlcblxuY29uc3QgTmF2Q29udGFpbmVyID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxuICBwYWRkaW5nOiAnMTJweCAwcHgnLFxuICBoZWlnaHQ6IDQ4LFxuICBiYWNrZ3JvdW5kQ29sb3I6ICcjZjhmOGZhJyxcbiAgYm9yZGVyVG9wOiAnMXB4IHNvbGlkICNlOGVjZWUnLFxuICB1c2VyU2VsZWN0OiAnbm9uZSdcbn0pXG5cbmNvbnN0IFRhc2sgPSBzdHlsZWQuZGl2KHtcbiAgaGVpZ2h0OiA0MixcbiAgcGFkZGluZzogJzAgMjVweCcsXG4gIGJvcmRlckJvdHRvbTogYDFweCBzb2xpZCAke1BBTEVUVEUuQk9SREVSX0dSQVl9YCxcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBjdXJzb3I6ICdwb2ludGVyJyxcbiAgJzpob3Zlcic6IHtcbiAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjZjdmOGY5J1xuICB9XG59KVxuXG5jb25zdCBHcmF5VGV4dCA9IHN0eWxlZC5kaXYoe1xuICBmb250U2l6ZTogJzE0cHgnLFxuICBjb2xvcjogYCR7UEFMRVRURS5URVhUX0dSQVl9YCxcbiAgcGFkZGluZ0xlZnQ6IDE1LFxuICBmb250V2VpZ2h0OiA1MDAsXG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgYWxpZ25JdGVtczogJ2NlbnRlcidcbn0pXG5cbmNvbnN0IElEID0gc3R5bGVkLnNwYW4oe1xuICBjb2xvcjogYCR7UEFMRVRURS5QUklNQVJZX01BSU59YFxufSlcblxuY29uc3QgQXNzaWduZWRUbyA9IHN0eWxlZC5zcGFuKHtcbiAgZGlzcGxheTogJ2ZsZXgnXG59KVxuXG5jb25zdCBOYW1lID0gc3R5bGVkLnNwYW4oe1xuICBtYXJnaW5MZWZ0OiA0LFxuICB3aGl0ZVNwYWNlOiAnbm93cmFwJyxcbiAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICB0ZXh0T3ZlcmZsb3c6ICdlbGxpcHNpcydcbn0pXG5cbmNvbnN0IENvbG9yZWRUZXh0ID0gc3R5bGVkLnNwYW4oe1xuICBjb2xvcjogYCR7UEFMRVRURS5QUklNQVJZX01BSU59YCxcbiAgZm9udFNpemU6IDE2LFxuICB0ZXh0QWxpZ246ICdjZW50ZXInLFxuICBmb250V2VpZ2h0OiA2MDAsXG4gIG1hcmdpblRvcDogMVxufSlcblxuY29uc3QgVGFza3MgPSBzdHlsZWQuZGl2KHtcbiAgaGVpZ2h0OiAnY2FsYygxMDAlIC0gNDhweCknLFxuICBvdmVyZmxvd1k6ICdhdXRvJ1xufSlcblxuY29uc3QgUXVldWVUaXRsZSA9IHN0eWxlZC5kaXYoe1xuICBkaXNwbGF5OiAnZmxleCdcbn0pXG5cbmNvbnN0IE1lbnVCdXR0b25Db250YWluZXIgPSBzdHlsZWQuZGl2KHtcbiAgd2lkdGg6IDMwLFxuICBoZWlnaHQ6IDMwLFxuICBwYWRkaW5nVG9wOiAyLjUsXG4gIHBhZGRpbmdMZWZ0OiA1XG59KVxuXG5jb25zdCBGaWx0ZXJNZW51QnV0dG9uQ29udGFpbmVyID0gc3R5bGVkLmRpdih7XG4gIHdpZHRoOiAzMCxcbiAgaGVpZ2h0OiAzMCxcbiAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gIHJpZ2h0OiAxMCxcbiAgdG9wOiAxOFxufSlcblxuY29uc3QgTWVudUJ1dHRvblNlY29uZGFyeSA9IHN0eWxlZChTZWNvbmRhcnlCdXR0b24pKHtcbiAgbWFyZ2luUmlnaHQ6IDE2XG59KVxuXG5jb25zdCBTdHlsZWRJY29uID0gc3R5bGVkKEljb24pKHtcbiAgZm9udFNpemU6IDE1LFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgbWFyZ2luOiAnMnB4IDAgMCA1cHgnXG59KVxuXG5jb25zdCBTdHlsZWRNZW51SWNvbiA9IHN0eWxlZChJY29uKSh7XG4gIGZvbnRTaXplOiAyNCxcbiAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gIG1hcmdpbjogJy0xMHB4IDAgMCA1cHgnLFxuICBjdXJzb3I6ICdwb2ludGVyJyxcbiAgJzpob3Zlcic6IHtcbiAgICBjb2xvcjogUEFMRVRURS5QUklNQVJZX01BSU5cbiAgfVxufSlcblxuY29uc3QgUXVldWUgPSAocHJvcHMpID0+IHtcbiAgY29uc3Qge1xuICAgIG9yZ0lkLFxuICAgIHF1ZXVlLFxuICAgIHN0YXJ0TmV4dFRhc2ssXG4gICAgcXVldWVJZCxcbiAgICBkZWxldGVRdWV1ZSxcbiAgICBmbHVzaFF1ZXVlVGFza3MsXG4gICAgZm9ybWF0LFxuICAgIHRhc2tzLFxuICAgIHRhc2tQYWdlLFxuICAgIHNldFRhc2tQYWdlLFxuICAgIHVzZXIsXG4gICAgaXNTdGFmZixcbiAgICBzZXRRdWV1ZSxcbiAgICBzZXRTZWxlY3RlZFF1ZXVlLFxuICAgIHVwZGF0ZVF1ZXVlXG4gIH0gPSBwcm9wc1xuXG4gIGNvbnN0IHtpc19ydW5uaW5nOiBpc1J1bm5pbmcsIHBpbm5lZF9ibG9jazogcGlubmVkQmxvY2t9ID0gcXVldWVcblxuICBjb25zdCBbcGlubmVkQmxvY2tJZCwgc2V0UGlubmVkQmxvY2tJZF0gPSB1c2VTdGF0ZShwaW5uZWRCbG9jayB8fCAnJylcblxuICBjb25zdCBuZXR3b3JrZXIgPSB1c2VOZXR3b3JrZXIoKVxuICBjb25zdCB7aGlzdG9yeX0gPSB1c2VSb3V0ZXIoKSBcbiAgY29uc3Qge21lbnVQb3J0YWwsIG9yaWdpblJlZiwgbWVudVByb3BzLCB0b2dnbGVQb3J0YWx9ID0gdXNlTWVudShNZW51UG9zaXRpb24uVVBQRVJfTEVGVCwge1xuICAgIGlzRHJvcGRvd246IHRydWVcbiAgfSlcbiAgY29uc3Qge21vZGFsUG9ydGFsLCB0b2dnbGVQb3J0YWw6IG5ld1Rhc2tUb2dnbGVQb3J0YWwsIGNsb3NlUG9ydGFsfSA9IHVzZU1vZGFsKHtvdmVyZmxvdzogJ2F1dG8nfSlcbiAgY29uc3Qge1xuICAgIG1vZGFsUG9ydGFsOiBxdWV1ZVNldHRpbmdzUG9ydGFsLFxuICAgIHRvZ2dsZVBvcnRhbDogdG9nZ2xlUXVldWVTZXR0aW5nc01vZGFsLFxuICAgIGNsb3NlUG9ydGFsOiBjbG9zZVF1ZXVlU2V0dGluZ3NNb2RhbFxuICB9ID0gdXNlTW9kYWwoe30pXG4gIGNvbnN0IHtcbiAgICBtb2RhbFBvcnRhbDogY29uZmlybU1vZGFsUG9ydGFsLFxuICAgIHRvZ2dsZVBvcnRhbDogY29uZmlybVRvZ2dsZVBvcnRhbCxcbiAgICBjbG9zZVBvcnRhbDogY29uZmlybUNsb3NlUG9ydGFsXG4gIH0gPSB1c2VNb2RhbCgpXG5cbiAgY29uc3Qge1xuICAgIG1vZGFsUG9ydGFsOiBjb25maXJtRmx1c2hNb2RhbFBvcnRhbCxcbiAgICB0b2dnbGVQb3J0YWw6IGNvbmZpcm1GbHVzaFRvZ2dsZVBvcnRhbCxcbiAgICBjbG9zZVBvcnRhbDogY29uZmlybUZsdXNoQ2xvc2VQb3J0YWxcbiAgfSA9IHVzZU1vZGFsKClcblxuICBjb25zdCB7XG4gICAgbWVudVBvcnRhbDogZmlsdGVyTWVudVBvcnRhbCxcbiAgICBvcmlnaW5SZWY6IG9yaWdpbkZpbHRlck1lbnVSZWYsXG4gICAgbWVudVByb3BzOiBmaWx0ZXJNZW51UHJvcHMsXG4gICAgdG9nZ2xlUG9ydGFsOiB0b2dnbGVGaWx0ZXJNZW51UG9ydGFsXG4gIH0gPSB1c2VNZW51KE1lbnVQb3NpdGlvbi5VUFBFUl9SSUdIVCwge1xuICAgIGlzRHJvcGRvd246IHRydWVcbiAgfSlcblxuICBjb25zdCBvblN1Ym1pdEhhbmRsZXIgPSBhc3luYyAodmFsdWVzKSA9PiB7XG4gICAgY29uc3QgcmV0dXJuRGF0YSA9IFtdXG4gICAgZm9ybWF0LmZvckVhY2goKHtpZCwgdHlwZSwgbmFtZX0pID0+IHtcbiAgICAgIGxldCB2YWx1ZSA9IHZhbHVlc1tpZF1cbiAgICAgIGlmICh2YWx1ZXMuZGF0YSAmJiB2YWx1ZXMuZGF0YVt0eXBlXSAmJiB2YWx1ZXMuZGF0YVt0eXBlXVtpZF0pIHtcbiAgICAgICAgdmFsdWUgPSB2YWx1ZXMuZGF0YVt0eXBlXVtpZF1cbiAgICAgIH1cblxuICAgICAgY29uc3QgcmV0dXJuT2JqID0ge2lkLCB0eXBlLCBuYW1lLCBbdHlwZV06IHt2YWx1ZX19IFxuICAgICAgcmV0dXJuRGF0YS5wdXNoKHJldHVybk9iailcbiAgICB9KVxuXG4gICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgZGF0YToge2RhdGE6IGZvcm1hdFZhbHVlcyhyZXR1cm5EYXRhKS5tYXAodHJhbnNmb3JtRGF0ZXMpfVxuICAgIH1cblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IG5ldHdvcmtlci5odHRwSGFuZGxlcihgL29yZ3MvJHtvcmdJZH0vcXVldWVzLyR7cXVldWVJZH0vdGFza3MvZm9ybWAsIHBheWxvYWQpXG5cbiAgICBpZiAocmVzLmVycm9ycykge1xuICAgICAgcHJvcHMuYWRkRmFpbHVyZU5vdGlmaWNhdGlvbignQW4gZXJyb3Igb2NjdXJyZWQnKVxuICAgIH1cblxuICAgIHJlcy5lcnJvcnMgJiYgY2xvc2VQb3J0YWwoKVxuXG4gICAgY29uc3QgZmV0Y2hUYXNrUGF5bG9hZCA9IHtcbiAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICB9XG5cbiAgICBjb25zdCBmZXRjaFRhc2tSZXMgPSBhd2FpdCBuZXR3b3JrZXIuaHR0cEhhbmRsZXIoXG4gICAgICBgL29yZ3MvJHtvcmdJZH0vcXVldWVzLyR7cXVldWVJZH0vdGFza3MvJHtyZXMuZGF0YS5pZH1gLFxuICAgICAgZmV0Y2hUYXNrUGF5bG9hZFxuICAgIClcblxuICAgIGNvbnN0IHtkYXRhfSA9IGZldGNoVGFza1JlcyB8fCB7fVxuXG4gICAgY29uc3Qgcm91dGUgPSBkYXRhLmlkID8gYC9xdWV1ZXMvJHtxdWV1ZUlkfS90YXNrcy8ke2RhdGEuaWR9YCA6IGAvcXVldWVzLyR7cXVldWVJZH0vY29ubmVjdGlvbnNgXG4gICAgY29uc3QgdGFza1N0YXRlID0gZGF0YS5pZCA/IHtoYXNDaGFuZ2VkOiBmYWxzZX0gOiBudWxsXG5cbiAgICBoaXN0b3J5LnB1c2goe1xuICAgICAgcGF0aG5hbWU6IHJvdXRlLFxuICAgICAgc3RhdGU6IHRhc2tTdGF0ZVxuICAgIH0pXG5cbiAgICBjbG9zZVBvcnRhbCgpXG4gIH1cblxuICBjb25zdCBydW5RdWV1ZSA9IGFzeW5jICh2YWx1ZXMpID0+IHtcbiAgICBjb25zdCB1cGRhdGVkUXVldWUgPSB7XG4gICAgICAuLi52YWx1ZXMsXG4gICAgICBpc19ydW5uaW5nOiB0cnVlXG4gICAgfVxuICAgIGNvbnN0IHBheWxvYWQgPSB7XG4gICAgICBtZXRob2Q6ICdQVVQnLFxuICAgICAgZGF0YTogdXBkYXRlZFF1ZXVlXG4gICAgfVxuXG4gICAgY29uc3QgcmVzID0gYXdhaXQgbmV0d29ya2VyLmh0dHBIYW5kbGVyKGAvb3Jncy8ke29yZ0lkfS9xdWV1ZXMvJHtxdWV1ZUlkfWAsIHBheWxvYWQpXG4gICAgaWYgKF9vcHRpb25hbENoYWluKFtyZXMsICdvcHRpb25hbEFjY2VzcycsIF8gPT4gXy5lcnJvcnNdKSkge1xuICAgICAgcHJvcHMuYWRkRmFpbHVyZU5vdGlmaWNhdGlvbignQW4gZXJyb3Igb2NjdXJyZWQnKVxuICAgIH0gZWxzZSB7XG4gICAgICBzZXRRdWV1ZSh1cGRhdGVkUXVldWUpXG4gICAgICBzZXRTZWxlY3RlZFF1ZXVlKHVwZGF0ZWRRdWV1ZSlcbiAgICAgIHVwZGF0ZVF1ZXVlKHVwZGF0ZWRRdWV1ZSlcbiAgICAgIHByb3BzLmFkZFN1Y2Nlc3NOb3RpZmljYXRpb24oJ1RoaXMgcXVldWUgaXMgbm93IGJlaW5nIGV4ZWN1dGVkIGJ5IEh1bWFuIExhbWJkYXMnKVxuICAgIH1cbiAgICBjbG9zZVF1ZXVlU2V0dGluZ3NNb2RhbCgpXG4gIH1cblxuICBjb25zdCBmaW5hbFBhZ2UgPSBNYXRoLmZsb29yKChxdWV1ZS5uX3Rhc2tzIC0gMSkgLyAxMCkgKyAxIHx8IDFcblxuICBjb25zdCBCYWNrTmF2SWNvbiA9IHN0eWxlZChJY29uKSh7XG4gICAgY29sb3I6IHRhc2tQYWdlID09PSAxID8gUEFMRVRURS5URVhUX0dSQVkgOiBQQUxFVFRFLlBSSU1BUllfTUFJTixcbiAgICBjdXJzb3I6IHRhc2tQYWdlID09PSAxID8gJ2F1dG8nIDogJ3BvaW50ZXInLFxuICAgIG1hcmdpbjogJzBweCAxMnB4J1xuICB9KVxuXG4gIGNvbnN0IEZvcndhcmROYXZJY29uID0gc3R5bGVkKEljb24pKHtcbiAgICBjb2xvcjogdGFza1BhZ2UgPT09IGZpbmFsUGFnZSA/IGAke1BBTEVUVEUuVEVYVF9HUkFZfWAgOiBgJHtQQUxFVFRFLlBSSU1BUllfTUFJTn1gLFxuICAgIGN1cnNvcjogdGFza1BhZ2UgPT09IGZpbmFsUGFnZSA/ICdhdXRvJyA6ICdwb2ludGVyJyxcbiAgICBtYXJnaW46ICcwcHggMTJweCdcbiAgfSlcblxuICBjb25zdCBwYXVzZVF1ZXVlID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZWRRdWV1ZSA9IHtcbiAgICAgIC4uLnF1ZXVlLFxuICAgICAgaXNfcnVubmluZzogZmFsc2VcbiAgICB9XG4gICAgc2V0UXVldWUodXBkYXRlZFF1ZXVlKVxuICAgIGNvbnN0IHBheWxvYWQgPSB7XG4gICAgICBtZXRob2Q6ICdQVVQnLFxuICAgICAgZGF0YTogdXBkYXRlZFF1ZXVlXG4gICAgfVxuXG4gICAgY29uc3QgcmVzID0gYXdhaXQgbmV0d29ya2VyLmh0dHBIYW5kbGVyKGAvb3Jncy8ke29yZ0lkfS9xdWV1ZXMvJHtxdWV1ZUlkfWAsIHBheWxvYWQpXG4gICAgaWYgKF9vcHRpb25hbENoYWluKFtyZXMsICdvcHRpb25hbEFjY2VzcycsIF8yID0+IF8yLmVycm9yc10pKSB7XG4gICAgICBwcm9wcy5hZGRGYWlsdXJlTm90aWZpY2F0aW9uKCdBbiBlcnJvciBvY2N1cnJlZCcpXG4gICAgfSBlbHNlIHtcbiAgICAgIHByb3BzLmFkZFN1Y2Nlc3NOb3RpZmljYXRpb24oJ1F1ZXVlIGV4ZWN1dGlvbiBoYXMgYmVlbiBzdWNjZXNzZnVsbHkgcGF1c2VkJylcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVSdW5PclBhdXNlID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGlmIChpc1J1bm5pbmcpIHtcbiAgICAgIHBhdXNlUXVldWUoKVxuICAgIH0gZWxzZSB7XG4gICAgICB0b2dnbGVRdWV1ZVNldHRpbmdzTW9kYWwoKVxuICAgIH1cbiAgfSwgW3F1ZXVlXSlcblxuICBsZXQgdGhlcmVBcmVOb25lUGlubmVkQmxvY2tzID0gdHJ1ZVxuXG4gIGlmIChxdWV1ZS5kYXRhICYmIEFycmF5LmlzQXJyYXkocXVldWUuZGF0YSkpIHtcbiAgICBxdWV1ZS5kYXRhLm1hcCgoYmxvY2ssIGlkKSA9PiB7XG4gICAgICBpZiAoRklMVEVSX0JMT0NLX1RZUEVTLmluY2x1ZGVzKGJsb2NrLnR5cGUpKSB7XG4gICAgICAgIHRoZXJlQXJlTm9uZVBpbm5lZEJsb2NrcyA9IGZhbHNlXG4gICAgICB9XG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IHNldFBpbm5lZEJsb2NrID0gYXN5bmMgKGlkKSA9PiB7XG4gICAgc2V0UGlubmVkQmxvY2tJZChpZClcblxuICAgIGF3YWl0IG5ldHdvcmtlci5odHRwSGFuZGxlcihgL29yZ3MvJHtvcmdJZH0vcXVldWVzLyR7cXVldWVJZH1gLCB7XG4gICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICBkYXRhOiB7cGlubmVkX2Jsb2NrOiBpZH1cbiAgICB9KVxuICB9XG5cbiAgY29uc3QgZXh0cmFjdFBpbm5lZFZhbHVlID0gKGRhdGEsIGlkKSA9PiB7XG4gICAgbGV0IHBpbm5lZFZhbHVlID0gJyMnICsgaWRcbiAgICBpZiAoZGF0YSAmJiBBcnJheS5pc0FycmF5KGRhdGEpICYmICF0aGVyZUFyZU5vbmVQaW5uZWRCbG9ja3MgJiYgcGlubmVkQmxvY2tJZCkge1xuICAgICAgbGV0IHRoZVZhbHVlSGFzQmVlbkFzc2lnbmVkID0gZmFsc2VcbiAgICAgIGRhdGEubWFwKChibG9jaykgPT4ge1xuICAgICAgICBcbiAgICAgICAgaWYgKGJsb2NrLmlkID09PSBwaW5uZWRCbG9ja0lkKSB7XG4gICAgICAgICAgcGlubmVkVmFsdWUgPSBfb3B0aW9uYWxDaGFpbihbYmxvY2ssICdhY2Nlc3MnLCBfMyA9PiBfM1tibG9jay50eXBlXSwgJ29wdGlvbmFsQWNjZXNzJywgXzQgPT4gXzQudmFsdWVdKVxuICAgICAgICAgIHRoZVZhbHVlSGFzQmVlbkFzc2lnbmVkID0gdHJ1ZVxuICAgICAgICB9XG4gICAgICAgIGlmICghdGhlVmFsdWVIYXNCZWVuQXNzaWduZWQpIHtcbiAgICAgICAgICBwaW5uZWRWYWx1ZSA9IFwiLVwiXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuXG4gICAgcmV0dXJuIHBpbm5lZFZhbHVlXG4gIH1cblxuICBjb25zdCBleHRyYWN0UGlubmVkVGl0bGUgPSAocXVldWUpID0+IHtcbiAgICBsZXQgcGlubmVkVGl0bGUgPSAnSUQnXG5cbiAgICBpZiAocXVldWUuZGF0YSAmJiBBcnJheS5pc0FycmF5KHF1ZXVlLmRhdGEpICYmIHBpbm5lZEJsb2NrSWQpIHtcbiAgICAgIHF1ZXVlLmRhdGEubWFwKChibG9jaykgPT4ge1xuICAgICAgICBpZiAoYmxvY2suaWQgPT09IHBpbm5lZEJsb2NrSWQpIHtcbiAgICAgICAgICBwaW5uZWRUaXRsZSA9IGJsb2NrLm5hbWVcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG5cbiAgICByZXR1cm4gcGlubmVkVGl0bGVcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChQYWdlLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ1MH19XG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSGVhZGVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ1MX19XG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChRdWV1ZVRpdGxlLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ1Mn19XG4gICAgICAgICAgLCBxdWV1ZS5uYW1lICYmIGNhcGl0YWxpemVGaXJzdExldHRlcihjdXRPZmZTdHJpbmcocXVldWUubmFtZSwgMjUpKVxuICAgICAgICAgICwgX29wdGlvbmFsQ2hhaW4oW3VzZXIsICdvcHRpb25hbEFjY2VzcycsIF81ID0+IF81LmlzX2FkbWluXSkgJiYgKFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChNZW51QnV0dG9uQ29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ1NX19XG4gICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTdHlsZWRNZW51SWNvbiwgeyBvbkNsaWNrOiB0b2dnbGVQb3J0YWwsIHJlZjogb3JpZ2luUmVmLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDU2fX0sIFwiZXhwYW5kX21vcmVcIlxuXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbnMsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDYyfX1cbiAgICAgICAgICAsIF9vcHRpb25hbENoYWluKFt1c2VyLCAnb3B0aW9uYWxBY2Nlc3MnLCBfNiA9PiBfNi5pc19hZG1pbl0pICYmICFpc1N0YWZmICYmIChcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTWVudUJ1dHRvblNlY29uZGFyeSwge1xuICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgaGlzdG9yeS5wdXNoKGAvcXVldWVzLyR7cXVldWVJZH0vY29ubmVjdGlvbnNgKVxuICAgICAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDY0fX1cbiAgICAgICAgICAgICwgXCJDb25uZWN0aW9uc1wiXG5cbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG4gICAgICAgICAgLCBxdWV1ZS5kYXRhICYmIHF1ZXVlLmRhdGEubGVuZ3RoID4gMCAmJiAhaXNTdGFmZiAmJiAoXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KE1lbnVCdXR0b25TZWNvbmRhcnksIHtcbiAgICAgICAgICAgICAgb25DbGljazogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGZvcm1hdC5sZW5ndGggPiAwID8gbmV3VGFza1RvZ2dsZVBvcnRhbCgpIDogb25TdWJtaXRIYW5kbGVyKHt9KVxuICAgICAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDczfX1cbiAgICAgICAgICAgICwgXCJOZXcgVGFza1wiXG5cbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG4gICAgICAgICAgLCAoIV9vcHRpb25hbENoYWluKFt1c2VyLCAnb3B0aW9uYWxBY2Nlc3MnLCBfNyA9PiBfNy5pc19hZG1pbl0pIHx8IGlzU3RhZmYpICYmIHF1ZXVlLm5fdGFza3MgPiAwID8gKFxuICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChQbGF5QnV0dG9uLCB7IG9uQ2xpY2s6IHN0YXJ0TmV4dFRhc2ssIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0ODJ9fSwgXCJQbGF5XCIpXG4gICAgICAgICAgKSA6IG51bGxcbiAgICAgICAgICAsIF9vcHRpb25hbENoYWluKFt1c2VyLCAnb3B0aW9uYWxBY2Nlc3MnLCBfOCA9PiBfOC5pc19hZG1pbl0pICYmICFpc1N0YWZmICYmIChcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUGxheUJ1dHRvbiwgeyBvbkNsaWNrOiBoYW5kbGVSdW5PclBhdXNlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDg1fX0sIGlzUnVubmluZyA/ICdQYXVzZScgOiAnUnVuJylcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgIClcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChUYWJsZUhlYWRlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0ODl9fVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSURIZWFkZXJJdGVtLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ5MH19XG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEhlYWRlckl0ZW1UZXh0LCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ5MX19LCBleHRyYWN0UGlubmVkVGl0bGUocXVldWUpKVxuICAgICAgICAgICwgX29wdGlvbmFsQ2hhaW4oW3VzZXIsICdvcHRpb25hbEFjY2VzcycsIF85ID0+IF85LmlzX2FkbWluXSkgJiYgIXRoZXJlQXJlTm9uZVBpbm5lZEJsb2NrcyAmJiAoXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEZpbHRlck1lbnVCdXR0b25Db250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDkzfX1cbiAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZE1lbnVJY29uLCB7IG9uQ2xpY2s6IHRvZ2dsZUZpbHRlck1lbnVQb3J0YWwsIHJlZjogb3JpZ2luRmlsdGVyTWVudVJlZiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ5NH19LCBcImV4cGFuZF9tb3JlXCJcblxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChUYWJsZUhlYWRlckl0ZW0sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTAwfX0sIFwiU3RhdHVzXCIpXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChUYWJsZUhlYWRlckl0ZW0sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTAxfX0sIFwiQXNzaWduZWQgVG9cIiApXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChUYWJsZUhlYWRlckl0ZW0sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTAyfX0sIFwiQ29tbWVudHNcIilcbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRhYmxlSGVhZGVySXRlbSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1MDN9fSwgXCJDcmVhdGVkIEF0XCIgKVxuICAgICAgKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRhc2tzQ29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUwNX19XG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChUYXNrcywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1MDZ9fVxuICAgICAgICAgICwgdGFza3MubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgIHRhc2tzLm1hcCgodGFzaykgPT4ge1xuICAgICAgICAgICAgICBjb25zdCB7aWQsIHN0YXR1cywgY3JlYXRlZF9hdCwgYXNzaWduZWRfdG8sIG5fY29tbWVudHMsIGRhdGF9ID0gdGFza1xuXG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUYXNrLCB7IGtleTogaWQsIG9uQ2xpY2s6ICgpID0+IGhpc3RvcnkucHVzaChgL3F1ZXVlcy8ke3F1ZXVlSWR9L3Rhc2tzLyR7aWR9YCksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1MTJ9fVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRhYmxlSXRlbSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1MTN9fVxuICAgICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSUQsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTE0fX1cbiAgICAgICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSGVhZGVySXRlbVRleHQsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTE1fX0sIGV4dHJhY3RQaW5uZWRWYWx1ZShkYXRhLCBpZCkpXG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChUYWJsZUl0ZW0sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTE4fX1cbiAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KCdkaXYnLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUxOX19XG4gICAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFN0YXR1c1RhZywgeyBzdGF0dXM6IHN0YXR1cywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUyMH19IClcbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRhYmxlSXRlbSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1MjN9fVxuICAgICAgICAgICAgICAgICAgICAsIGFzc2lnbmVkX3RvICYmIChcbiAgICAgICAgICAgICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEFzc2lnbmVkVG8sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTI1fX1cbiAgICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChBdmF0YXIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaW5pdGlhbHM6IGFzc2lnbmVkX3RvLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogY29sb3JGcm9tU3RyaW5nKGFzc2lnbmVkX3RvKSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUyNn19XG4gICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTmFtZSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1MzB9fSwgYXNzaWduZWRfdG8pXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGFibGVJdGVtLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUzNH19XG4gICAgICAgICAgICAgICAgICAgICwgbl9jb21tZW50cyA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoR3JheVRleHQsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTM2fX1cbiAgICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgnZGl2Jywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1Mzd9fSwgbl9jb21tZW50cylcbiAgICAgICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTdHlsZWRJY29uLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUzOH19LCBcImNvbW1lbnRcIilcbiAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChUYWJsZUl0ZW0sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTQyfX1cbiAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEdyYXlUZXh0LCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDU0M319LCBkYXlqcyhjcmVhdGVkX2F0KS5mcm9tTm93KCkpXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEVtcHR5UGFnZSwge1xuICAgICAgICAgICAgICBoZWFkZXI6ICdUaGlzIHF1ZXVlIGN1cnJlbnRseSBoYXMgbm8gdGFza3MnLFxuICAgICAgICAgICAgICBzdWJIZWFkZXI6IFwiWW91IGNhbiB1cGxvYWQgdGFza3MgYXQgdGhpcyBxdWV1ZSdzIGNvbm5lY3Rpb25zIHBhZ2VcIiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDU0OX19XG4gICAgICAgICAgICApXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChOYXZDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTU1fX1cbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmFja05hdkljb24sIHsgb25DbGljazogKCkgPT4gc2V0VGFza1BhZ2UoMSksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1NTZ9fSwgXCJmaXJzdF9wYWdlXCIpXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJhY2tOYXZJY29uLCB7XG4gICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgIGlmICh0YXNrUGFnZSA+IDEpIHNldFRhc2tQYWdlKHRhc2tQYWdlIC0gMSlcbiAgICAgICAgICAgIH0sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1NTd9fVxuICAgICAgICAgICwgXCJuYXZpZ2F0ZV9iZWZvcmVcIlxuXG4gICAgICAgICAgKVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChDb2xvcmVkVGV4dCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1NjR9fSwgdGFza1BhZ2UpXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEZvcndhcmROYXZJY29uLCB7XG4gICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgIGlmICh0YXNrUGFnZSAhPT0gZmluYWxQYWdlKSBzZXRUYXNrUGFnZSh0YXNrUGFnZSArIDEpXG4gICAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTY1fX1cbiAgICAgICAgICAsIFwibmF2aWdhdGVfbmV4dFwiXG5cbiAgICAgICAgICApXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEZvcndhcmROYXZJY29uLCB7XG4gICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgIHNldFRhc2tQYWdlKGZpbmFsUGFnZSlcbiAgICAgICAgICAgIH0sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1NzJ9fVxuICAgICAgICAgICwgXCJsYXN0X3BhZ2VcIlxuXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICApXG4gICAgICAsIG1lbnVQb3J0YWwoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUXVldWVBY3Rpb25zTWVudSwge1xuICAgICAgICAgIHF1ZXVlSWQ6IHF1ZXVlSWQsXG4gICAgICAgICAgb3JnSWQ6IG9yZ0lkLFxuICAgICAgICAgIG1lbnVQcm9wczogbWVudVByb3BzLFxuICAgICAgICAgIG9uRGVsZXRlOiBjb25maXJtVG9nZ2xlUG9ydGFsLFxuICAgICAgICAgIG9uRmx1c2g6IGNvbmZpcm1GbHVzaFRvZ2dsZVBvcnRhbCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDU4Mn19XG4gICAgICAgIClcbiAgICAgIClcbiAgICAgICwgbW9kYWxQb3J0YWwoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTmV3VGFza01lbnUsIHsgb25TdWJtaXRIYW5kbGVyOiBvblN1Ym1pdEhhbmRsZXIsIGNsb3NlUG9ydGFsOiBjbG9zZVBvcnRhbCwgZm9ybWF0OiBmb3JtYXQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1OTF9fSApXG4gICAgICApXG4gICAgICAsIGNvbmZpcm1Nb2RhbFBvcnRhbChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb25maXJtYXRpb25Nb2RhbCwge1xuICAgICAgICAgIGxhYmVsOiAnRGVsZXRlJyxcbiAgICAgICAgICBjbG9zZVBvcnRhbDogY29uZmlybUNsb3NlUG9ydGFsLFxuICAgICAgICAgIG1lc3NhZ2U6ICdBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gcGVybWFuZW50bHkgZGVsZXRlIHRoaXMgcXVldWU/JyxcbiAgICAgICAgICBvbkNvbmZpcm06ICgpID0+IHtcbiAgICAgICAgICAgIGRlbGV0ZVF1ZXVlKClcbiAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTk0fX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgLCBjb25maXJtRmx1c2hNb2RhbFBvcnRhbChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb25maXJtYXRpb25Nb2RhbCwge1xuICAgICAgICAgIGxhYmVsOiAnRGVsZXRlJyxcbiAgICAgICAgICBjbG9zZVBvcnRhbDogY29uZmlybUZsdXNoQ2xvc2VQb3J0YWwsXG4gICAgICAgICAgbWVzc2FnZTogJ0FyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBwZXJtYW5lbnRseSBkZWxldGUgYWxsIHRhc2tzIGZyb20gdGhpcyBxdWV1ZT8nLFxuICAgICAgICAgIG9uQ29uZmlybTogKCkgPT4ge1xuICAgICAgICAgICAgZmx1c2hRdWV1ZVRhc2tzKClcbiAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNjA0fX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgLCBxdWV1ZVNldHRpbmdzUG9ydGFsKFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFF1ZXVlU2V0dGluZ3NNb2RhbCwge1xuICAgICAgICAgIGNsb3NlUG9ydGFsOiBjbG9zZVF1ZXVlU2V0dGluZ3NNb2RhbCxcbiAgICAgICAgICBydW5RdWV1ZTogcnVuUXVldWUsXG4gICAgICAgICAgcXVldWU6IHF1ZXVlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNjE0fX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgLCBmaWx0ZXJNZW51UG9ydGFsKFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFF1ZXVlRmlsdGVyQ29sdW1uTWVudSwge1xuICAgICAgICAgIHF1ZXVlOiBxdWV1ZSxcbiAgICAgICAgICBhY3RpdmVCbG9ja05hbWU6IGV4dHJhY3RQaW5uZWRUaXRsZShxdWV1ZSksXG4gICAgICAgICAgbWVudVByb3BzOiBmaWx0ZXJNZW51UHJvcHMsXG4gICAgICAgICAgc2V0UGlubmVkQmxvY2s6IHNldFBpbm5lZEJsb2NrLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNjIxfX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuXG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSAoZGlzcGF0Y2gpID0+IHtcbiAgcmV0dXJuIHtcbiAgICBhZGRGYWlsdXJlTm90aWZpY2F0aW9uOiAoYXJnKSA9PiBkaXNwYXRjaChhZGRGYWlsdXJlTm90aWZpY2F0aW9uKGFyZykpLFxuICAgIGFkZFN1Y2Nlc3NOb3RpZmljYXRpb246IChhcmcpID0+IGRpc3BhdGNoKGFkZFN1Y2Nlc3NOb3RpZmljYXRpb24oYXJnKSksXG4gICAgdXBkYXRlUXVldWU6IChhcmcpID0+IGRpc3BhdGNoKHdvcmtmbGxvd0FjdGlvbnMudXBkYXRlUXVldWUoYXJnKSlcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBjb25uZWN0KG51bGwsIG1hcERpc3BhdGNoVG9Qcm9wcykoUXVldWUpXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL21vZHVsZXMvcXVldWUvY29tcG9uZW50cy9RdWV1ZVNldHRpbmdzTW9kYWwudHN4XCI7aW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtGb3JtaWssIEZvcm0sIHVzZUZpZWxkfSBmcm9tICdmb3JtaWsnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcbmltcG9ydCB7UEFMRVRURX0gZnJvbSAndW5pdmVyc2FsL3N0eWxlcy9wYWxldHRlJ1xuaW1wb3J0IHtCb3hTaGFkb3d9IGZyb20gJy4uLy4uLy4uLy4uL2NsaWVudC91dGlscy9jb25zdGFudHMnXG5cbmltcG9ydCBJbnB1dEZpZWxkIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0lucHV0RmllbGQnXG5pbXBvcnQgUHJpbWFyeUJ1dHRvbiBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9QcmltYXJ5QnV0dG9uJ1xuaW1wb3J0IFNlY29uZGFyeUJ1dHRvbiBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9TZWNvbmRhcnlCdXR0b24nXG5pbXBvcnQgVGV4dEFyZWEgZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvVGV4dEFyZWEnXG5pbXBvcnQge3F1ZXVlU2V0dGluZ3NTY2hlbWF9IGZyb20gJ3VuaXZlcnNhbC92YWxpZGF0aW9ucy95dXBTY2hlbWEnXG5cblxuXG5cblxuXG5cbmNvbnN0IE1vZGFsUm9vdCA9IHN0eWxlZC5kaXYoe1xuICBkaXNwbGF5OiAnZmxleCcsXG4gIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLFxuICBtYXhXaWR0aDogNzAwLFxuICB3aWR0aDogNzAwLFxuICBib3JkZXJSYWRpdXM6IDEwLFxuICBiYWNrZ3JvdW5kQ29sb3I6ICcjZmZmJyxcbiAgYm9yZGVyOiBgMXB4IHNvbGlkICR7UEFMRVRURS5CT1JERVJfTUFJTl9HUkFZfWAsXG4gIGJveFNoYWRvdzogQm94U2hhZG93Lk1PREFMLFxuICBwYWRkaW5nVG9wOiAzNSxcbiAgcGFkZGluZ0JvdHRvbTogMzUsXG4gIG1heEhlaWdodDogJ2NhbGMoMTAwdmggLSAxMDBweCknXG59KVxuXG5jb25zdCBNb2RhbFdyYXBwZXIgPSBzdHlsZWQuZGl2KHtcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBmbGV4RGlyZWN0aW9uOiAncm93JyxcbiAgd2lkdGg6ICcxMDAlJyxcbiAgb3ZlcmZsb3c6ICdhdXRvJ1xufSlcblxuY29uc3QgTW9kYWxIZWFkZXIgPSBzdHlsZWQuZGl2KHtcbiAgZm9udFdlaWdodDogNjAwLFxuICBmb250U2l6ZTogJzIycHgnLFxuICBsaW5lSGVpZ2h0OiAnMjdweCcsXG4gIG1hcmdpbkJvdHRvbTogMTAsXG4gIHBhZGRpbmdMZWZ0OiAzNSxcbiAgcGFkZGluZ1JpZ2h0OiAzNVxufSlcblxuY29uc3QgTW9kYWxOb3RlID0gc3R5bGVkLmRpdih7XG4gIGZvbnRXZWlnaHQ6IDUwMCxcbiAgZm9udFNpemU6ICcxOHB4JyxcbiAgbGluZUhlaWdodDogJzIwcHgnLFxuICBtYXJnaW5Cb3R0b206IDI1LFxuICBwYWRkaW5nTGVmdDogMzUsXG4gIHBhZGRpbmdSaWdodDogMzUsXG4gIGNvbG9yOiBQQUxFVFRFLlRFWFRfREFSS0VSX0dSQVlcbn0pXG5cbmNvbnN0IExhYmVsID0gc3R5bGVkLmRpdih7XG4gIGZvbnRTaXplOiAxNSxcbiAgY29sb3I6IFBBTEVUVEUuVEVYVF9NQUlOLFxuICBmb250V2VpZ2h0OiA0MDAsXG4gIG1hcmdpbkJvdHRvbTogNVxufSlcblxuY29uc3QgTm90ZSA9IHN0eWxlZC5zcGFuKHtcbiAgZm9udFNpemU6IDEyLFxuICBjb2xvcjogUEFMRVRURS5URVhUX0dSQVksXG4gIGZvbnRXZWlnaHQ6IDQwMFxufSlcblxuY29uc3QgRmllbGRXcmFwcGVyID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdncmlkJyxcbiAgYWxpZ25JdGVtczogJ3RvcCcsXG4gIG1hcmdpbkJvdHRvbTogNVxufSlcblxuY29uc3QgRm9ybUNvbnRlbnQgPSBzdHlsZWQoRm9ybSkoe1xuICBvdmVyZmxvdzogJ2F1dG8nLFxuICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgaGVpZ2h0OiAnaW5oZXJpdCdcbn0pXG5cbmNvbnN0IFF1b3RhSW5mb1dyYXBwZXIgPSBzdHlsZWQuZGl2KHtcbiAgZGlzcGxheTogJ2dyaWQnLFxuICBhbGlnbkl0ZW1zOiAndG9wJyxcbiAgbWFyZ2luVG9wOiAxMCxcbiAgZ3JpZEdhcDogMTAsXG4gIGJhY2tncm91bmRDb2xvcjogJyNmY2ZiZmYnLFxuICBwYWRkaW5nOiAyMCxcbiAgYm9yZGVyUmFkaXVzOiA0XG59KVxuXG5jb25zdCBRdW90YUluZm8gPSBzdHlsZWQuc3Bhbih7XG4gIGZvbnRTaXplOiAxMixcbiAgY29sb3I6ICcjODQ2Y2YxJyxcbiAgZm9udFdlaWdodDogNDAwXG59KVxuXG5jb25zdCBDb250ZW50QmxvY2sgPSBzdHlsZWQuZGl2KHtcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJyxcbiAgbWFyZ2luQm90dG9tOiAxMFxufSlcblxuY29uc3QgTW9kYWxGb290ZXIgPSBzdHlsZWQuZGl2KHtcbiAgbWFyZ2luVG9wOiAxMCxcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBmbGV4RGlyZWN0aW9uOiAncm93LXJldmVyc2UnLFxuICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJyxcbiAgcGFkZGluZ0xlZnQ6IDM1LFxuICBwYWRkaW5nUmlnaHQ6IDM1XG59KVxuXG5jb25zdCBDb250ZW50V3JhcHBlciA9IHN0eWxlZC5kaXYoe1xuICBiYWNrZ3JvdW5kQ29sb3I6ICcjZmZmJyxcbiAgd2lkdGg6ICcxMDAlJyxcbiAgcGFkZGluZ0xlZnQ6IDM1LFxuICBwYWRkaW5nUmlnaHQ6IDM1XG59KVxuXG5jb25zdCBTZXR0aW5nRmllbGRzID0gKCkgPT4ge1xuICBjb25zdCBbZGVzY3JpcHRpb25GaWVsZCwgZGVzY3JpcHRpb25NZXRhLCBfZGVzY3JpcHRpb25IZWxwZXJdID0gdXNlRmllbGQoJ3Rhc2tfZGVzY3JpcHRpb24nKVxuICBjb25zdCBbZ3VpZGVsaW5lc0ZpZWxkLCBndWlkZWxpbmVzTWV0YSwgX2d1aWRlbGluZXNIZWxwZXJdID0gdXNlRmllbGQoJ2d1aWRlbGluZXNfdXJsJylcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGxcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChDb250ZW50QmxvY2ssIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTI5fX1cbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEZpZWxkV3JhcHBlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMzB9fVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMzF9fSwgXCJEZXNjcmliZSB0aGUgZ29hbCBvZiB0aGUgdGFzayBcIiAgICAgIClcbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGV4dEFyZWEsIHtcbiAgICAgICAgICAgIC4uLmRlc2NyaXB0aW9uRmllbGQsXG4gICAgICAgICAgICBjYWNoZU1lYXN1cmVtZW50czogdHJ1ZSxcbiAgICAgICAgICAgIGVycm9yOiBkZXNjcmlwdGlvbk1ldGEuZXJyb3IsXG4gICAgICAgICAgICBwbGFjZWhvbGRlcjogXCJEZXNjcmlwdGlvblwiLFxuICAgICAgICAgICAgbWluUm93czogNCxcbiAgICAgICAgICAgIG1heFJvd3M6IDgsXG4gICAgICAgICAgICBwb3NpdGlvbkVycm9yQmVsb3c6IGZhbHNlLFxuICAgICAgICAgICAgc2Nyb2xsYWJsZTogdHJ1ZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEzMn19XG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChGaWVsZFdyYXBwZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTQzfX1cbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTm90ZSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNDR9fSwgXCJSZXF1aXJlZCBmaWVsZC4gVGhpcyB3aWxsIGhlbHAgdXMgdW5kZXJzdGFuZCBob3cgdGFza3MgaW4gdGhpcyBxdWV1ZSBzaG91bGQgYmUgZGVsaXZlcmVkLlwiXG5cblxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KENvbnRlbnRCbG9jaywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNTB9fVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRmllbGRXcmFwcGVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE1MX19XG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE1Mn19LCBcIkluY2x1ZGUgYSBsaW5rIHRvIGEgZ3VpZGVsaW5lcyBkb2N1bWVudCBvciBpbnN0cnVjdGlvbmFsIHZpZGVvXCIgICAgICAgICApXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KElucHV0RmllbGQsIHtcbiAgICAgICAgICAgIC4uLmd1aWRlbGluZXNGaWVsZCxcbiAgICAgICAgICAgIGVycm9yOiBndWlkZWxpbmVzTWV0YS5lcnJvcixcbiAgICAgICAgICAgIHR5cGU6IFwidGV4dFwiLFxuICAgICAgICAgICAgcGxhY2Vob2xkZXI6IFwiaHR0cHM6Ly9leGFtcGxlLmNvbS9saW5rLXRvLWRvY3VtZW50XCIsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNTN9fVxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRmllbGRXcmFwcGVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE2MH19XG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KE5vdGUsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTYxfX0sIFwiT3B0aW9uYWwgZmllbGQgd2l0aCBhIFVSTCB0byBwdWJsaWNseSBhY2Nlc3NpYmxlIGluc3RydWN0aW9ucy4gVGhlIG1vcmUgZGV0YWlsZWQgY29udGV4dCBhbmQgZXhhbXBsZXMsIHRoZSBoaWdoZXIgdGhlIG91dHB1dCBxdWFsaXR5IHdlJ2xsIGJlIGFibGUgdG8gcHJvdmlkZS5cIlxuXG5cbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgIClcbiAgICApXG4gIClcbn1cblxuY29uc3QgUXVldWVTZXR0aW5nc01vZGFsID0gKHtydW5RdWV1ZSwgcXVldWUsIGNsb3NlUG9ydGFsfSkgPT4gKFxuICBSZWFjdC5jcmVhdGVFbGVtZW50KE1vZGFsUm9vdCwgeyBpZDogXCJxdWV1ZS1zZXR0aW5ncy1tb2RhbFwiLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTcyfX1cbiAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRm9ybWlrLCB7XG4gICAgICB2YWxpZGF0aW9uU2NoZW1hOiBxdWV1ZVNldHRpbmdzU2NoZW1hLFxuICAgICAgdmFsaWRhdGVPbkNoYW5nZTogdHJ1ZSxcbiAgICAgIHZhbGlkYXRlT25CbHVyOiB0cnVlLFxuICAgICAgaW5pdGlhbFZhbHVlczogcXVldWUsXG4gICAgICBlbmFibGVSZWluaXRpYWxpemU6IHRydWUsXG4gICAgICBvblN1Ym1pdDogcnVuUXVldWUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNzN9fVxuICAgIFxuICAgICAgLCAoe2lzVmFsaWQsIGlzU3VibWl0dGluZ30pID0+IChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChGb3JtQ29udGVudCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxODJ9fVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChNb2RhbEhlYWRlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxODN9fSwgXCJBdXRvbWF0ZSB5b3VyIHF1ZXVlXCIgIClcbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTW9kYWxOb3RlLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE4NH19LCBcIlRlbGwgdXMgaG93IHRoaXMgcXVldWUgc2hvdWxkIGJlIHJ1biBhbmQgd2UnbGwgaGFuZGxlIGl0IGZvciB5b3UuXCIgICAgICAgICAgICAgKVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChNb2RhbFdyYXBwZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTg1fX1cbiAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChDb250ZW50V3JhcHBlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxODZ9fVxuICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU2V0dGluZ0ZpZWxkcywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxODd9fSApXG4gICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChDb250ZW50QmxvY2ssIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTg4fX1cbiAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUXVvdGFJbmZvV3JhcHBlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxODl9fVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFF1b3RhSW5mbywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxOTB9fSwgXCJZb3VyIGFjY291bnQgaW5jbHVkZXMgYVwiXG4gICAgICAgICAgICAgICAgICAgICAgICwgJyAnXG4gICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgnYicsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTkyfX0sIFwibW9udGhseSBxdW90YSBvZiAxMDAgdGFza3MgaGFuZGxlZCBieSB1cyBhdCBubyBjb3N0LiBcIiAgICAgICAgICAgKSwgXCJXZSB3aWxsIHNlbmQgeW91IGFuIGVtYWlsIG9uY2UgeW91IGFwcHJvYWNoIHlvdXIgbGltaXQuXCJcblxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFF1b3RhSW5mbywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxOTV9fSwgXCJJZiB5b3UgYXJlIGFudGljaXBhdGluZyBhIGxhcmdlIHRhc2sgbG9hZCwgaGF2ZSBzcGVjaWZpYyBTTEEgcmVxdWlyZW1lbnRzIG9yIHdhbnQgdG8gYXNrIGFkZGl0aWlvbmFsIHF1ZXN0aW9ucywgZG9uJ3QgaGVzaXRhdGUgdG8gY29udGFjdCB1cyBhdFwiXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgJyAnXG4gICAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgnYicsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTk4fX0sIFwiY29udGFjdEBodW1hbmxhbWJkYXMuY29tXCIpXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApXG4gICAgICAgICAgKVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChNb2RhbEZvb3Rlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMDR9fVxuICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFByaW1hcnlCdXR0b24sIHsgdHlwZTogXCJzdWJtaXRcIiwgZGlzYWJsZWQ6ICFpc1ZhbGlkIHx8IGlzU3VibWl0dGluZywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIwNX19LCBcIkVuYWJsZVwiXG5cbiAgICAgICAgICAgIClcbiAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTZWNvbmRhcnlCdXR0b24sIHsgdHlwZTogXCJidXR0b25cIiwgb25DbGljazogKCkgPT4gY2xvc2VQb3J0YWwoKSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIwOH19LCBcIkNhbmNlbFwiXG5cbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgIClcbiAgICApXG4gIClcbilcblxuZXhwb3J0IGRlZmF1bHQgUXVldWVTZXR0aW5nc01vZGFsXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL21vZHVsZXMvcXVldWUvY29udGFpbmVycy9RdWV1ZUNvbnRhaW5lci50c3hcIjtpbXBvcnQgUmVhY3QsIHt1c2VFZmZlY3QsIHVzZVN0YXRlfSBmcm9tICdyZWFjdCdcbmltcG9ydCBRdWV1ZSBmcm9tICd1bml2ZXJzYWwvbW9kdWxlcy9xdWV1ZS9jb21wb25lbnRzL1F1ZXVlJ1xuaW1wb3J0IExvYWRpbmdQYWdlIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0xvYWRpbmdQYWdlJ1xuaW1wb3J0IHVzZURvY3VtZW50VGl0bGUgZnJvbSAnY2xpZW50L2hvb2tzL3VzZURvY3VtZW50VGl0bGUnXG5pbXBvcnQgdXNlTmV0d29ya2VyIGZyb20gJ2NsaWVudC9ob29rcy91c2VOZXR3b3JrZXInXG5pbXBvcnQgdXNlUm91dGVyIGZyb20gJ2NsaWVudC9ob29rcy91c2VSb3V0ZXInXG5cbmltcG9ydCB7YWRkU3VjY2Vzc05vdGlmaWNhdGlvbn0gZnJvbSAnY2xpZW50L21vZHVsZXMvbm90aWZpY2F0aW9uU3lzdGVtL2R1Y2tzL25vdGlmaWNhdGlvblN5c3RlbUR1Y2snXG5pbXBvcnQge2Nvbm5lY3R9IGZyb20gJ3JlYWN0LXJlZHV4J1xuaW1wb3J0IHtzZWdtZW50VHJhY2t9IGZyb20gJ2NsaWVudC91dGlscy9zZWdtZW50SW8nXG5pbXBvcnQge3dvcmtmbGxvd0FjdGlvbnN9IGZyb20gJ2NsaWVudC9yZWR1eC9xdWV1ZXNSZWR1Y2VycydcbmltcG9ydCBpc1VzZXJTdGFmZiBmcm9tICdjbGllbnQvdXRpbHMvaXNVc2VyU3RhZmYnXG5cblxuXG5cblxuXG5cbmNvbnN0IFF1ZXVlQ29udGFpbmVyID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IFtxdWV1ZSwgc2V0UXVldWVdID0gdXNlU3RhdGUoe30gKVxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2Zvcm1hdCwgc2V0Rm9ybWF0XSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbZm9ybWF0TG9hZGluZywgc2V0Rm9ybWF0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3Rhc2tzLCBzZXRUYXNrc10gPSB1c2VTdGF0ZShbXSApXG4gIGNvbnN0IFt0YXNrTG9hZGluZywgc2V0VGFza0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFt0YXNrUGFnZSwgc2V0VGFza1BhZ2VdID0gdXNlU3RhdGUoMSlcbiAgY29uc3QgbmV0d29ya2VyID0gdXNlTmV0d29ya2VyKClcbiAgY29uc3Qge2hpc3Rvcnl9ID0gdXNlUm91dGVyKCkgXG5cbiAgY29uc3Qgb3JnSWQgPSBwcm9wcy51c2VyLmN1cnJlbnRfb3JnYW5pemF0aW9uX2lkXG4gIGNvbnN0IHF1ZXVlSWQgPSBwcm9wcy5tYXRjaC5wYXJhbXMucXVldWVJZFxuICBjb25zdCBvcmdhbml6YXRpb25zID0gcHJvcHMub3JnYW5pemF0aW9uc1xuICBjb25zdCBpc1N0YWZmID0gaXNVc2VyU3RhZmYob3JnYW5pemF0aW9ucywgb3JnSWQpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBhc3luYyBmdW5jdGlvbiBmZXRjaFF1ZXVlKCkge1xuICAgICAgc2V0TG9hZGluZyh0cnVlKVxuICAgICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgICAgfVxuICAgICAgY29uc3Qge2RhdGF9ID1cbiAgICAgICAgKGF3YWl0IG5ldHdvcmtlci5odHRwSGFuZGxlcihgL29yZ3MvJHtvcmdJZH0vcXVldWVzLyR7cXVldWVJZH1gLCBwYXlsb2FkKSkgfHwge31cbiAgICAgIGlmIChkYXRhKSB7XG4gICAgICAgIHNldFF1ZXVlKGRhdGEpXG4gICAgICAgIHByb3BzLnNldFNlbGVjdGVkUXVldWUoZGF0YSlcbiAgICAgIH1cbiAgICAgIHNldExvYWRpbmcoZmFsc2UpXG4gICAgfVxuXG4gICAgZmV0Y2hRdWV1ZSgpXG4gIH0sIFtdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYXN5bmMgZnVuY3Rpb24gZmV0Y2hRdWV1ZUZvcm1hdCgpIHtcbiAgICAgIGlmIChcbiAgICAgICAgb3JnYW5pemF0aW9ucy5sZW5ndGggPiAwICYmIC8vIElmIG9yZ3MgYXJlbid0IGxvYWRlZCBpc1N0YWZmIG1heSBiZSBpbmNvcnJlY3RcbiAgICAgICAgIWlzU3RhZmYgJiZcbiAgICAgICAgQXJyYXkuaXNBcnJheShmb3JtYXQpICYmXG4gICAgICAgIGZvcm1hdC5sZW5ndGggPT09IDBcbiAgICAgICkge1xuICAgICAgICBzZXRGb3JtYXRMb2FkaW5nKHRydWUpXG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSB7XG4gICAgICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHtkYXRhfSA9XG4gICAgICAgICAgKGF3YWl0IG5ldHdvcmtlci5odHRwSGFuZGxlcihgL29yZ3MvJHtvcmdJZH0vcXVldWVzLyR7cXVldWVJZH0vdGFza3MvZm9ybWAsIHBheWxvYWQpKSB8fFxuICAgICAgICAgIHt9XG4gICAgICAgIGlmIChkYXRhKSB7XG4gICAgICAgICAgY29uc3Qge2RhdGE6IGZvcm1hdERhdGF9ID0gZGF0YSB8fCB7fVxuICAgICAgICAgIHNldEZvcm1hdChmb3JtYXREYXRhKVxuICAgICAgICB9XG4gICAgICAgIHNldEZvcm1hdExvYWRpbmcoZmFsc2UpXG4gICAgICB9XG4gICAgfVxuXG4gICAgZmV0Y2hRdWV1ZUZvcm1hdCgpXG4gIH0sIFtdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYXN5bmMgZnVuY3Rpb24gZmV0Y2hUYXNrcygpIHtcbiAgICAgIHNldFRhc2tMb2FkaW5nKHRydWUpXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xuICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICB9XG4gICAgICBjb25zdCB7ZGF0YX0gPVxuICAgICAgICAoYXdhaXQgbmV0d29ya2VyLmh0dHBIYW5kbGVyKFxuICAgICAgICAgIGAvb3Jncy8ke29yZ0lkfS9xdWV1ZXMvJHtxdWV1ZUlkfS90YXNrcy9wZW5kaW5nP2xpbWl0PTEwJm9mZnNldD0ke1xuICAgICAgICAgICAgKHRhc2tQYWdlIC0gMSkgKiAxMCB8fCAwXG4gICAgICAgICAgfWAsXG4gICAgICAgICAgcGF5bG9hZFxuICAgICAgICApKSB8fCB7fVxuICAgICAgaWYgKGRhdGEpIHtcbiAgICAgICAgc2V0VGFza3MoZGF0YS50YXNrcylcbiAgICAgIH1cbiAgICAgIHNldFRhc2tMb2FkaW5nKGZhbHNlKVxuICAgIH1cblxuICAgIGZldGNoVGFza3MoKVxuICB9LCBbdGFza1BhZ2VdKVxuXG4gIGNvbnN0IGRlbGV0ZVF1ZXVlID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBuZXR3b3JrZXIuaHR0cEhhbmRsZXIoYC9vcmdzLyR7b3JnSWR9L3F1ZXVlcy8ke3F1ZXVlSWR9YCwge1xuICAgICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICAgIGRhdGE6IHtkaXNhYmxlZDogdHJ1ZX1cbiAgICAgIH0pXG4gICAgICBzZWdtZW50VHJhY2soJ1F1ZXVlIERlbGV0ZWQnLCB7XG4gICAgICAgIG9yZ0lkLFxuICAgICAgICBxdWV1ZUlkLFxuICAgICAgICB1c2VySWQ6IHByb3BzLnVzZXIuaWQsXG4gICAgICAgIG5hbWVcbiAgICAgIH0pXG4gICAgICBwcm9wcy5hZGRTdWNjZXNzTm90aWZpY2F0aW9uKCdUaGlzIHF1ZXVlIGhhcyBub3cgYmVlbiBkZWxldGVkJylcbiAgICAgIGhpc3RvcnkucHVzaChgL3F1ZXVlc2ApXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGZsdXNoUXVldWVUYXNrcyA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgbmV0d29ya2VyLmh0dHBIYW5kbGVyKGAvb3Jncy8ke29yZ0lkfS9xdWV1ZXMvJHtxdWV1ZUlkfS9mbHVzaGAsIHtcbiAgICAgICAgbWV0aG9kOiAnUFVUJ1xuICAgICAgfSlcbiAgICAgIHNlZ21lbnRUcmFjaygnUXVldWUgVGFza3MgRGVsZXRlZCcsIHtcbiAgICAgICAgb3JnSWQsXG4gICAgICAgIHF1ZXVlSWQsXG4gICAgICAgIHVzZXJJZDogcHJvcHMudXNlci5pZFxuICAgICAgfSlcbiAgICAgIHByb3BzLmFkZFN1Y2Nlc3NOb3RpZmljYXRpb24oYFRoZSBxdWV1ZSdzIHRhc2tzIGhhdmUgbm93IGJlZW4gZGVsZXRlZGApXG4gICAgICBzZXRUYXNrcyhbXSlcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgc3RhcnROZXh0VGFzayA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBwYXlsb2FkID0ge1xuICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgIH1cbiAgICBjb25zdCByZXMgPSBhd2FpdCBuZXR3b3JrZXIuaHR0cEhhbmRsZXIoYC9vcmdzLyR7b3JnSWR9L3F1ZXVlcy8ke3F1ZXVlSWR9L3Rhc2tzL25leHRgLCBwYXlsb2FkKVxuICAgIGNvbnN0IHtkYXRhfSA9IHJlcyB8fCB7fVxuICAgIGNvbnN0IHJvdXRlID0gZGF0YS5pZCA/IGAvcXVldWVzLyR7cXVldWVJZH0vdGFza3MvJHtkYXRhLmlkfWAgOiBgL3F1ZXVlcy8ke3F1ZXVlSWR9L2Nvbm5lY3Rpb25zYFxuICAgIGhpc3RvcnkucHVzaChyb3V0ZSlcbiAgfVxuXG4gIGxldCByZW5kZXJDb21wXG5cbiAgaWYgKGxvYWRpbmcgfHwgdGFza0xvYWRpbmcgfHwgZm9ybWF0TG9hZGluZyB8fCBxdWV1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmVuZGVyQ29tcCA9IFJlYWN0LmNyZWF0ZUVsZW1lbnQoTG9hZGluZ1BhZ2UsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTUxfX0gKVxuICB9IGVsc2Uge1xuICAgIHJlbmRlckNvbXAgPSAoXG4gICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFF1ZXVlLCB7XG4gICAgICAgIHF1ZXVlOiBxdWV1ZSxcbiAgICAgICAgdXNlcjogcHJvcHMudXNlcixcbiAgICAgICAgb3JnSWQ6IG9yZ0lkLFxuICAgICAgICBxdWV1ZUlkOiBxdWV1ZUlkLFxuICAgICAgICBkZWxldGVRdWV1ZTogZGVsZXRlUXVldWUsXG4gICAgICAgIGZsdXNoUXVldWVUYXNrczogZmx1c2hRdWV1ZVRhc2tzLFxuICAgICAgICBzdGFydE5leHRUYXNrOiBzdGFydE5leHRUYXNrLFxuICAgICAgICBmb3JtYXQ6IGZvcm1hdCxcbiAgICAgICAgdGFza3M6IHRhc2tzLFxuICAgICAgICBpc1N0YWZmOiBpc1N0YWZmLFxuICAgICAgICB0YXNrUGFnZTogdGFza1BhZ2UsXG4gICAgICAgIHNldFRhc2tQYWdlOiBzZXRUYXNrUGFnZSxcbiAgICAgICAgdGFza0xvYWRpbmc6IHRhc2tMb2FkaW5nLFxuICAgICAgICBzZXRRdWV1ZTogc2V0UXVldWUsXG4gICAgICAgIHNldFNlbGVjdGVkUXVldWU6IHByb3BzLnNldFNlbGVjdGVkUXVldWUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNTR9fVxuICAgICAgKVxuICAgIClcbiAgfVxuXG4gIHVzZURvY3VtZW50VGl0bGUoYFF1ZXVlIHwgSHVtYW4gTGFtYmRhc2ApXG5cbiAgcmV0dXJuIHJlbmRlckNvbXBcbn1cblxuY29uc3QgbWFwRGlzcGF0Y2hUb1Byb3BzID0gKGRpc3BhdGNoKSA9PiAoe1xuICBhZGRTdWNjZXNzTm90aWZpY2F0aW9uOiAoYXJnKSA9PiBkaXNwYXRjaChhZGRTdWNjZXNzTm90aWZpY2F0aW9uKGFyZykpLFxuICBzZXRTZWxlY3RlZFF1ZXVlOiAoYXJnKSA9PiBkaXNwYXRjaCh3b3JrZmxsb3dBY3Rpb25zLnNldFNlbGVjdGVkUXVldWUoYXJnKSlcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobnVsbCwgbWFwRGlzcGF0Y2hUb1Byb3BzKShRdWV1ZUNvbnRhaW5lcilcbiIsImNvbnN0IGN1dE9mZlN0cmluZyA9IChzdHJpbmcsIGxlbmd0aCkgPT5cbiAgc3RyaW5nLmxlbmd0aCA+IGxlbmd0aCA/IGAke3N0cmluZy5zdWJzdHJpbmcoMCwgbGVuZ3RoKX0uLi5gIDogc3RyaW5nXG5leHBvcnQgZGVmYXVsdCBjdXRPZmZTdHJpbmdcbiIsIiBmdW5jdGlvbiBfb3B0aW9uYWxDaGFpbihvcHMpIHsgbGV0IGxhc3RBY2Nlc3NMSFMgPSB1bmRlZmluZWQ7IGxldCB2YWx1ZSA9IG9wc1swXTsgbGV0IGkgPSAxOyB3aGlsZSAoaSA8IG9wcy5sZW5ndGgpIHsgY29uc3Qgb3AgPSBvcHNbaV07IGNvbnN0IGZuID0gb3BzW2kgKyAxXTsgaSArPSAyOyBpZiAoKG9wID09PSAnb3B0aW9uYWxBY2Nlc3MnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgJiYgdmFsdWUgPT0gbnVsbCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9IGlmIChvcCA9PT0gJ2FjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbEFjY2VzcycpIHsgbGFzdEFjY2Vzc0xIUyA9IHZhbHVlOyB2YWx1ZSA9IGZuKHZhbHVlKTsgfSBlbHNlIGlmIChvcCA9PT0gJ2NhbGwnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgeyB2YWx1ZSA9IGZuKCguLi5hcmdzKSA9PiB2YWx1ZS5jYWxsKGxhc3RBY2Nlc3NMSFMsIC4uLmFyZ3MpKTsgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgfSB9IHJldHVybiB2YWx1ZTsgfWltcG9ydCB7QkxPQ0tfVFlQRX0gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcblxuY29uc3QgZm9ybWF0VmFsdWVzID0gKHZhbHVlcykgPT4ge1xuICBsZXQgZmllbGRzXG5cbiAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWVzLmRhdGEpKSB7XG4gICAgZmllbGRzID0gdmFsdWVzLmRhdGFcbiAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHZhbHVlcykpIHtcbiAgICBmaWVsZHMgPSB2YWx1ZXNcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gdmFsdWVzXG4gIH1cblxuICBmaWVsZHMuZmlsdGVyKCh2YWwpID0+IHtcbiAgICBpZiAodmFsW0JMT0NLX1RZUEUuTkFNRURfRU5USVRZX1JFQ09HTklUSU9OXSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBfb3B0aW9uYWxDaGFpbihbdmFsLCAnYWNjZXNzJywgXyA9PiBfW0JMT0NLX1RZUEUuTkFNRURfRU5USVRZX1JFQ09HTklUSU9OXSwgJ2FjY2VzcycsIF8yID0+IF8yLmVudGl0aWVzLCAnb3B0aW9uYWxBY2Nlc3MnLCBfMyA9PiBfMy5maWx0ZXIsICdjYWxsJywgXzQgPT4gXzQoKGVudGl0eSkgPT4ge1xuICAgICAgICBkZWxldGUgZW50aXR5LmNvbG9yXG4gICAgICAgIGRlbGV0ZSBlbnRpdHkudGV4dFxuICAgICAgfSldKVxuICAgIH1cbiAgICBpZiAodmFsW0JMT0NLX1RZUEUuQk9VTkRJTkdfQk9YRVNdICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KHZhbFtCTE9DS19UWVBFLkJPVU5ESU5HX0JPWEVTXS52YWx1ZS5vYmplY3RzKSkge1xuICAgICAgICB2YWxbQkxPQ0tfVFlQRS5CT1VORElOR19CT1hFU10udmFsdWUub2JqZWN0cy5maWx0ZXIoKGVudGl0eSkgPT4ge1xuICAgICAgICAgIGRlbGV0ZSBlbnRpdHkuY29sb3JcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICAgIGlmICh2YWxbQkxPQ0tfVFlQRS5CT1VORElOR19CT1hFU10udmFsdWUuaW1hZ2UgPT09ICcnKSB7XG4gICAgICAgIHZhbFtCTE9DS19UWVBFLkJPVU5ESU5HX0JPWEVTXS52YWx1ZS5pbWFnZSA9IG51bGxcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHZhbFxuICB9KVxuICByZXR1cm4gdmFsdWVzXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZvcm1hdFZhbHVlc1xuIiwiY29uc3QgZ2V0Rmlyc3RMZXR0ZXIgPSAoc3RyKSA9PiB7XG4gIGxldCBmaXJzdExldHRlciA9IHN0clxuXG4gIGlmIChzdHIgJiYgc3RyLmxlbmd0aCA+IDEpIHtcbiAgICBmaXJzdExldHRlciA9IHN0ci5jaGFyQXQoMCkudG9VcHBlckNhc2UoKVxuICB9XG5cbiAgcmV0dXJuIGZpcnN0TGV0dGVyXG59XG5cbmV4cG9ydCBkZWZhdWx0IGdldEZpcnN0TGV0dGVyXG4iLCJpbXBvcnQge1FVRVVFX1NUQVRVU30gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcblxuY29uc3QgZ2V0UXVldWVTdGF0dXMgPSAodHlwZSkgPT4ge1xuICBsZXQgc3RhdHVzID0gJydcbiAgc3dpdGNoICh0eXBlKSB7XG4gICAgY2FzZSBRVUVVRV9TVEFUVVMuQ09NUExFVEVEOlxuICAgICAgc3RhdHVzID0gJ0NPTVBMRVRFRCdcbiAgICAgIGJyZWFrXG4gICAgY2FzZSBRVUVVRV9TVEFUVVMuTkVXOlxuICAgICAgc3RhdHVzID0gJ05FVydcbiAgICAgIGJyZWFrXG4gICAgY2FzZSBRVUVVRV9TVEFUVVMuSU5fUFJPR1JFU1M6XG4gICAgICBzdGF0dXMgPSAnSU4gUFJPR1JFU1MnXG4gICAgICBicmVha1xuICAgIGNhc2UgUVVFVUVfU1RBVFVTLk9QRU46XG4gICAgICBzdGF0dXMgPSAnT1BFTidcbiAgICAgIGJyZWFrXG4gICAgZGVmYXVsdDpcbiAgICAgIGJyZWFrXG4gIH1cbiAgcmV0dXJuIHN0YXR1c1xufVxuXG5leHBvcnQgZGVmYXVsdCBnZXRRdWV1ZVN0YXR1c1xuIl0sInNvdXJjZVJvb3QiOiIifQ==