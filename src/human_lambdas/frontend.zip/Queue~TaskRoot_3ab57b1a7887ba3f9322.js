(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Queue~TaskRoot"],{

/***/ "./node_modules/css-loader/dist/cjs.js!./src/universal/styles/css/react-grid-layout.css":
/*!**********************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/universal/styles/css/react-grid-layout.css ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".react-grid-layout {\n  position: relative;\n  transition: height 200ms ease;\n}\n.react-grid-item {\n  transition: all 200ms ease;\n  transition-property: left, top;\n}\n.react-grid-item.cssTransforms {\n  transition-property: transform;\n}\n.react-grid-item.resizing {\n  z-index: 1;\n  will-change: width, height;\n}\n\n.react-grid-item.react-draggable-dragging {\n  transition: none;\n  z-index: 3;\n  will-change: transform;\n}\n\n.react-grid-item.dropping {\n  visibility: hidden;\n}\n\n.react-grid-item.react-grid-placeholder {\n  background: red;\n  opacity: 0.2;\n  transition-duration: 100ms;\n  z-index: 2;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  -o-user-select: none;\n  user-select: none;\n}\n\n.react-grid-item > .react-resizable-handle {\n  position: absolute;\n  width: 20px;\n  height: 20px;\n  bottom: -10px;\n  right: -10px;\n  cursor: se-resize;\n  opacity: 0;\n}\n\n.react-grid-item > .react-resizable-handle::after {\n  content: \"\";\n  position: absolute;\n  right: 3px;\n  bottom: 3px;\n  width: 5px;\n  height: 5px;\n  border-right: 2px solid rgba(0, 0, 0, 0.4);\n  border-bottom: 2px solid rgba(0, 0, 0, 0.4);\n}\n\n.react-resizable-hide > .react-resizable-handle {\n  display: none;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/universal/styles/css/react-resizable.css":
/*!********************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/universal/styles/css/react-resizable.css ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".react-resizable {\n  position: relative;\n}\n.react-resizable-handle {\n  position: absolute;\n  width: 20px;\n  height: 20px;\n  background-repeat: no-repeat;\n  background-origin: content-box;\n  box-sizing: border-box;\n  background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA2IDYiIHN0eWxlPSJiYWNrZ3JvdW5kLWNvbG9yOiNmZmZmZmYwMCIgeD0iMHB4IiB5PSIwcHgiIHdpZHRoPSI2cHgiIGhlaWdodD0iNnB4Ij48ZyBvcGFjaXR5PSIwLjMwMiI+PHBhdGggZD0iTSA2IDYgTCAwIDYgTCAwIDQuMiBMIDQgNC4yIEwgNC4yIDQuMiBMIDQuMiAwIEwgNiAwIEwgNiA2IEwgNiA2IFoiIGZpbGw9IiMwMDAwMDAiLz48L2c+PC9zdmc+');\n  background-position: bottom right;\n  padding: 0 3px 3px 0;\n}\n.react-resizable-handle-sw {\n  bottom: 0;\n  left: 0;\n  cursor: sw-resize;\n  transform: rotate(90deg);\n}\n.react-resizable-handle-se {\n  bottom: 0;\n  right: 0;\n  cursor: se-resize;\n}\n.react-resizable-handle-nw {\n  top: 0;\n  left: 0;\n  cursor: nw-resize;\n  transform: rotate(180deg);\n}\n.react-resizable-handle-ne {\n  top: 0;\n  right: 0;\n  cursor: ne-resize;\n  transform: rotate(270deg);\n}\n.react-resizable-handle-w,\n.react-resizable-handle-e {\n  top: 50%;\n  margin-top: -10px;\n  cursor: ew-resize;\n}\n.react-resizable-handle-w {\n  left: 0;\n  transform: rotate(135deg);\n}\n.react-resizable-handle-e {\n  right: 0;\n  transform: rotate(315deg);\n}\n.react-resizable-handle-n,\n.react-resizable-handle-s {\n  left: 50%;\n  margin-left: -10px;\n  cursor: ns-resize;\n}\n.react-resizable-handle-n {\n  top: 0;\n  transform: rotate(225deg);\n}\n.react-resizable-handle-s {\n  bottom: 0;\n  transform: rotate(45deg);\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/universal/styles/css/rgl-overide.css":
/*!****************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/universal/styles/css/rgl-overide.css ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".react-grid-item.react-grid-placeholder {\n  background-color: #6648ee;\n  opacity: 0.15;\n  z-index: 10;\n}\n\n.react-draggable-dragging, .react-draggable.resizing {\n  z-index: 100 !important;\n}\n\n.react-grid-item:hover > .react-resizable-handle {\n  opacity: 1;\n}\n\n.react-grid-item.cssTransforms {\n  transition-property: none;\n}\n.animated .react-grid-item.cssTransforms {\n  transition-property: transform;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./src/client/components/InputField.tsx":
/*!**********************************************!*\
  !*** ./src/client/components/InputField.tsx ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styles_palette__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styles/palette */ "./src/client/styles/palette.ts");
/* harmony import */ var styles_typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styles/typography */ "./src/client/styles/typography.ts");
/* harmony import */ var components_StyledError__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! components/StyledError */ "./src/client/components/StyledError.tsx");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/InputField.tsx";





const Input = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("input", {
  target: "e10b86x70"
})(({
  error,
  disabled
}) => ({
  display: 'block',
  appearance: 'none',
  outline: 'none',
  margin: 0,
  border: `1px solid ${error ? styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].ERROR_MAIN : styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].BORDER_MAIN_GRAY}`,
  boxSizing: 'border-box',
  color: styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].TEXT_MAIN,
  fontFamily: styles_typography__WEBPACK_IMPORTED_MODULE_3__["FONT_FAMILY"].SANS_SERIF,
  fontWeight: 400,
  cursor: disabled ? 'not-allowed' : 'input',
  borderRadius: 4,
  fontSize: 15,
  lineHeight: '32px',
  backgroundColor: '#fff',
  height: 32,
  padding: '0 10px',
  transition: 'border-color 200ms ease-in',
  width: '100%',
  ':focus': {
    boxShadow: `0 0 0 3px ${error ? '#ffdacc' : styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].BOX_SHADOW_PRIMARY}`,
    borderColor: error ? styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].ERROR_MAIN : styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].PRIMARY_MAIN
  }
}));

const Label = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e10b86x71"
})({
  fontSize: 15,
  fontWeight: 500,
  lineHeight: '32px',
  color: styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].TEXT_MAIN
});

const StyledLabel = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e10b86x72"
})({
  name: "182kafx",
  styles: "display:flex;flex-direction:row;align-items:center;margin-left:5px;"
});

const LabelHelper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e10b86x73"
})({
  fontSize: 12,
  fontWeight: 400,
  color: styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].TEXT_GRAY,
  marginLeft: 6
});

const InputField = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["forwardRef"])((props, ref) => {
  const {
    autoComplete,
    autoFocus,
    disabled,
    error,
    isOptional,
    isRequired,
    name,
    onBlur,
    onFocus,
    onChange,
    placeholder,
    type = 'text',
    value,
    label,
    style,
    spellCheck
  } = props;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, label && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledLabel, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 100
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Label, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 101
    }
  }, label), isRequired && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LabelHelper, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 102
    }
  }, "Required"), isOptional && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(LabelHelper, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 103
    }
  }, "Optional")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Input, {
    autoComplete: autoComplete,
    autoFocus: autoFocus,
    disabled: Boolean(disabled),
    name: name,
    placeholder: placeholder,
    onBlur: onBlur,
    onFocus: onFocus,
    onChange: onChange,
    ref: ref,
    type: type,
    value: value,
    error: Boolean(error),
    spellCheck: spellCheck,
    style: style,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 106
    }
  }), error && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(components_StyledError__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 122
    }
  }, error));
});
/* harmony default export */ __webpack_exports__["default"] = (InputField);

/***/ }),

/***/ "./src/client/components/ListFilter.tsx":
/*!**********************************************!*\
  !*** ./src/client/components/ListFilter.tsx ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var match_sorter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! match-sorter */ "./node_modules/match-sorter/dist/match-sorter.esm.js");
/* harmony import */ var _InputField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./InputField */ "./src/client/components/InputField.tsx");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/client/components/ListFilter.tsx";




const Wrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1op9xzz0"
})({
  name: "iktmnx",
  styles: "margin:10px 0px;"
});

const ListFilter = ({
  list,
  setList,
  keys
}) => {
  const handleChange = e => {
    const term = e.target.value;
    setList(Object(match_sorter__WEBPACK_IMPORTED_MODULE_2__["matchSorter"])(list, term, {
      keys
    }));
  };

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Wrapper, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_InputField__WEBPACK_IMPORTED_MODULE_3__["default"], {
    placeholder: "Filter",
    onChange: handleChange,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (ListFilter);

/***/ }),

/***/ "./src/universal/components/AppHeader.tsx":
/*!************************************************!*\
  !*** ./src/universal/components/AppHeader.tsx ***!
  \************************************************/
/*! exports provided: APP_HEADER_HEIGHT, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "APP_HEADER_HEIGHT", function() { return APP_HEADER_HEIGHT; });
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var universal_utils_isEmptyArray__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/utils/isEmptyArray */ "./src/universal/utils/isEmptyArray.ts");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/AppHeader.tsx";



const APP_HEADER_HEIGHT = 50;

const Container = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1vjj9hv0"
})({
  display: 'flex',
  flexDirection: 'row-reverse',
  alignItems: 'center',
  justifyContent: 'space-between',
  padding: '0 25px',
  backgroundColor: universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].BACKGROUND_MAIN,
  borderBottom: `1px solid ${universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].BORDER_GRAY_NEW}`,
  minHeight: APP_HEADER_HEIGHT,
  minWidth: '100%'
});

const FlexItem = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1vjj9hv1"
})(prop => {
  return {
    flex: '1 1 0',
    textAlign: prop.center ? 'center' : 'inherit'
  };
});

const AppHeader = props => {
  const {
    leftBarItems,
    rightBarItems,
    midBarItems
  } = props;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Container, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FlexItem, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  }, rightBarItems), !Object(universal_utils_isEmptyArray__WEBPACK_IMPORTED_MODULE_3__["default"])(rightBarItems) && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FlexItem, {
    center: true,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    }
  }, midBarItems), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FlexItem, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    }
  }, leftBarItems));
};

/* harmony default export */ __webpack_exports__["default"] = (AppHeader);

/***/ }),

/***/ "./src/universal/components/BlockComponent.tsx":
/*!*****************************************************!*\
  !*** ./src/universal/components/BlockComponent.tsx ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var universal_components_blocks_Image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/blocks/Image */ "./src/universal/components/blocks/Image.tsx");
/* harmony import */ var universal_components_blocks_Number__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/components/blocks/Number */ "./src/universal/components/blocks/Number.tsx");
/* harmony import */ var universal_components_blocks_Text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! universal/components/blocks/Text */ "./src/universal/components/blocks/Text.tsx");
/* harmony import */ var universal_components_blocks_Email__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/components/blocks/Email */ "./src/universal/components/blocks/Email.tsx");
/* harmony import */ var universal_components_blocks_Link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/components/blocks/Link */ "./src/universal/components/blocks/Link.tsx");
/* harmony import */ var universal_components_blocks_MediaBlock__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! universal/components/blocks/MediaBlock */ "./src/universal/components/blocks/MediaBlock.tsx");
/* harmony import */ var universal_components_blocks_Binary__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/components/blocks/Binary */ "./src/universal/components/blocks/Binary.tsx");
/* harmony import */ var universal_components_blocks_Embed__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! universal/components/blocks/Embed */ "./src/universal/components/blocks/Embed.tsx");
/* harmony import */ var universal_components_blocks_PdfReader__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! universal/components/blocks/PdfReader */ "./src/universal/components/blocks/PdfReader.tsx");
/* harmony import */ var universal_components_blocks_SingleSelection__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! universal/components/blocks/SingleSelection */ "./src/universal/components/blocks/SingleSelection.tsx");
/* harmony import */ var universal_components_blocks_NamedEntityRecognition__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! universal/components/blocks/NamedEntityRecognition */ "./src/universal/components/blocks/NamedEntityRecognition.tsx");
/* harmony import */ var universal_components_blocks_MultipleSelection__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! universal/components/blocks/MultipleSelection */ "./src/universal/components/blocks/MultipleSelection.tsx");
/* harmony import */ var universal_components_blocks_FormSequence__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! universal/components/blocks/FormSequence */ "./src/universal/components/blocks/FormSequence.tsx");
/* harmony import */ var universal_components_blocks_RichTextEditor__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! universal/components/blocks/RichTextEditor */ "./src/universal/components/blocks/RichTextEditor.tsx");
/* harmony import */ var universal_components_blocks_BoundingBoxes__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! universal/components/blocks/BoundingBoxes */ "./src/universal/components/blocks/BoundingBoxes.tsx");
/* harmony import */ var universal_components_blocks_TextSequence__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! universal/components/blocks/TextSequence */ "./src/universal/components/blocks/TextSequence.tsx");
/* harmony import */ var universal_components_blocks_Date__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! universal/components/blocks/Date */ "./src/universal/components/blocks/Date.tsx");
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/BlockComponent.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}




















const BlockComponent = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(props => {
  const {
    isAudits,
    setFieldValue,
    isEditing,
    index,
    block,
    onDelete,
    handleChange,
    handleBlur,
    onEdit,
    errors
  } = props || {};
  let renderCmp;

  switch (block.type) {
    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].TEXT:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_Text__WEBPACK_IMPORTED_MODULE_4__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        onDelete: onDelete,
        onEdit: onEdit,
        handleChange: handleChange,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 53
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].EMAIL:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_Email__WEBPACK_IMPORTED_MODULE_5__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        error: _optionalChain([errors, 'optionalAccess', _ => _.email]),
        onDelete: onDelete,
        onEdit: onEdit,
        handleChange: handleChange,
        handleBlur: handleBlur,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 66
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].NUMBER:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_Number__WEBPACK_IMPORTED_MODULE_3__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        onDelete: onDelete,
        onEdit: onEdit,
        handleChange: handleChange,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 81
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].LINK:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_Link__WEBPACK_IMPORTED_MODULE_6__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        error: _optionalChain([errors, 'optionalAccess', _2 => _2.link]),
        onDelete: onDelete,
        onEdit: onEdit,
        handleChange: handleChange,
        handleBlur: handleBlur,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 94
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].IMAGE:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_Image__WEBPACK_IMPORTED_MODULE_2__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        block: block,
        onDelete: onDelete,
        onEdit: onEdit,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 109
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].AUDIO:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_MediaBlock__WEBPACK_IMPORTED_MODULE_7__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        block: block,
        onDelete: onDelete,
        onEdit: onEdit,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 120
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].VIDEO:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_MediaBlock__WEBPACK_IMPORTED_MODULE_7__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        block: block,
        onDelete: onDelete,
        onEdit: onEdit,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 131
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].BINARY:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_Binary__WEBPACK_IMPORTED_MODULE_8__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        onEdit: onEdit,
        onDelete: onDelete,
        handleChange: handleChange,
        setFieldValue: setFieldValue,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 142
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_NamedEntityRecognition__WEBPACK_IMPORTED_MODULE_12__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        onEdit: onEdit,
        error: errors,
        onDelete: onDelete,
        handleChange: handleChange,
        setFieldValue: setFieldValue,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 156
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].BOUNDING_BOXES:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_BoundingBoxes__WEBPACK_IMPORTED_MODULE_16__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        block: block,
        index: index,
        onDelete: onDelete,
        onEdit: onEdit,
        handleChange: handleChange,
        setFieldValue: setFieldValue,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 171
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].EMBED:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_Embed__WEBPACK_IMPORTED_MODULE_9__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        onEdit: onEdit,
        error: errors,
        onDelete: onDelete,
        handleChange: handleChange,
        setFieldValue: setFieldValue,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 185
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].PDF:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_PdfReader__WEBPACK_IMPORTED_MODULE_10__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        onEdit: onEdit,
        error: errors,
        onDelete: onDelete,
        handleChange: handleChange,
        setFieldValue: setFieldValue,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 200
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].SINGLE_SELECTION:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_SingleSelection__WEBPACK_IMPORTED_MODULE_11__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        onEdit: onEdit,
        onDelete: onDelete,
        handleChange: handleChange,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 215
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].MULTIPLE_SELECTION:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_MultipleSelection__WEBPACK_IMPORTED_MODULE_13__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        onEdit: onEdit,
        onDelete: onDelete,
        handleChange: handleChange,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 228
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].FORM_SEQUENCE:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_FormSequence__WEBPACK_IMPORTED_MODULE_14__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        onEdit: onEdit,
        onDelete: onDelete,
        handleChange: handleChange,
        setFieldValue: setFieldValue,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 241
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].RICH_TEXT:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_RichTextEditor__WEBPACK_IMPORTED_MODULE_15__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        onDelete: onDelete,
        onEdit: onEdit,
        setFieldValue: setFieldValue,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 255
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].TEXT_SEQUENCE:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_TextSequence__WEBPACK_IMPORTED_MODULE_17__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        onDelete: onDelete,
        onEdit: onEdit,
        handleChange: handleChange,
        setFieldValue: setFieldValue,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 268
        }
      });
      break;

    case universal_utils_constants__WEBPACK_IMPORTED_MODULE_1__["BLOCK_TYPE"].DATE:
      renderCmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_blocks_Date__WEBPACK_IMPORTED_MODULE_18__["default"], {
        isAudits: isAudits,
        isEditing: isEditing,
        index: index,
        block: block,
        onDelete: onDelete,
        onEdit: onEdit,
        handleChange: handleChange,
        setFieldValue: setFieldValue,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 282
        }
      });
      break;

    default:
      renderCmp = null;
  }

  return renderCmp;
});
/* harmony default export */ __webpack_exports__["default"] = (BlockComponent);

/***/ }),

/***/ "./src/universal/components/BlockHeader.tsx":
/*!**************************************************!*\
  !*** ./src/universal/components/BlockHeader.tsx ***!
  \**************************************************/
/*! exports provided: Container, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Container", function() { return Container; });
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_components_IconButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/IconButton */ "./src/universal/components/IconButton.tsx");
/* harmony import */ var universal_components_Icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/components/Icon */ "./src/universal/components/Icon.tsx");
/* harmony import */ var client_styles_palette__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! client/styles/palette */ "./src/client/styles/palette.ts");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/BlockHeader.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}






const Container = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ec495x90"
})({
  name: "1tvufdm",
  styles: "display:grid;grid-template-columns:25px 25px;visibility:hidden;opacity:0;transition:visibility 0s, opacity 0.250s linear;position:absolute;right:-5px;background-color:#fff;"
});

const StyledIcon = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_Icon__WEBPACK_IMPORTED_MODULE_3__["default"], {
  target: "ec495x91"
})({
  textAlign: 'center',
  display: 'block',
  fontSize: 18,
  color: client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].PRIMARY_MAIN
});

const TypeIcon = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(StyledIcon, {
  target: "ec495x92"
})({
  color: client_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].BACKGROUND_GRAY_MID,
  cursor: 'default'
});

const BlockHeader = props => {
  const {
    onDelete,
    onEdit,
    isEditing,
    blockType
  } = props;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    }
  }, isEditing && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Container, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_IconButton__WEBPACK_IMPORTED_MODULE_2__["default"], {
    type: "button",
    onClick: onEdit,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    }
  }, "settings")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_IconButton__WEBPACK_IMPORTED_MODULE_2__["default"], {
    type: "button",
    onClick: onDelete,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    }
  }, "delete"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TypeIcon, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    }
  }, _optionalChain([universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCKS"], 'access', _ => _.find, 'call', _2 => _2(b => b.type === blockType), 'optionalAccess', _3 => _3.icon])));
};

/* harmony default export */ __webpack_exports__["default"] = (BlockHeader);

/***/ }),

/***/ "./src/universal/components/BlockWrapper.tsx":
/*!***************************************************!*\
  !*** ./src/universal/components/BlockWrapper.tsx ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");


const BlockWrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e91a4cv0"
})(({
  type,
  index
}) => ({
  width: '100%',
  backgroundColor: '#fff !important',
  borderRadius: 4,
  border: '1px solid #e7e9ec',
  boxShadow: 'rgba(0, 0, 0, 0.025) 0px 2px 4px',
  zIndex: type === 'date' ? 10 - index : 1
}));

/* harmony default export */ __webpack_exports__["default"] = (BlockWrapper);

/***/ }),

/***/ "./src/universal/components/IconButton.tsx":
/*!*************************************************!*\
  !*** ./src/universal/components/IconButton.tsx ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var client_components_PlainButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! client/components/PlainButton */ "./src/client/components/PlainButton.tsx");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/IconButton.tsx";




const Container = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(client_components_PlainButton__WEBPACK_IMPORTED_MODULE_3__["default"], {
  target: "ek186l90"
})({
  cursor: 'pointer',
  backgroundColor: 'inherit',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: 50,
  width: 25,
  height: 25,
  padding: 0,
  margin: 0,
  transition: 'all 200ms ease-in',
  ':hover': {
    color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_2__["PALETTE"].PRIMARY_MAIN
  }
});

const IconButton = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["forwardRef"])((props, ref) => {
  const {
    onClick,
    type,
    children,
    style
  } = props;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Container, {
    ref: ref,
    onClick: onClick,
    type: type,
    style: style,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }, children);
});
/* harmony default export */ __webpack_exports__["default"] = (IconButton);

/***/ }),

/***/ "./src/universal/components/RGL.tsx":
/*!******************************************!*\
  !*** ./src/universal/components/RGL.tsx ***!
  \******************************************/
/*! exports provided: RGL_COLUMNS, RGL_ROWS, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RGL_COLUMNS", function() { return RGL_COLUMNS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RGL_ROWS", function() { return RGL_ROWS; });
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_grid_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-grid-layout */ "./node_modules/react-grid-layout/index.js");
/* harmony import */ var react_grid_layout__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_grid_layout__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var universal_styles_css_react_grid_layout_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/styles/css/react-grid-layout.css */ "./src/universal/styles/css/react-grid-layout.css");
/* harmony import */ var universal_styles_css_react_grid_layout_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(universal_styles_css_react_grid_layout_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var universal_styles_css_react_resizable_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! universal/styles/css/react-resizable.css */ "./src/universal/styles/css/react-resizable.css");
/* harmony import */ var universal_styles_css_react_resizable_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(universal_styles_css_react_resizable_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var universal_styles_css_rgl_overide_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/styles/css/rgl-overide.css */ "./src/universal/styles/css/rgl-overide.css");
/* harmony import */ var universal_styles_css_rgl_overide_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(universal_styles_css_rgl_overide_css__WEBPACK_IMPORTED_MODULE_5__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/RGL.tsx";





const RGLWidthProvider = Object(react_grid_layout__WEBPACK_IMPORTED_MODULE_2__["WidthProvider"])(react_grid_layout__WEBPACK_IMPORTED_MODULE_2__["Responsive"]);
const RGL_COLUMNS = 20;
const RGL_ROWS = 40;

const RGLContainer = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(RGLWidthProvider, {
  target: "epfjvic0"
})({
  name: "1xs5ypw",
  styles: "width:100%;min-height:calc(100vh - 50px);background-color:#f8f8fa;"
});

const RGLWrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "epfjvic1"
})({
  name: "kjhdb2",
  styles: "height:100%;width:100%;overflow:scroll;"
});

const RGL = props => {
  const {
    children,
    isDraggable,
    isDroppable,
    isResizable,
    onDragStart,
    onDragStop,
    onDrop,
    onLayoutChange,
    layouts,
    droppingItem
  } = props;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(RGLWrapper, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(RGLContainer, _objectSpread(_objectSpread({}, props), {}, {
    autoSize: true,
    breakpoints: {
      all: RGL_COLUMNS
    },
    cols: {
      all: RGL_COLUMNS
    },
    compactType: 'vertical',
    isDraggable: isDraggable,
    isDroppable: isDroppable,
    isBounded: true,
    droppingItem: droppingItem,
    isResizable: isResizable,
    layouts: {
      all: layouts
    },
    measureBeforeMount: true,
    useCSSTransforms: true,
    preventCollision: false,
    containerPadding: [10, 10],
    margin: [10, 10],
    onDragStart: onDragStart,
    onDragStop: onDragStop,
    onDrop: onDrop,
    rowHeight: RGL_ROWS,
    onLayoutChange: onLayoutChange,
    draggableHandle: ".drag-handle",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    }
  }), children));
};

/* harmony default export */ __webpack_exports__["default"] = (RGL);

/***/ }),

/***/ "./src/universal/components/TaggableListWrapper.tsx":
/*!**********************************************************!*\
  !*** ./src/universal/components/TaggableListWrapper.tsx ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var polished__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! polished */ "./node_modules/polished/dist/polished.esm.js");
/* harmony import */ var universal_components_Icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/components/Icon */ "./src/universal/components/Icon.tsx");
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var universal_utils_getColor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/utils/getColor */ "./src/universal/utils/getColor.ts");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/TaggableListWrapper.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}







const ListWrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1fn2uox0"
})({
  name: "2apgry",
  styles: "width:195px;min-width:195px;user-select:none;"
});

const List = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1fn2uox1"
})({
  name: "u70tf2",
  styles: "cursor:auto;"
});

const ListLabel = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1fn2uox2"
})({
  name: "1ut2p5e",
  styles: "font-weight:400;margin-top:20px;"
});

const CategoryButton = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "e1fn2uox3"
})(({
  active
}) => ({
  cursor: 'pointer',
  background: 'white',
  clear: 'both',
  width: '100%',
  marginBottom: '5px',
  padding: '10px 10px',
  textAlign: 'left',
  border: active ? '1px solid #6648EE !important' : '1px solid #E8ECEE',
  borderRadius: '4px',
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  ':hover': {
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.024)'
  }
}));

const EntityText = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "e1fn2uox4"
})({
  name: "qv8mh2",
  styles: "background:white;clear:both;width:100%;marginbottom:5px;padding:10px 10px;position:relative;textalign:left;border:1px solid white;boxshadow:0px 2px 4px rgba(0,0,0,0.024);borderradius:4px;display:flex;flexdirection:row;alignitems:center;cursor:default;&::selection{background:transparent;}&:hover{border:1px solid #e8ecee !important;border-radius:4px;i{display:block !important;opacity:0.6 !important;}}i{cursor:pointer;}"
});

const ColorArtifact = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("span", {
  target: "e1fn2uox5"
})(({
  color
}) => ({
  background: color,
  display: 'inline-block',
  width: '20px',
  height: '20px',
  marginRight: '10px',
  border: `1px solid ${Object(polished__WEBPACK_IMPORTED_MODULE_2__["darken"])(0.3, color)}`
}));

const TaggableListWrapper = props => {
  const {
    options,
    text,
    selectedCategory,
    onSelect,
    disabled,
    objects,
    onHover,
    onClick
  } = props;

  const getOptionIndex = id => {
    let index;
    options.map((option, i) => {
      if (option.id === id) {
        index = i;
      }
    });
    return index;
  };

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ListWrapper, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 106
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(List, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 107
    }
  }, options.map((option, optionIndex) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(CategoryButton, {
    key: optionIndex,
    onClick: () => {
      if (!disabled) {
        onSelect({
          tag: option.id,
          color: Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_5__["colorByIndex"])(optionIndex)
        });
      }
    },
    type: "button",
    active: !disabled && selectedCategory.tag === option.id,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 109
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ColorArtifact, {
    color: Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_5__["colorByIndex"])(optionIndex),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 119
    }
  }), option.name))), Array.isArray(text) && text.length > 0 && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(List, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 126
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ListLabel, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 127
    }
  }, "Entities"), text.map((item, key) => {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(EntityText, {
      key: key,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 130
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ColorArtifact, {
      key: key,
      color: item.color,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 131
      }
    }), item.text);
  })), Array.isArray(objects) && objects.length > 0 && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(List, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 140
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ListLabel, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 141
    }
  }, "Objects"), objects.map((item, key) => {
    const name = _optionalChain([options, 'access', _ => _.find, 'call', _2 => _2(opt => opt.id === item.category), 'optionalAccess', _3 => _3.name]);

    if (!name) return null;
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(EntityText, {
      key: key,
      onMouseEnter: () => {
        onHover(key);
      },
      onMouseLeave: () => {
        onHover(null);
      },
      onClick: e => {
        e.stopPropagation();
      },
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 146
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ColorArtifact, {
      key: key,
      color: Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_5__["colorByIndex"])(getOptionIndex(item.category)),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 158
      }
    }), name, !disabled && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_Icon__WEBPACK_IMPORTED_MODULE_3__["default"], {
      style: {
        fontSize: 18,
        position: 'absolute',
        right: '5px',
        top: '11px',
        display: 'none',
        color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_4__["PALETTE"].TEXT_MAIN
      },
      onClick: () => {
        onClick(key);
      },
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 162
      }
    }, "close"));
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (TaggableListWrapper);

/***/ }),

/***/ "./src/universal/components/TextSequence.tsx":
/*!***************************************************!*\
  !*** ./src/universal/components/TextSequence.tsx ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-dom */ "./node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-beautiful-dnd */ "./node_modules/react-beautiful-dnd/dist/react-beautiful-dnd.esm.js");
/* harmony import */ var client_components_TextArea__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! client/components/TextArea */ "./src/client/components/TextArea.tsx");
/* harmony import */ var universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/components/SecondaryButton */ "./src/universal/components/SecondaryButton.tsx");
/* harmony import */ var client_components_RootButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! client/components/RootButton */ "./src/client/components/RootButton.tsx");
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var universal_components_Icon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! universal/components/Icon */ "./src/universal/components/Icon.tsx");
/* harmony import */ var universal_utils_getItemStyle__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! universal/utils/getItemStyle */ "./src/universal/utils/getItemStyle.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/TextSequence.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}











const portal = document.createElement('div');

if (!document.body) {
  throw new Error('body not ready for portal creation!');
}

document.body.appendChild(portal);

const IconButton = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(client_components_RootButton__WEBPACK_IMPORTED_MODULE_7__["default"], {
  target: "e14q0dhs0"
})({
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_8__["PALETTE"].PRIMARY_MAIN
});

const FieldWrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14q0dhs1"
})({
  name: "139y8lg",
  styles: "display:grid;margin-bottom:2.5px;margin-top:2.5px;align-items:center;"
});

const ContentWrapper = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(FieldWrapper, {
  target: "e14q0dhs2"
})("grid-template-columns:1fr;", ({
  isTask,
  orderingDisabled,
  deleteDisabled
}) => isTask && !orderingDisabled && !deleteDisabled ? `
    grid-template-columns: auto 1fr auto;
    grid-gap: 10px;
    &.focused {
      grid-template-columns: auto 1fr auto;
      grid-gap: 10px;
    }
    &:hover {
      grid-template-columns: auto 1fr auto;
      grid-gap: 10px;
    }
` : ``, " ", ({
  isEditing
}) => isEditing ? `
  &.focused {
    grid-template-columns: 1fr auto;
  }
  &:hover {
    grid-template-columns: 1fr auto;
  }
` : ``, " ", ({
  isTask,
  orderingDisabled,
  deleteDisabled
}) => isTask && orderingDisabled && !deleteDisabled ? `
    grid-template-columns: 1fr auto;
    grid-gap: 10px;
  ` : ``, " ", ({
  isTask,
  deleteDisabled,
  orderingDisabled
}) => isTask && deleteDisabled && !orderingDisabled ? `
  grid-template-columns: auto 1fr;
  grid-gap: 10px;
` : ``, " ", ({
  isAudits
}) => isAudits ? `
    grid-template-columns: 1fr;
  ` : ``);

const ContentBlock = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14q0dhs3"
})({
  name: "1hb0vzk",
  styles: "padding:5px 0;display:flex;flex-direction:column;"
});

const InputWrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e14q0dhs4"
})(({
  isTask,
  orderingDisabled,
  deleteDisabled
}) => isTask && !orderingDisabled && !deleteDisabled ? `
      margin: 0px;
      ` : ``, " ", ({
  isTask,
  deleteDisabled,
  orderingDisabled
}) => isTask && deleteDisabled && orderingDisabled ? `
      margin: 0px;
      ` : ``, " ", ({
  isEditing,
  deleteDisabled
}) => isEditing && !deleteDisabled ? `
      margin-right: 25px;
      ${ContentWrapper}:hover & {
        margin-right: 10px;
      }
      &.focused {
        margin-right: 10px;
      }
      ` : ``);

const StyledIcon = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_Icon__WEBPACK_IMPORTED_MODULE_9__["default"], {
  target: "e14q0dhs5"
})(({
  isTask,
  orderingDisabled
}) => isTask && !orderingDisabled ? `
    visibility: hidden;
    &.focused {
      visibility: visible;
    }
    ${ContentWrapper}:hover & {
      visibility: visible;
    }
  ` : ``, " ", ({
  isTask,
  orderingDisabled
}) => isTask && orderingDisabled ? `
    display: none;
  ` : ``, " ", ({
  isEditing
}) => isEditing ? `
      display: none;
      &.focused {
        display: block;
      }

      ${ContentWrapper}:hover & {
        display: block;
      }
    ` : ``);

const BlockInput = ({
  provided,
  snapshot,
  seqIdx,
  data,
  index,
  type,
  setFieldValue,
  targetName,
  placeholder,
  isAudits,
  arrayHelpers,
  isEditing,
  settings
}) => {
  const setFocusStyles = (elements, action) => {
    elements.forEach(id => {
      const element = document.getElementById(id);

      _optionalChain([element, 'optionalAccess', _2 => _2.classList, 'access', _3 => _3[action], 'call', _4 => _4('focused')]);
    });
  };

  const isTask = !isEditing && !isAudits;
  const showDelete = isAudits ? false : !settings.deleteDisabled;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ContentBlock, _objectSpread(_objectSpread({}, provided.draggableProps), {}, {
    ref: provided.innerRef,
    style: Object(universal_utils_getItemStyle__WEBPACK_IMPORTED_MODULE_10__["default"])(snapshot.isDragging, provided.draggableProps.style),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 201
    }
  }), data.length > 0 && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ContentWrapper, {
    id: `content-wrapper-${seqIdx}`,
    isAudits: isAudits,
    isEditing: isEditing,
    isTask: isTask,
    orderingDisabled: settings.orderingDisabled,
    deleteDisabled: settings.deleteDisabled,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 207
    }
  }, isTask && !settings.orderingDisabled ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, _objectSpread(_objectSpread({}, provided.dragHandleProps), {}, {
    isAudits: isAudits,
    isEditing: isEditing,
    isTask: isTask,
    id: `drag-icon-${seqIdx}`,
    orderingDisabled: settings.orderingDisabled,
    style: {
      fontSize: 15,
      color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_8__["PALETTE"].TEXT_MAIN
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 216
    }
  }), "drag_indicator") : '', /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(InputWrapper, {
    id: `input-wrapper-${seqIdx}`,
    isAudits: isAudits,
    isEditing: isEditing,
    isTask: isTask,
    orderingDisabled: settings.orderingDisabled,
    deleteDisabled: settings.deleteDisabled,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 231
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_TextArea__WEBPACK_IMPORTED_MODULE_5__["default"], {
    name: `data[${index}][${type}].value[${seqIdx}]`,
    cacheMeasurements: true,
    type: "text",
    onFocus: () => setFocusStyles([`content-wrapper-${seqIdx}`, `drag-icon-${seqIdx}`, `close-icon-${seqIdx}`, `input-wrapper-${seqIdx}`], 'add'),
    onBlur: () => setFocusStyles([`content-wrapper-${seqIdx}`, `drag-icon-${seqIdx}`, `close-icon-${seqIdx}`, `input-wrapper-${seqIdx}`], 'remove'),
    onKeyDown: e => {
      if (e.keyCode === 13) {
        e.preventDefault();
      }
    },
    onChange: e => {
      const {
        value
      } = e.target;
      setFieldValue(`${targetName}[${seqIdx}]`, value);
    },
    value: data[seqIdx],
    placeholder: _optionalChain([placeholder, 'optionalAccess', _5 => _5[seqIdx]]) || 'Text',
    readOnly: isAudits,
    disabled: settings.editDisabled,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 239
    }
  })), showDelete && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(IconButton, {
    type: "button",
    disabled: isAudits,
    onClick: () => arrayHelpers.remove(seqIdx),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 281
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledIcon, {
    isAudits: isAudits,
    isEditing: isEditing,
    deleteDisabled: settings.deleteDisabled,
    id: `close-icon-${seqIdx}`,
    style: {
      fontSize: 15,
      color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_8__["PALETTE"].TEXT_MAIN
    },
    isTask: isTask,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 286
    }
  }, "close"))));
};

const TextSequence = props => {
  const {
    name,
    data,
    index,
    isEditing,
    type,
    isAudits,
    targetName,
    setFieldValue,
    placeholder,
    settings
  } = props;
  const onDragEnd = Object(react__WEBPACK_IMPORTED_MODULE_1__["useCallback"])(result => {
    const {
      destination,
      source,
      draggableId
    } = result;

    if (!destination || destination.droppableId === source.droppableId && destination.index === source.index) {
      return;
    }

    const changedItem = data[draggableId];
    const newList = data;
    newList.splice(source.index, 1);
    newList.splice(destination.index, 0, changedItem);
    setFieldValue(`data[${index}][${type}].value`, newList);
  }, [data, index]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(formik__WEBPACK_IMPORTED_MODULE_3__["FieldArray"], {
    name: name,
    render: arrayHelpers => {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_4__["DragDropContext"], {
        onDragEnd: onDragEnd,
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 342
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_4__["Droppable"], {
        droppableId: "dropable-list",
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 343
        }
      }, provided => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('div', _objectSpread(_objectSpread({}, provided.droppableProps), {}, {
        ref: provided.innerRef,
        style: {
          width: '100%'
        },
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 345
        }
      }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FieldWrapper, {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 346
        }
      }, Array.isArray(data) && data.map((_, seqIdx) => {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_4__["Draggable"], {
          key: seqIdx,
          draggableId: String(seqIdx),
          isDragDisabled: isEditing || isAudits || settings.orderingDisabled,
          index: seqIdx,
          __self: undefined,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 350
          }
        }, (provided, snapshot) => {
          const usePortal = snapshot.isDragging;
          const child = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(BlockInput, {
            provided: provided,
            snapshot: snapshot,
            seqIdx: seqIdx,
            data: data,
            index: index,
            type: type,
            setFieldValue: setFieldValue,
            targetName: targetName,
            placeholder: placeholder,
            isAudits: isAudits,
            arrayHelpers: arrayHelpers,
            isEditing: isEditing,
            settings: settings,
            __self: undefined,
            __source: {
              fileName: _jsxFileName,
              lineNumber: 359
            }
          });

          if (!usePortal) {
            return child;
          }

          return /*#__PURE__*/react_dom__WEBPACK_IMPORTED_MODULE_2___default.a.createPortal(child, portal);
        });
      })), provided.placeholder, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ContentBlock, {
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 386
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_6__["default"], {
        type: "button",
        disabled: isAudits || settings.editDisabled,
        onClick: () => {
          arrayHelpers.push('');
        },
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 387
        }
      }, "Add Item")))));
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 338
    }
  });
};

TextSequence.defaultProps = {
  settings: {
    deleteDisabled: false,
    editDisabled: false,
    orderingDisabled: false
  }
};
/* harmony default export */ __webpack_exports__["default"] = (TextSequence);

/***/ }),

/***/ "./src/universal/components/bbox-annotator/BBoxAnnotator.tsx":
/*!*******************************************************************!*\
  !*** ./src/universal/components/bbox-annotator/BBoxAnnotator.tsx ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _BBoxSelector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./BBoxSelector */ "./src/universal/components/bbox-annotator/BBoxSelector.tsx");
/* harmony import */ var universal_utils_getColor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/utils/getColor */ "./src/universal/utils/getColor.ts");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/bbox-annotator/BBoxAnnotator.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}






const BBoxAnnotator = ({
  url,
  borderWidth = 2,
  selectedLabel,
  onChange,
  objects,
  disabled,
  highlightIndex
}) => {
  const [pointer, setPointer] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  const [offset, setOffset] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  const [entries, setEntries] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(objects);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    onChange(entries.map(entry => ({
      w: +parseFloat(entry.w).toFixed(2),
      h: +parseFloat(entry.h).toFixed(2),
      y: +parseFloat(entry.y).toFixed(2),
      x: +parseFloat(entry.x).toFixed(2),
      category: entry.category,
      color: entry.color
    })));
  }, [entries]);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    if (Array.isArray(objects) && Array.isArray(entries) && !lodash__WEBPACK_IMPORTED_MODULE_3___default.a.isEqual(objects.sort(), entries.sort())) {
      setEntries(objects);
    }
  }, [objects]);
  const [status, setStatus] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])('free');
  const [imageFrameStyle, setImageFrameStyle] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({});
  const bBoxImageRef = Object(react__WEBPACK_IMPORTED_MODULE_0__["useRef"])(null);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    const imageElement = new Image();
    imageElement.src = url;

    imageElement.onload = () => {
      const width = imageElement.width;
      const height = imageElement.height;
      setImageFrameStyle({
        backgroundImageSrc: imageElement.src,
        width: width,
        height: height
      });
    };
  }, [bBoxImageRef, url]);

  const crop = (pageX, pageY) => {
    const x = bBoxImageRef.current && imageFrameStyle.width ? Math.min(Math.max(Math.round(pageX - bBoxImageRef.current.getBoundingClientRect().x), 0), _optionalChain([bBoxImageRef, 'access', _2 => _2.current, 'optionalAccess', _3 => _3.offsetWidth])) / _optionalChain([bBoxImageRef, 'access', _4 => _4.current, 'optionalAccess', _5 => _5.offsetWidth]) * 100 : 0;
    const y = bBoxImageRef.current && imageFrameStyle.height ? Math.min(Math.max(Math.round(pageY - bBoxImageRef.current.getBoundingClientRect().y), 0), _optionalChain([bBoxImageRef, 'access', _6 => _6.current, 'optionalAccess', _7 => _7.offsetHeight])) / _optionalChain([bBoxImageRef, 'access', _8 => _8.current, 'optionalAccess', _9 => _9.offsetHeight]) * 100 : 0;
    return {
      x,
      y
    };
  };

  const updateRectangle = (pageX, pageY) => {
    setPointer(crop(pageX, pageY));
  };

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    if (!disabled) {
      const mouseMoveHandler = e => {
        e.preventDefault();

        if (status === 'moved') {
          updateRectangle(e.pageX, e.pageY);
        }
      };

      _optionalChain([bBoxImageRef, 'access', _10 => _10.current, 'optionalAccess', _11 => _11.addEventListener, 'call', _12 => _12('mousemove', mouseMoveHandler)]);

      return () => _optionalChain([bBoxImageRef, 'access', _13 => _13.current, 'optionalAccess', _14 => _14.removeEventListener, 'call', _15 => _15('mousemove', mouseMoveHandler)]);
    }
  }, [status]);

  const mouseDownHandler = e => {
    e.stopPropagation();

    if (e.button !== 2 && !disabled) {
      setOffset(crop(e.pageX, e.pageY));
      setPointer(crop(e.pageX, e.pageY));
      setStatus('hold');
    }
  };

  const mouseMoveHandler = e => {
    e.stopPropagation();
    const currentPointer = crop(e.pageX, e.pageY);
    setPointer(currentPointer);

    const hasMoved = currentPointer.x !== _optionalChain([offset, 'optionalAccess', _16 => _16.x]) && currentPointer.y !== _optionalChain([offset, 'optionalAccess', _17 => _17.y]);

    if (status === 'hold' && hasMoved) {
      setStatus('moved');
    }
  };

  const rectangle = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => {
    const x1 = offset && pointer ? Math.min(offset.x, pointer.x) : 0;
    const x2 = offset && pointer ? Math.max(offset.x, pointer.x) : 0;
    const y1 = offset && pointer ? Math.min(offset.y, pointer.y) : 0;
    const y2 = offset && pointer ? Math.max(offset.y, pointer.y) : 0;
    return {
      x: x1,
      y: y1,
      w: x2 - x1,
      h: y2 - y1
    };
  }, [pointer, offset]);
  const rect = rectangle();
  const boxRef = Object(react__WEBPACK_IMPORTED_MODULE_0__["useRef"])();
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    if (!disabled) {
      const mouseUpHandler = e => {
        e.preventDefault();
        e.stopPropagation();

        if (status === 'moved') {
          updateRectangle(e.pageX, e.pageY);
          setEntries([...entries, _objectSpread(_objectSpread({}, rect), {}, {
            category: selectedLabel.tag,
            color: selectedLabel.color
          })]);
        }

        setStatus('free');
      };

      _optionalChain([boxRef, 'optionalAccess', _18 => _18.current, 'optionalAccess', _19 => _19.addEventListener, 'call', _20 => _20('mouseup', mouseUpHandler)]);

      return () => _optionalChain([boxRef, 'optionalAccess', _21 => _21.current, 'optionalAccess', _22 => _22.removeEventListener, 'call', _23 => _23('mouseup', mouseUpHandler)]);
    }
  }, [boxRef, status, rect]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
    onMouseDownCapture: mouseDownHandler,
    onMouseMoveCapture: mouseMoveHandler,
    draggable: false,
    ref: boxRef,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 178
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
    draggable: false,
    style: {
      width: `100%`,
      position: 'relative',
      float: `left`,
      cursor: !disabled ? 'crosshair' : 'auto'
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 184
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('img', {
    draggable: false,
    style: {
      maxWidth: `100%`,
      maxHeight: `100%`,
      float: `left`
    },
    ref: bBoxImageRef,
    src: imageFrameStyle.backgroundImageSrc,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 193
    }
  }), status === 'moved' ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_BBoxSelector__WEBPACK_IMPORTED_MODULE_1__["default"], {
    rectangle: rect,
    color: selectedLabel.color,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 203
    }
  }) : null, entries.map((entry, i) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
    draggable: false,
    style: {
      border: `${borderWidth}px solid ${entry.color || Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_2__["colorByIndex"])(i)}`,
      position: 'absolute',
      top: `${entry.y}%`,
      left: `${entry.x}%`,
      width: `${entry.w}%`,
      height: `${entry.h}%`,
      pointerEvents: 'none'
    },
    key: i,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 205
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
    draggable: false,
    style: {
      width: `100%`,
      height: `100%`,
      background: `${entry.color || Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_2__["colorByIndex"])(i)}`,
      opacity: highlightIndex === i ? `0.5` : `0.2`
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 218
    }
  })))));
};

/* harmony default export */ __webpack_exports__["default"] = (BBoxAnnotator);

/***/ }),

/***/ "./src/universal/components/bbox-annotator/BBoxSelector.tsx":
/*!******************************************************************!*\
  !*** ./src/universal/components/bbox-annotator/BBoxSelector.tsx ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/bbox-annotator/BBoxSelector.tsx";


const BBoxSelector = ({
  rectangle,
  borderWidth = 2,
  color
}) => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
    draggable: false,
    style: {
      left: `${rectangle.x}%`,
      top: `${rectangle.y}%`,
      width: `${rectangle.w}%`,
      height: `${rectangle.h}%`,
      border: `${borderWidth || 2}px solid ${color}`,
      borderWidth: `${borderWidth || 2}px`,
      position: 'absolute',
      pointerEvents: 'none'
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
    draggable: false,
    style: {
      width: `100%`,
      height: `100%`,
      background: `${color}`,
      opacity: `0.2`
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    }
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (BBoxSelector);

/***/ }),

/***/ "./src/universal/components/blocks/Binary.tsx":
/*!****************************************************!*\
  !*** ./src/universal/components/blocks/Binary.tsx ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_components_TaskRadio__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/TaskRadio */ "./src/universal/components/TaskRadio.tsx");
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/Binary.tsx";









const Block = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "etqvrm70"
})({
  name: "1r2f04i",
  styles: "margin-bottom:10px;"
});

const Binary = props => {
  const {
    isAudits,
    block,
    onEdit,
    onDelete,
    isEditing,
    setFieldValue,
    index
  } = props || {};
  const {
    binary,
    name,
    id,
    _id
  } = block;
  const {
    value
  } = binary || {};
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_7__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_6__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_3__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_8__["BLOCK_TYPE"].BINARY,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Block, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TaskRadio__WEBPACK_IMPORTED_MODULE_2__["default"], {
    autoFocus: false,
    name: `data.${index}.binary.value`,
    id: `${_id}-true`,
    value: "true",
    label: "Yes",
    onChange: () => setFieldValue(`data.${index}.binary.value`, true),
    checked: value === true,
    disabled: isAudits,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Block, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TaskRadio__WEBPACK_IMPORTED_MODULE_2__["default"], {
    autoFocus: false,
    name: `data.${index}.binary.value`,
    id: `${_id}-false`,
    value: "false",
    label: "No",
    onChange: () => setFieldValue(`data.${index}.binary.value`, false),
    checked: value === false,
    disabled: isAudits,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    }
  }))));
};

/* harmony default export */ __webpack_exports__["default"] = (Binary);

/***/ }),

/***/ "./src/universal/components/blocks/BoundingBoxes.tsx":
/*!***********************************************************!*\
  !*** ./src/universal/components/blocks/BoundingBoxes.tsx ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var universal_components_TaggableListWrapper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/components/TaggableListWrapper */ "./src/universal/components/TaggableListWrapper.tsx");
/* harmony import */ var _bbox_annotator_BBoxAnnotator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../bbox-annotator/BBoxAnnotator */ "./src/universal/components/bbox-annotator/BBoxAnnotator.tsx");
/* harmony import */ var universal_utils_getColor__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! universal/utils/getColor */ "./src/universal/utils/getColor.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/BoundingBoxes.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}












const ImageWrapper = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])('div', {
  target: "es0uq7l0"
})({
  name: "1w4x1lc",
  styles: "flex-grow:1;margin-right:10px;margin-bottom:10px;overflow:hidden;position:relative;width:100%;"
});

const BoundingBoxes = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.memo(props => {
  const {
    block,
    onDelete,
    onEdit,
    isEditing,
    setFieldValue,
    index,
    isAudits
  } = props;
  const {
    name
  } = block;
  const {
    placeholder,
    options,
    value
  } = block[universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__["BLOCK_TYPE"].BOUNDING_BOXES] || {};
  const [objects, setObjects] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(_optionalChain([value, 'optionalAccess', _2 => _2.objects]) || []);
  const [highlightIndex, setHighlightIndex] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const renderValue = isEditing || value.image === '' ? placeholder || '' : value.image;
  const [selectedLabel, setSelectedLabel] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({
    tag: options[0].id,
    color: Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_10__["colorByIndex"])(0)
  });
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    setObjects(_optionalChain([value, 'optionalAccess', _3 => _3.objects]));
  }, [block[universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__["BLOCK_TYPE"].BOUNDING_BOXES]]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    setFieldValue(`data[${index}][${universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__["BLOCK_TYPE"].BOUNDING_BOXES}].value.objects`, isEditing ? [] : _optionalChain([value, 'optionalAccess', _4 => _4.objects]));
    setObjects(isEditing ? [] : _optionalChain([value, 'optionalAccess', _5 => _5.objects]));
  }, [placeholder, options]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    let selectedIndex = 0;
    options.forEach((option, idx) => {
      if (option.id === selectedLabel.tag) {
        selectedIndex = idx;
      }
    });
    setSelectedLabel({
      tag: options[selectedIndex].id,
      color: Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_10__["colorByIndex"])(selectedIndex)
    });
  }, [options]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_3__["default"], _objectSpread(_objectSpread({}, props), {}, {
    style: {
      display: 'block',
      maxWidth: '100%',
      minWidth: '100%'
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 75
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 76
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 77
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__["BLOCK_TYPE"].BOUNDING_BOXES,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 78
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_7__["default"], {
    row: true,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 85
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ImageWrapper, {
    onMouseDown: e => {
      e.stopPropagation();
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 86
    }
  }, renderValue && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_bbox_annotator_BBoxAnnotator__WEBPACK_IMPORTED_MODULE_9__["default"], {
    url: renderValue,
    selectedLabel: selectedLabel,
    objects: objects,
    highlightIndex: highlightIndex,
    disabled: isAudits,
    onChange: e => {
      setObjects(e);
      setFieldValue(`data[${index}][${universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__["BLOCK_TYPE"].BOUNDING_BOXES}].value.objects`, e);
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 92
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TaggableListWrapper__WEBPACK_IMPORTED_MODULE_8__["default"], {
    options: options,
    objects: objects,
    disabled: isAudits,
    onSelect: label => {
      setSelectedLabel(label);
    },
    onHover: index => {
      setHighlightIndex(index);
    },
    onClick: index => {
      setObjects(objects.filter((_, i) => i !== index));
    },
    selectedCategory: selectedLabel,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 105
    }
  })));
});
/* harmony default export */ __webpack_exports__["default"] = (BoundingBoxes);

/***/ }),

/***/ "./src/universal/components/blocks/Content.tsx":
/*!*****************************************************!*\
  !*** ./src/universal/components/blocks/Content.tsx ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ContentWrapper; });
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var universal_components_Icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/components/Icon */ "./src/universal/components/Icon.tsx");

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/Content.tsx";




const Content = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1eg38ed0"
})("height:100%;padding:10px;display:flex;flex-direction:column;z-index:1;overflow:", ({
  overflow
}) => overflow ? overflow : 'auto', ";&:hover ", _components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__["Container"], "{visibility:visible;opacity:1;}");

const ContentContainer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1eg38ed1"
})({
  name: "1g4yje1",
  styles: "display:flex;flex-direction:column;height:100%;"
});

const DragHandle = /*#__PURE__*/Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(universal_components_Icon__WEBPACK_IMPORTED_MODULE_3__["default"], {
  target: "e1eg38ed2"
})("height:30px;width:30px;position:fixed;left:50%;z-index:10;top:-15px;cursor:", ({
  isEditing
}) => isEditing ? 'grab' : 'inherit', ";display:none !important;display:", ({
  isEditing
}) => isEditing ? 'block' : 'none', ";", ContentContainer, ":hover &{display:", ({
  isEditing
}) => isEditing ? 'block' : 'none', " !important;}&.dragging{cursor:grabbing;}");

function ContentWrapper({
  children,
  isEditing,
  overflow
}) {
  const addDraggingStyles = e => {
    e.target.classList.add('dragging');
  };

  const removeDraggingStyles = e => {
    e.target.classList.remove('dragging');
  };

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ContentContainer, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 56
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(DragHandle, {
    className: "drag-handle",
    isEditing: isEditing,
    style: {
      fontSize: 18,
      color: '#686869'
    },
    onMouseOut: removeDraggingStyles,
    onMouseDown: addDraggingStyles,
    onMouseUp: removeDraggingStyles,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    }
  }, "drag_handle"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Content, {
    isEditing: isEditing,
    overflow: overflow,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 70
    }
  }, children));
}

/***/ }),

/***/ "./src/universal/components/blocks/Date.tsx":
/*!**************************************************!*\
  !*** ./src/universal/components/blocks/Date.tsx ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var universal_components_DatePicker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! universal/components/DatePicker */ "./src/universal/components/DatePicker.tsx");
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var client_utils_dateHelpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! client/utils/dateHelpers */ "./src/client/utils/dateHelpers.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/Date.tsx";










const DateBlock = props => {
  const {
    isAudits,
    block,
    onEdit,
    onDelete,
    setFieldValue,
    isEditing,
    index
  } = props;
  const {
    date,
    name
  } = block;
  const {
    placeholder,
    read_only: readOnly,
    value = ''
  } = date || {};
  const renderValue = isEditing ? value || placeholder : value;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_5__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__["BLOCK_TYPE"].DATE,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }, readOnly || isAudits ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    }
  }, Object(client_utils_dateHelpers__WEBPACK_IMPORTED_MODULE_8__["getDisplayFormat"])(renderValue)) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_DatePicker__WEBPACK_IMPORTED_MODULE_1__["default"], {
    name: `data.${index}.date.value`,
    value: renderValue,
    readOnly: readOnly || isAudits,
    placeholder: placeholder,
    setFieldValue: setFieldValue,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    }
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (DateBlock);

/***/ }),

/***/ "./src/universal/components/blocks/Email.tsx":
/*!***************************************************!*\
  !*** ./src/universal/components/blocks/Email.tsx ***!
  \***************************************************/
/*! exports provided: StyledLink, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StyledLink", function() { return StyledLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Email; });
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var universal_components_InputField__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/components/InputField */ "./src/universal/components/InputField.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/Email.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}










const StyledLink = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("a", {
  target: "e16yuwdr0"
})({
  fontSize: 16,
  lineHeight: 1.5,
  fontWeight: 400,
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_7__["PALETTE"].LINK,
  whiteSpace: 'pre-wrap',
  wordWrap: 'break-word',
  wordBreak: 'break-word'
});
function Email(props) {
  const {
    isAudits,
    block,
    onEdit,
    onDelete,
    isEditing,
    index,
    error,
    handleBlur,
    handleChange
  } = props;
  const {
    email,
    name
  } = block;
  const {
    placeholder,
    read_only: readOnly,
    value = ''
  } = email || {};
  const renderValue = isEditing ? placeholder : value;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_6__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_9__["BLOCK_TYPE"].EMAIL,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    }
  }, !readOnly && !isAudits ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_InputField__WEBPACK_IMPORTED_MODULE_8__["default"], {
    type: "email",
    name: `data.${index}.email.value`,
    value: renderValue || "",
    hideErrorMessage: true,
    error: _optionalChain([error, 'optionalAccess', _ => _.value]),
    autoFocus: false,
    onChange: handleChange,
    onBlur: handleBlur,
    readOnly: readOnly,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    }
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledLink, {
    href: `mailto:${renderValue}`,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 76
    }
  }, renderValue)));
}

/***/ }),

/***/ "./src/universal/components/blocks/Embed.tsx":
/*!***************************************************!*\
  !*** ./src/universal/components/blocks/Embed.tsx ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/Embed.tsx";








const IFrame = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("iframe", {
  target: "eevjo720"
})({
  name: "np0iat",
  styles: "width:100%;height:100%;border:0;"
});

const Embed = props => {
  const {
    block,
    onEdit,
    onDelete,
    isEditing,
    error,
    index
  } = props || {};
  const {
    embed,
    name
  } = block;
  const {
    value,
    placeholder
  } = embed || {};
  let sourceUrl = isEditing ? placeholder : value;

  if (error.data && error.data[index] && error.data.length) {
    sourceUrl = '';
  }

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_5__["default"], _objectSpread(_objectSpread({}, props), {}, {
    overflow: `hidden`,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__["BLOCK_TYPE"].EMBED,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(IFrame, {
    src: sourceUrl,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    }
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (Embed);

/***/ }),

/***/ "./src/universal/components/blocks/FormSequence.tsx":
/*!**********************************************************!*\
  !*** ./src/universal/components/blocks/FormSequence.tsx ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var universal_components_BasicTextArea__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! universal/components/BasicTextArea */ "./src/universal/components/BasicTextArea.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var universal_components_PrimaryButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/components/PrimaryButton */ "./src/universal/components/PrimaryButton.tsx");
/* harmony import */ var universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! universal/components/SecondaryButton */ "./src/universal/components/SecondaryButton.tsx");
/* harmony import */ var universal_components_InputField__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/components/InputField */ "./src/universal/components/InputField.tsx");
/* harmony import */ var universal_components_TaskRadio__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! universal/components/TaskRadio */ "./src/universal/components/TaskRadio.tsx");
/* harmony import */ var universal_components_TaskCheckbox__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! universal/components/TaskCheckbox */ "./src/universal/components/TaskCheckbox.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/FormSequence.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}
















const ButtonBlock = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "emzfyox0"
})({
  name: "1hx5wtv",
  styles: "display:flex;flex-direction:row;justify-content:space-between;margin-bottom:10px;flex:0 0 auto;"
});

const Block = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "emzfyox1"
})({
  name: "o6l5fu",
  styles: "padding:5px 0;"
});

const Wrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "emzfyox2"
})({
  name: "tjjfeh",
  styles: "height:100%;width:100%;display:flex;flex-direction:column;"
});

const Item = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "emzfyox3"
})({
  name: "1rr4qq7",
  styles: "flex:1;"
});

const assignNextAndBackVisibility = (currentIdx, currentType, nextBlockId, nextBlockIndex, value, data) => {
  let isNextDisabled = false;
  let isBackDisabled = false;
  isBackDisabled = currentIdx === 0;

  if (currentIdx === data.length - 1) {
    if (nextBlockIndex === -1) {
      isNextDisabled = true;
    }
  } else {
    if (currentType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCK_TYPE"].SINGLE_SELECTION || currentType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCK_TYPE"].BINARY) {
      if (!value) isNextDisabled = true;
    } else {
      if (value === '' || value === null) {
        isNextDisabled = true;
      } else {
        isNextDisabled = false;
      }
    }
  }

  if (!nextBlockId !== null && nextBlockId !== undefined) {
    isNextDisabled = false;
  } else if (nextBlockId === null) {
    isNextDisabled = true;
  }

  return {
    isNextDisabled,
    isBackDisabled
  };
};

const FormSequence = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["memo"])(props => {
  const [currentIdx, setCurrentIdx] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(0);
  const {
    isAudits,
    block,
    onDelete,
    handleChange,
    index,
    isEditing,
    onEdit,
    setFieldValue
  } = props;
  const {
    name,
    type,
    _id
  } = block || {};
  const {
    data,
    history = []
  } = block[type];
  const currentBlock = data[currentIdx];
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (isAudits) return;

    if (currentBlock && _optionalChain([history, 'optionalAccess', _ => _.length]) > 0) {
      const lastBlockId = history.pop();
      const lastBlockIdx = data.findIndex(({
        id
      }) => id === lastBlockId);
      setCurrentIdx(lastBlockIdx + 1);
    }
  }, []);
  if (!currentBlock) return null;
  const {
    type: currentType,
    name: currentBlockName
  } = currentBlock;
  const {
    value = ''
  } = currentBlock[currentType];
  const nextBlockId = _optionalChain([currentBlock, 'optionalAccess', _2 => _2.logic_jump]) ? currentBlock.logic_jump[value] : undefined;
  const nextBlockIndex = data.findIndex(block => block.id === nextBlockId);
  const logicBlocks = [universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCK_TYPE"].BINARY, universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCK_TYPE"].SINGLE_SELECTION];

  const handleNext = arrayHelpers => {
    if (logicBlocks.includes(currentType)) {
      if (!nextBlockId) {
        arrayHelpers.push(currentBlock.id);
        setCurrentIdx(currentIdx + 1);
      } else {
        if (nextBlockIndex !== -1) {
          arrayHelpers.push(currentBlock.id);
          setCurrentIdx(nextBlockIndex);
        } else {
          console.error('Error: unable to find next block ID');
        }
      }
    } else {
      // pop current index into history
      arrayHelpers.push(currentBlock.id);
      setCurrentIdx(currentIdx + 1);
    }
  };

  const handleBack = () => {
    if (_optionalChain([history, 'optionalAccess', _3 => _3.length]) <= 0) {
      setCurrentIdx(0);
    } else {
      const stackedId = history.pop();
      const nextBlockIndex = data.findIndex(block => block.id === stackedId);

      if (nextBlockIndex !== -1) {
        setCurrentIdx(nextBlockIndex);
      } else {
        setCurrentIdx(0);
      }
    }
  };

  const {
    isNextDisabled,
    isBackDisabled
  } = assignNextAndBackVisibility(currentIdx, currentType, nextBlockId, nextBlockIndex, value, data);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(formik__WEBPACK_IMPORTED_MODULE_2__["FieldArray"], {
    name: `data.${index}.${type}.history`,
    render: arrayHelpers => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_14__["default"], _objectSpread(_objectSpread({}, props), {}, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 165
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Wrapper, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 166
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_12__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 167
      }
    }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_11__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 168
      }
    }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_3__["default"], {
      onDelete: onDelete,
      onEdit: onEdit,
      isEditing: isEditing,
      blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCK_TYPE"].FORM_SEQUENCE,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 169
      }
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_13__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 176
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ButtonBlock, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 177
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_PrimaryButton__WEBPACK_IMPORTED_MODULE_6__["default"], {
      type: "button",
      disabled: isBackDisabled,
      onClick: () => handleBack(arrayHelpers),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 178
      }
    }, "Back"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_7__["default"], {
      type: "button",
      disabled: isNextDisabled,
      onClick: () => handleNext(arrayHelpers),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 185
      }
    }, "Next")), currentBlockName && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_11__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 193
      }
    }, currentBlockName), currentType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCK_TYPE"].TEXT && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BasicTextArea__WEBPACK_IMPORTED_MODULE_4__["default"], {
      name: `data.${index}.${type}.data.${currentIdx}.${currentType}.value`,
      onChange: handleChange,
      autoFocus: false,
      value: value,
      style: {
        flex: 1
      },
      disabled: isAudits,
      key: _optionalChain([currentBlock, 'optionalAccess', _4 => _4.id]),
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 195
      }
    }), currentType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCK_TYPE"].NUMBER && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Item, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 206
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_InputField__WEBPACK_IMPORTED_MODULE_8__["default"], {
      name: `data.${index}.${type}.data.${currentIdx}.${currentType}.value`,
      onChange: handleChange,
      type: "number",
      autoFocus: false,
      value: value,
      disabled: isAudits,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 207
      }
    })), currentType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCK_TYPE"].EMAIL && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Item, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 218
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_InputField__WEBPACK_IMPORTED_MODULE_8__["default"], {
      name: `data.${index}.${type}.data.${currentIdx}.${currentType}.value`,
      onChange: handleChange,
      type: "email",
      autoFocus: false,
      value: value,
      disabled: isAudits,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 219
      }
    })), currentType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCK_TYPE"].LINK && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Item, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 230
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_InputField__WEBPACK_IMPORTED_MODULE_8__["default"], {
      name: `data.${index}.${type}.data.${currentIdx}.${currentType}.value`,
      onChange: handleChange,
      type: "text",
      autoFocus: false,
      value: value,
      disabled: isAudits,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 231
      }
    })), currentType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCK_TYPE"].BINARY && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Item, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 242
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Block, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 243
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TaskRadio__WEBPACK_IMPORTED_MODULE_9__["default"], {
      name: `data.${index}.${type}.data.${currentIdx}.${currentType}.value`,
      id: `${_id}-${currentIdx}-true`,
      value: "true",
      label: "Yes",
      onChange: () => setFieldValue(`data.${index}.${type}.data.${currentIdx}.${currentType}.value`, true),
      checked: value === true,
      disabled: isAudits,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 244
      }
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Block, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 259
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TaskRadio__WEBPACK_IMPORTED_MODULE_9__["default"], {
      name: `data.${index}.${type}.data.${currentIdx}.${currentType}.value`,
      id: `${_id}-${currentIdx}-false`,
      value: "false",
      label: "No",
      onChange: () => setFieldValue(`data.${index}.${type}.data.${currentIdx}.${currentType}.value`, false),
      checked: value === false,
      disabled: isAudits,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 260
      }
    }))), currentType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCK_TYPE"].SINGLE_SELECTION && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Item, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 278
      }
    }, currentBlock[currentType].options.map((option, optionIndex) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Block, {
      key: optionIndex,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 280
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TaskRadio__WEBPACK_IMPORTED_MODULE_9__["default"], {
      name: `data.${index}.${type}.data.${currentIdx}.${currentType}.value`,
      id: `${index}-${optionIndex}`,
      value: option.id,
      label: option.name,
      onChange: handleChange,
      checked: option.id === value,
      disabled: isAudits,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 281
      }
    })))), currentType === universal_utils_constants__WEBPACK_IMPORTED_MODULE_5__["BLOCK_TYPE"].MULTIPLE_SELECTION && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Item, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 295
      }
    }, currentBlock[currentType].options.map((option, optionIndex) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Block, {
      key: optionIndex,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 297
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TaskCheckbox__WEBPACK_IMPORTED_MODULE_10__["default"], {
      name: `data.${index}.${type}.data.${currentIdx}.${currentType}.value`,
      id: `${index}-${optionIndex}`,
      value: option.id,
      label: option.name,
      onChange: handleChange,
      checked: value && value.includes(option.id),
      disabled: isAudits,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 298
      }
    }))))))),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 162
    }
  });
});
/* harmony default export */ __webpack_exports__["default"] = (FormSequence);

/***/ }),

/***/ "./src/universal/components/blocks/HeaderContainer.tsx":
/*!*************************************************************!*\
  !*** ./src/universal/components/blocks/HeaderContainer.tsx ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/HeaderContainer.tsx";


const HeaderContainer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e20h3ap0"
})({
  name: "gum8km",
  styles: "align-items:center;display:flex;flex-direction:row;justify-content:space-between;flex:0 0 auto;height:auto;background:white;z-index:11;position:relative;user-select:none;"
});

/* harmony default export */ __webpack_exports__["default"] = (({
  children
}) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(HeaderContainer, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 21
  }
}, children));

/***/ }),

/***/ "./src/universal/components/blocks/Image.tsx":
/*!***************************************************!*\
  !*** ./src/universal/components/blocks/Image.tsx ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/Image.tsx";








const StyledImg = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("img", {
  target: "e1vflmxe0"
})({
  name: "10tv4cy",
  styles: "object-fit:contain;max-width:100%;max-height:100%;width:auto;height:auto;"
});

const Image = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__["memo"](props => {
  const {
    block,
    onDelete,
    onEdit,
    isEditing
  } = props;
  const {
    name,
    type,
    id,
    image
  } = block;
  const {
    value,
    placeholder
  } = image || {};
  const renderValue = isEditing ? value || placeholder : value;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_Content__WEBPACK_IMPORTED_MODULE_3__["default"], _objectSpread(_objectSpread({}, props), {}, {
    style: {
      display: 'block',
      maxWidth: '100%',
      minWidth: '100%'
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 34
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_HeaderContainer__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_Label__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__["createElement"](universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__["BLOCK_TYPE"].IMAGE,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_BodyContainer__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    }
  }, renderValue && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__["createElement"](StyledImg, {
    src: renderValue,
    alt: name || type,
    title: name || type,
    onDragStart: e => e.preventDefault(),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    }
  })));
});
/* harmony default export */ __webpack_exports__["default"] = (Image);

/***/ }),

/***/ "./src/universal/components/blocks/Label.tsx":
/*!***************************************************!*\
  !*** ./src/universal/components/blocks/Label.tsx ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");


const Label = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e13k15rh0"
})({
  name: "18ugfwx",
  styles: "font-weight:500;font-size:15px;"
});

/* harmony default export */ __webpack_exports__["default"] = (Label);

/***/ }),

/***/ "./src/universal/components/blocks/Link.tsx":
/*!**************************************************!*\
  !*** ./src/universal/components/blocks/Link.tsx ***!
  \**************************************************/
/*! exports provided: StyledLink, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StyledLink", function() { return StyledLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Link; });
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var universal_components_InputField__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/components/InputField */ "./src/universal/components/InputField.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/Link.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}










const StyledLink = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("a", {
  target: "e1fp8dlm0"
})({
  fontSize: 16,
  lineHeight: 1.5,
  fontWeight: 400,
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_7__["PALETTE"].LINK,
  whiteSpace: 'pre-wrap',
  wordWrap: 'break-word',
  wordBreak: 'break-word'
});
function Link(props) {
  const {
    isAudits,
    block,
    onEdit,
    onDelete,
    isEditing,
    index,
    error,
    handleBlur,
    handleChange
  } = props;
  const {
    link,
    name
  } = block;
  const {
    placeholder,
    read_only: readOnly,
    value = ''
  } = link || {};
  const renderValue = isEditing ? placeholder : value;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_6__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_9__["BLOCK_TYPE"].LINK,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    }
  }, !readOnly && !isAudits ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_InputField__WEBPACK_IMPORTED_MODULE_8__["default"], {
    type: "text",
    name: `data.${index}.link.value`,
    value: renderValue || "",
    hideErrorMessage: true,
    error: _optionalChain([error, 'optionalAccess', _ => _.value]),
    autoFocus: false,
    onChange: handleChange,
    onBlur: handleBlur,
    readOnly: readOnly,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    }
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledLink, {
    href: `${renderValue}`,
    target: "_blank",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 76
    }
  }, renderValue)));
}

/***/ }),

/***/ "./src/universal/components/blocks/MediaBlock.tsx":
/*!********************************************************!*\
  !*** ./src/universal/components/blocks/MediaBlock.tsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_hooks_usePrevious__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/hooks/usePrevious */ "./src/universal/hooks/usePrevious.ts");
/* harmony import */ var _BlockHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var plyr__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! plyr */ "./node_modules/plyr/dist/plyr.min.js");
/* harmony import */ var plyr__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(plyr__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var plyr_dist_plyr_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! plyr/dist/plyr.css */ "./node_modules/plyr/dist/plyr.css");
/* harmony import */ var plyr_dist_plyr_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(plyr_dist_plyr_css__WEBPACK_IMPORTED_MODULE_9__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/MediaBlock.tsx";









const options = {
  controls: ['play', 'progress', 'current-time', 'mute', 'volume', 'settings', 'fullscreen']
};

const VideoPlayer = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ez974t10"
})(({
  show,
  hideOverflow
}) => ({
  display: show === false ? 'none' : 'block',
  overflow: hideOverflow ? 'hidden' : 'visible',
  zIndex: 1
}));

const MediaBlock = props => {
  const {
    block,
    onDelete,
    onEdit,
    isEditing
  } = props;
  const {
    name,
    type,
    id
  } = block;
  const {
    value,
    placeholder
  } = block[type] || {};
  const sourceUrl = isEditing ? value || placeholder : value;
  const prevSourceUrl = Object(universal_hooks_usePrevious__WEBPACK_IMPORTED_MODULE_2__["default"])(sourceUrl);
  const sources = {
    type: type,
    sources: [{
      src: sourceUrl
    }]
  };
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (prevSourceUrl !== sourceUrl) {
      const el = document.getElementById(`plyr-${id}`); // @ts-ignore

      const player = new plyr__WEBPACK_IMPORTED_MODULE_8___default.a(el, options); // @ts-ignore

      player.source = sources;
      return () => player.destroy();
    }

    return;
  }, [sourceUrl]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_7__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_6__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BlockHeader__WEBPACK_IMPORTED_MODULE_3__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: type,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(VideoPlayer, {
    show: sourceUrl !== '' && sourceUrl !== undefined,
    hideOverflow: type === 'video',
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('video', {
    id: `plyr-${id}`,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 66
    }
  }))));
};

/* harmony default export */ __webpack_exports__["default"] = (MediaBlock);

/***/ }),

/***/ "./src/universal/components/blocks/MultipleSelection.tsx":
/*!***************************************************************!*\
  !*** ./src/universal/components/blocks/MultipleSelection.tsx ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_components_TaskCheckbox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/TaskCheckbox */ "./src/universal/components/TaskCheckbox.tsx");
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var client_components_ListFilter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! client/components/ListFilter */ "./src/client/components/ListFilter.tsx");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/MultipleSelection.tsx";










const Checkbox = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1ayrd540"
})({
  name: "1r2f04i",
  styles: "margin-bottom:10px;"
});

const MultiClass = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["memo"])(props => {
  const {
    isAudits,
    block,
    onDelete,
    handleChange,
    index,
    isEditing,
    onEdit
  } = props;
  const {
    name,
    type
  } = block;
  const {
    value
  } = block['multiple_selection'] || {};
  const isTask = !isEditing && !isAudits;
  const [list, setList] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(block[type].options);
  const options = isEditing ? block[type].options : list;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_7__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_6__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_3__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_8__["BLOCK_TYPE"].MULTIPLE_SELECTION,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  })), isTask && Array.isArray(block[type].options) && block[type].options.length > 10 && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListFilter__WEBPACK_IMPORTED_MODULE_9__["default"], {
    list: block[type].options,
    setList: setList,
    keys: ['name'],
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    }
  }, options.map((option, optionIndex) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Checkbox, {
    key: optionIndex,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TaskCheckbox__WEBPACK_IMPORTED_MODULE_2__["default"], {
    name: `data.${index}.multiple_selection.value`,
    id: `${index}-${optionIndex}`,
    value: option.id,
    label: option.name,
    onChange: handleChange,
    checked: value && value.includes(option.id),
    disabled: isAudits,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    }
  })))));
});
/* harmony default export */ __webpack_exports__["default"] = (MultiClass);

/***/ }),

/***/ "./src/universal/components/blocks/NamedEntityRecognition.tsx":
/*!********************************************************************!*\
  !*** ./src/universal/components/blocks/NamedEntityRecognition.tsx ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var client_components_TextArea__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! client/components/TextArea */ "./src/client/components/TextArea.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var universal_components_PrimaryButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/components/PrimaryButton */ "./src/universal/components/PrimaryButton.tsx");
/* harmony import */ var universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! universal/components/SecondaryButton */ "./src/universal/components/SecondaryButton.tsx");
/* harmony import */ var universal_components_TaggableListWrapper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! universal/components/TaggableListWrapper */ "./src/universal/components/TaggableListWrapper.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var universal_components_text_annotator_TextAnnotator__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! universal/components/text-annotator/TextAnnotator */ "./src/universal/components/text-annotator/TextAnnotator.tsx");
/* harmony import */ var universal_utils_getColor__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! universal/utils/getColor */ "./src/universal/utils/getColor.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/NamedEntityRecognition.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}















const ButtonBlock = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1gz0wis0"
})({
  name: "12h07at",
  styles: "display:grid;margin-bottom:10px;margin-top:10px;grid-template-columns:80px 80px;grid-gap:10px;"
});

const Wrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1gz0wis1"
})(({
  editMode
}) => _objectSpread({}, editMode && {
  display: 'grid',
  gridTemplateRows: 'auto 50px'
}));

const TextWrapper = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "e1gz0wis2"
})(({
  highlightColor
}) => `
    cursor: auto;
    flex-grow: 1;
    padding-right: 10px;
    padding-bottom: 10px;
    line-height: 25px;
    margin-left: -10px;
    white-space: pre-wrap;
    & mark {
      padding: 4px !important;
      position: relative;
      cursor: pointer;
      &:hover:after {
        font-size: 8px;
        color: #000;
        white-space:nowrap;
        top: 0;
        line-height: 11px;
        left: 0;
        position: absolute;
        content: 'x';
        font-weight: bold;
        z-index: 11;
        width: 11px;
        background: white;
        text-align: center;
        opacity: 0.5;
      }
    }
    & mark > span {
      display: none;
    }

    & span {

      &::selection {
        background: ${highlightColor};
      }
    }
`);

const NamedEntityRecognition = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["memo"])(props => {
  const {
    block,
    onDelete,
    isEditing,
    onEdit,
    setFieldValue,
    index,
    isAudits
  } = props;
  const {
    name
  } = block;
  const {
    allow_edits: allowEdits,
    placeholder,
    options,
    value = '',
    entities = []
  } = block[universal_utils_constants__WEBPACK_IMPORTED_MODULE_11__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION] || {};
  const [text, setText] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(entities);
  const [userSelect, setUserSelect] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const [disableSelection, setDisableSelection] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(true);
  const [editMode, togglEditMode] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const [selectedCategory, setSelectedCategory] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({
    tag: options[0].id,
    color: Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_13__["colorByIndex"])(0)
  });
  const renderText = isEditing || value === '' ? placeholder || '' : value;
  let textFieldName = `data.${index}.${universal_utils_constants__WEBPACK_IMPORTED_MODULE_11__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION}.value`;

  if (isEditing || value === '') {
    textFieldName = `data.${index}.${universal_utils_constants__WEBPACK_IMPORTED_MODULE_11__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION}.placeholder`;
  }

  const [textFieldValue, setTextFieldValue] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(renderText);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    // reset tags when placeholder and options changed
    if (isEditing) {
      setText([]);
      setFieldValue(`data[${index}][${universal_utils_constants__WEBPACK_IMPORTED_MODULE_11__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION}].entities`, []);
    } else {
      setText(entities);
      setFieldValue(`data[${index}][${universal_utils_constants__WEBPACK_IMPORTED_MODULE_11__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION}].entities`, entities);
    }
  }, [placeholder, options]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    setFieldValue(`data[${index}][${universal_utils_constants__WEBPACK_IMPORTED_MODULE_11__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION}].entities`, isEditing ? [] : text);
  }, [text]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    setSelectedCategory({
      tag: options[0].id,
      color: Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_13__["colorByIndex"])(0)
    });
  }, [options]);
  const handleTextChange = Object(react__WEBPACK_IMPORTED_MODULE_1__["useCallback"])(e => {
    const {
      value
    } = e.target;
    setTextFieldValue(value);
  }, [textFieldValue]);

  const formatEntitiesForUIRendering = entities => {
    const entitiesInstance = entities;
    return entitiesInstance.filter(itm => {
      const [optionName, index] = findOptionNameFromId(itm.tag);

      if (!optionName) {
        return false;
      }

      itm.color = Object(universal_utils_getColor__WEBPACK_IMPORTED_MODULE_13__["colorByIndex"])(index);
      return itm;
    });
  };

  const findOptionNameFromId = id => {
    let name;
    let index;
    options.map((option, i) => {
      if (option.id === id) {
        name = option.name;
        index = i;
      }
    });
    return [name, index];
  };

  const handleAnnotate = text => {
    if (userSelect) {
      setUserSelect(false);
      return false;
    }

    if (!isAudits) {
      setText(text);
      setFieldValue(`data[${index}][${universal_utils_constants__WEBPACK_IMPORTED_MODULE_11__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION}].entities`, isEditing ? [] : text);
      setFieldValue(`data[${index}][${universal_utils_constants__WEBPACK_IMPORTED_MODULE_11__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION}].value`, renderText);
    }
  };

  const boxRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])();
  const inputRef = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createRef();
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (boxRef !== undefined && boxRef.current !== undefined) {
      boxRef.current.addEventListener('mouseup', e => {
        if (e.detail >= 3) {
          setUserSelect(true);
          e.preventDefault();
        }
      });
    }
  }, [boxRef]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (_optionalChain([inputRef, 'optionalAccess', _ => _.current])) {
      _optionalChain([inputRef, 'optionalAccess', _2 => _2.current, 'optionalAccess', _3 => _3.style, 'access', _4 => _4.setProperty, 'call', _5 => _5('height', '100%', 'important')]);
    }
  }, [inputRef]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_4__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 206
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 207
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 208
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_11__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 209
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_6__["default"], {
    row: true,
    style: {
      display: 'grid',
      gridTemplateColumns: 'auto 195px',
      gridGap: 20
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 216
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Wrapper, {
    editMode: editMode,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 220
    }
  }, editMode ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_TextArea__WEBPACK_IMPORTED_MODULE_3__["default"], {
    ref: inputRef,
    style: {
      height: '90% !important'
    },
    positionErrorBelow: false,
    value: textFieldValue,
    onChange: handleTextChange,
    scrollable: true,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 222
    }
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(TextWrapper, {
    onMouseDown: e => {
      e.stopPropagation();
    },
    onMouseEnter: () => {
      setDisableSelection(false);
    },
    onMouseLeave: () => {
      setDisableSelection(true);
      window.getSelection().empty();
    },
    style: {
      userSelect: disableSelection ? 'none' : 'auto'
    },
    highlightColor: selectedCategory.color,
    ref: boxRef,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 231
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_text_annotator_TextAnnotator__WEBPACK_IMPORTED_MODULE_12__["default"], {
    style: {
      paddingLeft: '10px'
    },
    content: renderText,
    value: formatEntitiesForUIRendering(text),
    onChange: handleAnnotate,
    getSpan: span => _objectSpread(_objectSpread({}, span), selectedCategory),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 246
    }
  })), allowEdits && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ButtonBlock, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 261
    }
  }, editMode ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_9__["default"], {
    style: {
      width: '100%',
      marginRight: 10
    },
    type: "button",
    disabled: false,
    onClick: () => {
      togglEditMode(false);
      setTextFieldValue(renderText);
    },
    hideFocus: true,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 264
    }
  }, "Cancel"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_PrimaryButton__WEBPACK_IMPORTED_MODULE_8__["default"], {
    style: {
      width: '100%'
    },
    type: "button",
    disabled: false,
    onClick: () => {
      if (!isEditing) {
        setText([]);
        setFieldValue(`data[${index}][${universal_utils_constants__WEBPACK_IMPORTED_MODULE_11__["BLOCK_TYPE"].NAMED_ENTITY_RECOGNITION}].entities`, []);
      }

      setFieldValue(textFieldName, textFieldValue);
      togglEditMode(false);
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 276
    }
  }, "Save")) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_SecondaryButton__WEBPACK_IMPORTED_MODULE_9__["default"], {
    style: {
      width: '100%'
    },
    type: "button",
    onClick: () => togglEditMode(true),
    hideFocus: true,
    disabled: isAudits,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 296
    }
  }, "Edit Text"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TaggableListWrapper__WEBPACK_IMPORTED_MODULE_10__["default"], {
    options: options,
    onSelect: category => {
      setSelectedCategory(category);
    },
    selectedCategory: selectedCategory,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 310
    }
  })));
});
/* harmony default export */ __webpack_exports__["default"] = (NamedEntityRecognition);

/***/ }),

/***/ "./src/universal/components/blocks/Number.tsx":
/*!****************************************************!*\
  !*** ./src/universal/components/blocks/Number.tsx ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NumberBlock; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var universal_components_InputField__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! universal/components/InputField */ "./src/universal/components/InputField.tsx");
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/Number.tsx";








function NumberBlock(props) {
  const {
    block,
    onDelete,
    handleChange,
    index,
    isAudits,
    isEditing,
    onEdit
  } = props;
  const {
    number,
    name
  } = block;
  const {
    placeholder,
    read_only: readOnly,
    value = ''
  } = number || {};
  const renderValue = isEditing ? value || placeholder : value;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_Content__WEBPACK_IMPORTED_MODULE_6__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_HeaderContainer__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_Label__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__["createElement"](universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_7__["BLOCK_TYPE"].NUMBER,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_BodyContainer__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    }
  }, readOnly || isAudits ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__["createElement"]('div', {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  }, renderValue) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__["createElement"](universal_components_InputField__WEBPACK_IMPORTED_MODULE_1__["default"], {
    name: `data.${index}.number.value`,
    onChange: handleChange,
    type: "number",
    autoFocus: false,
    value: renderValue || "",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    }
  })));
}

/***/ }),

/***/ "./src/universal/components/blocks/PdfReader.tsx":
/*!*******************************************************!*\
  !*** ./src/universal/components/blocks/PdfReader.tsx ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/PdfReader.tsx";








const IFrame = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("iframe", {
  target: "eiejtyd0"
})({
  name: "np0iat",
  styles: "width:100%;height:100%;border:0;"
});

const PdfReader = props => {
  const {
    block,
    onEdit,
    onDelete,
    isEditing,
    error,
    index
  } = props || {};
  const {
    pdf,
    name
  } = block;
  const {
    value,
    placeholder
  } = pdf || {};
  let sourceUrl = isEditing ? placeholder : value;

  if (error.data && error.data[index] && error.data.length) {
    sourceUrl = '';
  }

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_5__["default"], _objectSpread(_objectSpread({}, props), {}, {
    overflow: `hidden`,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 41
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__["BLOCK_TYPE"].PDF,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(IFrame, {
    src: sourceUrl,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    }
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (PdfReader);

/***/ }),

/***/ "./src/universal/components/blocks/RichTextEditor.tsx":
/*!************************************************************!*\
  !*** ./src/universal/components/blocks/RichTextEditor.tsx ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var universal_components_TextEditor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! universal/components/TextEditor */ "./src/universal/components/TextEditor.tsx");
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/RichTextEditor.tsx";








const RichTextEditor = props => {
  const {
    isAudits,
    block,
    onEdit,
    onDelete,
    setFieldValue,
    isEditing,
    index
  } = props;
  const {
    rich_text: richText,
    name
  } = block;
  const {
    placeholder,
    read_only: readOnly,
    value = '',
    format
  } = richText || {};
  const renderValue = isEditing ? placeholder : value;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_5__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 29
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_6__["BLOCK_TYPE"].RICH_TEXT,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(universal_components_TextEditor__WEBPACK_IMPORTED_MODULE_1__["default"], {
    name: `data.${index}.rich_text.value`,
    value: renderValue,
    readOnly: readOnly || isAudits,
    placeholder: placeholder,
    setFieldValue: setFieldValue,
    format: format,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    }
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (RichTextEditor);

/***/ }),

/***/ "./src/universal/components/blocks/SingleSelection.tsx":
/*!*************************************************************!*\
  !*** ./src/universal/components/blocks/SingleSelection.tsx ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_components_TaskRadio__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/TaskRadio */ "./src/universal/components/TaskRadio.tsx");
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var client_components_ListFilter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! client/components/ListFilter */ "./src/client/components/ListFilter.tsx");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/SingleSelection.tsx";










const Radio = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "eg86qua0"
})({
  name: "1r2f04i",
  styles: "margin-bottom:10px;"
});

const SingleSelection = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["memo"])(props => {
  const {
    block,
    onDelete,
    isAudits,
    handleChange,
    index,
    isEditing,
    onEdit
  } = props;
  const {
    name,
    type
  } = block;
  const {
    value
  } = block['single_selection'] || {};
  const isTask = !isEditing && !isAudits;
  const [list, setList] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(block[type].options);
  const options = isEditing ? block[type].options : list;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_4__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_3__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_8__["BLOCK_TYPE"].SINGLE_SELECTION,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    }
  })), isTask && Array.isArray(block[type].options) && block[type].options.length > 10 && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(client_components_ListFilter__WEBPACK_IMPORTED_MODULE_9__["default"], {
    list: block[type].options,
    setList: setList,
    keys: ['name'],
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_6__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    }
  }, options.map((option, optionIndex) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Radio, {
    key: optionIndex,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TaskRadio__WEBPACK_IMPORTED_MODULE_2__["default"], {
    name: `data.${index}.single_selection.value`,
    id: `${index}-${optionIndex}`,
    value: option.id,
    label: option.name,
    onChange: handleChange,
    checked: option.id === value,
    disabled: isAudits,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    }
  })))));
});
/* harmony default export */ __webpack_exports__["default"] = (SingleSelection);

/***/ }),

/***/ "./src/universal/components/blocks/Text.tsx":
/*!**************************************************!*\
  !*** ./src/universal/components/blocks/Text.tsx ***!
  \**************************************************/
/*! exports provided: StyledText, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StyledText", function() { return StyledText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Text; });
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_linkify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-linkify */ "./node_modules/react-linkify/dist/index.js");
/* harmony import */ var react_linkify__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_linkify__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var universal_components_BasicTextArea__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! universal/components/BasicTextArea */ "./src/universal/components/BasicTextArea.tsx");
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var universal_styles_palette__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! universal/styles/palette */ "./src/universal/styles/palette.ts");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/Text.tsx";










const StyledText = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("p", {
  target: "efy0fkk0"
})({
  fontSize: 16,
  lineHeight: 1.35,
  fontWeight: 400,
  color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_9__["PALETTE"].TEXT_MAIN,
  whiteSpace: 'pre-wrap',
  wordWrap: 'break-word',
  wordBreak: 'break-word',
  cursor: 'text'
});
function Text(props) {
  const {
    isAudits,
    block,
    onEdit,
    onDelete,
    handleChange,
    isEditing,
    index
  } = props;
  const {
    text,
    name
  } = block;
  const {
    placeholder,
    read_only: readOnly,
    value = ''
  } = text || {};
  const renderValue = isEditing ? placeholder : value;
  const decorator = Object(react__WEBPACK_IMPORTED_MODULE_1__["useCallback"])((href, text, key) => {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement('a', {
      href: href,
      key: key,
      target: "_blank",
      rel: "noopener noreferrer",
      style: {
        color: universal_styles_palette__WEBPACK_IMPORTED_MODULE_9__["PALETTE"].LINK
        /* textDecoration: 'underline' */

      },
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 44
      }
    }, text);
  }, [renderValue]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_8__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_6__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 60
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_10__["BLOCK_TYPE"].TEXT,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_7__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 69
    }
  }, !readOnly && !isAudits ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BasicTextArea__WEBPACK_IMPORTED_MODULE_3__["default"], {
    name: `data.${index}.text.value`,
    onChange: handleChange,
    autoFocus: false,
    style: {
      height: '100%'
    },
    value: renderValue || value,
    readOnly: readOnly,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    }
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_linkify__WEBPACK_IMPORTED_MODULE_2___default.a, {
    componentDecorator: decorator,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 82
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(StyledText, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 83
    }
  }, renderValue))));
}

/***/ }),

/***/ "./src/universal/components/blocks/TextSequence.tsx":
/*!**********************************************************!*\
  !*** ./src/universal/components/blocks/TextSequence.tsx ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TextSequence; });
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled-base */ "./node_modules/@emotion/styled-base/dist/styled-base.browser.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! universal/components/BlockHeader */ "./src/universal/components/BlockHeader.tsx");
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Label */ "./src/universal/components/blocks/Label.tsx");
/* harmony import */ var _HeaderContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./HeaderContainer */ "./src/universal/components/blocks/HeaderContainer.tsx");
/* harmony import */ var _BodyContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./BodyContainer */ "./src/universal/components/blocks/BodyContainer.tsx");
/* harmony import */ var _Content__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Content */ "./src/universal/components/blocks/Content.tsx");
/* harmony import */ var universal_utils_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! universal/utils/constants */ "./src/universal/utils/constants.ts");
/* harmony import */ var universal_components_TextSequence__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! universal/components/TextSequence */ "./src/universal/components/TextSequence.tsx");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/blocks/TextSequence.tsx";

function _optionalChain(ops) {
  let lastAccessLHS = undefined;
  let value = ops[0];
  let i = 1;

  while (i < ops.length) {
    const op = ops[i];
    const fn = ops[i + 1];
    i += 2;

    if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
      return undefined;
    }

    if (op === 'access' || op === 'optionalAccess') {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === 'call' || op === 'optionalCall') {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = undefined;
    }
  }

  return value;
}










const Block = Object(_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])("div", {
  target: "ef6bqbm0"
})({
  name: "1hx5wtv",
  styles: "display:flex;flex-direction:row;justify-content:space-between;margin-bottom:10px;flex:0 0 auto;"
});

function TextSequence(props) {
  const {
    isAudits,
    block,
    onEdit,
    onDelete,
    handleChange,
    isEditing,
    index,
    setFieldValue
  } = props;
  const {
    name,
    type
  } = block || {};
  const data = isEditing ? block[type].placeholder : block[type].value;
  const {
    delete_disabled: deleteDisabled,
    edit_disabled: editDisabled,
    ordering_disabled: orderingDisabled
  } = block[type];
  const settings = {
    deleteDisabled,
    editDisabled,
    orderingDisabled
  };
  const targetName = isEditing ? `data[${index}][${type}].placeholder` : `data[${index}][${type}].value`;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Content__WEBPACK_IMPORTED_MODULE_6__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_HeaderContainer__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    }
  }, name && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_Label__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    }
  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_BlockHeader__WEBPACK_IMPORTED_MODULE_2__["default"], {
    onDelete: onDelete,
    onEdit: onEdit,
    isEditing: isEditing,
    blockType: universal_utils_constants__WEBPACK_IMPORTED_MODULE_7__["BLOCK_TYPE"].TEXT,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_BodyContainer__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 61
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Block, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 62
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(universal_components_TextSequence__WEBPACK_IMPORTED_MODULE_8__["default"], {
    name: targetName,
    targetName: targetName,
    data: data,
    type: type,
    setFieldValue: setFieldValue,
    index: index,
    handleChange: handleChange,
    isEditing: isEditing,
    isAudits: isAudits,
    placeholder: _optionalChain([block, 'access', _ => _[type], 'optionalAccess', _2 => _2.placeholder]) || [],
    settings: settings,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 63
    }
  }))));
}

/***/ }),

/***/ "./src/universal/components/text-annotator/Functions.ts":
/*!**************************************************************!*\
  !*** ./src/universal/components/text-annotator/Functions.ts ***!
  \**************************************************************/
/*! exports provided: splitWithOffsets, splitTokensWithOffsets, selectionIsEmpty, selectionIsBackwards */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "splitWithOffsets", function() { return splitWithOffsets; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "splitTokensWithOffsets", function() { return splitTokensWithOffsets; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectionIsEmpty", function() { return selectionIsEmpty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectionIsBackwards", function() { return selectionIsBackwards; });
/* harmony import */ var lodash_sortby__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash.sortby */ "./node_modules/lodash.sortby/index.js");
/* harmony import */ var lodash_sortby__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_sortby__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const splitWithOffsets = (text, offsets) => {
  let lastEnd = 0;
  const splits = [];

  for (let offset of lodash_sortby__WEBPACK_IMPORTED_MODULE_0___default()(offsets, o => o.start)) {
    const {
      start,
      end
    } = offset;

    if (lastEnd < start) {
      splits.push({
        start: lastEnd,
        end: start,
        content: text.slice(lastEnd, start)
      });
    }

    splits.push(_objectSpread(_objectSpread({}, offset), {}, {
      mark: true,
      content: text.slice(start, end)
    }));
    lastEnd = end;
  }

  if (lastEnd < text.length) {
    splits.push({
      start: lastEnd,
      end: text.length,
      content: text.slice(lastEnd, text.length)
    });
  }

  return splits;
};
const splitTokensWithOffsets = (text, offsets) => {
  let lastEnd = 0;
  const splits = [];

  for (let offset of lodash_sortby__WEBPACK_IMPORTED_MODULE_0___default()(offsets, o => o.start)) {
    const {
      start,
      end
    } = offset;

    if (lastEnd < start) {
      for (let i = lastEnd; i < start; i++) {
        splits.push({
          i,
          content: text[i]
        });
      }
    }

    splits.push(_objectSpread(_objectSpread({}, offset), {}, {
      mark: true,
      content: text.slice(start, end).join(' ')
    }));
    lastEnd = end;
  }

  for (let i = lastEnd; i < text.length; i++) {
    splits.push({
      i,
      content: text[i]
    });
  }

  return splits;
};
const selectionIsEmpty = selection => {
  let position = selection.anchorNode.compareDocumentPosition(selection.focusNode);
  return position === 0 && selection.focusOffset === selection.anchorOffset;
};
const selectionIsBackwards = selection => {
  if (selectionIsEmpty(selection)) return false;
  let position = selection.anchorNode.compareDocumentPosition(selection.focusNode);
  let backward = false;
  if (!position && selection.anchorOffset > selection.focusOffset || position === Node.DOCUMENT_POSITION_PRECEDING) backward = true;
  return backward;
};

/***/ }),

/***/ "./src/universal/components/text-annotator/Mark.tsx":
/*!**********************************************************!*\
  !*** ./src/universal/components/text-annotator/Mark.tsx ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/text-annotator/Mark.tsx";


const Mark = props => {
  const {
    color,
    start,
    end,
    content,
    tag,
    onClick
  } = props;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('mark', {
    style: {
      backgroundColor: color || '#84d2ff',
      padding: '0 4px'
    },
    'data-start': start,
    'data-end': end,
    onClick: () => onClick({
      start,
      end
    }),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 17
    }
  }, content, tag && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
    style: {
      fontSize: '0.7em',
      fontWeight: 500,
      marginLeft: 6
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  }, tag));
};

/* harmony default export */ __webpack_exports__["default"] = (Mark);

/***/ }),

/***/ "./src/universal/components/text-annotator/TextAnnotator.tsx":
/*!*******************************************************************!*\
  !*** ./src/universal/components/text-annotator/TextAnnotator.tsx ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Mark__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Mark */ "./src/universal/components/text-annotator/Mark.tsx");
/* harmony import */ var _Functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Functions */ "./src/universal/components/text-annotator/Functions.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const _jsxFileName = "/Users/a/git/Human-Lambdas/hl-web/src/universal/components/text-annotator/TextAnnotator.tsx";




const Split = props => {
  if (props.mark) return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Mark__WEBPACK_IMPORTED_MODULE_1__["default"], _objectSpread(_objectSpread({}, props), {}, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 8
    }
  }));
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('span', {
    'data-start': props.start,
    'data-end': props.end,
    onClick: () => props.onClick({
      start: props.start,
      end: props.end
    }),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11
    }
  }, props.content);
};

const TextAnnotator = props => {
  const getSpan = span => {
    // TODO: Better typings here.
    if (props.getSpan) return props.getSpan(span);
    return {
      start: span.start,
      end: span.end
    };
  };

  const handleMouseUp = () => {
    if (!props.onChange) return;
    const selection = window.getSelection();
    if (!selection.anchorNode || !selection.focusNode || Object(_Functions__WEBPACK_IMPORTED_MODULE_2__["selectionIsEmpty"])(selection)) return;
    let start = parseInt(selection.anchorNode.parentElement.getAttribute('data-start'), 10) + selection.anchorOffset;
    let end = parseInt(selection.focusNode.parentElement.getAttribute('data-start'), 10) + selection.focusOffset;

    if (!Number.isInteger(start) || !Number.isInteger(end) || selection.anchorNode.compareDocumentPosition(selection.focusNode) !== 0) {
      window.getSelection().empty();
      return;
    }

    if (Object(_Functions__WEBPACK_IMPORTED_MODULE_2__["selectionIsBackwards"])(selection)) {
      ;
      [start, end] = [end, start];
    }

    props.onChange([...props.value, getSpan({
      start,
      end,
      text: content.slice(start, end)
    })]);
    window.getSelection().empty();
  };

  const handleSplitClick = ({
    start,
    end
  }) => {
    // Find and remove the matching split.
    const splitIndex = props.value.findIndex(s => s.start === start && s.end === end);

    if (splitIndex >= 0) {
      props.onChange([...props.value.slice(0, splitIndex), ...props.value.slice(splitIndex + 1)]);
    }
  };

  const {
    content,
    value,
    style
  } = props;
  const splits = Object(_Functions__WEBPACK_IMPORTED_MODULE_2__["splitWithOffsets"])(content, value);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement('div', {
    style: style,
    onMouseUp: handleMouseUp,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 86
    }
  }, splits.map(split => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Split, _objectSpread(_objectSpread({
    key: `${split.start}-${split.end}`
  }, split), {}, {
    onClick: handleSplitClick,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 88
    }
  }))));
};

/* harmony default export */ __webpack_exports__["default"] = (TextAnnotator);

/***/ }),

/***/ "./src/universal/hooks/usePrevious.ts":
/*!********************************************!*\
  !*** ./src/universal/hooks/usePrevious.ts ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


const usePrevious = value => {
  const ref = Object(react__WEBPACK_IMPORTED_MODULE_0__["useRef"])();
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    ref.current = value;
  });
  return ref.current;
};

/* harmony default export */ __webpack_exports__["default"] = (usePrevious);

/***/ }),

/***/ "./src/universal/styles/css/react-grid-layout.css":
/*!********************************************************!*\
  !*** ./src/universal/styles/css/react-grid-layout.css ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!./react-grid-layout.css */ "./node_modules/css-loader/dist/cjs.js!./src/universal/styles/css/react-grid-layout.css");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/universal/styles/css/react-resizable.css":
/*!******************************************************!*\
  !*** ./src/universal/styles/css/react-resizable.css ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!./react-resizable.css */ "./node_modules/css-loader/dist/cjs.js!./src/universal/styles/css/react-resizable.css");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/universal/styles/css/rgl-overide.css":
/*!**************************************************!*\
  !*** ./src/universal/styles/css/rgl-overide.css ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!./rgl-overide.css */ "./node_modules/css-loader/dist/cjs.js!./src/universal/styles/css/rgl-overide.css");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./src/universal/utils/getItemStyle.ts":
/*!*********************************************!*\
  !*** ./src/universal/utils/getItemStyle.ts ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const getItemStyle = (_isDragging, draggableStyle) => {
  const {
    transform
  } = draggableStyle;
  let activeTransform = {};

  if (transform) {
    activeTransform = {
      transform: `translate(0, ${transform.substring(transform.indexOf(',') + 1, transform.indexOf(')'))})`
    };
  }

  return _objectSpread(_objectSpread({
    userSelect: 'none',
    // background: isDragging ? '#fff' : '#fff',
    background: '#fff',
    outline: 'none',
    width: '100%',
    height: '100%'
  }, draggableStyle), activeTransform);
};

/* harmony default export */ __webpack_exports__["default"] = (getItemStyle);

/***/ }),

/***/ "./src/universal/utils/isEmptyArray.ts":
/*!*********************************************!*\
  !*** ./src/universal/utils/isEmptyArray.ts ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const isEmptyArray = value => {
  if (value === null || value === undefined) return true;

  if (Array.isArray(value) || typeof value === 'string' || typeof value.splice === 'function') {
    return !value.length;
  }

  return false;
};

/* harmony default export */ __webpack_exports__["default"] = (isEmptyArray);

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL3N0eWxlcy9jc3MvcmVhY3QtZ3JpZC1sYXlvdXQuY3NzIiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvc3R5bGVzL2Nzcy9yZWFjdC1yZXNpemFibGUuY3NzIiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvc3R5bGVzL2Nzcy9yZ2wtb3ZlcmlkZS5jc3MiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NsaWVudC9jb21wb25lbnRzL0lucHV0RmllbGQudHN4Iiwid2VicGFjazovLy8uL3NyYy9jbGllbnQvY29tcG9uZW50cy9MaXN0RmlsdGVyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvQXBwSGVhZGVyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvQmxvY2tDb21wb25lbnQudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9CbG9ja0hlYWRlci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL0Jsb2NrV3JhcHBlci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL0ljb25CdXR0b24udHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9SR0wudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9UYWdnYWJsZUxpc3RXcmFwcGVyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvVGV4dFNlcXVlbmNlLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmJveC1hbm5vdGF0b3IvQkJveEFubm90YXRvci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jib3gtYW5ub3RhdG9yL0JCb3hTZWxlY3Rvci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9CaW5hcnkudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvQm91bmRpbmdCb3hlcy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9Db250ZW50LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL0RhdGUudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvRW1haWwudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvRW1iZWQudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvRm9ybVNlcXVlbmNlLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL0hlYWRlckNvbnRhaW5lci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9JbWFnZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9MYWJlbC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9MaW5rLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL01lZGlhQmxvY2sudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvTXVsdGlwbGVTZWxlY3Rpb24udHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvTmFtZWRFbnRpdHlSZWNvZ25pdGlvbi50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9OdW1iZXIudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvUGRmUmVhZGVyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL1JpY2hUZXh0RWRpdG9yLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL1NpbmdsZVNlbGVjdGlvbi50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9UZXh0LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL1RleHRTZXF1ZW5jZS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL3RleHQtYW5ub3RhdG9yL0Z1bmN0aW9ucy50cyIsIndlYnBhY2s6Ly8vLi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvdGV4dC1hbm5vdGF0b3IvTWFyay50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL3RleHQtYW5ub3RhdG9yL1RleHRBbm5vdGF0b3IudHN4Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvaG9va3MvdXNlUHJldmlvdXMudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9zdHlsZXMvY3NzL3JlYWN0LWdyaWQtbGF5b3V0LmNzcz9iOWY5Iiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvc3R5bGVzL2Nzcy9yZWFjdC1yZXNpemFibGUuY3NzP2I3NzYiLCJ3ZWJwYWNrOi8vLy4vc3JjL3VuaXZlcnNhbC9zdHlsZXMvY3NzL3JnbC1vdmVyaWRlLmNzcz9kN2YxIiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvdXRpbHMvZ2V0SXRlbVN0eWxlLnRzIiwid2VicGFjazovLy8uL3NyYy91bml2ZXJzYWwvdXRpbHMvaXNFbXB0eUFycmF5LnRzIl0sIm5hbWVzIjpbIl9qc3hGaWxlTmFtZSIsIklucHV0IiwiZXJyb3IiLCJkaXNhYmxlZCIsImRpc3BsYXkiLCJhcHBlYXJhbmNlIiwib3V0bGluZSIsIm1hcmdpbiIsImJvcmRlciIsIlBBTEVUVEUiLCJFUlJPUl9NQUlOIiwiQk9SREVSX01BSU5fR1JBWSIsImJveFNpemluZyIsImNvbG9yIiwiVEVYVF9NQUlOIiwiZm9udEZhbWlseSIsIkZPTlRfRkFNSUxZIiwiU0FOU19TRVJJRiIsImZvbnRXZWlnaHQiLCJjdXJzb3IiLCJib3JkZXJSYWRpdXMiLCJmb250U2l6ZSIsImxpbmVIZWlnaHQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJoZWlnaHQiLCJwYWRkaW5nIiwidHJhbnNpdGlvbiIsIndpZHRoIiwiYm94U2hhZG93IiwiQk9YX1NIQURPV19QUklNQVJZIiwiYm9yZGVyQ29sb3IiLCJQUklNQVJZX01BSU4iLCJMYWJlbCIsIlN0eWxlZExhYmVsIiwiTGFiZWxIZWxwZXIiLCJURVhUX0dSQVkiLCJtYXJnaW5MZWZ0IiwiSW5wdXRGaWVsZCIsImZvcndhcmRSZWYiLCJwcm9wcyIsInJlZiIsImF1dG9Db21wbGV0ZSIsImF1dG9Gb2N1cyIsImlzT3B0aW9uYWwiLCJpc1JlcXVpcmVkIiwibmFtZSIsIm9uQmx1ciIsIm9uRm9jdXMiLCJvbkNoYW5nZSIsInBsYWNlaG9sZGVyIiwidHlwZSIsInZhbHVlIiwibGFiZWwiLCJzdHlsZSIsInNwZWxsQ2hlY2siLCJSZWFjdCIsImNyZWF0ZUVsZW1lbnQiLCJGcmFnbWVudCIsIl9fc2VsZiIsIl9fc291cmNlIiwiZmlsZU5hbWUiLCJsaW5lTnVtYmVyIiwiQm9vbGVhbiIsIlN0eWxlZEVycm9yIiwiV3JhcHBlciIsIkxpc3RGaWx0ZXIiLCJsaXN0Iiwic2V0TGlzdCIsImtleXMiLCJoYW5kbGVDaGFuZ2UiLCJlIiwidGVybSIsInRhcmdldCIsIm1hdGNoU29ydGVyIiwiQVBQX0hFQURFUl9IRUlHSFQiLCJDb250YWluZXIiLCJmbGV4RGlyZWN0aW9uIiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiQkFDS0dST1VORF9NQUlOIiwiYm9yZGVyQm90dG9tIiwiQk9SREVSX0dSQVlfTkVXIiwibWluSGVpZ2h0IiwibWluV2lkdGgiLCJGbGV4SXRlbSIsInByb3AiLCJmbGV4IiwidGV4dEFsaWduIiwiY2VudGVyIiwiQXBwSGVhZGVyIiwibGVmdEJhckl0ZW1zIiwicmlnaHRCYXJJdGVtcyIsIm1pZEJhckl0ZW1zIiwiaXNFbXB0eUFycmF5IiwiX29wdGlvbmFsQ2hhaW4iLCJvcHMiLCJsYXN0QWNjZXNzTEhTIiwidW5kZWZpbmVkIiwiaSIsImxlbmd0aCIsIm9wIiwiZm4iLCJhcmdzIiwiY2FsbCIsIkJsb2NrQ29tcG9uZW50IiwibWVtbyIsImlzQXVkaXRzIiwic2V0RmllbGRWYWx1ZSIsImlzRWRpdGluZyIsImluZGV4IiwiYmxvY2siLCJvbkRlbGV0ZSIsImhhbmRsZUJsdXIiLCJvbkVkaXQiLCJlcnJvcnMiLCJyZW5kZXJDbXAiLCJCTE9DS19UWVBFIiwiVEVYVCIsIlRleHQiLCJFTUFJTCIsIkVtYWlsIiwiXyIsImVtYWlsIiwiTlVNQkVSIiwiTnVtYmVyIiwiTElOSyIsIkxpbmsiLCJfMiIsImxpbmsiLCJJTUFHRSIsIkltYWdlIiwiQVVESU8iLCJNZWRpYUJsb2NrIiwiVklERU8iLCJCSU5BUlkiLCJCaW5hcnkiLCJOQU1FRF9FTlRJVFlfUkVDT0dOSVRJT04iLCJOYW1lZEVudGl0eVJlY29nbml0aW9uIiwiQk9VTkRJTkdfQk9YRVMiLCJCb3VuZGluZ0JveGVzIiwiRU1CRUQiLCJFbWJlZCIsIlBERiIsIlBkZlJlYWRlciIsIlNJTkdMRV9TRUxFQ1RJT04iLCJTaW5nbGVTZWxlY3Rpb24iLCJNVUxUSVBMRV9TRUxFQ1RJT04iLCJNdWx0aXBsZVNlbGVjdGlvbiIsIkZPUk1fU0VRVUVOQ0UiLCJGb3JtU2VxdWVuY2UiLCJSSUNIX1RFWFQiLCJSaWNoVGV4dEVkaXRvciIsIlRFWFRfU0VRVUVOQ0UiLCJUZXh0U2VxdWVuY2UiLCJEQVRFIiwiRGF0ZSIsIlN0eWxlZEljb24iLCJJY29uIiwiVHlwZUljb24iLCJCQUNLR1JPVU5EX0dSQVlfTUlEIiwiQmxvY2tIZWFkZXIiLCJibG9ja1R5cGUiLCJJY29uQnV0dG9uIiwib25DbGljayIsIkJMT0NLUyIsImZpbmQiLCJiIiwiXzMiLCJpY29uIiwiQmxvY2tXcmFwcGVyIiwiekluZGV4IiwiUGxhaW5CdXR0b24iLCJjaGlsZHJlbiIsIlJHTFdpZHRoUHJvdmlkZXIiLCJXaWR0aFByb3ZpZGVyIiwiUmVzcG9uc2l2ZSIsIlJHTF9DT0xVTU5TIiwiUkdMX1JPV1MiLCJSR0xDb250YWluZXIiLCJSR0xXcmFwcGVyIiwiUkdMIiwiaXNEcmFnZ2FibGUiLCJpc0Ryb3BwYWJsZSIsImlzUmVzaXphYmxlIiwib25EcmFnU3RhcnQiLCJvbkRyYWdTdG9wIiwib25Ecm9wIiwib25MYXlvdXRDaGFuZ2UiLCJsYXlvdXRzIiwiZHJvcHBpbmdJdGVtIiwiYXV0b1NpemUiLCJicmVha3BvaW50cyIsImFsbCIsImNvbHMiLCJjb21wYWN0VHlwZSIsImlzQm91bmRlZCIsIm1lYXN1cmVCZWZvcmVNb3VudCIsInVzZUNTU1RyYW5zZm9ybXMiLCJwcmV2ZW50Q29sbGlzaW9uIiwiY29udGFpbmVyUGFkZGluZyIsInJvd0hlaWdodCIsImRyYWdnYWJsZUhhbmRsZSIsIkxpc3RXcmFwcGVyIiwiTGlzdCIsIkxpc3RMYWJlbCIsIkNhdGVnb3J5QnV0dG9uIiwiYWN0aXZlIiwiYmFja2dyb3VuZCIsImNsZWFyIiwibWFyZ2luQm90dG9tIiwiRW50aXR5VGV4dCIsIkNvbG9yQXJ0aWZhY3QiLCJtYXJnaW5SaWdodCIsImRhcmtlbiIsIlRhZ2dhYmxlTGlzdFdyYXBwZXIiLCJvcHRpb25zIiwidGV4dCIsInNlbGVjdGVkQ2F0ZWdvcnkiLCJvblNlbGVjdCIsIm9iamVjdHMiLCJvbkhvdmVyIiwiZ2V0T3B0aW9uSW5kZXgiLCJpZCIsIm1hcCIsIm9wdGlvbiIsIm9wdGlvbkluZGV4Iiwia2V5IiwidGFnIiwiY29sb3JCeUluZGV4IiwiQXJyYXkiLCJpc0FycmF5IiwiaXRlbSIsIm9wdCIsImNhdGVnb3J5Iiwib25Nb3VzZUVudGVyIiwib25Nb3VzZUxlYXZlIiwic3RvcFByb3BhZ2F0aW9uIiwicG9zaXRpb24iLCJyaWdodCIsInRvcCIsInBvcnRhbCIsImRvY3VtZW50IiwiYm9keSIsIkVycm9yIiwiYXBwZW5kQ2hpbGQiLCJSb290QnV0dG9uIiwiRmllbGRXcmFwcGVyIiwiQ29udGVudFdyYXBwZXIiLCJpc1Rhc2siLCJvcmRlcmluZ0Rpc2FibGVkIiwiZGVsZXRlRGlzYWJsZWQiLCJDb250ZW50QmxvY2siLCJJbnB1dFdyYXBwZXIiLCJCbG9ja0lucHV0IiwicHJvdmlkZWQiLCJzbmFwc2hvdCIsInNlcUlkeCIsImRhdGEiLCJ0YXJnZXROYW1lIiwiYXJyYXlIZWxwZXJzIiwic2V0dGluZ3MiLCJzZXRGb2N1c1N0eWxlcyIsImVsZW1lbnRzIiwiYWN0aW9uIiwiZm9yRWFjaCIsImVsZW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsImNsYXNzTGlzdCIsIl80Iiwic2hvd0RlbGV0ZSIsImRyYWdnYWJsZVByb3BzIiwiaW5uZXJSZWYiLCJnZXRJdGVtU3R5bGUiLCJpc0RyYWdnaW5nIiwiZHJhZ0hhbmRsZVByb3BzIiwiVGV4dEFyZWEiLCJjYWNoZU1lYXN1cmVtZW50cyIsIm9uS2V5RG93biIsImtleUNvZGUiLCJwcmV2ZW50RGVmYXVsdCIsIl81IiwicmVhZE9ubHkiLCJlZGl0RGlzYWJsZWQiLCJyZW1vdmUiLCJvbkRyYWdFbmQiLCJ1c2VDYWxsYmFjayIsInJlc3VsdCIsImRlc3RpbmF0aW9uIiwic291cmNlIiwiZHJhZ2dhYmxlSWQiLCJkcm9wcGFibGVJZCIsImNoYW5nZWRJdGVtIiwibmV3TGlzdCIsInNwbGljZSIsIkZpZWxkQXJyYXkiLCJyZW5kZXIiLCJEcmFnRHJvcENvbnRleHQiLCJEcm9wcGFibGUiLCJkcm9wcGFibGVQcm9wcyIsIkRyYWdnYWJsZSIsIlN0cmluZyIsImlzRHJhZ0Rpc2FibGVkIiwidXNlUG9ydGFsIiwiY2hpbGQiLCJSZWFjdERPTSIsImNyZWF0ZVBvcnRhbCIsIlNlY29uZGFyeUJ1dHRvbiIsInB1c2giLCJkZWZhdWx0UHJvcHMiLCJCQm94QW5ub3RhdG9yIiwidXJsIiwiYm9yZGVyV2lkdGgiLCJzZWxlY3RlZExhYmVsIiwiaGlnaGxpZ2h0SW5kZXgiLCJwb2ludGVyIiwic2V0UG9pbnRlciIsInVzZVN0YXRlIiwib2Zmc2V0Iiwic2V0T2Zmc2V0IiwiZW50cmllcyIsInNldEVudHJpZXMiLCJ1c2VFZmZlY3QiLCJlbnRyeSIsInciLCJwYXJzZUZsb2F0IiwidG9GaXhlZCIsImgiLCJ5IiwieCIsImlzRXF1YWwiLCJzb3J0Iiwic3RhdHVzIiwic2V0U3RhdHVzIiwiaW1hZ2VGcmFtZVN0eWxlIiwic2V0SW1hZ2VGcmFtZVN0eWxlIiwiYkJveEltYWdlUmVmIiwidXNlUmVmIiwiaW1hZ2VFbGVtZW50Iiwic3JjIiwib25sb2FkIiwiYmFja2dyb3VuZEltYWdlU3JjIiwiY3JvcCIsInBhZ2VYIiwicGFnZVkiLCJjdXJyZW50IiwiTWF0aCIsIm1pbiIsIm1heCIsInJvdW5kIiwiZ2V0Qm91bmRpbmdDbGllbnRSZWN0Iiwib2Zmc2V0V2lkdGgiLCJfNiIsIl83Iiwib2Zmc2V0SGVpZ2h0IiwiXzgiLCJfOSIsInVwZGF0ZVJlY3RhbmdsZSIsIm1vdXNlTW92ZUhhbmRsZXIiLCJfMTAiLCJfMTEiLCJhZGRFdmVudExpc3RlbmVyIiwiXzEyIiwiXzEzIiwiXzE0IiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIl8xNSIsIm1vdXNlRG93bkhhbmRsZXIiLCJidXR0b24iLCJjdXJyZW50UG9pbnRlciIsImhhc01vdmVkIiwiXzE2IiwiXzE3IiwicmVjdGFuZ2xlIiwieDEiLCJ4MiIsInkxIiwieTIiLCJyZWN0IiwiYm94UmVmIiwibW91c2VVcEhhbmRsZXIiLCJfMTgiLCJfMTkiLCJfMjAiLCJfMjEiLCJfMjIiLCJfMjMiLCJvbk1vdXNlRG93bkNhcHR1cmUiLCJvbk1vdXNlTW92ZUNhcHR1cmUiLCJkcmFnZ2FibGUiLCJmbG9hdCIsIm1heFdpZHRoIiwibWF4SGVpZ2h0IiwiQkJveFNlbGVjdG9yIiwibGVmdCIsInBvaW50ZXJFdmVudHMiLCJvcGFjaXR5IiwiQmxvY2siLCJiaW5hcnkiLCJfaWQiLCJDb250ZW50IiwiSGVhZGVyQ29udGFpbmVyIiwiQm9keUNvbnRhaW5lciIsIlRhc2tSYWRpbyIsImNoZWNrZWQiLCJJbWFnZVdyYXBwZXIiLCJzZXRPYmplY3RzIiwic2V0SGlnaGxpZ2h0SW5kZXgiLCJyZW5kZXJWYWx1ZSIsImltYWdlIiwic2V0U2VsZWN0ZWRMYWJlbCIsInNlbGVjdGVkSW5kZXgiLCJpZHgiLCJyb3ciLCJvbk1vdXNlRG93biIsImZpbHRlciIsIm92ZXJmbG93IiwiQ29udGVudENvbnRhaW5lciIsIkRyYWdIYW5kbGUiLCJhZGREcmFnZ2luZ1N0eWxlcyIsImFkZCIsInJlbW92ZURyYWdnaW5nU3R5bGVzIiwiY2xhc3NOYW1lIiwib25Nb3VzZU91dCIsIm9uTW91c2VVcCIsIkRhdGVCbG9jayIsImRhdGUiLCJyZWFkX29ubHkiLCJnZXREaXNwbGF5Rm9ybWF0IiwiRGF0ZVBpY2tlciIsIlN0eWxlZExpbmsiLCJ3aGl0ZVNwYWNlIiwid29yZFdyYXAiLCJ3b3JkQnJlYWsiLCJoaWRlRXJyb3JNZXNzYWdlIiwiaHJlZiIsIklGcmFtZSIsImVtYmVkIiwic291cmNlVXJsIiwiQnV0dG9uQmxvY2siLCJJdGVtIiwiYXNzaWduTmV4dEFuZEJhY2tWaXNpYmlsaXR5IiwiY3VycmVudElkeCIsImN1cnJlbnRUeXBlIiwibmV4dEJsb2NrSWQiLCJuZXh0QmxvY2tJbmRleCIsImlzTmV4dERpc2FibGVkIiwiaXNCYWNrRGlzYWJsZWQiLCJzZXRDdXJyZW50SWR4IiwiaGlzdG9yeSIsImN1cnJlbnRCbG9jayIsImxhc3RCbG9ja0lkIiwicG9wIiwibGFzdEJsb2NrSWR4IiwiZmluZEluZGV4IiwiY3VycmVudEJsb2NrTmFtZSIsImxvZ2ljX2p1bXAiLCJsb2dpY0Jsb2NrcyIsImhhbmRsZU5leHQiLCJpbmNsdWRlcyIsImNvbnNvbGUiLCJoYW5kbGVCYWNrIiwic3RhY2tlZElkIiwiUHJpbWFyeUJ1dHRvbiIsIkJhc2ljVGV4dEFyZWEiLCJUYXNrQ2hlY2tib3giLCJTdHlsZWRJbWciLCJhbHQiLCJ0aXRsZSIsImNvbnRyb2xzIiwiVmlkZW9QbGF5ZXIiLCJzaG93IiwiaGlkZU92ZXJmbG93IiwicHJldlNvdXJjZVVybCIsInVzZVByZXZpb3VzIiwic291cmNlcyIsImVsIiwicGxheWVyIiwiUGx5ciIsImRlc3Ryb3kiLCJDaGVja2JveCIsIk11bHRpQ2xhc3MiLCJlZGl0TW9kZSIsImdyaWRUZW1wbGF0ZVJvd3MiLCJUZXh0V3JhcHBlciIsImhpZ2hsaWdodENvbG9yIiwiYWxsb3dfZWRpdHMiLCJhbGxvd0VkaXRzIiwiZW50aXRpZXMiLCJzZXRUZXh0IiwidXNlclNlbGVjdCIsInNldFVzZXJTZWxlY3QiLCJkaXNhYmxlU2VsZWN0aW9uIiwic2V0RGlzYWJsZVNlbGVjdGlvbiIsInRvZ2dsRWRpdE1vZGUiLCJzZXRTZWxlY3RlZENhdGVnb3J5IiwicmVuZGVyVGV4dCIsInRleHRGaWVsZE5hbWUiLCJ0ZXh0RmllbGRWYWx1ZSIsInNldFRleHRGaWVsZFZhbHVlIiwiaGFuZGxlVGV4dENoYW5nZSIsImZvcm1hdEVudGl0aWVzRm9yVUlSZW5kZXJpbmciLCJlbnRpdGllc0luc3RhbmNlIiwiaXRtIiwib3B0aW9uTmFtZSIsImZpbmRPcHRpb25OYW1lRnJvbUlkIiwiaGFuZGxlQW5ub3RhdGUiLCJpbnB1dFJlZiIsImNyZWF0ZVJlZiIsImRldGFpbCIsInNldFByb3BlcnR5IiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsImdyaWRHYXAiLCJwb3NpdGlvbkVycm9yQmVsb3ciLCJzY3JvbGxhYmxlIiwid2luZG93IiwiZ2V0U2VsZWN0aW9uIiwiZW1wdHkiLCJUZXh0QW5ub3RhdG9yIiwicGFkZGluZ0xlZnQiLCJjb250ZW50IiwiZ2V0U3BhbiIsInNwYW4iLCJoaWRlRm9jdXMiLCJOdW1iZXJCbG9jayIsIm51bWJlciIsInBkZiIsInJpY2hfdGV4dCIsInJpY2hUZXh0IiwiZm9ybWF0IiwiVGV4dEVkaXRvciIsIlJhZGlvIiwiU3R5bGVkVGV4dCIsImRlY29yYXRvciIsInJlbCIsIkxpbmtpZnkiLCJjb21wb25lbnREZWNvcmF0b3IiLCJkZWxldGVfZGlzYWJsZWQiLCJlZGl0X2Rpc2FibGVkIiwib3JkZXJpbmdfZGlzYWJsZWQiLCJTZXF1ZW5jZSIsInNwbGl0V2l0aE9mZnNldHMiLCJvZmZzZXRzIiwibGFzdEVuZCIsInNwbGl0cyIsInNvcnRCeSIsIm8iLCJzdGFydCIsImVuZCIsInNsaWNlIiwibWFyayIsInNwbGl0VG9rZW5zV2l0aE9mZnNldHMiLCJqb2luIiwic2VsZWN0aW9uSXNFbXB0eSIsInNlbGVjdGlvbiIsImFuY2hvck5vZGUiLCJjb21wYXJlRG9jdW1lbnRQb3NpdGlvbiIsImZvY3VzTm9kZSIsImZvY3VzT2Zmc2V0IiwiYW5jaG9yT2Zmc2V0Iiwic2VsZWN0aW9uSXNCYWNrd2FyZHMiLCJiYWNrd2FyZCIsIk5vZGUiLCJET0NVTUVOVF9QT1NJVElPTl9QUkVDRURJTkciLCJNYXJrIiwiU3BsaXQiLCJoYW5kbGVNb3VzZVVwIiwicGFyc2VJbnQiLCJwYXJlbnRFbGVtZW50IiwiZ2V0QXR0cmlidXRlIiwiaXNJbnRlZ2VyIiwiaGFuZGxlU3BsaXRDbGljayIsInNwbGl0SW5kZXgiLCJzIiwic3BsaXQiLCJfaXNEcmFnZ2luZyIsImRyYWdnYWJsZVN0eWxlIiwidHJhbnNmb3JtIiwiYWN0aXZlVHJhbnNmb3JtIiwic3Vic3RyaW5nIiwiaW5kZXhPZiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFDQSxrQ0FBa0MsbUJBQU8sQ0FBQyw4R0FBeUQ7QUFDbkc7QUFDQTtBQUNBLGNBQWMsUUFBUyx1QkFBdUIsdUJBQXVCLGtDQUFrQyxHQUFHLG9CQUFvQiwrQkFBK0IsbUNBQW1DLEdBQUcsa0NBQWtDLG1DQUFtQyxHQUFHLDZCQUE2QixlQUFlLCtCQUErQixHQUFHLCtDQUErQyxxQkFBcUIsZUFBZSwyQkFBMkIsR0FBRywrQkFBK0IsdUJBQXVCLEdBQUcsNkNBQTZDLG9CQUFvQixpQkFBaUIsK0JBQStCLGVBQWUsOEJBQThCLDJCQUEyQiwwQkFBMEIseUJBQXlCLHNCQUFzQixHQUFHLGdEQUFnRCx1QkFBdUIsZ0JBQWdCLGlCQUFpQixrQkFBa0IsaUJBQWlCLHNCQUFzQixlQUFlLEdBQUcsdURBQXVELGtCQUFrQix1QkFBdUIsZUFBZSxnQkFBZ0IsZUFBZSxnQkFBZ0IsK0NBQStDLGdEQUFnRCxHQUFHLHFEQUFxRCxrQkFBa0IsR0FBRztBQUNyd0M7QUFDQTs7Ozs7Ozs7Ozs7O0FDTkE7QUFDQSxrQ0FBa0MsbUJBQU8sQ0FBQyw4R0FBeUQ7QUFDbkc7QUFDQTtBQUNBLGNBQWMsUUFBUyxxQkFBcUIsdUJBQXVCLEdBQUcsMkJBQTJCLHVCQUF1QixnQkFBZ0IsaUJBQWlCLGlDQUFpQyxtQ0FBbUMsMkJBQTJCLDhDQUE4Qyw4VkFBOFYsc0NBQXNDLHlCQUF5QixHQUFHLDhCQUE4QixjQUFjLFlBQVksc0JBQXNCLDZCQUE2QixHQUFHLDhCQUE4QixjQUFjLGFBQWEsc0JBQXNCLEdBQUcsOEJBQThCLFdBQVcsWUFBWSxzQkFBc0IsOEJBQThCLEdBQUcsOEJBQThCLFdBQVcsYUFBYSxzQkFBc0IsOEJBQThCLEdBQUcseURBQXlELGFBQWEsc0JBQXNCLHNCQUFzQixHQUFHLDZCQUE2QixZQUFZLDhCQUE4QixHQUFHLDZCQUE2QixhQUFhLDhCQUE4QixHQUFHLHlEQUF5RCxjQUFjLHVCQUF1QixzQkFBc0IsR0FBRyw2QkFBNkIsV0FBVyw4QkFBOEIsR0FBRyw2QkFBNkIsY0FBYyw2QkFBNkIsR0FBRztBQUNwbkQ7QUFDQTs7Ozs7Ozs7Ozs7O0FDTkE7QUFDQSxrQ0FBa0MsbUJBQU8sQ0FBQyw4R0FBeUQ7QUFDbkc7QUFDQTtBQUNBLGNBQWMsUUFBUyw0Q0FBNEMsOEJBQThCLGtCQUFrQixnQkFBZ0IsR0FBRywwREFBMEQsNEJBQTRCLEdBQUcsc0RBQXNELGVBQWUsR0FBRyxvQ0FBb0MsOEJBQThCLEdBQUcsNENBQTRDLG1DQUFtQyxHQUFHO0FBQzliO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ05BLE1BQU1BLFlBQVksR0FBRyx3RUFBckI7QUFBOEY7QUFFOUY7QUFDQTtBQUNBOztBQTBCQSxNQUFNQyxLQUFLLEdBQUc7QUFBQTtBQUFBLEdBQWEsQ0FBQztBQUFDQyxPQUFEO0FBQVFDO0FBQVIsQ0FBRCxNQUF3QjtBQUNqREMsU0FBTyxFQUFFLE9BRHdDO0FBRWpEQyxZQUFVLEVBQUUsTUFGcUM7QUFHakRDLFNBQU8sRUFBRSxNQUh3QztBQUlqREMsUUFBTSxFQUFFLENBSnlDO0FBS2pEQyxRQUFNLEVBQUcsYUFBWU4sS0FBSyxHQUFHTyxzREFBTyxDQUFDQyxVQUFYLEdBQXdCRCxzREFBTyxDQUFDRSxnQkFBaUIsRUFMMUI7QUFNakRDLFdBQVMsRUFBRSxZQU5zQztBQU9qREMsT0FBSyxFQUFFSixzREFBTyxDQUFDSyxTQVBrQztBQVFqREMsWUFBVSxFQUFFQyw2REFBVyxDQUFDQyxVQVJ5QjtBQVNqREMsWUFBVSxFQUFFLEdBVHFDO0FBVWpEQyxRQUFNLEVBQUVoQixRQUFRLEdBQUcsYUFBSCxHQUFtQixPQVZjO0FBV2pEaUIsY0FBWSxFQUFFLENBWG1DO0FBWWpEQyxVQUFRLEVBQUUsRUFadUM7QUFhakRDLFlBQVUsRUFBRSxNQWJxQztBQWNqREMsaUJBQWUsRUFBRSxNQWRnQztBQWVqREMsUUFBTSxFQUFFLEVBZnlDO0FBZ0JqREMsU0FBTyxFQUFFLFFBaEJ3QztBQWlCakRDLFlBQVUsRUFBRSw0QkFqQnFDO0FBa0JqREMsT0FBSyxFQUFFLE1BbEIwQztBQW1CakQsWUFBVTtBQUNSQyxhQUFTLEVBQUcsYUFBWTFCLEtBQUssR0FBRyxTQUFILEdBQWVPLHNEQUFPLENBQUNvQixrQkFBbUIsRUFEL0Q7QUFFUkMsZUFBVyxFQUFFNUIsS0FBSyxHQUFHTyxzREFBTyxDQUFDQyxVQUFYLEdBQXdCRCxzREFBTyxDQUFDc0I7QUFGMUM7QUFuQnVDLENBQXhCLENBQWIsQ0FBZDs7QUF5QkEsTUFBTUMsS0FBSyxHQUFHO0FBQUE7QUFBQSxHQUFXO0FBQ3ZCWCxVQUFRLEVBQUUsRUFEYTtBQUV2QkgsWUFBVSxFQUFFLEdBRlc7QUFHdkJJLFlBQVUsRUFBRSxNQUhXO0FBSXZCVCxPQUFLLEVBQUVKLHNEQUFPLENBQUNLO0FBSlEsQ0FBWCxDQUFkOztBQU9BLE1BQU1tQixXQUFXLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXBCOztBQU9BLE1BQU1DLFdBQVcsR0FBRztBQUFBO0FBQUEsR0FBVztBQUM3QmIsVUFBUSxFQUFFLEVBRG1CO0FBRTdCSCxZQUFVLEVBQUUsR0FGaUI7QUFHN0JMLE9BQUssRUFBRUosc0RBQU8sQ0FBQzBCLFNBSGM7QUFJN0JDLFlBQVUsRUFBRTtBQUppQixDQUFYLENBQXBCOztBQU9BLE1BQU1DLFVBQVUsZ0JBQUdDLHdEQUFVLENBQUMsQ0FBQ0MsS0FBRCxFQUFRQyxHQUFSLEtBQWdCO0FBQzVDLFFBQU07QUFDSkMsZ0JBREk7QUFFSkMsYUFGSTtBQUdKdkMsWUFISTtBQUlKRCxTQUpJO0FBS0p5QyxjQUxJO0FBTUpDLGNBTkk7QUFPSkMsUUFQSTtBQVFKQyxVQVJJO0FBU0pDLFdBVEk7QUFVSkMsWUFWSTtBQVdKQyxlQVhJO0FBWUpDLFFBQUksR0FBRyxNQVpIO0FBYUpDLFNBYkk7QUFjSkMsU0FkSTtBQWVKQyxTQWZJO0FBZ0JKQztBQWhCSSxNQWlCRmYsS0FqQko7QUFtQkEsc0JBQ0VnQiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CRCw0Q0FBSyxDQUFDRSxRQUExQixFQUFvQyxJQUFwQyxFQUNJTCxLQUFLLGlCQUNMRyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CdkIsV0FBcEIsRUFBaUM7QUFBQ3lCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFqQyxlQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeEIsS0FBcEIsRUFBMkI7QUFBQzBCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEzQixFQUFnR1QsS0FBaEcsQ0FESixFQUVJUixVQUFVLGlCQUFJVyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CdEIsV0FBcEIsRUFBaUM7QUFBQ3dCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFqQyxFQUFzRyxVQUF0RyxDQUZsQixFQUdJbEIsVUFBVSxpQkFBSVksNENBQUssQ0FBQ0MsYUFBTixDQUFvQnRCLFdBQXBCLEVBQWlDO0FBQUN3QixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBakMsRUFBc0csVUFBdEcsQ0FIbEIsQ0FGSixlQVFJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CdkQsS0FBcEIsRUFBMkI7QUFDM0J3QyxnQkFBWSxFQUFFQSxZQURhO0FBRTNCQyxhQUFTLEVBQUVBLFNBRmdCO0FBRzNCdkMsWUFBUSxFQUFFMkQsT0FBTyxDQUFDM0QsUUFBRCxDQUhVO0FBSTNCMEMsUUFBSSxFQUFFQSxJQUpxQjtBQUszQkksZUFBVyxFQUFFQSxXQUxjO0FBTTNCSCxVQUFNLEVBQUVBLE1BTm1CO0FBTzNCQyxXQUFPLEVBQUVBLE9BUGtCO0FBUTNCQyxZQUFRLEVBQUVBLFFBUmlCO0FBUzNCUixPQUFHLEVBQUVBLEdBVHNCO0FBVTNCVSxRQUFJLEVBQUVBLElBVnFCO0FBVzNCQyxTQUFLLEVBQUVBLEtBWG9CO0FBWTNCakQsU0FBSyxFQUFFNEQsT0FBTyxDQUFDNUQsS0FBRCxDQVphO0FBYTNCb0QsY0FBVSxFQUFFQSxVQWJlO0FBYzNCRCxTQUFLLEVBQUVBLEtBZG9CO0FBY2JLLFVBQU0sRUFBRSxTQWRLO0FBY0NDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQWRYLEdBQTNCLENBUkosRUF3QkkzRCxLQUFLLGlCQUFJcUQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQk8sOERBQXBCLEVBQWlDO0FBQUNMLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFqQyxFQUFzRzNELEtBQXRHLENBeEJiLENBREY7QUE0QkQsQ0FoRDRCLENBQTdCO0FBa0RlbUMseUVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzlIQSxNQUFNckMsWUFBWSxHQUFHLHdFQUFyQjtBQUE4RjtBQUU5RjtBQUNBOztBQXFCQSxNQUFNZ0UsT0FBTyxHQUFHO0FBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFiOztBQUlBLE1BQU1DLFVBQVUsR0FBRyxDQUFDO0FBQUNDLE1BQUQ7QUFBT0MsU0FBUDtBQUFnQkM7QUFBaEIsQ0FBRCxLQUEyQjtBQUM1QyxRQUFNQyxZQUFZLEdBQUlDLENBQUQsSUFBTztBQUMxQixVQUFNQyxJQUFJLEdBQUdELENBQUMsQ0FBQ0UsTUFBRixDQUFTckIsS0FBdEI7QUFDQWdCLFdBQU8sQ0FBQ00sZ0VBQVcsQ0FBQ1AsSUFBRCxFQUFPSyxJQUFQLEVBQWE7QUFBQ0g7QUFBRCxLQUFiLENBQVosQ0FBUDtBQUNELEdBSEQ7O0FBSUEsc0JBQ0ViLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JRLE9BQXBCLEVBQTZCO0FBQUNOLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUE3QixlQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CbkIsbURBQXBCLEVBQWdDO0FBQUVZLGVBQVcsRUFBRSxRQUFmO0FBQXlCRCxZQUFRLEVBQUVxQixZQUFuQztBQUFpRFgsVUFBTSxFQUFFLFNBQXpEO0FBQStEQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekUsR0FBaEMsQ0FESixDQURGO0FBS0QsQ0FWRDs7QUFZZUkseUVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4Q0EsTUFBTWpFLFlBQVksR0FBRywwRUFBckI7QUFBZ0c7QUFFaEc7QUFDQTtBQUVPLE1BQU0wRSxpQkFBaUIsR0FBRyxFQUExQjs7QUFRUCxNQUFNQyxTQUFTLEdBQUc7QUFBQTtBQUFBLEdBQVc7QUFDM0J2RSxTQUFPLEVBQUUsTUFEa0I7QUFFM0J3RSxlQUFhLEVBQUUsYUFGWTtBQUczQkMsWUFBVSxFQUFFLFFBSGU7QUFJM0JDLGdCQUFjLEVBQUUsZUFKVztBQUszQnJELFNBQU8sRUFBRSxRQUxrQjtBQU0zQkYsaUJBQWUsRUFBRWQsZ0VBQU8sQ0FBQ3NFLGVBTkU7QUFPM0JDLGNBQVksRUFBRyxhQUFZdkUsZ0VBQU8sQ0FBQ3dFLGVBQWdCLEVBUHhCO0FBUTNCQyxXQUFTLEVBQUVSLGlCQVJnQjtBQVMzQlMsVUFBUSxFQUFFO0FBVGlCLENBQVgsQ0FBbEI7O0FBWUEsTUFBTUMsUUFBUSxHQUFHO0FBQUE7QUFBQSxHQUFZQyxJQUFELElBQVU7QUFDcEMsU0FBTztBQUNMQyxRQUFJLEVBQUUsT0FERDtBQUVMQyxhQUFTLEVBQUVGLElBQUksQ0FBQ0csTUFBTCxHQUFjLFFBQWQsR0FBd0I7QUFGOUIsR0FBUDtBQUlELENBTGdCLENBQWpCOztBQU9BLE1BQU1DLFNBQVMsR0FBSWxELEtBQUQsSUFBVztBQUMzQixRQUFNO0FBQUNtRCxnQkFBRDtBQUFlQyxpQkFBZjtBQUE4QkM7QUFBOUIsTUFBNkNyRCxLQUFuRDtBQUNBLHNCQUNFZ0IsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm1CLFNBQXBCLEVBQStCO0FBQUNqQixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBL0IsZUFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjRCLFFBQXBCLEVBQThCO0FBQUMxQixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBOUIsRUFBa0c4QixhQUFsRyxDQURKLEVBRUksQ0FBQ0UsNEVBQVksQ0FBQ0YsYUFBRCxDQUFiLGlCQUFnQ3BDLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I0QixRQUFwQixFQUE4QjtBQUFFSSxVQUFNLEVBQUUsSUFBVjtBQUFnQjlCLFVBQU0sRUFBRSxTQUF4QjtBQUE4QkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXhDLEdBQTlCLEVBQWlIK0IsV0FBakgsQ0FGcEMsZUFHSXJDLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I0QixRQUFwQixFQUE4QjtBQUFDMUIsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTlCLEVBQWtHNkIsWUFBbEcsQ0FISixDQURGO0FBT0QsQ0FURDs7QUFXZUQsd0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDM0NBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQU16RixZQUFZLEdBQUcsK0VBQXJCOztBQUFzRyxTQUFTOEYsY0FBVCxDQUF3QkMsR0FBeEIsRUFBNkI7QUFBRSxNQUFJQyxhQUFhLEdBQUdDLFNBQXBCO0FBQStCLE1BQUk5QyxLQUFLLEdBQUc0QyxHQUFHLENBQUMsQ0FBRCxDQUFmO0FBQW9CLE1BQUlHLENBQUMsR0FBRyxDQUFSOztBQUFXLFNBQU9BLENBQUMsR0FBR0gsR0FBRyxDQUFDSSxNQUFmLEVBQXVCO0FBQUUsVUFBTUMsRUFBRSxHQUFHTCxHQUFHLENBQUNHLENBQUQsQ0FBZDtBQUFtQixVQUFNRyxFQUFFLEdBQUdOLEdBQUcsQ0FBQ0csQ0FBQyxHQUFHLENBQUwsQ0FBZDtBQUF1QkEsS0FBQyxJQUFJLENBQUw7O0FBQVEsUUFBSSxDQUFDRSxFQUFFLEtBQUssZ0JBQVAsSUFBMkJBLEVBQUUsS0FBSyxjQUFuQyxLQUFzRGpELEtBQUssSUFBSSxJQUFuRSxFQUF5RTtBQUFFLGFBQU84QyxTQUFQO0FBQW1COztBQUFDLFFBQUlHLEVBQUUsS0FBSyxRQUFQLElBQW1CQSxFQUFFLEtBQUssZ0JBQTlCLEVBQWdEO0FBQUVKLG1CQUFhLEdBQUc3QyxLQUFoQjtBQUF1QkEsV0FBSyxHQUFHa0QsRUFBRSxDQUFDbEQsS0FBRCxDQUFWO0FBQW9CLEtBQTdGLE1BQW1HLElBQUlpRCxFQUFFLEtBQUssTUFBUCxJQUFpQkEsRUFBRSxLQUFLLGNBQTVCLEVBQTRDO0FBQUVqRCxXQUFLLEdBQUdrRCxFQUFFLENBQUMsQ0FBQyxHQUFHQyxJQUFKLEtBQWFuRCxLQUFLLENBQUNvRCxJQUFOLENBQVdQLGFBQVgsRUFBMEIsR0FBR00sSUFBN0IsQ0FBZCxDQUFWO0FBQTZETixtQkFBYSxHQUFHQyxTQUFoQjtBQUE0QjtBQUFFOztBQUFDLFNBQU85QyxLQUFQO0FBQWU7O0FBQUE7QUFDem1CO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWVBLE1BQU1xRCxjQUFjLGdCQUFHQyxrREFBSSxDQUFFbEUsS0FBRCxJQUFXO0FBQ3JDLFFBQU07QUFDSm1FLFlBREk7QUFFSkMsaUJBRkk7QUFHSkMsYUFISTtBQUlKQyxTQUpJO0FBS0pDLFNBTEk7QUFNSkMsWUFOSTtBQU9KMUMsZ0JBUEk7QUFRSjJDLGNBUkk7QUFTSkMsVUFUSTtBQVVKQztBQVZJLE1BV0YzRSxLQUFLLElBQUksRUFYYjtBQVlBLE1BQUk0RSxTQUFKOztBQUVBLFVBQVFMLEtBQUssQ0FBQzVELElBQWQ7QUFDRSxTQUFLa0Usb0VBQVUsQ0FBQ0MsSUFBaEI7QUFDRUYsZUFBUyxnQkFDUDVELDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I4RCx3RUFBcEIsRUFBMEI7QUFDeEJaLGdCQUFRLEVBQUVBLFFBRGM7QUFFeEJFLGlCQUFTLEVBQUVBLFNBRmE7QUFHeEJDLGFBQUssRUFBRUEsS0FIaUI7QUFJeEJDLGFBQUssRUFBRUEsS0FKaUI7QUFLeEJDLGdCQUFRLEVBQUVBLFFBTGM7QUFNeEJFLGNBQU0sRUFBRUEsTUFOZ0I7QUFPeEI1QyxvQkFBWSxFQUFFQSxZQVBVO0FBT0lYLGNBQU0sRUFBRSxTQVBaO0FBT2tCQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsb0JBQVUsRUFBRTtBQUFyQztBQVA1QixPQUExQixDQURGO0FBV0E7O0FBQ0YsU0FBS3VELG9FQUFVLENBQUNHLEtBQWhCO0FBQ0VKLGVBQVMsZ0JBQ1A1RCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CZ0UseUVBQXBCLEVBQTJCO0FBQ3pCZCxnQkFBUSxFQUFFQSxRQURlO0FBRXpCRSxpQkFBUyxFQUFFQSxTQUZjO0FBR3pCQyxhQUFLLEVBQUVBLEtBSGtCO0FBSXpCQyxhQUFLLEVBQUVBLEtBSmtCO0FBS3pCNUcsYUFBSyxFQUFFNEYsY0FBYyxDQUFDLENBQUNvQixNQUFELEVBQVMsZ0JBQVQsRUFBMkJPLENBQUMsSUFBSUEsQ0FBQyxDQUFDQyxLQUFsQyxDQUFELENBTEk7QUFNekJYLGdCQUFRLEVBQUVBLFFBTmU7QUFPekJFLGNBQU0sRUFBRUEsTUFQaUI7QUFRekI1QyxvQkFBWSxFQUFFQSxZQVJXO0FBU3pCMkMsa0JBQVUsRUFBRUEsVUFUYTtBQVNEdEQsY0FBTSxFQUFFLFNBVFA7QUFTYUMsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELG9CQUFVLEVBQUU7QUFBckM7QUFUdkIsT0FBM0IsQ0FERjtBQWFBOztBQUNGLFNBQUt1RCxvRUFBVSxDQUFDTyxNQUFoQjtBQUNFUixlQUFTLGdCQUNQNUQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm9FLDBFQUFwQixFQUE0QjtBQUMxQmxCLGdCQUFRLEVBQUVBLFFBRGdCO0FBRTFCRSxpQkFBUyxFQUFFQSxTQUZlO0FBRzFCQyxhQUFLLEVBQUVBLEtBSG1CO0FBSTFCQyxhQUFLLEVBQUVBLEtBSm1CO0FBSzFCQyxnQkFBUSxFQUFFQSxRQUxnQjtBQU0xQkUsY0FBTSxFQUFFQSxNQU5rQjtBQU8xQjVDLG9CQUFZLEVBQUVBLFlBUFk7QUFPRVgsY0FBTSxFQUFFLFNBUFY7QUFPZ0JDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxvQkFBVSxFQUFFO0FBQXJDO0FBUDFCLE9BQTVCLENBREY7QUFXQTs7QUFDRixTQUFLdUQsb0VBQVUsQ0FBQ1MsSUFBaEI7QUFDRVYsZUFBUyxnQkFDUDVELDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JzRSx3RUFBcEIsRUFBMEI7QUFDeEJwQixnQkFBUSxFQUFFQSxRQURjO0FBRXhCRSxpQkFBUyxFQUFFQSxTQUZhO0FBR3hCQyxhQUFLLEVBQUVBLEtBSGlCO0FBSXhCQyxhQUFLLEVBQUVBLEtBSmlCO0FBS3hCNUcsYUFBSyxFQUFFNEYsY0FBYyxDQUFDLENBQUNvQixNQUFELEVBQVMsZ0JBQVQsRUFBMkJhLEVBQUUsSUFBSUEsRUFBRSxDQUFDQyxJQUFwQyxDQUFELENBTEc7QUFNeEJqQixnQkFBUSxFQUFFQSxRQU5jO0FBT3hCRSxjQUFNLEVBQUVBLE1BUGdCO0FBUXhCNUMsb0JBQVksRUFBRUEsWUFSVTtBQVN4QjJDLGtCQUFVLEVBQUVBLFVBVFk7QUFTQXRELGNBQU0sRUFBRSxTQVRSO0FBU2NDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxvQkFBVSxFQUFFO0FBQXJDO0FBVHhCLE9BQTFCLENBREY7QUFhQTs7QUFDRixTQUFLdUQsb0VBQVUsQ0FBQ2EsS0FBaEI7QUFDRWQsZUFBUyxnQkFDUDVELDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IwRSx5RUFBcEIsRUFBMkI7QUFDekJ4QixnQkFBUSxFQUFFQSxRQURlO0FBRXpCRSxpQkFBUyxFQUFFQSxTQUZjO0FBR3pCRSxhQUFLLEVBQUVBLEtBSGtCO0FBSXpCQyxnQkFBUSxFQUFFQSxRQUplO0FBS3pCRSxjQUFNLEVBQUVBLE1BTGlCO0FBS1R2RCxjQUFNLEVBQUUsU0FMQztBQUtLQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsb0JBQVUsRUFBRTtBQUFyQztBQUxmLE9BQTNCLENBREY7QUFTQTs7QUFDRixTQUFLdUQsb0VBQVUsQ0FBQ2UsS0FBaEI7QUFDRWhCLGVBQVMsZ0JBQ1A1RCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CNEUsOEVBQXBCLEVBQWdDO0FBQzlCMUIsZ0JBQVEsRUFBRUEsUUFEb0I7QUFFOUJFLGlCQUFTLEVBQUVBLFNBRm1CO0FBRzlCRSxhQUFLLEVBQUVBLEtBSHVCO0FBSTlCQyxnQkFBUSxFQUFFQSxRQUpvQjtBQUs5QkUsY0FBTSxFQUFFQSxNQUxzQjtBQUtkdkQsY0FBTSxFQUFFLFNBTE07QUFLQUMsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELG9CQUFVLEVBQUU7QUFBckM7QUFMVixPQUFoQyxDQURGO0FBU0E7O0FBQ0YsU0FBS3VELG9FQUFVLENBQUNpQixLQUFoQjtBQUNFbEIsZUFBUyxnQkFDUDVELDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I0RSw4RUFBcEIsRUFBZ0M7QUFDOUIxQixnQkFBUSxFQUFFQSxRQURvQjtBQUU5QkUsaUJBQVMsRUFBRUEsU0FGbUI7QUFHOUJFLGFBQUssRUFBRUEsS0FIdUI7QUFJOUJDLGdCQUFRLEVBQUVBLFFBSm9CO0FBSzlCRSxjQUFNLEVBQUVBLE1BTHNCO0FBS2R2RCxjQUFNLEVBQUUsU0FMTTtBQUtBQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsb0JBQVUsRUFBRTtBQUFyQztBQUxWLE9BQWhDLENBREY7QUFTQTs7QUFDRixTQUFLdUQsb0VBQVUsQ0FBQ2tCLE1BQWhCO0FBQ0VuQixlQUFTLGdCQUNQNUQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQitFLDBFQUFwQixFQUE0QjtBQUMxQjdCLGdCQUFRLEVBQUVBLFFBRGdCO0FBRTFCRSxpQkFBUyxFQUFFQSxTQUZlO0FBRzFCQyxhQUFLLEVBQUVBLEtBSG1CO0FBSTFCQyxhQUFLLEVBQUVBLEtBSm1CO0FBSzFCRyxjQUFNLEVBQUVBLE1BTGtCO0FBTTFCRixnQkFBUSxFQUFFQSxRQU5nQjtBQU8xQjFDLG9CQUFZLEVBQUVBLFlBUFk7QUFRMUJzQyxxQkFBYSxFQUFFQSxhQVJXO0FBUUlqRCxjQUFNLEVBQUUsU0FSWjtBQVFrQkMsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELG9CQUFVLEVBQUU7QUFBckM7QUFSNUIsT0FBNUIsQ0FERjtBQVlBOztBQUNGLFNBQUt1RCxvRUFBVSxDQUFDb0Isd0JBQWhCO0FBQ0VyQixlQUFTLGdCQUNQNUQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQmlGLDJGQUFwQixFQUE0QztBQUMxQy9CLGdCQUFRLEVBQUVBLFFBRGdDO0FBRTFDRSxpQkFBUyxFQUFFQSxTQUYrQjtBQUcxQ0MsYUFBSyxFQUFFQSxLQUhtQztBQUkxQ0MsYUFBSyxFQUFFQSxLQUptQztBQUsxQ0csY0FBTSxFQUFFQSxNQUxrQztBQU0xQy9HLGFBQUssRUFBRWdILE1BTm1DO0FBTzFDSCxnQkFBUSxFQUFFQSxRQVBnQztBQVExQzFDLG9CQUFZLEVBQUVBLFlBUjRCO0FBUzFDc0MscUJBQWEsRUFBRUEsYUFUMkI7QUFTWmpELGNBQU0sRUFBRSxTQVRJO0FBU0VDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxvQkFBVSxFQUFFO0FBQXJDO0FBVFosT0FBNUMsQ0FERjtBQWFBOztBQUNGLFNBQUt1RCxvRUFBVSxDQUFDc0IsY0FBaEI7QUFDRXZCLGVBQVMsZ0JBQ1A1RCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CbUYsa0ZBQXBCLEVBQW1DO0FBQ2pDakMsZ0JBQVEsRUFBRUEsUUFEdUI7QUFFakNFLGlCQUFTLEVBQUVBLFNBRnNCO0FBR2pDRSxhQUFLLEVBQUVBLEtBSDBCO0FBSWpDRCxhQUFLLEVBQUVBLEtBSjBCO0FBS2pDRSxnQkFBUSxFQUFFQSxRQUx1QjtBQU1qQ0UsY0FBTSxFQUFFQSxNQU55QjtBQU9qQzVDLG9CQUFZLEVBQUVBLFlBUG1CO0FBUWpDc0MscUJBQWEsRUFBRUEsYUFSa0I7QUFRSGpELGNBQU0sRUFBRSxTQVJMO0FBUVdDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxvQkFBVSxFQUFFO0FBQXJDO0FBUnJCLE9BQW5DLENBREY7QUFZQTs7QUFDRixTQUFLdUQsb0VBQVUsQ0FBQ3dCLEtBQWhCO0FBQ0V6QixlQUFTLGdCQUNQNUQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnFGLHlFQUFwQixFQUEyQjtBQUN6Qm5DLGdCQUFRLEVBQUVBLFFBRGU7QUFFekJFLGlCQUFTLEVBQUVBLFNBRmM7QUFHekJDLGFBQUssRUFBRUEsS0FIa0I7QUFJekJDLGFBQUssRUFBRUEsS0FKa0I7QUFLekJHLGNBQU0sRUFBRUEsTUFMaUI7QUFNekIvRyxhQUFLLEVBQUVnSCxNQU5rQjtBQU96QkgsZ0JBQVEsRUFBRUEsUUFQZTtBQVF6QjFDLG9CQUFZLEVBQUVBLFlBUlc7QUFTekJzQyxxQkFBYSxFQUFFQSxhQVRVO0FBU0tqRCxjQUFNLEVBQUUsU0FUYjtBQVNtQkMsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELG9CQUFVLEVBQUU7QUFBckM7QUFUN0IsT0FBM0IsQ0FERjtBQWFBOztBQUNGLFNBQUt1RCxvRUFBVSxDQUFDMEIsR0FBaEI7QUFDRTNCLGVBQVMsZ0JBQ1A1RCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CdUYsOEVBQXBCLEVBQStCO0FBQzdCckMsZ0JBQVEsRUFBRUEsUUFEbUI7QUFFN0JFLGlCQUFTLEVBQUVBLFNBRmtCO0FBRzdCQyxhQUFLLEVBQUVBLEtBSHNCO0FBSTdCQyxhQUFLLEVBQUVBLEtBSnNCO0FBSzdCRyxjQUFNLEVBQUVBLE1BTHFCO0FBTTdCL0csYUFBSyxFQUFFZ0gsTUFOc0I7QUFPN0JILGdCQUFRLEVBQUVBLFFBUG1CO0FBUTdCMUMsb0JBQVksRUFBRUEsWUFSZTtBQVM3QnNDLHFCQUFhLEVBQUVBLGFBVGM7QUFTQ2pELGNBQU0sRUFBRSxTQVRUO0FBU2VDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxvQkFBVSxFQUFFO0FBQXJDO0FBVHpCLE9BQS9CLENBREY7QUFhQTs7QUFDRixTQUFLdUQsb0VBQVUsQ0FBQzRCLGdCQUFoQjtBQUNFN0IsZUFBUyxnQkFDUDVELDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5RixvRkFBcEIsRUFBcUM7QUFDbkN2QyxnQkFBUSxFQUFFQSxRQUR5QjtBQUVuQ0UsaUJBQVMsRUFBRUEsU0FGd0I7QUFHbkNDLGFBQUssRUFBRUEsS0FINEI7QUFJbkNDLGFBQUssRUFBRUEsS0FKNEI7QUFLbkNHLGNBQU0sRUFBRUEsTUFMMkI7QUFNbkNGLGdCQUFRLEVBQUVBLFFBTnlCO0FBT25DMUMsb0JBQVksRUFBRUEsWUFQcUI7QUFPUFgsY0FBTSxFQUFFLFNBUEQ7QUFPT0MsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELG9CQUFVLEVBQUU7QUFBckM7QUFQakIsT0FBckMsQ0FERjtBQVdBOztBQUNGLFNBQUt1RCxvRUFBVSxDQUFDOEIsa0JBQWhCO0FBQ0UvQixlQUFTLGdCQUNQNUQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjJGLHNGQUFwQixFQUF1QztBQUNyQ3pDLGdCQUFRLEVBQUVBLFFBRDJCO0FBRXJDRSxpQkFBUyxFQUFFQSxTQUYwQjtBQUdyQ0MsYUFBSyxFQUFFQSxLQUg4QjtBQUlyQ0MsYUFBSyxFQUFFQSxLQUo4QjtBQUtyQ0csY0FBTSxFQUFFQSxNQUw2QjtBQU1yQ0YsZ0JBQVEsRUFBRUEsUUFOMkI7QUFPckMxQyxvQkFBWSxFQUFFQSxZQVB1QjtBQU9UWCxjQUFNLEVBQUUsU0FQQztBQU9LQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsb0JBQVUsRUFBRTtBQUFyQztBQVBmLE9BQXZDLENBREY7QUFXQTs7QUFDRixTQUFLdUQsb0VBQVUsQ0FBQ2dDLGFBQWhCO0FBQ0VqQyxlQUFTLGdCQUNQNUQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjZGLGlGQUFwQixFQUFrQztBQUNoQzNDLGdCQUFRLEVBQUVBLFFBRHNCO0FBRWhDRSxpQkFBUyxFQUFFQSxTQUZxQjtBQUdoQ0MsYUFBSyxFQUFFQSxLQUh5QjtBQUloQ0MsYUFBSyxFQUFFQSxLQUp5QjtBQUtoQ0csY0FBTSxFQUFFQSxNQUx3QjtBQU1oQ0YsZ0JBQVEsRUFBRUEsUUFOc0I7QUFPaEMxQyxvQkFBWSxFQUFFQSxZQVBrQjtBQVFoQ3NDLHFCQUFhLEVBQUVBLGFBUmlCO0FBUUZqRCxjQUFNLEVBQUUsU0FSTjtBQVFZQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsb0JBQVUsRUFBRTtBQUFyQztBQVJ0QixPQUFsQyxDQURGO0FBWUE7O0FBQ0YsU0FBS3VELG9FQUFVLENBQUNrQyxTQUFoQjtBQUNFbkMsZUFBUyxnQkFDUDVELDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IrRixtRkFBcEIsRUFBb0M7QUFDbEM3QyxnQkFBUSxFQUFFQSxRQUR3QjtBQUVsQ0UsaUJBQVMsRUFBRUEsU0FGdUI7QUFHbENDLGFBQUssRUFBRUEsS0FIMkI7QUFJbENDLGFBQUssRUFBRUEsS0FKMkI7QUFLbENDLGdCQUFRLEVBQUVBLFFBTHdCO0FBTWxDRSxjQUFNLEVBQUVBLE1BTjBCO0FBT2xDTixxQkFBYSxFQUFFQSxhQVBtQjtBQU9KakQsY0FBTSxFQUFFLFNBUEo7QUFPVUMsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELG9CQUFVLEVBQUU7QUFBckM7QUFQcEIsT0FBcEMsQ0FERjtBQVdBOztBQUNGLFNBQUt1RCxvRUFBVSxDQUFDb0MsYUFBaEI7QUFDRXJDLGVBQVMsZ0JBQ1A1RCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CaUcsaUZBQXBCLEVBQWtDO0FBQ2hDL0MsZ0JBQVEsRUFBRUEsUUFEc0I7QUFFaENFLGlCQUFTLEVBQUVBLFNBRnFCO0FBR2hDQyxhQUFLLEVBQUVBLEtBSHlCO0FBSWhDQyxhQUFLLEVBQUVBLEtBSnlCO0FBS2hDQyxnQkFBUSxFQUFFQSxRQUxzQjtBQU1oQ0UsY0FBTSxFQUFFQSxNQU53QjtBQU9oQzVDLG9CQUFZLEVBQUVBLFlBUGtCO0FBUWhDc0MscUJBQWEsRUFBRUEsYUFSaUI7QUFRRmpELGNBQU0sRUFBRSxTQVJOO0FBUVlDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxvQkFBVSxFQUFFO0FBQXJDO0FBUnRCLE9BQWxDLENBREY7QUFZQTs7QUFDRixTQUFLdUQsb0VBQVUsQ0FBQ3NDLElBQWhCO0FBQ0V2QyxlQUFTLGdCQUNQNUQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm1HLHlFQUFwQixFQUEwQjtBQUN4QmpELGdCQUFRLEVBQUVBLFFBRGM7QUFFeEJFLGlCQUFTLEVBQUVBLFNBRmE7QUFHeEJDLGFBQUssRUFBRUEsS0FIaUI7QUFJeEJDLGFBQUssRUFBRUEsS0FKaUI7QUFLeEJDLGdCQUFRLEVBQUVBLFFBTGM7QUFNeEJFLGNBQU0sRUFBRUEsTUFOZ0I7QUFPeEI1QyxvQkFBWSxFQUFFQSxZQVBVO0FBUXhCc0MscUJBQWEsRUFBRUEsYUFSUztBQVFNakQsY0FBTSxFQUFFLFNBUmQ7QUFRb0JDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxvQkFBVSxFQUFFO0FBQXJDO0FBUjlCLE9BQTFCLENBREY7QUFZQTs7QUFDRjtBQUNFc0QsZUFBUyxHQUFHLElBQVo7QUFyUEo7O0FBdVBBLFNBQU9BLFNBQVA7QUFDRCxDQXZRMEIsQ0FBM0I7QUF5UWVYLDZFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzU0EsTUFBTXhHLFlBQVksR0FBRyw0RUFBckI7O0FBQW1HLFNBQVM4RixjQUFULENBQXdCQyxHQUF4QixFQUE2QjtBQUFFLE1BQUlDLGFBQWEsR0FBR0MsU0FBcEI7QUFBK0IsTUFBSTlDLEtBQUssR0FBRzRDLEdBQUcsQ0FBQyxDQUFELENBQWY7QUFBb0IsTUFBSUcsQ0FBQyxHQUFHLENBQVI7O0FBQVcsU0FBT0EsQ0FBQyxHQUFHSCxHQUFHLENBQUNJLE1BQWYsRUFBdUI7QUFBRSxVQUFNQyxFQUFFLEdBQUdMLEdBQUcsQ0FBQ0csQ0FBRCxDQUFkO0FBQW1CLFVBQU1HLEVBQUUsR0FBR04sR0FBRyxDQUFDRyxDQUFDLEdBQUcsQ0FBTCxDQUFkO0FBQXVCQSxLQUFDLElBQUksQ0FBTDs7QUFBUSxRQUFJLENBQUNFLEVBQUUsS0FBSyxnQkFBUCxJQUEyQkEsRUFBRSxLQUFLLGNBQW5DLEtBQXNEakQsS0FBSyxJQUFJLElBQW5FLEVBQXlFO0FBQUUsYUFBTzhDLFNBQVA7QUFBbUI7O0FBQUMsUUFBSUcsRUFBRSxLQUFLLFFBQVAsSUFBbUJBLEVBQUUsS0FBSyxnQkFBOUIsRUFBZ0Q7QUFBRUosbUJBQWEsR0FBRzdDLEtBQWhCO0FBQXVCQSxXQUFLLEdBQUdrRCxFQUFFLENBQUNsRCxLQUFELENBQVY7QUFBb0IsS0FBN0YsTUFBbUcsSUFBSWlELEVBQUUsS0FBSyxNQUFQLElBQWlCQSxFQUFFLEtBQUssY0FBNUIsRUFBNEM7QUFBRWpELFdBQUssR0FBR2tELEVBQUUsQ0FBQyxDQUFDLEdBQUdDLElBQUosS0FBYW5ELEtBQUssQ0FBQ29ELElBQU4sQ0FBV1AsYUFBWCxFQUEwQixHQUFHTSxJQUE3QixDQUFkLENBQVY7QUFBNkROLG1CQUFhLEdBQUdDLFNBQWhCO0FBQTRCO0FBQUU7O0FBQUMsU0FBTzlDLEtBQVA7QUFBZTs7QUFBQTtBQUd0bUI7QUFDQTtBQUNBO0FBQ0E7QUFTTyxNQUFNd0IsU0FBUyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFsQjs7QUFXUCxNQUFNaUYsVUFBVSxHQUFHLGtGQUFPQyxpRUFBUDtBQUFBO0FBQUEsR0FBYTtBQUM5QnRFLFdBQVMsRUFBRSxRQURtQjtBQUU5Qm5GLFNBQU8sRUFBRSxPQUZxQjtBQUc5QmlCLFVBQVEsRUFBRSxFQUhvQjtBQUk5QlIsT0FBSyxFQUFFSiw2REFBTyxDQUFDc0I7QUFKZSxDQUFiLENBQW5COztBQU9BLE1BQU0rSCxRQUFRLEdBQUcsa0ZBQU9GLFVBQVA7QUFBQTtBQUFBLEdBQW1CO0FBQ2xDL0ksT0FBSyxFQUFFSiw2REFBTyxDQUFDc0osbUJBRG1CO0FBRWxDNUksUUFBTSxFQUFFO0FBRjBCLENBQW5CLENBQWpCOztBQUtBLE1BQU02SSxXQUFXLEdBQUl6SCxLQUFELElBQVc7QUFDN0IsUUFBTTtBQUFDd0UsWUFBRDtBQUFXRSxVQUFYO0FBQW1CTCxhQUFuQjtBQUE4QnFEO0FBQTlCLE1BQTJDMUgsS0FBakQ7QUFDQSxzQkFDRWdCLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JDLDhDQUFwQixFQUE4QjtBQUFDQyxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBOUIsRUFDSStDLFNBQVMsaUJBQ1RyRCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CbUIsU0FBcEIsRUFBK0I7QUFBQ2pCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEvQixlQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMEcsdUVBQXBCLEVBQWdDO0FBQUVoSCxRQUFJLEVBQUUsUUFBUjtBQUFrQmlILFdBQU8sRUFBRWxELE1BQTNCO0FBQW1DdkQsVUFBTSxFQUFFLFNBQTNDO0FBQWlEQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBM0QsR0FBaEMsZUFDRU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQm9HLFVBQXBCLEVBQWdDO0FBQUNsRyxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBaEMsRUFBb0csVUFBcEcsQ0FERixDQURKLGVBSUlOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IwRyx1RUFBcEIsRUFBZ0M7QUFBRWhILFFBQUksRUFBRSxRQUFSO0FBQWtCaUgsV0FBTyxFQUFFcEQsUUFBM0I7QUFBcUNyRCxVQUFNLEVBQUUsU0FBN0M7QUFBbURDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUE3RCxHQUFoQyxlQUNFTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cb0csVUFBcEIsRUFBZ0M7QUFBQ2xHLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFoQyxFQUFvRyxRQUFwRyxDQURGLENBSkosQ0FGSixlQVdJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc0csUUFBcEIsRUFBOEI7QUFBQ3BHLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUE5QixFQUFrR2lDLGNBQWMsQ0FBQyxDQUFDc0UsZ0VBQUQsRUFBUyxRQUFULEVBQW1CM0MsQ0FBQyxJQUFJQSxDQUFDLENBQUM0QyxJQUExQixFQUFnQyxNQUFoQyxFQUF3Q3RDLEVBQUUsSUFBSUEsRUFBRSxDQUFDdUMsQ0FBQyxJQUFJQSxDQUFDLENBQUNwSCxJQUFGLEtBQVcrRyxTQUFqQixDQUFoRCxFQUE2RSxnQkFBN0UsRUFBK0ZNLEVBQUUsSUFBSUEsRUFBRSxDQUFDQyxJQUF4RyxDQUFELENBQWhILENBWEosQ0FERjtBQWVELENBakJEOztBQW1CZVIsMEVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZEQSxNQUFNUyxZQUFZLEdBQUc7QUFBQTtBQUFBLEdBQVcsQ0FBQztBQUFDdkgsTUFBRDtBQUFPMkQ7QUFBUCxDQUFELE1BQW9CO0FBQ2xEbEYsT0FBSyxFQUFFLE1BRDJDO0FBRWxESixpQkFBZSxFQUFFLGlCQUZpQztBQUdsREgsY0FBWSxFQUFFLENBSG9DO0FBSWxEWixRQUFNLEVBQUUsbUJBSjBDO0FBS2xEb0IsV0FBUyxFQUFFLGtDQUx1QztBQU1sRDhJLFFBQU0sRUFBRXhILElBQUksS0FBSyxNQUFULEdBQWtCLEtBQUsyRCxLQUF2QixHQUErQjtBQU5XLENBQXBCLENBQVgsQ0FBckI7O0FBU2U0RCwyRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWEEsTUFBTXpLLFlBQVksR0FBRywyRUFBckI7QUFBaUc7QUFFakc7QUFDQTs7QUFTQSxNQUFNMkUsU0FBUyxHQUFHLGtGQUFPZ0cscUVBQVA7QUFBQTtBQUFBLEdBQW9CO0FBQ3BDeEosUUFBTSxFQUFFLFNBRDRCO0FBRXBDSSxpQkFBZSxFQUFFLFNBRm1CO0FBR3BDbkIsU0FBTyxFQUFFLE1BSDJCO0FBSXBDeUUsWUFBVSxFQUFFLFFBSndCO0FBS3BDQyxnQkFBYyxFQUFFLFFBTG9CO0FBTXBDMUQsY0FBWSxFQUFFLEVBTnNCO0FBT3BDTyxPQUFLLEVBQUUsRUFQNkI7QUFRcENILFFBQU0sRUFBRSxFQVI0QjtBQVNwQ0MsU0FBTyxFQUFFLENBVDJCO0FBVXBDbEIsUUFBTSxFQUFFLENBVjRCO0FBV3BDbUIsWUFBVSxFQUFFLG1CQVh3QjtBQVlwQyxZQUFVO0FBQ1JiLFNBQUssRUFBRUosZ0VBQU8sQ0FBQ3NCO0FBRFA7QUFaMEIsQ0FBcEIsQ0FBbEI7O0FBaUJBLE1BQU1tSSxVQUFVLGdCQUFHNUgsd0RBQVUsQ0FBQyxDQUFDQyxLQUFELEVBQVFDLEdBQVIsS0FBZ0I7QUFDNUMsUUFBTTtBQUFDMkgsV0FBRDtBQUFVakgsUUFBVjtBQUFnQjBILFlBQWhCO0FBQTBCdkg7QUFBMUIsTUFBbUNkLEtBQXpDO0FBQ0Esc0JBQ0VnQiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CbUIsU0FBcEIsRUFBK0I7QUFBRW5DLE9BQUcsRUFBRUEsR0FBUDtBQUFZMkgsV0FBTyxFQUFFQSxPQUFyQjtBQUE4QmpILFFBQUksRUFBRUEsSUFBcEM7QUFBMENHLFNBQUssRUFBRUEsS0FBakQ7QUFBd0RLLFVBQU0sRUFBRSxTQUFoRTtBQUFzRUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQWhGLEdBQS9CLEVBQ0krRyxRQURKLENBREY7QUFLRCxDQVA0QixDQUE3QjtBQVNlVix5RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdENBLE1BQU1sSyxZQUFZLEdBQUcsb0VBQXJCO0FBQTBGO0FBRTFGO0FBR0E7QUFDQTtBQUNBO0FBRUEsTUFBTTZLLGdCQUFnQixHQUFHQyx1RUFBYSxDQUFDQyw0REFBRCxDQUF0QztBQUNPLE1BQU1DLFdBQVcsR0FBRyxFQUFwQjtBQUNBLE1BQU1DLFFBQVEsR0FBRyxFQUFqQjs7QUFlUCxNQUFNQyxZQUFZLEdBQUcsa0ZBQU9MLGdCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFyQjs7QUFNQSxNQUFNTSxVQUFVLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQW5COztBQU1BLE1BQU1DLEdBQUcsR0FBSTdJLEtBQUQsSUFBVztBQUNyQixRQUFNO0FBQ0pxSSxZQURJO0FBRUpTLGVBRkk7QUFHSkMsZUFISTtBQUlKQyxlQUpJO0FBS0pDLGVBTEk7QUFNSkMsY0FOSTtBQU9KQyxVQVBJO0FBUUpDLGtCQVJJO0FBU0pDLFdBVEk7QUFVSkM7QUFWSSxNQVdGdEosS0FYSjtBQVlBLHNCQUNFZ0IsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjJILFVBQXBCLEVBQWdDO0FBQUN6SCxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBaEMsZUFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjBILFlBQXBCLGtDQUNHM0ksS0FESDtBQUVBdUosWUFBUSxFQUFFLElBRlY7QUFHQUMsZUFBVyxFQUFFO0FBQUNDLFNBQUcsRUFBRWhCO0FBQU4sS0FIYjtBQUlBaUIsUUFBSSxFQUFFO0FBQUNELFNBQUcsRUFBRWhCO0FBQU4sS0FKTjtBQUtBa0IsZUFBVyxFQUFFLFVBTGI7QUFNQWIsZUFBVyxFQUFFQSxXQU5iO0FBT0FDLGVBQVcsRUFBRUEsV0FQYjtBQVFBYSxhQUFTLEVBQUUsSUFSWDtBQVNBTixnQkFBWSxFQUFFQSxZQVRkO0FBVUFOLGVBQVcsRUFBRUEsV0FWYjtBQVdBSyxXQUFPLEVBQUU7QUFBQ0ksU0FBRyxFQUFFSjtBQUFOLEtBWFQ7QUFZQVEsc0JBQWtCLEVBQUUsSUFacEI7QUFhQUMsb0JBQWdCLEVBQUUsSUFibEI7QUFjQUMsb0JBQWdCLEVBQUUsS0FkbEI7QUFlQUMsb0JBQWdCLEVBQUUsQ0FBQyxFQUFELEVBQUssRUFBTCxDQWZsQjtBQWdCQWhNLFVBQU0sRUFBRSxDQUFDLEVBQUQsRUFBSyxFQUFMLENBaEJSO0FBaUJBaUwsZUFBVyxFQUFFQSxXQWpCYjtBQWtCQUMsY0FBVSxFQUFFQSxVQWxCWjtBQW1CQUMsVUFBTSxFQUFFQSxNQW5CUjtBQW9CQWMsYUFBUyxFQUFFdkIsUUFwQlg7QUFxQkFVLGtCQUFjLEVBQUVBLGNBckJoQjtBQXNCQWMsbUJBQWUsRUFBRSxjQXRCakI7QUFzQmlDL0ksVUFBTSxFQUFFLFNBdEJ6QztBQXNCK0NDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQXRCekQsTUF3QkUrRyxRQXhCRixDQURKLENBREY7QUE4QkQsQ0EzQ0Q7O0FBNkNlUSxrRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuRkEsTUFBTXBMLFlBQVksR0FBRyxvRkFBckI7O0FBQTJHLFNBQVM4RixjQUFULENBQXdCQyxHQUF4QixFQUE2QjtBQUFFLE1BQUlDLGFBQWEsR0FBR0MsU0FBcEI7QUFBK0IsTUFBSTlDLEtBQUssR0FBRzRDLEdBQUcsQ0FBQyxDQUFELENBQWY7QUFBb0IsTUFBSUcsQ0FBQyxHQUFHLENBQVI7O0FBQVcsU0FBT0EsQ0FBQyxHQUFHSCxHQUFHLENBQUNJLE1BQWYsRUFBdUI7QUFBRSxVQUFNQyxFQUFFLEdBQUdMLEdBQUcsQ0FBQ0csQ0FBRCxDQUFkO0FBQW1CLFVBQU1HLEVBQUUsR0FBR04sR0FBRyxDQUFDRyxDQUFDLEdBQUcsQ0FBTCxDQUFkO0FBQXVCQSxLQUFDLElBQUksQ0FBTDs7QUFBUSxRQUFJLENBQUNFLEVBQUUsS0FBSyxnQkFBUCxJQUEyQkEsRUFBRSxLQUFLLGNBQW5DLEtBQXNEakQsS0FBSyxJQUFJLElBQW5FLEVBQXlFO0FBQUUsYUFBTzhDLFNBQVA7QUFBbUI7O0FBQUMsUUFBSUcsRUFBRSxLQUFLLFFBQVAsSUFBbUJBLEVBQUUsS0FBSyxnQkFBOUIsRUFBZ0Q7QUFBRUosbUJBQWEsR0FBRzdDLEtBQWhCO0FBQXVCQSxXQUFLLEdBQUdrRCxFQUFFLENBQUNsRCxLQUFELENBQVY7QUFBb0IsS0FBN0YsTUFBbUcsSUFBSWlELEVBQUUsS0FBSyxNQUFQLElBQWlCQSxFQUFFLEtBQUssY0FBNUIsRUFBNEM7QUFBRWpELFdBQUssR0FBR2tELEVBQUUsQ0FBQyxDQUFDLEdBQUdDLElBQUosS0FBYW5ELEtBQUssQ0FBQ29ELElBQU4sQ0FBV1AsYUFBWCxFQUEwQixHQUFHTSxJQUE3QixDQUFkLENBQVY7QUFBNkROLG1CQUFhLEdBQUdDLFNBQWhCO0FBQTRCO0FBQUU7O0FBQUMsU0FBTzlDLEtBQVA7QUFBZTs7QUFBQTtBQUU5bUI7QUFDQTtBQUNBO0FBQ0E7O0FBYUEsTUFBTXVKLFdBQVcsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBcEI7O0FBTUEsTUFBTUMsSUFBSSxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFiOztBQUlBLE1BQU1DLFNBQVMsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBbEI7O0FBS0EsTUFBTUMsY0FBYyxHQUFHO0FBQUE7QUFBQSxHQUFZLENBQUM7QUFBQ0M7QUFBRCxDQUFELE1BQWU7QUFDaEQzTCxRQUFNLEVBQUUsU0FEd0M7QUFFaEQ0TCxZQUFVLEVBQUUsT0FGb0M7QUFHaERDLE9BQUssRUFBRSxNQUh5QztBQUloRHJMLE9BQUssRUFBRSxNQUp5QztBQUtoRHNMLGNBQVksRUFBRSxLQUxrQztBQU1oRHhMLFNBQU8sRUFBRSxXQU51QztBQU9oRDhELFdBQVMsRUFBRSxNQVBxQztBQVFoRC9FLFFBQU0sRUFBRXNNLE1BQU0sR0FBRyw4QkFBSCxHQUFvQyxtQkFSRjtBQVNoRDFMLGNBQVksRUFBRSxLQVRrQztBQVVoRGhCLFNBQU8sRUFBRSxNQVZ1QztBQVdoRHdFLGVBQWEsRUFBRSxLQVhpQztBQVloREMsWUFBVSxFQUFFLFFBWm9DO0FBYWhELFlBQVU7QUFDUmpELGFBQVMsRUFBRTtBQURIO0FBYnNDLENBQWYsQ0FBWixDQUF2Qjs7QUFrQkEsTUFBTXNMLFVBQVUsR0FBRztBQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBaEI7O0FBZ0NBLE1BQU1DLGFBQWEsR0FBRztBQUFBO0FBQUEsR0FBWSxDQUFDO0FBQUN0TTtBQUFELENBQUQsTUFBYztBQUM5Q2tNLFlBQVUsRUFBRWxNLEtBRGtDO0FBRTlDVCxTQUFPLEVBQUUsY0FGcUM7QUFHOUN1QixPQUFLLEVBQUUsTUFIdUM7QUFJOUNILFFBQU0sRUFBRSxNQUpzQztBQUs5QzRMLGFBQVcsRUFBRSxNQUxpQztBQU05QzVNLFFBQU0sRUFBRyxhQUFZNk0sdURBQU0sQ0FBQyxHQUFELEVBQU14TSxLQUFOLENBQWE7QUFOTSxDQUFkLENBQVosQ0FBdEI7O0FBU0EsTUFBTXlNLG1CQUFtQixHQUFJL0ssS0FBRCxJQUFXO0FBQ3JDLFFBQU07QUFBQ2dMLFdBQUQ7QUFBVUMsUUFBVjtBQUFnQkMsb0JBQWhCO0FBQWtDQyxZQUFsQztBQUE0Q3ZOLFlBQTVDO0FBQXNEd04sV0FBdEQ7QUFBK0RDLFdBQS9EO0FBQXdFekQ7QUFBeEUsTUFBbUY1SCxLQUF6Rjs7QUFDQSxRQUFNc0wsY0FBYyxHQUFJQyxFQUFELElBQVE7QUFDN0IsUUFBSWpILEtBQUo7QUFDQTBHLFdBQU8sQ0FBQ1EsR0FBUixDQUFZLENBQUNDLE1BQUQsRUFBUzlILENBQVQsS0FBZTtBQUN6QixVQUFJOEgsTUFBTSxDQUFDRixFQUFQLEtBQWNBLEVBQWxCLEVBQXNCO0FBQ3BCakgsYUFBSyxHQUFHWCxDQUFSO0FBQ0Q7QUFDRixLQUpEO0FBTUEsV0FBT1csS0FBUDtBQUNELEdBVEQ7O0FBVUEsc0JBQ0V0RCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Ca0osV0FBcEIsRUFBaUM7QUFBQ2hKLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFqQyxlQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CbUosSUFBcEIsRUFBMEI7QUFBQ2pKLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUExQixFQUNFMEosT0FBTyxDQUFDUSxHQUFSLENBQVksQ0FBQ0MsTUFBRCxFQUFTQyxXQUFULGtCQUNaMUssNENBQUssQ0FBQ0MsYUFBTixDQUFvQnFKLGNBQXBCLEVBQW9DO0FBQ2xDcUIsT0FBRyxFQUFFRCxXQUQ2QjtBQUVsQzlELFdBQU8sRUFBRSxNQUFNO0FBQ2IsVUFBSSxDQUFDaEssUUFBTCxFQUFlO0FBQ2J1TixnQkFBUSxDQUFDO0FBQUNTLGFBQUcsRUFBRUgsTUFBTSxDQUFDRixFQUFiO0FBQWlCak4sZUFBSyxFQUFFdU4sNkVBQVksQ0FBQ0gsV0FBRDtBQUFwQyxTQUFELENBQVI7QUFDRDtBQUNGLEtBTmlDO0FBT2xDL0ssUUFBSSxFQUFFLFFBUDRCO0FBUWxDNEosVUFBTSxFQUFFLENBQUMzTSxRQUFELElBQWFzTixnQkFBZ0IsQ0FBQ1UsR0FBakIsS0FBeUJILE1BQU0sQ0FBQ0YsRUFSbkI7QUFRdUJwSyxVQUFNLEVBQUUsU0FSL0I7QUFRcUNDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQVIvQyxHQUFwQyxlQVVJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMkosYUFBcEIsRUFBbUM7QUFBRXRNLFNBQUssRUFBRXVOLDZFQUFZLENBQUNILFdBQUQsQ0FBckI7QUFBb0N2SyxVQUFNLEVBQUUsU0FBNUM7QUFBa0RDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUE1RCxHQUFuQyxDQVZKLEVBV0ltSyxNQUFNLENBQUNuTCxJQVhYLENBREEsQ0FERixDQURKLEVBbUJJd0wsS0FBSyxDQUFDQyxPQUFOLENBQWNkLElBQWQsS0FBdUJBLElBQUksQ0FBQ3JILE1BQUwsR0FBYyxDQUFyQyxpQkFDQTVDLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JtSixJQUFwQixFQUEwQjtBQUFDakosVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTFCLGVBQ0lOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvSixTQUFwQixFQUErQjtBQUFDbEosVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQS9CLEVBQW9HLFVBQXBHLENBREosRUFFSTJKLElBQUksQ0FBQ08sR0FBTCxDQUFTLENBQUNRLElBQUQsRUFBT0wsR0FBUCxLQUFlO0FBQ3hCLHdCQUNFM0ssNENBQUssQ0FBQ0MsYUFBTixDQUFvQjBKLFVBQXBCLEVBQWdDO0FBQUVnQixTQUFHLEVBQUVBLEdBQVA7QUFBWXhLLFlBQU0sRUFBRSxTQUFwQjtBQUEwQkMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsa0JBQVUsRUFBRTtBQUFyQztBQUFwQyxLQUFoQyxlQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMkosYUFBcEIsRUFBbUM7QUFBRWUsU0FBRyxFQUFFQSxHQUFQO0FBQVlyTixXQUFLLEVBQUUwTixJQUFJLENBQUMxTixLQUF4QjtBQUErQjZDLFlBQU0sRUFBRSxTQUF2QztBQUE2Q0MsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsa0JBQVUsRUFBRTtBQUFyQztBQUF2RCxLQUFuQyxDQURKLEVBRUkwSyxJQUFJLENBQUNmLElBRlQsQ0FERjtBQU1ELEdBUEMsQ0FGSixDQXBCSixFQWlDSWEsS0FBSyxDQUFDQyxPQUFOLENBQWNYLE9BQWQsS0FBMEJBLE9BQU8sQ0FBQ3hILE1BQVIsR0FBaUIsQ0FBM0MsaUJBQ0E1Qyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CbUosSUFBcEIsRUFBMEI7QUFBQ2pKLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUExQixlQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cb0osU0FBcEIsRUFBK0I7QUFBQ2xKLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEvQixFQUFvRyxTQUFwRyxDQURKLEVBRUk4SixPQUFPLENBQUNJLEdBQVIsQ0FBWSxDQUFDUSxJQUFELEVBQU9MLEdBQVAsS0FBZTtBQUMzQixVQUFNckwsSUFBSSxHQUFHaUQsY0FBYyxDQUFDLENBQUN5SCxPQUFELEVBQVUsUUFBVixFQUFvQjlGLENBQUMsSUFBSUEsQ0FBQyxDQUFDNEMsSUFBM0IsRUFBaUMsTUFBakMsRUFBeUN0QyxFQUFFLElBQUlBLEVBQUUsQ0FBRXlHLEdBQUQsSUFBU0EsR0FBRyxDQUFDVixFQUFKLEtBQVdTLElBQUksQ0FBQ0UsUUFBMUIsQ0FBakQsRUFBc0YsZ0JBQXRGLEVBQXdHbEUsRUFBRSxJQUFJQSxFQUFFLENBQUMxSCxJQUFqSCxDQUFELENBQTNCOztBQUNBLFFBQUksQ0FBQ0EsSUFBTCxFQUFXLE9BQU8sSUFBUDtBQUNYLHdCQUNFVSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMEosVUFBcEIsRUFBZ0M7QUFDOUJnQixTQUFHLEVBQUVBLEdBRHlCO0FBRTlCUSxrQkFBWSxFQUFFLE1BQU07QUFDbEJkLGVBQU8sQ0FBQ00sR0FBRCxDQUFQO0FBQ0QsT0FKNkI7QUFLOUJTLGtCQUFZLEVBQUUsTUFBTTtBQUNsQmYsZUFBTyxDQUFDLElBQUQsQ0FBUDtBQUNELE9BUDZCO0FBUTlCekQsYUFBTyxFQUFHN0YsQ0FBRCxJQUFPO0FBQ2RBLFNBQUMsQ0FBQ3NLLGVBQUY7QUFDRCxPQVY2QjtBQVUzQmxMLFlBQU0sRUFBRSxTQVZtQjtBQVViQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxrQkFBVSxFQUFFO0FBQXJDO0FBVkcsS0FBaEMsZUFZSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjJKLGFBQXBCLEVBQW1DO0FBQUVlLFNBQUcsRUFBRUEsR0FBUDtBQUFZck4sV0FBSyxFQUFFdU4sNkVBQVksQ0FBQ1AsY0FBYyxDQUFDVSxJQUFJLENBQUNFLFFBQU4sQ0FBZixDQUEvQjtBQUFnRS9LLFlBQU0sRUFBRSxTQUF4RTtBQUE4RUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsa0JBQVUsRUFBRTtBQUFyQztBQUF4RixLQUFuQyxDQVpKLEVBYUloQixJQWJKLEVBZUksQ0FBQzFDLFFBQUQsaUJBQ0FvRCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CcUcsaUVBQXBCLEVBQTBCO0FBQ3hCeEcsV0FBSyxFQUFFO0FBQ0xoQyxnQkFBUSxFQUFFLEVBREw7QUFFTHdOLGdCQUFRLEVBQUUsVUFGTDtBQUdMQyxhQUFLLEVBQUUsS0FIRjtBQUlMQyxXQUFHLEVBQUUsTUFKQTtBQUtMM08sZUFBTyxFQUFFLE1BTEo7QUFNTFMsYUFBSyxFQUFFSixnRUFBTyxDQUFDSztBQU5WLE9BRGlCO0FBU3hCcUosYUFBTyxFQUFFLE1BQU07QUFDYkEsZUFBTyxDQUFDK0QsR0FBRCxDQUFQO0FBQ0QsT0FYdUI7QUFXckJ4SyxZQUFNLEVBQUUsU0FYYTtBQVdQQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxrQkFBVSxFQUFFO0FBQXJDO0FBWEgsS0FBMUIsRUFZRSxPQVpGLENBaEJKLENBREY7QUFtQ0QsR0F0Q0MsQ0FGSixDQWxDSixDQURGO0FBZ0ZELENBNUZEOztBQThGZXlKLGtGQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxTEEsTUFBTXROLFlBQVksR0FBRyw2RUFBckI7O0FBQW9HLFNBQVM4RixjQUFULENBQXdCQyxHQUF4QixFQUE2QjtBQUFFLE1BQUlDLGFBQWEsR0FBR0MsU0FBcEI7QUFBK0IsTUFBSTlDLEtBQUssR0FBRzRDLEdBQUcsQ0FBQyxDQUFELENBQWY7QUFBb0IsTUFBSUcsQ0FBQyxHQUFHLENBQVI7O0FBQVcsU0FBT0EsQ0FBQyxHQUFHSCxHQUFHLENBQUNJLE1BQWYsRUFBdUI7QUFBRSxVQUFNQyxFQUFFLEdBQUdMLEdBQUcsQ0FBQ0csQ0FBRCxDQUFkO0FBQW1CLFVBQU1HLEVBQUUsR0FBR04sR0FBRyxDQUFDRyxDQUFDLEdBQUcsQ0FBTCxDQUFkO0FBQXVCQSxLQUFDLElBQUksQ0FBTDs7QUFBUSxRQUFJLENBQUNFLEVBQUUsS0FBSyxnQkFBUCxJQUEyQkEsRUFBRSxLQUFLLGNBQW5DLEtBQXNEakQsS0FBSyxJQUFJLElBQW5FLEVBQXlFO0FBQUUsYUFBTzhDLFNBQVA7QUFBbUI7O0FBQUMsUUFBSUcsRUFBRSxLQUFLLFFBQVAsSUFBbUJBLEVBQUUsS0FBSyxnQkFBOUIsRUFBZ0Q7QUFBRUosbUJBQWEsR0FBRzdDLEtBQWhCO0FBQXVCQSxXQUFLLEdBQUdrRCxFQUFFLENBQUNsRCxLQUFELENBQVY7QUFBb0IsS0FBN0YsTUFBbUcsSUFBSWlELEVBQUUsS0FBSyxNQUFQLElBQWlCQSxFQUFFLEtBQUssY0FBNUIsRUFBNEM7QUFBRWpELFdBQUssR0FBR2tELEVBQUUsQ0FBQyxDQUFDLEdBQUdDLElBQUosS0FBYW5ELEtBQUssQ0FBQ29ELElBQU4sQ0FBV1AsYUFBWCxFQUEwQixHQUFHTSxJQUE3QixDQUFkLENBQVY7QUFBNkROLG1CQUFhLEdBQUdDLFNBQWhCO0FBQTRCO0FBQUU7O0FBQUMsU0FBTzlDLEtBQVA7QUFBZTs7QUFBQTtBQUN2bUI7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBMEJBLE1BQU02TCxNQUFNLEdBQUdDLFFBQVEsQ0FBQ3pMLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBZjs7QUFFQSxJQUFJLENBQUN5TCxRQUFRLENBQUNDLElBQWQsRUFBb0I7QUFDbEIsUUFBTSxJQUFJQyxLQUFKLENBQVUscUNBQVYsQ0FBTjtBQUNEOztBQUVERixRQUFRLENBQUNDLElBQVQsQ0FBY0UsV0FBZCxDQUEwQkosTUFBMUI7O0FBRUEsTUFBTTlFLFVBQVUsR0FBRyxrRkFBT21GLG9FQUFQO0FBQUE7QUFBQSxHQUFtQjtBQUNwQ3hPLE9BQUssRUFBRUosZ0VBQU8sQ0FBQ3NCO0FBRHFCLENBQW5CLENBQW5COztBQUlBLE1BQU11TixZQUFZLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXJCOztBQU9BLE1BQU1DLGNBQWMsR0FBRyxrRkFBT0QsWUFBUDtBQUFBO0FBQUEsRUFBSCwrQkFFaEIsQ0FBQztBQUFDRSxRQUFEO0FBQVNDLGtCQUFUO0FBQTJCQztBQUEzQixDQUFELEtBQ0FGLE1BQU0sSUFBSSxDQUFDQyxnQkFBWCxJQUErQixDQUFDQyxjQUFoQyxHQUNLO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVpJLEdBYUssRUFoQlcsT0FrQmhCLENBQUM7QUFBQzlJO0FBQUQsQ0FBRCxLQUNBQSxTQUFTLEdBQ0o7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVJhLEdBU0osRUE1QlcsT0E2QmhCLENBQUM7QUFBQzRJLFFBQUQ7QUFBU0Msa0JBQVQ7QUFBMkJDO0FBQTNCLENBQUQsS0FDQUYsTUFBTSxJQUFJQyxnQkFBVixJQUE4QixDQUFDQyxjQUEvQixHQUNLO0FBQ1Q7QUFDQTtBQUNBLEdBSkksR0FLSyxFQW5DVyxPQXFDaEIsQ0FBQztBQUFDRixRQUFEO0FBQVNFLGdCQUFUO0FBQXlCRDtBQUF6QixDQUFELEtBQ0FELE1BQU0sSUFBSUUsY0FBVixJQUE0QixDQUFDRCxnQkFBN0IsR0FDSztBQUNUO0FBQ0E7QUFDQSxDQUpJLEdBS0ssRUEzQ1csT0E0Q2hCLENBQUM7QUFBQy9JO0FBQUQsQ0FBRCxLQUNBQSxRQUFRLEdBQ0g7QUFDVDtBQUNBLEdBSFksR0FJSCxFQWpEVyxDQUFwQjs7QUFvREEsTUFBTWlKLFlBQVksR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBckI7O0FBTUEsTUFBTUMsWUFBWSxHQUFHO0FBQUg7QUFBQSxHQUNkLENBQUM7QUFBQ0osUUFBRDtBQUFTQyxrQkFBVDtBQUEyQkM7QUFBM0IsQ0FBRCxLQUNBRixNQUFNLElBQUksQ0FBQ0MsZ0JBQVgsSUFBK0IsQ0FBQ0MsY0FBaEMsR0FDSztBQUNUO0FBQ0EsT0FISSxHQUlLLEVBTlMsT0FRZCxDQUFDO0FBQUNGLFFBQUQ7QUFBU0UsZ0JBQVQ7QUFBeUJEO0FBQXpCLENBQUQsS0FDQUQsTUFBTSxJQUFJRSxjQUFWLElBQTRCRCxnQkFBNUIsR0FDSztBQUNUO0FBQ0EsT0FISSxHQUlLLEVBYlMsT0FlZCxDQUFDO0FBQUM3SSxXQUFEO0FBQVk4STtBQUFaLENBQUQsS0FDQTlJLFNBQVMsSUFBSSxDQUFDOEksY0FBZCxHQUNLO0FBQ1Q7QUFDQSxRQUFRSCxjQUFlO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQVRJLEdBVUssRUExQlMsQ0FBbEI7O0FBNkJBLE1BQU0zRixVQUFVLEdBQUcsa0ZBQU9DLGlFQUFQO0FBQUE7QUFBQSxFQUFILENBQ1osQ0FBQztBQUFDMkYsUUFBRDtBQUFTQztBQUFULENBQUQsS0FDQUQsTUFBTSxJQUFJLENBQUNDLGdCQUFYLEdBQ0s7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU1GLGNBQWU7QUFDckI7QUFDQTtBQUNBLEdBVEksR0FVSyxFQVpPLE9BYVosQ0FBQztBQUFDQyxRQUFEO0FBQVNDO0FBQVQsQ0FBRCxLQUNBRCxNQUFNLElBQUlDLGdCQUFWLEdBQ0s7QUFDVDtBQUNBLEdBSEksR0FJSyxFQWxCTyxPQW1CWixDQUFDO0FBQUM3STtBQUFELENBQUQsS0FDQUEsU0FBUyxHQUNKO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVEySSxjQUFlO0FBQ3ZCO0FBQ0E7QUFDQSxLQVZhLEdBV0osRUEvQk8sQ0FBaEI7O0FBa0NBLE1BQU1NLFVBQVUsR0FBRyxDQUFDO0FBQ2xCQyxVQURrQjtBQUVsQkMsVUFGa0I7QUFHbEJDLFFBSGtCO0FBSWxCQyxNQUprQjtBQUtsQnBKLE9BTGtCO0FBTWxCM0QsTUFOa0I7QUFPbEJ5RCxlQVBrQjtBQVFsQnVKLFlBUmtCO0FBU2xCak4sYUFUa0I7QUFVbEJ5RCxVQVZrQjtBQVdsQnlKLGNBWGtCO0FBWWxCdkosV0Faa0I7QUFhbEJ3SjtBQWJrQixDQUFELEtBY2I7QUFDSixRQUFNQyxjQUFjLEdBQUcsQ0FBQ0MsUUFBRCxFQUFXQyxNQUFYLEtBQXNCO0FBQzNDRCxZQUFRLENBQUNFLE9BQVQsQ0FBa0IxQyxFQUFELElBQVE7QUFDdkIsWUFBTTJDLE9BQU8sR0FBR3hCLFFBQVEsQ0FBQ3lCLGNBQVQsQ0FBd0I1QyxFQUF4QixDQUFoQjs7QUFDQWhJLG9CQUFjLENBQUMsQ0FBQzJLLE9BQUQsRUFBVSxnQkFBVixFQUE0QjFJLEVBQUUsSUFBSUEsRUFBRSxDQUFDNEksU0FBckMsRUFBZ0QsUUFBaEQsRUFBMERwRyxFQUFFLElBQUlBLEVBQUUsQ0FBQ2dHLE1BQUQsQ0FBbEUsRUFBNEUsTUFBNUUsRUFBb0ZLLEVBQUUsSUFBSUEsRUFBRSxDQUFDLFNBQUQsQ0FBNUYsQ0FBRCxDQUFkO0FBQ0QsS0FIRDtBQUlELEdBTEQ7O0FBTUEsUUFBTXBCLE1BQU0sR0FBRyxDQUFDNUksU0FBRCxJQUFjLENBQUNGLFFBQTlCO0FBQ0EsUUFBTW1LLFVBQVUsR0FBR25LLFFBQVEsR0FBRyxLQUFILEdBQVcsQ0FBQzBKLFFBQVEsQ0FBQ1YsY0FBaEQ7QUFDQSxzQkFDRW5NLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JtTSxZQUFwQixrQ0FDS0csUUFBUSxDQUFDZ0IsY0FEZDtBQUVFdE8sT0FBRyxFQUFFc04sUUFBUSxDQUFDaUIsUUFGaEI7QUFHRTFOLFNBQUssRUFBRTJOLDZFQUFZLENBQUNqQixRQUFRLENBQUNrQixVQUFWLEVBQXNCbkIsUUFBUSxDQUFDZ0IsY0FBVCxDQUF3QnpOLEtBQTlDLENBSHJCO0FBRzJFSyxVQUFNLEVBQUUsU0FIbkY7QUFHeUZDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUhuRyxNQUtJb00sSUFBSSxDQUFDOUosTUFBTCxHQUFjLENBQWQsaUJBQ0E1Qyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK0wsY0FBcEIsRUFBb0M7QUFDbEN6QixNQUFFLEVBQUcsbUJBQWtCa0MsTUFBTyxFQURJO0FBRWxDdEosWUFBUSxFQUFFQSxRQUZ3QjtBQUdsQ0UsYUFBUyxFQUFFQSxTQUh1QjtBQUlsQzRJLFVBQU0sRUFBRUEsTUFKMEI7QUFLbENDLG9CQUFnQixFQUFFVyxRQUFRLENBQUNYLGdCQUxPO0FBTWxDQyxrQkFBYyxFQUFFVSxRQUFRLENBQUNWLGNBTlM7QUFNT2hNLFVBQU0sRUFBRSxTQU5mO0FBTXFCQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFOL0IsR0FBcEMsRUFRSTJMLE1BQU0sSUFBSSxDQUFDWSxRQUFRLENBQUNYLGdCQUFwQixnQkFDQWxNLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvRyxVQUFwQixrQ0FDS2tHLFFBQVEsQ0FBQ29CLGVBRGQ7QUFFRXhLLFlBQVEsRUFBRUEsUUFGWjtBQUdFRSxhQUFTLEVBQUVBLFNBSGI7QUFJRTRJLFVBQU0sRUFBRUEsTUFKVjtBQUtFMUIsTUFBRSxFQUFHLGFBQVlrQyxNQUFPLEVBTDFCO0FBTUVQLG9CQUFnQixFQUFFVyxRQUFRLENBQUNYLGdCQU43QjtBQU9FcE0sU0FBSyxFQUFFO0FBQUNoQyxjQUFRLEVBQUUsRUFBWDtBQUFlUixXQUFLLEVBQUVKLGdFQUFPLENBQUNLO0FBQTlCLEtBUFQ7QUFPbUQ0QyxVQUFNLEVBQUUsU0FQM0Q7QUFPaUVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQVAzRSxNQVFFLGdCQVJGLENBREEsR0FhQSxFQXJCSixlQXdCSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQm9NLFlBQXBCLEVBQWtDO0FBQ2xDOUIsTUFBRSxFQUFHLGlCQUFnQmtDLE1BQU8sRUFETTtBQUVsQ3RKLFlBQVEsRUFBRUEsUUFGd0I7QUFHbENFLGFBQVMsRUFBRUEsU0FIdUI7QUFJbEM0SSxVQUFNLEVBQUVBLE1BSjBCO0FBS2xDQyxvQkFBZ0IsRUFBRVcsUUFBUSxDQUFDWCxnQkFMTztBQU1sQ0Msa0JBQWMsRUFBRVUsUUFBUSxDQUFDVixjQU5TO0FBTU9oTSxVQUFNLEVBQUUsU0FOZjtBQU1xQkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBTi9CLEdBQWxDLGVBUUVOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IyTixrRUFBcEIsRUFBOEI7QUFDOUJ0TyxRQUFJLEVBQUcsUUFBT2dFLEtBQU0sS0FBSTNELElBQUssV0FBVThNLE1BQU8sR0FEaEI7QUFFOUJvQixxQkFBaUIsRUFBRSxJQUZXO0FBRzlCbE8sUUFBSSxFQUFFLE1BSHdCO0FBSTlCSCxXQUFPLEVBQUUsTUFDUHNOLGNBQWMsQ0FDWixDQUNHLG1CQUFrQkwsTUFBTyxFQUQ1QixFQUVHLGFBQVlBLE1BQU8sRUFGdEIsRUFHRyxjQUFhQSxNQUFPLEVBSHZCLEVBSUcsaUJBQWdCQSxNQUFPLEVBSjFCLENBRFksRUFPWixLQVBZLENBTGM7QUFlOUJsTixVQUFNLEVBQUUsTUFDTnVOLGNBQWMsQ0FDWixDQUNHLG1CQUFrQkwsTUFBTyxFQUQ1QixFQUVHLGFBQVlBLE1BQU8sRUFGdEIsRUFHRyxjQUFhQSxNQUFPLEVBSHZCLEVBSUcsaUJBQWdCQSxNQUFPLEVBSjFCLENBRFksRUFPWixRQVBZLENBaEJjO0FBMEI5QnFCLGFBQVMsRUFBRy9NLENBQUQsSUFBTztBQUNoQixVQUFJQSxDQUFDLENBQUNnTixPQUFGLEtBQWMsRUFBbEIsRUFBc0I7QUFDcEJoTixTQUFDLENBQUNpTixjQUFGO0FBQ0Q7QUFDRixLQTlCNkI7QUErQjlCdk8sWUFBUSxFQUFHc0IsQ0FBRCxJQUFPO0FBQ2YsWUFBTTtBQUFDbkI7QUFBRCxVQUFVbUIsQ0FBQyxDQUFDRSxNQUFsQjtBQUNBbUMsbUJBQWEsQ0FBRSxHQUFFdUosVUFBVyxJQUFHRixNQUFPLEdBQXpCLEVBQTZCN00sS0FBN0IsQ0FBYjtBQUNELEtBbEM2QjtBQW1DOUJBLFNBQUssRUFBRThNLElBQUksQ0FBQ0QsTUFBRCxDQW5DbUI7QUFvQzlCL00sZUFBVyxFQUFFNkMsY0FBYyxDQUFDLENBQUM3QyxXQUFELEVBQWMsZ0JBQWQsRUFBZ0N1TyxFQUFFLElBQUlBLEVBQUUsQ0FBQ3hCLE1BQUQsQ0FBeEMsQ0FBRCxDQUFkLElBQXFFLE1BcENwRDtBQXFDOUJ5QixZQUFRLEVBQUUvSyxRQXJDb0I7QUFzQzlCdkcsWUFBUSxFQUFFaVEsUUFBUSxDQUFDc0IsWUF0Q1c7QUFzQ0doTyxVQUFNLEVBQUUsU0F0Q1g7QUFzQ2lCQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUF0QzNCLEdBQTlCLENBUkYsQ0F4QkosRUF5RUlnTixVQUFVLGlCQUNWdE4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjBHLFVBQXBCLEVBQWdDO0FBQzlCaEgsUUFBSSxFQUFFLFFBRHdCO0FBRTlCL0MsWUFBUSxFQUFFdUcsUUFGb0I7QUFHOUJ5RCxXQUFPLEVBQUUsTUFBTWdHLFlBQVksQ0FBQ3dCLE1BQWIsQ0FBb0IzQixNQUFwQixDQUhlO0FBR2N0TSxVQUFNLEVBQUUsU0FIdEI7QUFHNEJDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUh0QyxHQUFoQyxlQUtJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cb0csVUFBcEIsRUFBZ0M7QUFDaENsRCxZQUFRLEVBQUVBLFFBRHNCO0FBRWhDRSxhQUFTLEVBQUVBLFNBRnFCO0FBR2hDOEksa0JBQWMsRUFBRVUsUUFBUSxDQUFDVixjQUhPO0FBSWhDNUIsTUFBRSxFQUFHLGNBQWFrQyxNQUFPLEVBSk87QUFLaEMzTSxTQUFLLEVBQUU7QUFBQ2hDLGNBQVEsRUFBRSxFQUFYO0FBQWVSLFdBQUssRUFBRUosZ0VBQU8sQ0FBQ0s7QUFBOUIsS0FMeUI7QUFNaEMwTyxVQUFNLEVBQUVBLE1BTndCO0FBTWhCOUwsVUFBTSxFQUFFLFNBTlE7QUFNRkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBTlIsR0FBaEMsRUFPQSxPQVBBLENBTEosQ0ExRUosQ0FOSixDQURGO0FBc0dELENBN0hEOztBQStIQSxNQUFNNEYsWUFBWSxHQUFJbEgsS0FBRCxJQUFXO0FBQzlCLFFBQU07QUFDSk0sUUFESTtBQUVKb04sUUFGSTtBQUdKcEosU0FISTtBQUlKRCxhQUpJO0FBS0oxRCxRQUxJO0FBTUp3RCxZQU5JO0FBT0p3SixjQVBJO0FBUUp2SixpQkFSSTtBQVNKMUQsZUFUSTtBQVVKbU47QUFWSSxNQVdGN04sS0FYSjtBQVlBLFFBQU1xUCxTQUFTLEdBQUdDLHlEQUFXLENBQzFCQyxNQUFELElBQVk7QUFDVixVQUFNO0FBQUNDLGlCQUFEO0FBQWNDLFlBQWQ7QUFBc0JDO0FBQXRCLFFBQXFDSCxNQUEzQzs7QUFDQSxRQUNFLENBQUNDLFdBQUQsSUFDQ0EsV0FBVyxDQUFDRyxXQUFaLEtBQTRCRixNQUFNLENBQUNFLFdBQW5DLElBQWtESCxXQUFXLENBQUNsTCxLQUFaLEtBQXNCbUwsTUFBTSxDQUFDbkwsS0FGbEYsRUFHRTtBQUNBO0FBQ0Q7O0FBRUQsVUFBTXNMLFdBQVcsR0FBR2xDLElBQUksQ0FBQ2dDLFdBQUQsQ0FBeEI7QUFFQSxVQUFNRyxPQUFPLEdBQUduQyxJQUFoQjtBQUNBbUMsV0FBTyxDQUFDQyxNQUFSLENBQWVMLE1BQU0sQ0FBQ25MLEtBQXRCLEVBQTZCLENBQTdCO0FBQ0F1TCxXQUFPLENBQUNDLE1BQVIsQ0FBZU4sV0FBVyxDQUFDbEwsS0FBM0IsRUFBa0MsQ0FBbEMsRUFBcUNzTCxXQUFyQztBQUNBeEwsaUJBQWEsQ0FBRSxRQUFPRSxLQUFNLEtBQUkzRCxJQUFLLFNBQXhCLEVBQWtDa1AsT0FBbEMsQ0FBYjtBQUNELEdBaEIwQixFQWlCM0IsQ0FBQ25DLElBQUQsRUFBT3BKLEtBQVAsQ0FqQjJCLENBQTdCO0FBb0JBLHNCQUNFdEQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhPLGlEQUFwQixFQUFnQztBQUM5QnpQLFFBQUksRUFBRUEsSUFEd0I7QUFFOUIwUCxVQUFNLEVBQUdwQyxZQUFELElBQWtCO0FBQ3hCLDBCQUNFNU0sNENBQUssQ0FBQ0MsYUFBTixDQUFvQmdQLG1FQUFwQixFQUFxQztBQUFFWixpQkFBUyxFQUFFQSxTQUFiO0FBQXdCbE8sY0FBTSxFQUFFLFNBQWhDO0FBQXNDQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsb0JBQVUsRUFBRTtBQUFyQztBQUFoRCxPQUFyQyxlQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CaVAsNkRBQXBCLEVBQStCO0FBQUVQLG1CQUFXLEVBQUUsZUFBZjtBQUFnQ3hPLGNBQU0sRUFBRSxTQUF4QztBQUE4Q0MsZ0JBQVEsRUFBRTtBQUFDQyxrQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELG9CQUFVLEVBQUU7QUFBckM7QUFBeEQsT0FBL0IsRUFDR2lNLFFBQUQsaUJBQ0F2TSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLEtBQXBCLGtDQUFnQ3NNLFFBQVEsQ0FBQzRDLGNBQXpDO0FBQXlEbFEsV0FBRyxFQUFFc04sUUFBUSxDQUFDaUIsUUFBdkU7QUFBaUYxTixhQUFLLEVBQUU7QUFBQzFCLGVBQUssRUFBRTtBQUFSLFNBQXhGO0FBQXlHK0IsY0FBTSxFQUFFLFNBQWpIO0FBQXVIQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsb0JBQVUsRUFBRTtBQUFyQztBQUFqSSx1QkFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhMLFlBQXBCLEVBQWtDO0FBQUM1TCxjQUFNLEVBQUUsU0FBVDtBQUFlQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsb0JBQVUsRUFBRTtBQUFyQztBQUF6QixPQUFsQyxFQUNFd0ssS0FBSyxDQUFDQyxPQUFOLENBQWMyQixJQUFkLEtBQ0FBLElBQUksQ0FBQ2xDLEdBQUwsQ0FBUyxDQUFDdEcsQ0FBRCxFQUFJdUksTUFBSixLQUFlO0FBQ3RCLDRCQUNFek0sNENBQUssQ0FBQ0MsYUFBTixDQUFvQm1QLDZEQUFwQixFQUErQjtBQUM3QnpFLGFBQUcsRUFBRThCLE1BRHdCO0FBRTdCaUMscUJBQVcsRUFBRVcsTUFBTSxDQUFDNUMsTUFBRCxDQUZVO0FBRzdCNkMsd0JBQWMsRUFBRWpNLFNBQVMsSUFBSUYsUUFBYixJQUF5QjBKLFFBQVEsQ0FBQ1gsZ0JBSHJCO0FBSTdCNUksZUFBSyxFQUFFbUosTUFKc0I7QUFJZHRNLGdCQUFNLEVBQUUsU0FKTTtBQUlBQyxrQkFBUSxFQUFFO0FBQUNDLG9CQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsc0JBQVUsRUFBRTtBQUFyQztBQUpWLFNBQS9CLEVBTUksQ0FBQ2lNLFFBQUQsRUFBV0MsUUFBWCxLQUF3QjtBQUN4QixnQkFBTStDLFNBQVMsR0FBRy9DLFFBQVEsQ0FBQ2tCLFVBQTNCO0FBQ0EsZ0JBQU04QixLQUFLLGdCQUNUeFAsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnFNLFVBQXBCLEVBQWdDO0FBQzlCQyxvQkFBUSxFQUFFQSxRQURvQjtBQUU5QkMsb0JBQVEsRUFBRUEsUUFGb0I7QUFHOUJDLGtCQUFNLEVBQUVBLE1BSHNCO0FBSTlCQyxnQkFBSSxFQUFFQSxJQUp3QjtBQUs5QnBKLGlCQUFLLEVBQUVBLEtBTHVCO0FBTTlCM0QsZ0JBQUksRUFBRUEsSUFOd0I7QUFPOUJ5RCx5QkFBYSxFQUFFQSxhQVBlO0FBUTlCdUosc0JBQVUsRUFBRUEsVUFSa0I7QUFTOUJqTix1QkFBVyxFQUFFQSxXQVRpQjtBQVU5QnlELG9CQUFRLEVBQUVBLFFBVm9CO0FBVzlCeUosd0JBQVksRUFBRUEsWUFYZ0I7QUFZOUJ2SixxQkFBUyxFQUFFQSxTQVptQjtBQWE5QndKLG9CQUFRLEVBQUVBLFFBYm9CO0FBYVYxTSxrQkFBTSxFQUFFLFNBYkU7QUFhSUMsb0JBQVEsRUFBRTtBQUFDQyxzQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELHdCQUFVLEVBQUU7QUFBckM7QUFiZCxXQUFoQyxDQURGOztBQWlCQSxjQUFJLENBQUNpUCxTQUFMLEVBQWdCO0FBQ2QsbUJBQU9DLEtBQVA7QUFDRDs7QUFFRCw4QkFBT0MsZ0RBQVEsQ0FBQ0MsWUFBVCxDQUFzQkYsS0FBdEIsRUFBNkIvRCxNQUE3QixDQUFQO0FBQ0QsU0E5QkgsQ0FERjtBQWtDRCxPQW5DRCxDQUZGLENBREosRUF3Q0ljLFFBQVEsQ0FBQzdNLFdBeENiLGVBeUNJTSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CbU0sWUFBcEIsRUFBa0M7QUFBQ2pNLGNBQU0sRUFBRSxTQUFUO0FBQWVDLGdCQUFRLEVBQUU7QUFBQ0Msa0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxvQkFBVSxFQUFFO0FBQXJDO0FBQXpCLE9BQWxDLGVBQ0VOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IwUCw0RUFBcEIsRUFBcUM7QUFDckNoUSxZQUFJLEVBQUUsUUFEK0I7QUFFckMvQyxnQkFBUSxFQUFFdUcsUUFBUSxJQUFJMEosUUFBUSxDQUFDc0IsWUFGTTtBQUdyQ3ZILGVBQU8sRUFBRSxNQUFNO0FBQ2JnRyxzQkFBWSxDQUFDZ0QsSUFBYixDQUFrQixFQUFsQjtBQUNELFNBTG9DO0FBS2xDelAsY0FBTSxFQUFFLFNBTDBCO0FBS3BCQyxnQkFBUSxFQUFFO0FBQUNDLGtCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsb0JBQVUsRUFBRTtBQUFyQztBQUxVLE9BQXJDLEVBTUEsVUFOQSxDQURGLENBekNKLENBRkYsQ0FESixDQURGO0FBNkRELEtBaEU2QjtBQWdFM0JILFVBQU0sRUFBRSxTQWhFbUI7QUFnRWJDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQWhFRyxHQUFoQyxDQURGO0FBb0VELENBckdEOztBQXVHQTRGLFlBQVksQ0FBQzJKLFlBQWIsR0FBNEI7QUFDMUJoRCxVQUFRLEVBQUU7QUFDUlYsa0JBQWMsRUFBRSxLQURSO0FBRVJnQyxnQkFBWSxFQUFFLEtBRk47QUFHUmpDLG9CQUFnQixFQUFFO0FBSFY7QUFEZ0IsQ0FBNUI7QUFRZWhHLDJFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5WkEsTUFBTXpKLFlBQVksR0FBRyw2RkFBckI7O0FBQW9ILFNBQVM4RixjQUFULENBQXdCQyxHQUF4QixFQUE2QjtBQUFFLE1BQUlDLGFBQWEsR0FBR0MsU0FBcEI7QUFBK0IsTUFBSTlDLEtBQUssR0FBRzRDLEdBQUcsQ0FBQyxDQUFELENBQWY7QUFBb0IsTUFBSUcsQ0FBQyxHQUFHLENBQVI7O0FBQVcsU0FBT0EsQ0FBQyxHQUFHSCxHQUFHLENBQUNJLE1BQWYsRUFBdUI7QUFBRSxVQUFNQyxFQUFFLEdBQUdMLEdBQUcsQ0FBQ0csQ0FBRCxDQUFkO0FBQW1CLFVBQU1HLEVBQUUsR0FBR04sR0FBRyxDQUFDRyxDQUFDLEdBQUcsQ0FBTCxDQUFkO0FBQXVCQSxLQUFDLElBQUksQ0FBTDs7QUFBUSxRQUFJLENBQUNFLEVBQUUsS0FBSyxnQkFBUCxJQUEyQkEsRUFBRSxLQUFLLGNBQW5DLEtBQXNEakQsS0FBSyxJQUFJLElBQW5FLEVBQXlFO0FBQUUsYUFBTzhDLFNBQVA7QUFBbUI7O0FBQUMsUUFBSUcsRUFBRSxLQUFLLFFBQVAsSUFBbUJBLEVBQUUsS0FBSyxnQkFBOUIsRUFBZ0Q7QUFBRUosbUJBQWEsR0FBRzdDLEtBQWhCO0FBQXVCQSxXQUFLLEdBQUdrRCxFQUFFLENBQUNsRCxLQUFELENBQVY7QUFBb0IsS0FBN0YsTUFBbUcsSUFBSWlELEVBQUUsS0FBSyxNQUFQLElBQWlCQSxFQUFFLEtBQUssY0FBNUIsRUFBNEM7QUFBRWpELFdBQUssR0FBR2tELEVBQUUsQ0FBQyxDQUFDLEdBQUdDLElBQUosS0FBYW5ELEtBQUssQ0FBQ29ELElBQU4sQ0FBV1AsYUFBWCxFQUEwQixHQUFHTSxJQUE3QixDQUFkLENBQVY7QUFBNkROLG1CQUFhLEdBQUdDLFNBQWhCO0FBQTRCO0FBQUU7O0FBQUMsU0FBTzlDLEtBQVA7QUFBZTs7QUFBQTtBQUN2bkI7QUFDQTtBQUNBOztBQW1CQSxNQUFNa1EsYUFBYSxHQUFHLENBQUM7QUFDckJDLEtBRHFCO0FBRXJCQyxhQUFXLEdBQUcsQ0FGTztBQUdyQkMsZUFIcUI7QUFJckJ4USxVQUpxQjtBQUtyQjJLLFNBTHFCO0FBTXJCeE4sVUFOcUI7QUFPckJzVDtBQVBxQixDQUFELEtBUWhCO0FBQ0osUUFBTSxDQUFDQyxPQUFELEVBQVVDLFVBQVYsSUFBd0JDLHNEQUFRLENBQUMsSUFBRCxDQUF0QztBQUNBLFFBQU0sQ0FBQ0MsTUFBRCxFQUFTQyxTQUFULElBQXNCRixzREFBUSxDQUFDLElBQUQsQ0FBcEM7QUFDQSxRQUFNLENBQUNHLE9BQUQsRUFBVUMsVUFBVixJQUF3Qkosc0RBQVEsQ0FBQ2pHLE9BQUQsQ0FBdEM7QUFFQXNHLHlEQUFTLENBQUMsTUFBTTtBQUNkalIsWUFBUSxDQUNOK1EsT0FBTyxDQUFDaEcsR0FBUixDQUFhbUcsS0FBRCxLQUFZO0FBQ3RCQyxPQUFDLEVBQUUsQ0FBQ0MsVUFBVSxDQUFDRixLQUFLLENBQUNDLENBQVAsQ0FBVixDQUFvQkUsT0FBcEIsQ0FBNEIsQ0FBNUIsQ0FEa0I7QUFFdEJDLE9BQUMsRUFBRSxDQUFDRixVQUFVLENBQUNGLEtBQUssQ0FBQ0ksQ0FBUCxDQUFWLENBQW9CRCxPQUFwQixDQUE0QixDQUE1QixDQUZrQjtBQUd0QkUsT0FBQyxFQUFFLENBQUNILFVBQVUsQ0FBQ0YsS0FBSyxDQUFDSyxDQUFQLENBQVYsQ0FBb0JGLE9BQXBCLENBQTRCLENBQTVCLENBSGtCO0FBSXRCRyxPQUFDLEVBQUUsQ0FBQ0osVUFBVSxDQUFDRixLQUFLLENBQUNNLENBQVAsQ0FBVixDQUFvQkgsT0FBcEIsQ0FBNEIsQ0FBNUIsQ0FKa0I7QUFLdEI1RixjQUFRLEVBQUV5RixLQUFLLENBQUN6RixRQUxNO0FBTXRCNU4sV0FBSyxFQUFFcVQsS0FBSyxDQUFDclQ7QUFOUyxLQUFaLENBQVosQ0FETSxDQUFSO0FBVUQsR0FYUSxFQVdOLENBQUNrVCxPQUFELENBWE0sQ0FBVDtBQWFBRSx5REFBUyxDQUFDLE1BQU07QUFDZCxRQUNFNUYsS0FBSyxDQUFDQyxPQUFOLENBQWNYLE9BQWQsS0FDQVUsS0FBSyxDQUFDQyxPQUFOLENBQWN5RixPQUFkLENBREEsSUFFQSxDQUFDdE0sNkNBQUMsQ0FBQ2dOLE9BQUYsQ0FBVTlHLE9BQU8sQ0FBQytHLElBQVIsRUFBVixFQUEwQlgsT0FBTyxDQUFDVyxJQUFSLEVBQTFCLENBSEgsRUFJRTtBQUNBVixnQkFBVSxDQUFDckcsT0FBRCxDQUFWO0FBQ0Q7QUFDRixHQVJRLEVBUU4sQ0FBQ0EsT0FBRCxDQVJNLENBQVQ7QUFVQSxRQUFNLENBQUNnSCxNQUFELEVBQVNDLFNBQVQsSUFBc0JoQixzREFBUSxDQUFDLE1BQUQsQ0FBcEM7QUFDQSxRQUFNLENBQUNpQixlQUFELEVBQWtCQyxrQkFBbEIsSUFBd0NsQixzREFBUSxDQUl2RCxFQUp1RCxDQUF0RDtBQU1BLFFBQU1tQixZQUFZLEdBQUdDLG9EQUFNLENBQUMsSUFBRCxDQUEzQjtBQUNBZix5REFBUyxDQUFDLE1BQU07QUFDZCxVQUFNZ0IsWUFBWSxHQUFHLElBQUkvTSxLQUFKLEVBQXJCO0FBQ0ErTSxnQkFBWSxDQUFDQyxHQUFiLEdBQW1CNUIsR0FBbkI7O0FBQ0EyQixnQkFBWSxDQUFDRSxNQUFiLEdBQXNCLE1BQU07QUFDMUIsWUFBTXhULEtBQUssR0FBR3NULFlBQVksQ0FBQ3RULEtBQTNCO0FBQ0EsWUFBTUgsTUFBTSxHQUFHeVQsWUFBWSxDQUFDelQsTUFBNUI7QUFDQXNULHdCQUFrQixDQUFDO0FBQ2pCTSwwQkFBa0IsRUFBRUgsWUFBWSxDQUFDQyxHQURoQjtBQUVqQnZULGFBQUssRUFBRUEsS0FGVTtBQUdqQkgsY0FBTSxFQUFFQTtBQUhTLE9BQUQsQ0FBbEI7QUFLRCxLQVJEO0FBU0QsR0FaUSxFQVlOLENBQUN1VCxZQUFELEVBQWV6QixHQUFmLENBWk0sQ0FBVDs7QUFjQSxRQUFNK0IsSUFBSSxHQUFHLENBQUNDLEtBQUQsRUFBUUMsS0FBUixLQUFrQjtBQUM3QixVQUFNZixDQUFDLEdBQ0xPLFlBQVksQ0FBQ1MsT0FBYixJQUF3QlgsZUFBZSxDQUFDbFQsS0FBeEMsR0FDSzhULElBQUksQ0FBQ0MsR0FBTCxDQUNDRCxJQUFJLENBQUNFLEdBQUwsQ0FBU0YsSUFBSSxDQUFDRyxLQUFMLENBQVdOLEtBQUssR0FBR1AsWUFBWSxDQUFDUyxPQUFiLENBQXFCSyxxQkFBckIsR0FBNkNyQixDQUFoRSxDQUFULEVBQTZFLENBQTdFLENBREQsRUFFQzFPLGNBQWMsQ0FBQyxDQUFDaVAsWUFBRCxFQUFlLFFBQWYsRUFBeUJoTixFQUFFLElBQUlBLEVBQUUsQ0FBQ3lOLE9BQWxDLEVBQTJDLGdCQUEzQyxFQUE2RGpMLEVBQUUsSUFBSUEsRUFBRSxDQUFDdUwsV0FBdEUsQ0FBRCxDQUZmLElBSUNoUSxjQUFjLENBQUMsQ0FBQ2lQLFlBQUQsRUFBZSxRQUFmLEVBQXlCbkUsRUFBRSxJQUFJQSxFQUFFLENBQUM0RSxPQUFsQyxFQUEyQyxnQkFBM0MsRUFBNkRoRSxFQUFFLElBQUlBLEVBQUUsQ0FBQ3NFLFdBQXRFLENBQUQsQ0FKaEIsR0FLQSxHQU5KLEdBT0ksQ0FSTjtBQVVBLFVBQU12QixDQUFDLEdBQ0xRLFlBQVksQ0FBQ1MsT0FBYixJQUF3QlgsZUFBZSxDQUFDclQsTUFBeEMsR0FDS2lVLElBQUksQ0FBQ0MsR0FBTCxDQUNDRCxJQUFJLENBQUNFLEdBQUwsQ0FBU0YsSUFBSSxDQUFDRyxLQUFMLENBQVdMLEtBQUssR0FBR1IsWUFBWSxDQUFDUyxPQUFiLENBQXFCSyxxQkFBckIsR0FBNkN0QixDQUFoRSxDQUFULEVBQTZFLENBQTdFLENBREQsRUFFQ3pPLGNBQWMsQ0FBQyxDQUFDaVAsWUFBRCxFQUFlLFFBQWYsRUFBeUJnQixFQUFFLElBQUlBLEVBQUUsQ0FBQ1AsT0FBbEMsRUFBMkMsZ0JBQTNDLEVBQTZEUSxFQUFFLElBQUlBLEVBQUUsQ0FBQ0MsWUFBdEUsQ0FBRCxDQUZmLElBSUNuUSxjQUFjLENBQUMsQ0FBQ2lQLFlBQUQsRUFBZSxRQUFmLEVBQXlCbUIsRUFBRSxJQUFJQSxFQUFFLENBQUNWLE9BQWxDLEVBQTJDLGdCQUEzQyxFQUE2RFcsRUFBRSxJQUFJQSxFQUFFLENBQUNGLFlBQXRFLENBQUQsQ0FKaEIsR0FLQSxHQU5KLEdBT0ksQ0FSTjtBQVVBLFdBQU87QUFBQ3pCLE9BQUQ7QUFBSUQ7QUFBSixLQUFQO0FBQ0QsR0F0QkQ7O0FBdUJBLFFBQU02QixlQUFlLEdBQUcsQ0FBQ2QsS0FBRCxFQUFRQyxLQUFSLEtBQWtCO0FBQ3hDNUIsY0FBVSxDQUFDMEIsSUFBSSxDQUFDQyxLQUFELEVBQVFDLEtBQVIsQ0FBTCxDQUFWO0FBQ0QsR0FGRDs7QUFJQXRCLHlEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUksQ0FBQzlULFFBQUwsRUFBZTtBQUNiLFlBQU1rVyxnQkFBZ0IsR0FBSS9SLENBQUQsSUFBTztBQUM5QkEsU0FBQyxDQUFDaU4sY0FBRjs7QUFDQSxZQUFJb0QsTUFBTSxLQUFLLE9BQWYsRUFBd0I7QUFDdEJ5Qix5QkFBZSxDQUFDOVIsQ0FBQyxDQUFDZ1IsS0FBSCxFQUFVaFIsQ0FBQyxDQUFDaVIsS0FBWixDQUFmO0FBQ0Q7QUFDRixPQUxEOztBQU9BelAsb0JBQWMsQ0FBQyxDQUFDaVAsWUFBRCxFQUFlLFFBQWYsRUFBeUJ1QixHQUFHLElBQUlBLEdBQUcsQ0FBQ2QsT0FBcEMsRUFBNkMsZ0JBQTdDLEVBQStEZSxHQUFHLElBQUlBLEdBQUcsQ0FBQ0MsZ0JBQTFFLEVBQTRGLE1BQTVGLEVBQW9HQyxHQUFHLElBQUlBLEdBQUcsQ0FBQyxXQUFELEVBQWNKLGdCQUFkLENBQTlHLENBQUQsQ0FBZDs7QUFDQSxhQUFPLE1BQU12USxjQUFjLENBQUMsQ0FBQ2lQLFlBQUQsRUFBZSxRQUFmLEVBQXlCMkIsR0FBRyxJQUFJQSxHQUFHLENBQUNsQixPQUFwQyxFQUE2QyxnQkFBN0MsRUFBK0RtQixHQUFHLElBQUlBLEdBQUcsQ0FBQ0MsbUJBQTFFLEVBQStGLE1BQS9GLEVBQXVHQyxHQUFHLElBQUlBLEdBQUcsQ0FBQyxXQUFELEVBQWNSLGdCQUFkLENBQWpILENBQUQsQ0FBM0I7QUFDRDtBQUNGLEdBWlEsRUFZTixDQUFDMUIsTUFBRCxDQVpNLENBQVQ7O0FBY0EsUUFBTW1DLGdCQUFnQixHQUFJeFMsQ0FBRCxJQUFPO0FBQzlCQSxLQUFDLENBQUNzSyxlQUFGOztBQUNBLFFBQUl0SyxDQUFDLENBQUN5UyxNQUFGLEtBQWEsQ0FBYixJQUFrQixDQUFDNVcsUUFBdkIsRUFBaUM7QUFDL0IyVCxlQUFTLENBQUN1QixJQUFJLENBQUMvUSxDQUFDLENBQUNnUixLQUFILEVBQVVoUixDQUFDLENBQUNpUixLQUFaLENBQUwsQ0FBVDtBQUNBNUIsZ0JBQVUsQ0FBQzBCLElBQUksQ0FBQy9RLENBQUMsQ0FBQ2dSLEtBQUgsRUFBVWhSLENBQUMsQ0FBQ2lSLEtBQVosQ0FBTCxDQUFWO0FBQ0FYLGVBQVMsQ0FBQyxNQUFELENBQVQ7QUFDRDtBQUNGLEdBUEQ7O0FBU0EsUUFBTXlCLGdCQUFnQixHQUFJL1IsQ0FBRCxJQUFPO0FBQzlCQSxLQUFDLENBQUNzSyxlQUFGO0FBQ0EsVUFBTW9JLGNBQWMsR0FBRzNCLElBQUksQ0FBQy9RLENBQUMsQ0FBQ2dSLEtBQUgsRUFBVWhSLENBQUMsQ0FBQ2lSLEtBQVosQ0FBM0I7QUFDQTVCLGNBQVUsQ0FBQ3FELGNBQUQsQ0FBVjs7QUFDQSxVQUFNQyxRQUFRLEdBQUdELGNBQWMsQ0FBQ3hDLENBQWYsS0FBcUIxTyxjQUFjLENBQUMsQ0FBQytOLE1BQUQsRUFBUyxnQkFBVCxFQUEyQnFELEdBQUcsSUFBSUEsR0FBRyxDQUFDMUMsQ0FBdEMsQ0FBRCxDQUFuQyxJQUFpRndDLGNBQWMsQ0FBQ3pDLENBQWYsS0FBcUJ6TyxjQUFjLENBQUMsQ0FBQytOLE1BQUQsRUFBUyxnQkFBVCxFQUEyQnNELEdBQUcsSUFBSUEsR0FBRyxDQUFDNUMsQ0FBdEMsQ0FBRCxDQUFySTs7QUFDQSxRQUFJSSxNQUFNLEtBQUssTUFBWCxJQUFxQnNDLFFBQXpCLEVBQW1DO0FBQ2pDckMsZUFBUyxDQUFDLE9BQUQsQ0FBVDtBQUNEO0FBQ0YsR0FSRDs7QUFVQSxRQUFNd0MsU0FBUyxHQUFHdkYseURBQVcsQ0FBQyxNQUFNO0FBQ2xDLFVBQU13RixFQUFFLEdBQUd4RCxNQUFNLElBQUlILE9BQVYsR0FBb0IrQixJQUFJLENBQUNDLEdBQUwsQ0FBUzdCLE1BQU0sQ0FBQ1csQ0FBaEIsRUFBbUJkLE9BQU8sQ0FBQ2MsQ0FBM0IsQ0FBcEIsR0FBb0QsQ0FBL0Q7QUFDQSxVQUFNOEMsRUFBRSxHQUFHekQsTUFBTSxJQUFJSCxPQUFWLEdBQW9CK0IsSUFBSSxDQUFDRSxHQUFMLENBQVM5QixNQUFNLENBQUNXLENBQWhCLEVBQW1CZCxPQUFPLENBQUNjLENBQTNCLENBQXBCLEdBQW9ELENBQS9EO0FBQ0EsVUFBTStDLEVBQUUsR0FBRzFELE1BQU0sSUFBSUgsT0FBVixHQUFvQitCLElBQUksQ0FBQ0MsR0FBTCxDQUFTN0IsTUFBTSxDQUFDVSxDQUFoQixFQUFtQmIsT0FBTyxDQUFDYSxDQUEzQixDQUFwQixHQUFvRCxDQUEvRDtBQUNBLFVBQU1pRCxFQUFFLEdBQUczRCxNQUFNLElBQUlILE9BQVYsR0FBb0IrQixJQUFJLENBQUNFLEdBQUwsQ0FBUzlCLE1BQU0sQ0FBQ1UsQ0FBaEIsRUFBbUJiLE9BQU8sQ0FBQ2EsQ0FBM0IsQ0FBcEIsR0FBb0QsQ0FBL0Q7QUFFQSxXQUFPO0FBQ0xDLE9BQUMsRUFBRTZDLEVBREU7QUFFTDlDLE9BQUMsRUFBRWdELEVBRkU7QUFHTHBELE9BQUMsRUFBRW1ELEVBQUUsR0FBR0QsRUFISDtBQUlML0MsT0FBQyxFQUFFa0QsRUFBRSxHQUFHRDtBQUpILEtBQVA7QUFNRCxHQVo0QixFQVkxQixDQUFDN0QsT0FBRCxFQUFVRyxNQUFWLENBWjBCLENBQTdCO0FBY0EsUUFBTTRELElBQUksR0FBR0wsU0FBUyxFQUF0QjtBQUNBLFFBQU1NLE1BQU0sR0FBRzFDLG9EQUFNLEVBQXJCO0FBRUFmLHlEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUksQ0FBQzlULFFBQUwsRUFBZTtBQUNiLFlBQU13WCxjQUFjLEdBQUlyVCxDQUFELElBQU87QUFDNUJBLFNBQUMsQ0FBQ2lOLGNBQUY7QUFDQWpOLFNBQUMsQ0FBQ3NLLGVBQUY7O0FBQ0EsWUFBSStGLE1BQU0sS0FBSyxPQUFmLEVBQXdCO0FBQ3RCeUIseUJBQWUsQ0FBQzlSLENBQUMsQ0FBQ2dSLEtBQUgsRUFBVWhSLENBQUMsQ0FBQ2lSLEtBQVosQ0FBZjtBQUNBdkIsb0JBQVUsQ0FBQyxDQUNULEdBQUdELE9BRE0sa0NBRUwwRCxJQUZLO0FBRUNoSixvQkFBUSxFQUFFK0UsYUFBYSxDQUFDckYsR0FGekI7QUFFOEJ0TixpQkFBSyxFQUFFMlMsYUFBYSxDQUFDM1M7QUFGbkQsYUFBRCxDQUFWO0FBSUQ7O0FBQ0QrVCxpQkFBUyxDQUFDLE1BQUQsQ0FBVDtBQUNELE9BWEQ7O0FBWUE5TyxvQkFBYyxDQUFDLENBQUM0UixNQUFELEVBQVMsZ0JBQVQsRUFBMkJFLEdBQUcsSUFBSUEsR0FBRyxDQUFDcEMsT0FBdEMsRUFBK0MsZ0JBQS9DLEVBQWlFcUMsR0FBRyxJQUFJQSxHQUFHLENBQUNyQixnQkFBNUUsRUFBOEYsTUFBOUYsRUFBc0dzQixHQUFHLElBQUlBLEdBQUcsQ0FBQyxTQUFELEVBQVlILGNBQVosQ0FBaEgsQ0FBRCxDQUFkOztBQUNBLGFBQU8sTUFBTTdSLGNBQWMsQ0FBQyxDQUFDNFIsTUFBRCxFQUFTLGdCQUFULEVBQTJCSyxHQUFHLElBQUlBLEdBQUcsQ0FBQ3ZDLE9BQXRDLEVBQStDLGdCQUEvQyxFQUFpRXdDLEdBQUcsSUFBSUEsR0FBRyxDQUFDcEIsbUJBQTVFLEVBQWlHLE1BQWpHLEVBQXlHcUIsR0FBRyxJQUFJQSxHQUFHLENBQUMsU0FBRCxFQUFZTixjQUFaLENBQW5ILENBQUQsQ0FBM0I7QUFDRDtBQUNGLEdBakJRLEVBaUJOLENBQUNELE1BQUQsRUFBUy9DLE1BQVQsRUFBaUI4QyxJQUFqQixDQWpCTSxDQUFUO0FBbUJBLHNCQUNFbFUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixLQUFwQixFQUEyQjtBQUN6QjBVLHNCQUFrQixFQUFFcEIsZ0JBREs7QUFFekJxQixzQkFBa0IsRUFBRTlCLGdCQUZLO0FBR3pCK0IsYUFBUyxFQUFFLEtBSGM7QUFJekI1VixPQUFHLEVBQUVrVixNQUpvQjtBQUlaaFUsVUFBTSxFQUFFLFNBSkk7QUFJRUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBSlosR0FBM0IsZUFNSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQixLQUFwQixFQUEyQjtBQUMzQjRVLGFBQVMsRUFBRSxLQURnQjtBQUUzQi9VLFNBQUssRUFBRTtBQUNMMUIsV0FBSyxFQUFHLE1BREg7QUFFTGtOLGNBQVEsRUFBRSxVQUZMO0FBR0x3SixXQUFLLEVBQUcsTUFISDtBQUlMbFgsWUFBTSxFQUFFLENBQUNoQixRQUFELEdBQVksV0FBWixHQUEwQjtBQUo3QixLQUZvQjtBQU94QnVELFVBQU0sRUFBRSxTQVBnQjtBQU9WQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFQQSxHQUEzQixlQVNFTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLEtBQXBCLEVBQTJCO0FBQzNCNFUsYUFBUyxFQUFFLEtBRGdCO0FBRTNCL1UsU0FBSyxFQUFFO0FBQ0xpVixjQUFRLEVBQUcsTUFETjtBQUVMQyxlQUFTLEVBQUcsTUFGUDtBQUdMRixXQUFLLEVBQUc7QUFISCxLQUZvQjtBQU8zQjdWLE9BQUcsRUFBRXVTLFlBUHNCO0FBUTNCRyxPQUFHLEVBQUVMLGVBQWUsQ0FBQ08sa0JBUk07QUFRYzFSLFVBQU0sRUFBRSxTQVJ0QjtBQVE0QkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBUnRDLEdBQTNCLENBVEYsRUFtQkU4USxNQUFNLEtBQUssT0FBWCxnQkFBcUJwUiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CZ1YscURBQXBCLEVBQWtDO0FBQUVwQixhQUFTLEVBQUVLLElBQWI7QUFBbUI1VyxTQUFLLEVBQUUyUyxhQUFhLENBQUMzUyxLQUF4QztBQUErQzZDLFVBQU0sRUFBRSxTQUF2RDtBQUE2REMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXZFLEdBQWxDLENBQXJCLEdBQTZLLElBbkIvSyxFQW9CRWtRLE9BQU8sQ0FBQ2hHLEdBQVIsQ0FBWSxDQUFDbUcsS0FBRCxFQUFRaE8sQ0FBUixrQkFDWjNDLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsS0FBcEIsRUFBMkI7QUFDekI0VSxhQUFTLEVBQUUsS0FEYztBQUV6Qi9VLFNBQUssRUFBRTtBQUNMN0MsWUFBTSxFQUFHLEdBQUUrUyxXQUFZLFlBQVdXLEtBQUssQ0FBQ3JULEtBQU4sSUFBZXVOLDZFQUFZLENBQUNsSSxDQUFELENBQUksRUFENUQ7QUFFTDJJLGNBQVEsRUFBRSxVQUZMO0FBR0xFLFNBQUcsRUFBRyxHQUFFbUYsS0FBSyxDQUFDSyxDQUFFLEdBSFg7QUFJTGtFLFVBQUksRUFBRyxHQUFFdkUsS0FBSyxDQUFDTSxDQUFFLEdBSlo7QUFLTDdTLFdBQUssRUFBRyxHQUFFdVMsS0FBSyxDQUFDQyxDQUFFLEdBTGI7QUFNTDNTLFlBQU0sRUFBRyxHQUFFMFMsS0FBSyxDQUFDSSxDQUFFLEdBTmQ7QUFPTG9FLG1CQUFhLEVBQUU7QUFQVixLQUZrQjtBQVd6QnhLLE9BQUcsRUFBRWhJLENBWG9CO0FBV2pCeEMsVUFBTSxFQUFFLFNBWFM7QUFXSEMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBWFAsR0FBM0IsZUFhSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQixLQUFwQixFQUEyQjtBQUMzQjRVLGFBQVMsRUFBRSxLQURnQjtBQUUzQi9VLFNBQUssRUFBRTtBQUNMMUIsV0FBSyxFQUFHLE1BREg7QUFFTEgsWUFBTSxFQUFHLE1BRko7QUFHTHVMLGdCQUFVLEVBQUcsR0FBRW1ILEtBQUssQ0FBQ3JULEtBQU4sSUFBZXVOLDZFQUFZLENBQUNsSSxDQUFELENBQUksRUFIekM7QUFJTHlTLGFBQU8sRUFBRWxGLGNBQWMsS0FBS3ZOLENBQW5CLEdBQXdCLEtBQXhCLEdBQWdDO0FBSnBDLEtBRm9CO0FBT3hCeEMsVUFBTSxFQUFFLFNBUGdCO0FBT1ZDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQVBBLEdBQTNCLENBYkosQ0FEQSxDQXBCRixDQU5KLENBREY7QUF1REQsQ0FqTkQ7O0FBa05ld1AsNEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDeE9BO0FBQUE7QUFBQTtBQUFBLE1BQU1yVCxZQUFZLEdBQUcsNEZBQXJCO0FBQWtIOztBQU9sSCxNQUFNd1ksWUFBWSxHQUFHLENBQUM7QUFBQ3BCLFdBQUQ7QUFBWTdELGFBQVcsR0FBRyxDQUExQjtBQUE2QjFTO0FBQTdCLENBQUQsS0FBeUM7QUFDNUQsc0JBQ0UwQyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLEtBQXBCLEVBQTJCO0FBQ3pCNFUsYUFBUyxFQUFFLEtBRGM7QUFFekIvVSxTQUFLLEVBQUU7QUFDTG9WLFVBQUksRUFBRyxHQUFFckIsU0FBUyxDQUFDNUMsQ0FBRSxHQURoQjtBQUVMekYsU0FBRyxFQUFHLEdBQUVxSSxTQUFTLENBQUM3QyxDQUFFLEdBRmY7QUFHTDVTLFdBQUssRUFBRyxHQUFFeVYsU0FBUyxDQUFDakQsQ0FBRSxHQUhqQjtBQUlMM1MsWUFBTSxFQUFHLEdBQUU0VixTQUFTLENBQUM5QyxDQUFFLEdBSmxCO0FBS0w5VCxZQUFNLEVBQUcsR0FBRStTLFdBQVcsSUFBSSxDQUFFLFlBQVcxUyxLQUFNLEVBTHhDO0FBTUwwUyxpQkFBVyxFQUFHLEdBQUVBLFdBQVcsSUFBSSxDQUFFLElBTjVCO0FBT0wxRSxjQUFRLEVBQUUsVUFQTDtBQVFMNkosbUJBQWEsRUFBRTtBQVJWLEtBRmtCO0FBV3RCaFYsVUFBTSxFQUFFLFNBWGM7QUFXUkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBWEYsR0FBM0IsZUFhSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQixLQUFwQixFQUEyQjtBQUMzQjRVLGFBQVMsRUFBRSxLQURnQjtBQUUzQi9VLFNBQUssRUFBRTtBQUNMMUIsV0FBSyxFQUFHLE1BREg7QUFFTEgsWUFBTSxFQUFHLE1BRko7QUFHTHVMLGdCQUFVLEVBQUcsR0FBRWxNLEtBQU0sRUFIaEI7QUFJTDhYLGFBQU8sRUFBRztBQUpMLEtBRm9CO0FBT3hCalYsVUFBTSxFQUFFLFNBUGdCO0FBT1ZDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQVBBLEdBQTNCLENBYkosQ0FERjtBQXlCRCxDQTFCRDs7QUEyQmUyVSwyRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbENBLE1BQU14WSxZQUFZLEdBQUcsOEVBQXJCO0FBQW9HO0FBRXBHO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVlBLE1BQU00WSxLQUFLLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQWQ7O0FBSUEsTUFBTXJRLE1BQU0sR0FBSWhHLEtBQUQsSUFBVztBQUN4QixRQUFNO0FBQUNtRSxZQUFEO0FBQVdJLFNBQVg7QUFBa0JHLFVBQWxCO0FBQTBCRixZQUExQjtBQUFvQ0gsYUFBcEM7QUFBK0NELGlCQUEvQztBQUE4REU7QUFBOUQsTUFBdUV0RSxLQUFLLElBQUksRUFBdEY7QUFDQSxRQUFNO0FBQUNzVyxVQUFEO0FBQVNoVyxRQUFUO0FBQWVpTCxNQUFmO0FBQW1CZ0w7QUFBbkIsTUFBMEJoUyxLQUFoQztBQUNBLFFBQU07QUFBQzNEO0FBQUQsTUFBVTBWLE1BQU0sSUFBSSxFQUExQjtBQUNBLHNCQUNFdFYsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnVWLGdEQUFwQixrQ0FBa0N4VyxLQUFsQztBQUF5Q21CLFVBQU0sRUFBRSxTQUFqRDtBQUF1REMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQWpFLG1CQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd1Ysd0RBQXBCLEVBQXFDO0FBQUN0VixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBckMsRUFDRWhCLElBQUksaUJBQUlVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J4Qiw4Q0FBcEIsRUFBMkI7QUFBQzBCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEzQixFQUErRmhCLElBQS9GLENBRFYsZUFFRVUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQndHLHdFQUFwQixFQUFpQztBQUNqQ2pELFlBQVEsRUFBRUEsUUFEdUI7QUFFakNFLFVBQU0sRUFBRUEsTUFGeUI7QUFHakNMLGFBQVMsRUFBRUEsU0FIc0I7QUFJakNxRCxhQUFTLEVBQUU3QyxvRUFBVSxDQUFDa0IsTUFKVztBQUlINUUsVUFBTSxFQUFFLFNBSkw7QUFJV0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBSnJCLEdBQWpDLENBRkYsQ0FESixlQVVJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeVYsc0RBQXBCLEVBQW1DO0FBQUN2VixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBbkMsZUFDRU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQm9WLEtBQXBCLEVBQTJCO0FBQUNsVixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBM0IsZUFDRU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjBWLHNFQUFwQixFQUErQjtBQUMvQnhXLGFBQVMsRUFBRSxLQURvQjtBQUUvQkcsUUFBSSxFQUFHLFFBQU9nRSxLQUFNLGVBRlc7QUFHL0JpSCxNQUFFLEVBQUcsR0FBRWdMLEdBQUksT0FIb0I7QUFJL0IzVixTQUFLLEVBQUUsTUFKd0I7QUFLL0JDLFNBQUssRUFBRSxLQUx3QjtBQU0vQkosWUFBUSxFQUFFLE1BQU0yRCxhQUFhLENBQUUsUUFBT0UsS0FBTSxlQUFmLEVBQStCLElBQS9CLENBTkU7QUFPL0JzUyxXQUFPLEVBQUVoVyxLQUFLLEtBQUssSUFQWTtBQVEvQmhELFlBQVEsRUFBRXVHLFFBUnFCO0FBUVhoRCxVQUFNLEVBQUUsU0FSRztBQVFHQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFSYixHQUEvQixDQURGLENBREYsZUFhRU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQm9WLEtBQXBCLEVBQTJCO0FBQUNsVixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBM0IsZUFDRU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjBWLHNFQUFwQixFQUErQjtBQUMvQnhXLGFBQVMsRUFBRSxLQURvQjtBQUUvQkcsUUFBSSxFQUFHLFFBQU9nRSxLQUFNLGVBRlc7QUFHL0JpSCxNQUFFLEVBQUcsR0FBRWdMLEdBQUksUUFIb0I7QUFJL0IzVixTQUFLLEVBQUUsT0FKd0I7QUFLL0JDLFNBQUssRUFBRSxJQUx3QjtBQU0vQkosWUFBUSxFQUFFLE1BQU0yRCxhQUFhLENBQUUsUUFBT0UsS0FBTSxlQUFmLEVBQStCLEtBQS9CLENBTkU7QUFPL0JzUyxXQUFPLEVBQUVoVyxLQUFLLEtBQUssS0FQWTtBQVEvQmhELFlBQVEsRUFBRXVHLFFBUnFCO0FBUVhoRCxVQUFNLEVBQUUsU0FSRztBQVFHQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFSYixHQUEvQixDQURGLENBYkYsQ0FWSixDQURGO0FBdUNELENBM0NEOztBQTZDZTBFLHFFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3RFQSxNQUFNdkksWUFBWSxHQUFHLHFGQUFyQjs7QUFBNEcsU0FBUzhGLGNBQVQsQ0FBd0JDLEdBQXhCLEVBQTZCO0FBQUUsTUFBSUMsYUFBYSxHQUFHQyxTQUFwQjtBQUErQixNQUFJOUMsS0FBSyxHQUFHNEMsR0FBRyxDQUFDLENBQUQsQ0FBZjtBQUFvQixNQUFJRyxDQUFDLEdBQUcsQ0FBUjs7QUFBVyxTQUFPQSxDQUFDLEdBQUdILEdBQUcsQ0FBQ0ksTUFBZixFQUF1QjtBQUFFLFVBQU1DLEVBQUUsR0FBR0wsR0FBRyxDQUFDRyxDQUFELENBQWQ7QUFBbUIsVUFBTUcsRUFBRSxHQUFHTixHQUFHLENBQUNHLENBQUMsR0FBRyxDQUFMLENBQWQ7QUFBdUJBLEtBQUMsSUFBSSxDQUFMOztBQUFRLFFBQUksQ0FBQ0UsRUFBRSxLQUFLLGdCQUFQLElBQTJCQSxFQUFFLEtBQUssY0FBbkMsS0FBc0RqRCxLQUFLLElBQUksSUFBbkUsRUFBeUU7QUFBRSxhQUFPOEMsU0FBUDtBQUFtQjs7QUFBQyxRQUFJRyxFQUFFLEtBQUssUUFBUCxJQUFtQkEsRUFBRSxLQUFLLGdCQUE5QixFQUFnRDtBQUFFSixtQkFBYSxHQUFHN0MsS0FBaEI7QUFBdUJBLFdBQUssR0FBR2tELEVBQUUsQ0FBQ2xELEtBQUQsQ0FBVjtBQUFvQixLQUE3RixNQUFtRyxJQUFJaUQsRUFBRSxLQUFLLE1BQVAsSUFBaUJBLEVBQUUsS0FBSyxjQUE1QixFQUE0QztBQUFFakQsV0FBSyxHQUFHa0QsRUFBRSxDQUFDLENBQUMsR0FBR0MsSUFBSixLQUFhbkQsS0FBSyxDQUFDb0QsSUFBTixDQUFXUCxhQUFYLEVBQTBCLEdBQUdNLElBQTdCLENBQWQsQ0FBVjtBQUE2RE4sbUJBQWEsR0FBR0MsU0FBaEI7QUFBNEI7QUFBRTs7QUFBQyxTQUFPOUMsS0FBUDtBQUFlOztBQUFBO0FBRy9tQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBWUEsTUFBTWlXLFlBQVksR0FBRyxrRkFBTyxLQUFQO0FBQUE7QUFBQSxFQUFIO0FBQUE7QUFBQTtBQUFBLEVBQWxCOztBQVNBLE1BQU16USxhQUFhLGdCQUFHcEYsNENBQUssQ0FBQ2tELElBQU4sQ0FBWWxFLEtBQUQsSUFBVztBQUMxQyxRQUFNO0FBQUN1RSxTQUFEO0FBQVFDLFlBQVI7QUFBa0JFLFVBQWxCO0FBQTBCTCxhQUExQjtBQUFxQ0QsaUJBQXJDO0FBQW9ERSxTQUFwRDtBQUEyREg7QUFBM0QsTUFBdUVuRSxLQUE3RTtBQUNBLFFBQU07QUFBQ007QUFBRCxNQUFTaUUsS0FBZjtBQUVBLFFBQU07QUFBQzdELGVBQUQ7QUFBY3NLLFdBQWQ7QUFBdUJwSztBQUF2QixNQUFnQzJELEtBQUssQ0FBQ00sb0VBQVUsQ0FBQ3NCLGNBQVosQ0FBTCxJQUFvQyxFQUExRTtBQUVBLFFBQU0sQ0FBQ2lGLE9BQUQsRUFBVTBMLFVBQVYsSUFBd0J6RixzREFBUSxDQUFDOU4sY0FBYyxDQUFDLENBQUMzQyxLQUFELEVBQVEsZ0JBQVIsRUFBMEI0RSxFQUFFLElBQUlBLEVBQUUsQ0FBQzRGLE9BQW5DLENBQUQsQ0FBZCxJQUErRCxFQUFoRSxDQUF0QztBQUNBLFFBQU0sQ0FBQzhGLGNBQUQsRUFBaUI2RixpQkFBakIsSUFBc0MxRixzREFBUSxDQUFDLElBQUQsQ0FBcEQ7QUFFQSxRQUFNMkYsV0FBVyxHQUFHM1MsU0FBUyxJQUFJekQsS0FBSyxDQUFDcVcsS0FBTixLQUFnQixFQUE3QixHQUFrQ3ZXLFdBQVcsSUFBSSxFQUFqRCxHQUFzREUsS0FBSyxDQUFDcVcsS0FBaEY7QUFFQSxRQUFNLENBQUNoRyxhQUFELEVBQWdCaUcsZ0JBQWhCLElBQW9DN0Ysc0RBQVEsQ0FBQztBQUNqRHpGLE9BQUcsRUFBRVosT0FBTyxDQUFDLENBQUQsQ0FBUCxDQUFXTyxFQURpQztBQUVqRGpOLFNBQUssRUFBRXVOLDhFQUFZLENBQUMsQ0FBRDtBQUY4QixHQUFELENBQWxEO0FBS0E2Rix5REFBUyxDQUFDLE1BQU07QUFDZG9GLGNBQVUsQ0FBQ3ZULGNBQWMsQ0FBQyxDQUFDM0MsS0FBRCxFQUFRLGdCQUFSLEVBQTBCb0gsRUFBRSxJQUFJQSxFQUFFLENBQUNvRCxPQUFuQyxDQUFELENBQWYsQ0FBVjtBQUNELEdBRlEsRUFFTixDQUFDN0csS0FBSyxDQUFDTSxvRUFBVSxDQUFDc0IsY0FBWixDQUFOLENBRk0sQ0FBVDtBQUlBdUwseURBQVMsQ0FBQyxNQUFNO0FBQ2R0TixpQkFBYSxDQUNWLFFBQU9FLEtBQU0sS0FBSU8sb0VBQVUsQ0FBQ3NCLGNBQWUsaUJBRGpDLEVBRVg5QixTQUFTLEdBQUcsRUFBSCxHQUFRZCxjQUFjLENBQUMsQ0FBQzNDLEtBQUQsRUFBUSxnQkFBUixFQUEwQnlOLEVBQUUsSUFBSUEsRUFBRSxDQUFDakQsT0FBbkMsQ0FBRCxDQUZwQixDQUFiO0FBSUEwTCxjQUFVLENBQUN6UyxTQUFTLEdBQUcsRUFBSCxHQUFRZCxjQUFjLENBQUMsQ0FBQzNDLEtBQUQsRUFBUSxnQkFBUixFQUEwQnFPLEVBQUUsSUFBSUEsRUFBRSxDQUFDN0QsT0FBbkMsQ0FBRCxDQUFoQyxDQUFWO0FBQ0QsR0FOUSxFQU1OLENBQUMxSyxXQUFELEVBQWNzSyxPQUFkLENBTk0sQ0FBVDtBQVFBMEcseURBQVMsQ0FBQyxNQUFNO0FBQ2QsUUFBSXlGLGFBQWEsR0FBRyxDQUFwQjtBQUNBbk0sV0FBTyxDQUFDaUQsT0FBUixDQUFnQixDQUFDeEMsTUFBRCxFQUFTMkwsR0FBVCxLQUFpQjtBQUMvQixVQUFJM0wsTUFBTSxDQUFDRixFQUFQLEtBQWMwRixhQUFhLENBQUNyRixHQUFoQyxFQUFxQztBQUNuQ3VMLHFCQUFhLEdBQUdDLEdBQWhCO0FBQ0Q7QUFDRixLQUpEO0FBS0FGLG9CQUFnQixDQUFDO0FBQ2Z0TCxTQUFHLEVBQUVaLE9BQU8sQ0FBQ21NLGFBQUQsQ0FBUCxDQUF1QjVMLEVBRGI7QUFFZmpOLFdBQUssRUFBRXVOLDhFQUFZLENBQUNzTCxhQUFEO0FBRkosS0FBRCxDQUFoQjtBQUlELEdBWFEsRUFXTixDQUFDbk0sT0FBRCxDQVhNLENBQVQ7QUFhQSxzQkFDRWhLLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1VixnREFBcEIsa0NBQWtDeFcsS0FBbEM7QUFBeUNjLFNBQUssRUFBRTtBQUFDakQsYUFBTyxFQUFFLE9BQVY7QUFBbUJrWSxjQUFRLEVBQUUsTUFBN0I7QUFBcUNuVCxjQUFRLEVBQUU7QUFBL0MsS0FBaEQ7QUFBd0d6QixVQUFNLEVBQUUsU0FBaEg7QUFBc0hDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUFoSSxtQkFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQndWLHdEQUFwQixFQUFxQztBQUFDdFYsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQXJDLEVBQ0VoQixJQUFJLGlCQUFJVSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeEIsOENBQXBCLEVBQTJCO0FBQUMwQixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBM0IsRUFBK0ZoQixJQUEvRixDQURWLGVBRUVVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J3Ryx3RUFBcEIsRUFBaUM7QUFDakNqRCxZQUFRLEVBQUVBLFFBRHVCO0FBRWpDRSxVQUFNLEVBQUVBLE1BRnlCO0FBR2pDTCxhQUFTLEVBQUVBLFNBSHNCO0FBSWpDcUQsYUFBUyxFQUFFN0Msb0VBQVUsQ0FBQ3NCLGNBSlc7QUFJS2hGLFVBQU0sRUFBRSxTQUpiO0FBSW1CQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFKN0IsR0FBakMsQ0FGRixDQURKLGVBVUlOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5VixzREFBcEIsRUFBbUM7QUFBRVcsT0FBRyxFQUFFLElBQVA7QUFBYWxXLFVBQU0sRUFBRSxTQUFyQjtBQUEyQkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXJDLEdBQW5DLGVBQ0VOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I0VixZQUFwQixFQUFrQztBQUNsQ1MsZUFBVyxFQUFHdlYsQ0FBRCxJQUFPO0FBQ2xCQSxPQUFDLENBQUNzSyxlQUFGO0FBQ0QsS0FIaUM7QUFHL0JsTCxVQUFNLEVBQUUsU0FIdUI7QUFHakJDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUhPLEdBQWxDLEVBS0UwVixXQUFXLGlCQUNYaFcsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjZQLHFFQUFwQixFQUFtQztBQUNqQ0MsT0FBRyxFQUFFaUcsV0FENEI7QUFFakMvRixpQkFBYSxFQUFFQSxhQUZrQjtBQUdqQzdGLFdBQU8sRUFBRUEsT0FId0I7QUFJakM4RixrQkFBYyxFQUFFQSxjQUppQjtBQUtqQ3RULFlBQVEsRUFBRXVHLFFBTHVCO0FBTWpDMUQsWUFBUSxFQUFHc0IsQ0FBRCxJQUFPO0FBQ2YrVSxnQkFBVSxDQUFDL1UsQ0FBRCxDQUFWO0FBQ0FxQyxtQkFBYSxDQUFFLFFBQU9FLEtBQU0sS0FBSU8sb0VBQVUsQ0FBQ3NCLGNBQWUsaUJBQTdDLEVBQStEcEUsQ0FBL0QsQ0FBYjtBQUNELEtBVGdDO0FBUzlCWixVQUFNLEVBQUUsU0FUc0I7QUFTaEJDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQVRNLEdBQW5DLENBTkYsQ0FERixlQW9CRU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhKLGdGQUFwQixFQUF5QztBQUN6Q0MsV0FBTyxFQUFFQSxPQURnQztBQUV6Q0ksV0FBTyxFQUFFQSxPQUZnQztBQUd6Q3hOLFlBQVEsRUFBRXVHLFFBSCtCO0FBSXpDZ0gsWUFBUSxFQUFHdEssS0FBRCxJQUFXO0FBQ25CcVcsc0JBQWdCLENBQUNyVyxLQUFELENBQWhCO0FBQ0QsS0FOd0M7QUFPekN3SyxXQUFPLEVBQUcvRyxLQUFELElBQVc7QUFDbEJ5Uyx1QkFBaUIsQ0FBQ3pTLEtBQUQsQ0FBakI7QUFDRCxLQVR3QztBQVV6Q3NELFdBQU8sRUFBR3RELEtBQUQsSUFBVztBQUNsQndTLGdCQUFVLENBQUMxTCxPQUFPLENBQUNtTSxNQUFSLENBQWUsQ0FBQ3JTLENBQUQsRUFBSXZCLENBQUosS0FBVUEsQ0FBQyxLQUFLVyxLQUEvQixDQUFELENBQVY7QUFDRCxLQVp3QztBQWF6QzRHLG9CQUFnQixFQUFFK0YsYUFidUI7QUFhUjlQLFVBQU0sRUFBRSxTQWJBO0FBYU1DLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQWJoQixHQUF6QyxDQXBCRixDQVZKLENBREY7QUFpREQsQ0ExRnFCLENBQXRCO0FBNEZlOEUsNEVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1SEEsTUFBTTNJLFlBQVksR0FBRywrRUFBckI7QUFBcUc7QUFFckc7QUFDQTs7QUFPQSxNQUFNK1ksT0FBTyxHQUFHO0FBQUg7QUFBQSxzRkFNQyxDQUFDO0FBQUNnQjtBQUFELENBQUQsS0FBaUJBLFFBQVEsR0FBR0EsUUFBSCxHQUFjLE1BTnhDLGVBT0RwVixpRUFQQyxvQ0FBYjs7QUFZQSxNQUFNcVYsZ0JBQWdCLEdBQUc7QUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXRCOztBQU1BLE1BQU1DLFVBQVUsR0FBRyxrRkFBT3BRLGlFQUFQO0FBQUE7QUFBQSxFQUFILGdGQU9KLENBQUM7QUFBQ2pEO0FBQUQsQ0FBRCxLQUFrQkEsU0FBUyxHQUFHLE1BQUgsR0FBWSxTQVBuQyx1Q0FTSCxDQUFDO0FBQUNBO0FBQUQsQ0FBRCxLQUFrQkEsU0FBUyxHQUFHLE9BQUgsR0FBYSxNQVRyQyxPQVVab1QsZ0JBVlksdUJBV0QsQ0FBQztBQUFDcFQ7QUFBRCxDQUFELEtBQWtCQSxTQUFTLEdBQUcsT0FBSCxHQUFhLE1BWHZDLDhDQUFoQjs7QUFrQmUsU0FBUzJJLGNBQVQsQ0FBd0I7QUFBQzNFLFVBQUQ7QUFBV2hFLFdBQVg7QUFBc0JtVDtBQUF0QixDQUF4QixFQUF5RDtBQUN0RSxRQUFNRyxpQkFBaUIsR0FBSTVWLENBQUQsSUFBTztBQUMvQkEsS0FBQyxDQUFDRSxNQUFGLENBQVNtTSxTQUFULENBQW1Cd0osR0FBbkIsQ0FBdUIsVUFBdkI7QUFDRCxHQUZEOztBQUlBLFFBQU1DLG9CQUFvQixHQUFJOVYsQ0FBRCxJQUFPO0FBQ2xDQSxLQUFDLENBQUNFLE1BQUYsQ0FBU21NLFNBQVQsQ0FBbUJnQixNQUFuQixDQUEwQixVQUExQjtBQUNELEdBRkQ7O0FBR0Esc0JBQ0VwTyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd1csZ0JBQXBCLEVBQXNDO0FBQUN0VyxVQUFNLEVBQUUsSUFBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBdEMsZUFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQnlXLFVBQXBCLEVBQWdDO0FBQ2hDSSxhQUFTLEVBQUUsYUFEcUI7QUFFaEN6VCxhQUFTLEVBQUVBLFNBRnFCO0FBR2hDdkQsU0FBSyxFQUFFO0FBQ0xoQyxjQUFRLEVBQUUsRUFETDtBQUVMUixXQUFLLEVBQUU7QUFGRixLQUh5QjtBQU9oQ3laLGNBQVUsRUFBRUYsb0JBUG9CO0FBUWhDUCxlQUFXLEVBQUVLLGlCQVJtQjtBQVNoQ0ssYUFBUyxFQUFFSCxvQkFUcUI7QUFTQzFXLFVBQU0sRUFBRSxJQVRUO0FBU2VDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQVR6QixHQUFoQyxFQVVBLGFBVkEsQ0FESixlQWNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CdVYsT0FBcEIsRUFBNkI7QUFBRW5TLGFBQVMsRUFBRUEsU0FBYjtBQUF3Qm1ULFlBQVEsRUFBRUEsUUFBbEM7QUFBNENyVyxVQUFNLEVBQUUsSUFBcEQ7QUFBMERDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUFwRSxHQUE3QixFQUNFK0csUUFERixDQWRKLENBREY7QUFvQkQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxRUQsTUFBTTVLLFlBQVksR0FBRyw0RUFBckI7QUFBa0c7QUFDbEc7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFhQSxNQUFNd2EsU0FBUyxHQUFJalksS0FBRCxJQUFXO0FBQzNCLFFBQU07QUFBQ21FLFlBQUQ7QUFBV0ksU0FBWDtBQUFrQkcsVUFBbEI7QUFBMEJGLFlBQTFCO0FBQW9DSixpQkFBcEM7QUFBbURDLGFBQW5EO0FBQThEQztBQUE5RCxNQUF1RXRFLEtBQTdFO0FBQ0EsUUFBTTtBQUFDa1ksUUFBRDtBQUFPNVg7QUFBUCxNQUFlaUUsS0FBckI7QUFDQSxRQUFNO0FBQUM3RCxlQUFEO0FBQWN5WCxhQUFTLEVBQUVqSixRQUF6QjtBQUFtQ3RPLFNBQUssR0FBRztBQUEzQyxNQUFpRHNYLElBQUksSUFBSSxFQUEvRDtBQUVBLFFBQU1sQixXQUFXLEdBQUczUyxTQUFTLEdBQUd6RCxLQUFLLElBQUlGLFdBQVosR0FBMEJFLEtBQXZEO0FBRUEsc0JBQ0VJLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1VixnREFBcEIsa0NBQWtDeFcsS0FBbEM7QUFBeUNtQixVQUFNLEVBQUUsU0FBakQ7QUFBdURDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUFqRSxtQkFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQndWLHdEQUFwQixFQUFxQztBQUFDdFYsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQXJDLEVBQ0VoQixJQUFJLGlCQUFJVSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeEIsOENBQXBCLEVBQTJCO0FBQUMwQixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBM0IsRUFBK0ZoQixJQUEvRixDQURWLGVBRUVVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J3Ryx3RUFBcEIsRUFBaUM7QUFDakNqRCxZQUFRLEVBQUVBLFFBRHVCO0FBRWpDRSxVQUFNLEVBQUVBLE1BRnlCO0FBR2pDTCxhQUFTLEVBQUVBLFNBSHNCO0FBSWpDcUQsYUFBUyxFQUFFN0Msb0VBQVUsQ0FBQ3NDLElBSlc7QUFJTGhHLFVBQU0sRUFBRSxTQUpIO0FBSVNDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUpuQixHQUFqQyxDQUZGLENBREosZUFVSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQnlWLHNEQUFwQixFQUFtQztBQUFDdlYsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQW5DLEVBQ0U0TixRQUFRLElBQUkvSyxRQUFaLGdCQUNBbkQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixLQUFwQixFQUEyQjtBQUFDRSxVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBM0IsRUFBK0Y4VyxpRkFBZ0IsQ0FBQ3BCLFdBQUQsQ0FBL0csQ0FEQSxnQkFHQWhXLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvWCx1RUFBcEIsRUFBZ0M7QUFDOUIvWCxRQUFJLEVBQUcsUUFBT2dFLEtBQU0sYUFEVTtBQUU5QjFELFNBQUssRUFBRW9XLFdBRnVCO0FBRzlCOUgsWUFBUSxFQUFFQSxRQUFRLElBQUkvSyxRQUhRO0FBSTlCekQsZUFBVyxFQUFFQSxXQUppQjtBQUs5QjBELGlCQUFhLEVBQUVBLGFBTGU7QUFLQWpELFVBQU0sRUFBRSxTQUxSO0FBS2NDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUx4QixHQUFoQyxDQUpGLENBVkosQ0FERjtBQTBCRCxDQWpDRDs7QUFtQ2UyVyx3RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekRBLE1BQU14YSxZQUFZLEdBQUcsNkVBQXJCOztBQUFvRyxTQUFTOEYsY0FBVCxDQUF3QkMsR0FBeEIsRUFBNkI7QUFBRSxNQUFJQyxhQUFhLEdBQUdDLFNBQXBCO0FBQStCLE1BQUk5QyxLQUFLLEdBQUc0QyxHQUFHLENBQUMsQ0FBRCxDQUFmO0FBQW9CLE1BQUlHLENBQUMsR0FBRyxDQUFSOztBQUFXLFNBQU9BLENBQUMsR0FBR0gsR0FBRyxDQUFDSSxNQUFmLEVBQXVCO0FBQUUsVUFBTUMsRUFBRSxHQUFHTCxHQUFHLENBQUNHLENBQUQsQ0FBZDtBQUFtQixVQUFNRyxFQUFFLEdBQUdOLEdBQUcsQ0FBQ0csQ0FBQyxHQUFHLENBQUwsQ0FBZDtBQUF1QkEsS0FBQyxJQUFJLENBQUw7O0FBQVEsUUFBSSxDQUFDRSxFQUFFLEtBQUssZ0JBQVAsSUFBMkJBLEVBQUUsS0FBSyxjQUFuQyxLQUFzRGpELEtBQUssSUFBSSxJQUFuRSxFQUF5RTtBQUFFLGFBQU84QyxTQUFQO0FBQW1COztBQUFDLFFBQUlHLEVBQUUsS0FBSyxRQUFQLElBQW1CQSxFQUFFLEtBQUssZ0JBQTlCLEVBQWdEO0FBQUVKLG1CQUFhLEdBQUc3QyxLQUFoQjtBQUF1QkEsV0FBSyxHQUFHa0QsRUFBRSxDQUFDbEQsS0FBRCxDQUFWO0FBQW9CLEtBQTdGLE1BQW1HLElBQUlpRCxFQUFFLEtBQUssTUFBUCxJQUFpQkEsRUFBRSxLQUFLLGNBQTVCLEVBQTRDO0FBQUVqRCxXQUFLLEdBQUdrRCxFQUFFLENBQUMsQ0FBQyxHQUFHQyxJQUFKLEtBQWFuRCxLQUFLLENBQUNvRCxJQUFOLENBQVdQLGFBQVgsRUFBMEIsR0FBR00sSUFBN0IsQ0FBZCxDQUFWO0FBQTZETixtQkFBYSxHQUFHQyxTQUFoQjtBQUE0QjtBQUFFOztBQUFDLFNBQU85QyxLQUFQO0FBQWU7O0FBQUE7QUFHdm1CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFjTyxNQUFNMFgsVUFBVSxHQUFHO0FBQUE7QUFBQSxHQUFTO0FBQ2pDeFosVUFBUSxFQUFFLEVBRHVCO0FBRWpDQyxZQUFVLEVBQUUsR0FGcUI7QUFHakNKLFlBQVUsRUFBRSxHQUhxQjtBQUlqQ0wsT0FBSyxFQUFFSixnRUFBTyxDQUFDb0gsSUFKa0I7QUFLakNpVCxZQUFVLEVBQUUsVUFMcUI7QUFNakNDLFVBQVEsRUFBRSxZQU51QjtBQU9qQ0MsV0FBUyxFQUFFO0FBUHNCLENBQVQsQ0FBbkI7QUFVUSxTQUFTeFQsS0FBVCxDQUFlakYsS0FBZixFQUFzQjtBQUNuQyxRQUFNO0FBQ0ptRSxZQURJO0FBRUpJLFNBRkk7QUFHSkcsVUFISTtBQUlKRixZQUpJO0FBS0pILGFBTEk7QUFNSkMsU0FOSTtBQU9KM0csU0FQSTtBQVFKOEcsY0FSSTtBQVNKM0M7QUFUSSxNQVVGOUIsS0FWSjtBQVdBLFFBQU07QUFBQ21GLFNBQUQ7QUFBUTdFO0FBQVIsTUFBZ0JpRSxLQUF0QjtBQUNBLFFBQU07QUFBQzdELGVBQUQ7QUFBY3lYLGFBQVMsRUFBRWpKLFFBQXpCO0FBQW1DdE8sU0FBSyxHQUFHO0FBQTNDLE1BQWlEdUUsS0FBSyxJQUFJLEVBQWhFO0FBQ0EsUUFBTTZSLFdBQVcsR0FBRzNTLFNBQVMsR0FBRzNELFdBQUgsR0FBaUJFLEtBQTlDO0FBRUEsc0JBQ0VJLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1VixnREFBcEIsa0NBQWtDeFcsS0FBbEM7QUFBeUNtQixVQUFNLEVBQUUsSUFBakQ7QUFBdURDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUFqRSxtQkFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQndWLHdEQUFwQixFQUFxQztBQUFDdFYsVUFBTSxFQUFFLElBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQXJDLEVBQ0VoQixJQUFJLGlCQUFJVSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeEIsOENBQXBCLEVBQTJCO0FBQUMwQixVQUFNLEVBQUUsSUFBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBM0IsRUFBK0ZoQixJQUEvRixDQURWLGVBRUVVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J3Ryx3RUFBcEIsRUFBaUM7QUFDakNqRCxZQUFRLEVBQUVBLFFBRHVCO0FBRWpDRSxVQUFNLEVBQUVBLE1BRnlCO0FBR2pDTCxhQUFTLEVBQUVBLFNBSHNCO0FBSWpDcUQsYUFBUyxFQUFFN0Msb0VBQVUsQ0FBQ0csS0FKVztBQUlKN0QsVUFBTSxFQUFFLElBSko7QUFJVUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBSnBCLEdBQWpDLENBRkYsQ0FESixlQVVJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeVYsc0RBQXBCLEVBQW1DO0FBQUN2VixVQUFNLEVBQUUsSUFBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBbkMsRUFDRSxDQUFDNE4sUUFBRCxJQUFhLENBQUMvSyxRQUFkLGdCQUNBbkQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm5CLHVFQUFwQixFQUFnQztBQUM5QmEsUUFBSSxFQUFFLE9BRHdCO0FBRTlCTCxRQUFJLEVBQUcsUUFBT2dFLEtBQU0sY0FGVTtBQUc5QjFELFNBQUssRUFBRW9XLFdBQVcsSUFBSSxFQUhRO0FBSTlCMEIsb0JBQWdCLEVBQUUsSUFKWTtBQUs5Qi9hLFNBQUssRUFBRTRGLGNBQWMsQ0FBQyxDQUFDNUYsS0FBRCxFQUFRLGdCQUFSLEVBQTBCdUgsQ0FBQyxJQUFJQSxDQUFDLENBQUN0RSxLQUFqQyxDQUFELENBTFM7QUFNOUJULGFBQVMsRUFBRSxLQU5tQjtBQU85Qk0sWUFBUSxFQUFFcUIsWUFQb0I7QUFROUJ2QixVQUFNLEVBQUVrRSxVQVJzQjtBQVM5QnlLLFlBQVEsRUFBRUEsUUFUb0I7QUFTVi9OLFVBQU0sRUFBRSxJQVRFO0FBU0lDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQVRkLEdBQWhDLENBREEsZ0JBYUFOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JxWCxVQUFwQixFQUFnQztBQUFFSyxRQUFJLEVBQUcsVUFBUzNCLFdBQVksRUFBOUI7QUFBaUM3VixVQUFNLEVBQUUsSUFBekM7QUFBK0NDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6RCxHQUFoQyxFQUFvSTBWLFdBQXBJLENBZEYsQ0FWSixDQURGO0FBOEJELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hGRCxNQUFNdlosWUFBWSxHQUFHLDZFQUFyQjtBQUFtRztBQUduRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBYUEsTUFBTW1iLE1BQU0sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBZjs7QUFNQSxNQUFNdFMsS0FBSyxHQUFJdEcsS0FBRCxJQUFXO0FBQ3ZCLFFBQU07QUFBQ3VFLFNBQUQ7QUFBUUcsVUFBUjtBQUFnQkYsWUFBaEI7QUFBMEJILGFBQTFCO0FBQXFDMUcsU0FBckM7QUFBNEMyRztBQUE1QyxNQUFxRHRFLEtBQUssSUFBSSxFQUFwRTtBQUNBLFFBQU07QUFBQzZZLFNBQUQ7QUFBUXZZO0FBQVIsTUFBZ0JpRSxLQUF0QjtBQUNBLFFBQU07QUFBQzNELFNBQUQ7QUFBUUY7QUFBUixNQUF1Qm1ZLEtBQUssSUFBSSxFQUF0QztBQUVBLE1BQUlDLFNBQVMsR0FBR3pVLFNBQVMsR0FBRzNELFdBQUgsR0FBaUJFLEtBQTFDOztBQUVBLE1BQUlqRCxLQUFLLENBQUMrUCxJQUFOLElBQWMvUCxLQUFLLENBQUMrUCxJQUFOLENBQVdwSixLQUFYLENBQWQsSUFBbUMzRyxLQUFLLENBQUMrUCxJQUFOLENBQVc5SixNQUFsRCxFQUEwRDtBQUN4RGtWLGFBQVMsR0FBRyxFQUFaO0FBQ0Q7O0FBRUQsc0JBQ0U5WCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK0wsZ0RBQXBCLGtDQUF5Q2hOLEtBQXpDO0FBQWdEd1gsWUFBUSxFQUFHLFFBQTNEO0FBQW9FclcsVUFBTSxFQUFFLFNBQTVFO0FBQWtGQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBNUYsbUJBQ0lOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J3Vix3REFBcEIsRUFBcUM7QUFBQ3RWLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFyQyxFQUNFaEIsSUFBSSxpQkFBSVUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnhCLDhDQUFwQixFQUEyQjtBQUFDMEIsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTNCLEVBQStGaEIsSUFBL0YsQ0FEVixlQUVFVSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd0csd0VBQXBCLEVBQWlDO0FBQ2pDakQsWUFBUSxFQUFFQSxRQUR1QjtBQUVqQ0UsVUFBTSxFQUFFQSxNQUZ5QjtBQUdqQ0wsYUFBUyxFQUFFQSxTQUhzQjtBQUlqQ3FELGFBQVMsRUFBRTdDLG9FQUFVLENBQUN3QixLQUpXO0FBSUpsRixVQUFNLEVBQUUsU0FKSjtBQUlVQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFKcEIsR0FBakMsQ0FGRixDQURKLGVBVUlOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5VixzREFBcEIsRUFBbUM7QUFBQ3ZWLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFuQyxlQUNFTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMlgsTUFBcEIsRUFBNEI7QUFBRWpHLE9BQUcsRUFBRW1HLFNBQVA7QUFBa0IzWCxVQUFNLEVBQUUsU0FBMUI7QUFBZ0NDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUExQyxHQUE1QixDQURGLENBVkosQ0FERjtBQWdCRCxDQTNCRDs7QUE2QmVnRixvRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeERBLE1BQU03SSxZQUFZLEdBQUcsb0ZBQXJCOztBQUEyRyxTQUFTOEYsY0FBVCxDQUF3QkMsR0FBeEIsRUFBNkI7QUFBRSxNQUFJQyxhQUFhLEdBQUdDLFNBQXBCO0FBQStCLE1BQUk5QyxLQUFLLEdBQUc0QyxHQUFHLENBQUMsQ0FBRCxDQUFmO0FBQW9CLE1BQUlHLENBQUMsR0FBRyxDQUFSOztBQUFXLFNBQU9BLENBQUMsR0FBR0gsR0FBRyxDQUFDSSxNQUFmLEVBQXVCO0FBQUUsVUFBTUMsRUFBRSxHQUFHTCxHQUFHLENBQUNHLENBQUQsQ0FBZDtBQUFtQixVQUFNRyxFQUFFLEdBQUdOLEdBQUcsQ0FBQ0csQ0FBQyxHQUFHLENBQUwsQ0FBZDtBQUF1QkEsS0FBQyxJQUFJLENBQUw7O0FBQVEsUUFBSSxDQUFDRSxFQUFFLEtBQUssZ0JBQVAsSUFBMkJBLEVBQUUsS0FBSyxjQUFuQyxLQUFzRGpELEtBQUssSUFBSSxJQUFuRSxFQUF5RTtBQUFFLGFBQU84QyxTQUFQO0FBQW1COztBQUFDLFFBQUlHLEVBQUUsS0FBSyxRQUFQLElBQW1CQSxFQUFFLEtBQUssZ0JBQTlCLEVBQWdEO0FBQUVKLG1CQUFhLEdBQUc3QyxLQUFoQjtBQUF1QkEsV0FBSyxHQUFHa0QsRUFBRSxDQUFDbEQsS0FBRCxDQUFWO0FBQW9CLEtBQTdGLE1BQW1HLElBQUlpRCxFQUFFLEtBQUssTUFBUCxJQUFpQkEsRUFBRSxLQUFLLGNBQTVCLEVBQTRDO0FBQUVqRCxXQUFLLEdBQUdrRCxFQUFFLENBQUMsQ0FBQyxHQUFHQyxJQUFKLEtBQWFuRCxLQUFLLENBQUNvRCxJQUFOLENBQVdQLGFBQVgsRUFBMEIsR0FBR00sSUFBN0IsQ0FBZCxDQUFWO0FBQTZETixtQkFBYSxHQUFHQyxTQUFoQjtBQUE0QjtBQUFFOztBQUFDLFNBQU85QyxLQUFQO0FBQWU7O0FBQUE7QUFFOW1CO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQWFBLE1BQU1tWSxXQUFXLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXBCOztBQVFBLE1BQU0xQyxLQUFLLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQWQ7O0FBSUEsTUFBTTVVLE9BQU8sR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBaEI7O0FBT0EsTUFBTXVYLElBQUksR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBYjs7QUFJQSxNQUFNQywyQkFBMkIsR0FBRyxDQUNsQ0MsVUFEa0MsRUFFbENDLFdBRmtDLEVBR2xDQyxXQUhrQyxFQUlsQ0MsY0FKa0MsRUFLbEN6WSxLQUxrQyxFQU1sQzhNLElBTmtDLEtBTy9CO0FBQ0gsTUFBSTRMLGNBQWMsR0FBRyxLQUFyQjtBQUNBLE1BQUlDLGNBQWMsR0FBRyxLQUFyQjtBQUVBQSxnQkFBYyxHQUFHTCxVQUFVLEtBQUssQ0FBaEM7O0FBRUEsTUFBSUEsVUFBVSxLQUFLeEwsSUFBSSxDQUFDOUosTUFBTCxHQUFjLENBQWpDLEVBQW9DO0FBQ2xDLFFBQUl5VixjQUFjLEtBQUssQ0FBQyxDQUF4QixFQUEyQjtBQUN6QkMsb0JBQWMsR0FBRyxJQUFqQjtBQUNEO0FBQ0YsR0FKRCxNQUlPO0FBQ0wsUUFBSUgsV0FBVyxLQUFLdFUsb0VBQVUsQ0FBQzRCLGdCQUEzQixJQUErQzBTLFdBQVcsS0FBS3RVLG9FQUFVLENBQUNrQixNQUE5RSxFQUFzRjtBQUNwRixVQUFJLENBQUNuRixLQUFMLEVBQVkwWSxjQUFjLEdBQUcsSUFBakI7QUFDYixLQUZELE1BRU87QUFDTCxVQUFJMVksS0FBSyxLQUFLLEVBQVYsSUFBZ0JBLEtBQUssS0FBSyxJQUE5QixFQUFvQztBQUNsQzBZLHNCQUFjLEdBQUcsSUFBakI7QUFDRCxPQUZELE1BRU87QUFDTEEsc0JBQWMsR0FBRyxLQUFqQjtBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxNQUFJLENBQUNGLFdBQUQsS0FBaUIsSUFBakIsSUFBeUJBLFdBQVcsS0FBSzFWLFNBQTdDLEVBQXdEO0FBQ3RENFYsa0JBQWMsR0FBRyxLQUFqQjtBQUNELEdBRkQsTUFFTyxJQUFJRixXQUFXLEtBQUssSUFBcEIsRUFBMEI7QUFDL0JFLGtCQUFjLEdBQUcsSUFBakI7QUFDRDs7QUFFRCxTQUFPO0FBQ0xBLGtCQURLO0FBRUxDO0FBRkssR0FBUDtBQUlELENBdkNEOztBQXlDQSxNQUFNelMsWUFBWSxnQkFBRzVDLGtEQUFJLENBQUVsRSxLQUFELElBQVc7QUFDbkMsUUFBTSxDQUFDa1osVUFBRCxFQUFhTSxhQUFiLElBQThCbkksc0RBQVEsQ0FBQyxDQUFELENBQTVDO0FBQ0EsUUFBTTtBQUFDbE4sWUFBRDtBQUFXSSxTQUFYO0FBQWtCQyxZQUFsQjtBQUE0QjFDLGdCQUE1QjtBQUEwQ3dDLFNBQTFDO0FBQWlERCxhQUFqRDtBQUE0REssVUFBNUQ7QUFBb0VOO0FBQXBFLE1BQXFGcEUsS0FBM0Y7QUFDQSxRQUFNO0FBQUNNLFFBQUQ7QUFBT0ssUUFBUDtBQUFhNFY7QUFBYixNQUFvQmhTLEtBQUssSUFBSSxFQUFuQztBQUNBLFFBQU07QUFBQ21KLFFBQUQ7QUFBTytMLFdBQU8sR0FBRztBQUFqQixNQUF1QmxWLEtBQUssQ0FBQzVELElBQUQsQ0FBbEM7QUFFQSxRQUFNK1ksWUFBWSxHQUFHaE0sSUFBSSxDQUFDd0wsVUFBRCxDQUF6QjtBQUVBeEgseURBQVMsQ0FBQyxNQUFNO0FBQ2QsUUFBSXZOLFFBQUosRUFBYzs7QUFDZCxRQUFJdVYsWUFBWSxJQUFJblcsY0FBYyxDQUFDLENBQUNrVyxPQUFELEVBQVUsZ0JBQVYsRUFBNEJ2VSxDQUFDLElBQUlBLENBQUMsQ0FBQ3RCLE1BQW5DLENBQUQsQ0FBZCxHQUE2RCxDQUFqRixFQUFvRjtBQUNsRixZQUFNK1YsV0FBVyxHQUFHRixPQUFPLENBQUNHLEdBQVIsRUFBcEI7QUFDQSxZQUFNQyxZQUFZLEdBQUduTSxJQUFJLENBQUNvTSxTQUFMLENBQWUsQ0FBQztBQUFDdk87QUFBRCxPQUFELEtBQVVBLEVBQUUsS0FBS29PLFdBQWhDLENBQXJCO0FBQ0FILG1CQUFhLENBQUNLLFlBQVksR0FBRyxDQUFoQixDQUFiO0FBQ0Q7QUFDRixHQVBRLEVBT04sRUFQTSxDQUFUO0FBU0EsTUFBSSxDQUFDSCxZQUFMLEVBQW1CLE9BQU8sSUFBUDtBQUVuQixRQUFNO0FBQUMvWSxRQUFJLEVBQUV3WSxXQUFQO0FBQW9CN1ksUUFBSSxFQUFFeVo7QUFBMUIsTUFBOENMLFlBQXBEO0FBQ0EsUUFBTTtBQUFDOVksU0FBSyxHQUFHO0FBQVQsTUFBZThZLFlBQVksQ0FBQ1AsV0FBRCxDQUFqQztBQUNBLFFBQU1DLFdBQVcsR0FBRzdWLGNBQWMsQ0FBQyxDQUFDbVcsWUFBRCxFQUFlLGdCQUFmLEVBQWlDbFUsRUFBRSxJQUFJQSxFQUFFLENBQUN3VSxVQUExQyxDQUFELENBQWQsR0FBd0VOLFlBQVksQ0FBQ00sVUFBYixDQUF3QnBaLEtBQXhCLENBQXhFLEdBQXlHOEMsU0FBN0g7QUFDQSxRQUFNMlYsY0FBYyxHQUFHM0wsSUFBSSxDQUFDb00sU0FBTCxDQUFnQnZWLEtBQUQsSUFBV0EsS0FBSyxDQUFDZ0gsRUFBTixLQUFhNk4sV0FBdkMsQ0FBdkI7QUFDQSxRQUFNYSxXQUFXLEdBQUcsQ0FBQ3BWLG9FQUFVLENBQUNrQixNQUFaLEVBQW9CbEIsb0VBQVUsQ0FBQzRCLGdCQUEvQixDQUFwQjs7QUFFQSxRQUFNeVQsVUFBVSxHQUFJdE0sWUFBRCxJQUFrQjtBQUNuQyxRQUFJcU0sV0FBVyxDQUFDRSxRQUFaLENBQXFCaEIsV0FBckIsQ0FBSixFQUF1QztBQUNyQyxVQUFJLENBQUNDLFdBQUwsRUFBa0I7QUFDaEJ4TCxvQkFBWSxDQUFDZ0QsSUFBYixDQUFrQjhJLFlBQVksQ0FBQ25PLEVBQS9CO0FBQ0FpTyxxQkFBYSxDQUFDTixVQUFVLEdBQUcsQ0FBZCxDQUFiO0FBQ0QsT0FIRCxNQUdPO0FBQ0wsWUFBSUcsY0FBYyxLQUFLLENBQUMsQ0FBeEIsRUFBMkI7QUFDekJ6TCxzQkFBWSxDQUFDZ0QsSUFBYixDQUFrQjhJLFlBQVksQ0FBQ25PLEVBQS9CO0FBQ0FpTyx1QkFBYSxDQUFDSCxjQUFELENBQWI7QUFDRCxTQUhELE1BR087QUFDTGUsaUJBQU8sQ0FBQ3pjLEtBQVIsQ0FBYyxxQ0FBZDtBQUNEO0FBQ0Y7QUFDRixLQVpELE1BWU87QUFDTDtBQUNBaVEsa0JBQVksQ0FBQ2dELElBQWIsQ0FBa0I4SSxZQUFZLENBQUNuTyxFQUEvQjtBQUNBaU8sbUJBQWEsQ0FBQ04sVUFBVSxHQUFHLENBQWQsQ0FBYjtBQUNEO0FBQ0YsR0FsQkQ7O0FBb0JBLFFBQU1tQixVQUFVLEdBQUcsTUFBTTtBQUN2QixRQUFJOVcsY0FBYyxDQUFDLENBQUNrVyxPQUFELEVBQVUsZ0JBQVYsRUFBNEJ6UixFQUFFLElBQUlBLEVBQUUsQ0FBQ3BFLE1BQXJDLENBQUQsQ0FBZCxJQUFnRSxDQUFwRSxFQUF1RTtBQUNyRTRWLG1CQUFhLENBQUMsQ0FBRCxDQUFiO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsWUFBTWMsU0FBUyxHQUFHYixPQUFPLENBQUNHLEdBQVIsRUFBbEI7QUFDQSxZQUFNUCxjQUFjLEdBQUczTCxJQUFJLENBQUNvTSxTQUFMLENBQWdCdlYsS0FBRCxJQUFXQSxLQUFLLENBQUNnSCxFQUFOLEtBQWErTyxTQUF2QyxDQUF2Qjs7QUFDQSxVQUFJakIsY0FBYyxLQUFLLENBQUMsQ0FBeEIsRUFBMkI7QUFDekJHLHFCQUFhLENBQUNILGNBQUQsQ0FBYjtBQUNELE9BRkQsTUFFTztBQUNMRyxxQkFBYSxDQUFDLENBQUQsQ0FBYjtBQUNEO0FBQ0Y7QUFDRixHQVpEOztBQWNBLFFBQU07QUFBQ0Ysa0JBQUQ7QUFBaUJDO0FBQWpCLE1BQW1DTiwyQkFBMkIsQ0FDbEVDLFVBRGtFLEVBRWxFQyxXQUZrRSxFQUdsRUMsV0FIa0UsRUFJbEVDLGNBSmtFLEVBS2xFelksS0FMa0UsRUFNbEU4TSxJQU5rRSxDQUFwRTtBQVNBLHNCQUNFMU0sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhPLGlEQUFwQixFQUFnQztBQUM5QnpQLFFBQUksRUFBRyxRQUFPZ0UsS0FBTSxJQUFHM0QsSUFBSyxVQURFO0FBRTlCcVAsVUFBTSxFQUFHcEMsWUFBRCxpQkFDTjVNLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1VixpREFBcEIsa0NBQWtDeFcsS0FBbEM7QUFBeUNtQixZQUFNLEVBQUUsU0FBakQ7QUFBdURDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFBakUscUJBQ0lOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JRLE9BQXBCLEVBQTZCO0FBQUNOLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBN0IsZUFDRU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQndWLHlEQUFwQixFQUFxQztBQUFDdFYsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUFyQyxFQUNFaEIsSUFBSSxpQkFBSVUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnhCLCtDQUFwQixFQUEyQjtBQUFDMEIsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUEzQixFQUFnR2hCLElBQWhHLENBRFYsZUFFRVUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQndHLHdFQUFwQixFQUFpQztBQUNqQ2pELGNBQVEsRUFBRUEsUUFEdUI7QUFFakNFLFlBQU0sRUFBRUEsTUFGeUI7QUFHakNMLGVBQVMsRUFBRUEsU0FIc0I7QUFJakNxRCxlQUFTLEVBQUU3QyxvRUFBVSxDQUFDZ0MsYUFKVztBQUlJMUYsWUFBTSxFQUFFLFNBSlo7QUFJa0JDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFKNUIsS0FBakMsQ0FGRixDQURGLGVBVUVOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5Vix1REFBcEIsRUFBbUM7QUFBQ3ZWLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBbkMsZUFDRU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjhYLFdBQXBCLEVBQWlDO0FBQUM1WCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQWpDLGVBQ0VOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JzWiwwRUFBcEIsRUFBbUM7QUFDbkM1WixVQUFJLEVBQUUsUUFENkI7QUFFbkMvQyxjQUFRLEVBQUUyYixjQUZ5QjtBQUduQzNSLGFBQU8sRUFBRSxNQUFNeVMsVUFBVSxDQUFDek0sWUFBRCxDQUhVO0FBR016TSxZQUFNLEVBQUUsU0FIZDtBQUdvQkMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsa0JBQVUsRUFBRTtBQUFyQztBQUg5QixLQUFuQyxFQUlBLE1BSkEsQ0FERixlQVFFTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMFAsNEVBQXBCLEVBQXFDO0FBQ3JDaFEsVUFBSSxFQUFFLFFBRCtCO0FBRXJDL0MsY0FBUSxFQUFFMGIsY0FGMkI7QUFHckMxUixhQUFPLEVBQUUsTUFBTXNTLFVBQVUsQ0FBQ3RNLFlBQUQsQ0FIWTtBQUdJek0sWUFBTSxFQUFFLFNBSFo7QUFHa0JDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFINUIsS0FBckMsRUFJQSxNQUpBLENBUkYsQ0FERixFQWlCRXlZLGdCQUFnQixpQkFBSS9ZLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J4QiwrQ0FBcEIsRUFBMkI7QUFBQzBCLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBM0IsRUFBZ0d5WSxnQkFBaEcsQ0FqQnRCLEVBa0JFWixXQUFXLEtBQUt0VSxvRUFBVSxDQUFDQyxJQUEzQixpQkFDQTlELDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1WiwwRUFBcEIsRUFBbUM7QUFDakNsYSxVQUFJLEVBQUcsUUFBT2dFLEtBQU0sSUFBRzNELElBQUssU0FBUXVZLFVBQVcsSUFBR0MsV0FBWSxRQUQ3QjtBQUVqQzFZLGNBQVEsRUFBRXFCLFlBRnVCO0FBR2pDM0IsZUFBUyxFQUFFLEtBSHNCO0FBSWpDUyxXQUFLLEVBQUVBLEtBSjBCO0FBS2pDRSxXQUFLLEVBQUU7QUFBQ2lDLFlBQUksRUFBRTtBQUFQLE9BTDBCO0FBTWpDbkYsY0FBUSxFQUFFdUcsUUFOdUI7QUFPakN3SCxTQUFHLEVBQUVwSSxjQUFjLENBQUMsQ0FBQ21XLFlBQUQsRUFBZSxnQkFBZixFQUFpQ3JMLEVBQUUsSUFBSUEsRUFBRSxDQUFDOUMsRUFBMUMsQ0FBRCxDQVBjO0FBT21DcEssWUFBTSxFQUFFLFNBUDNDO0FBT2lEQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxrQkFBVSxFQUFFO0FBQXJDO0FBUDNELEtBQW5DLENBbkJGLEVBNkJFNlgsV0FBVyxLQUFLdFUsb0VBQVUsQ0FBQ08sTUFBM0IsaUJBQ0FwRSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK1gsSUFBcEIsRUFBMEI7QUFBQzdYLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBMUIsZUFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQm5CLHVFQUFwQixFQUFnQztBQUNoQ1EsVUFBSSxFQUFHLFFBQU9nRSxLQUFNLElBQUczRCxJQUFLLFNBQVF1WSxVQUFXLElBQUdDLFdBQVksUUFEOUI7QUFFaEMxWSxjQUFRLEVBQUVxQixZQUZzQjtBQUdoQ25CLFVBQUksRUFBRSxRQUgwQjtBQUloQ1IsZUFBUyxFQUFFLEtBSnFCO0FBS2hDUyxXQUFLLEVBQUVBLEtBTHlCO0FBTWhDaEQsY0FBUSxFQUFFdUcsUUFOc0I7QUFNWmhELFlBQU0sRUFBRSxTQU5JO0FBTUVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFOWixLQUFoQyxDQURKLENBOUJGLEVBeUNFNlgsV0FBVyxLQUFLdFUsb0VBQVUsQ0FBQ0csS0FBM0IsaUJBQ0FoRSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK1gsSUFBcEIsRUFBMEI7QUFBQzdYLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBMUIsZUFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQm5CLHVFQUFwQixFQUFnQztBQUNoQ1EsVUFBSSxFQUFHLFFBQU9nRSxLQUFNLElBQUczRCxJQUFLLFNBQVF1WSxVQUFXLElBQUdDLFdBQVksUUFEOUI7QUFFaEMxWSxjQUFRLEVBQUVxQixZQUZzQjtBQUdoQ25CLFVBQUksRUFBRSxPQUgwQjtBQUloQ1IsZUFBUyxFQUFFLEtBSnFCO0FBS2hDUyxXQUFLLEVBQUVBLEtBTHlCO0FBTWhDaEQsY0FBUSxFQUFFdUcsUUFOc0I7QUFNWmhELFlBQU0sRUFBRSxTQU5JO0FBTUVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFOWixLQUFoQyxDQURKLENBMUNGLEVBcURFNlgsV0FBVyxLQUFLdFUsb0VBQVUsQ0FBQ1MsSUFBM0IsaUJBQ0F0RSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK1gsSUFBcEIsRUFBMEI7QUFBQzdYLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBMUIsZUFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQm5CLHVFQUFwQixFQUFnQztBQUNoQ1EsVUFBSSxFQUFHLFFBQU9nRSxLQUFNLElBQUczRCxJQUFLLFNBQVF1WSxVQUFXLElBQUdDLFdBQVksUUFEOUI7QUFFaEMxWSxjQUFRLEVBQUVxQixZQUZzQjtBQUdoQ25CLFVBQUksRUFBRSxNQUgwQjtBQUloQ1IsZUFBUyxFQUFFLEtBSnFCO0FBS2hDUyxXQUFLLEVBQUVBLEtBTHlCO0FBTWhDaEQsY0FBUSxFQUFFdUcsUUFOc0I7QUFNWmhELFlBQU0sRUFBRSxTQU5JO0FBTUVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFOWixLQUFoQyxDQURKLENBdERGLEVBaUVFNlgsV0FBVyxLQUFLdFUsb0VBQVUsQ0FBQ2tCLE1BQTNCLGlCQUNBL0UsNENBQUssQ0FBQ0MsYUFBTixDQUFvQitYLElBQXBCLEVBQTBCO0FBQUM3WCxZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTFCLGVBQ0lOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvVixLQUFwQixFQUEyQjtBQUFDbFYsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUEzQixlQUNFTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMFYsc0VBQXBCLEVBQStCO0FBQy9CclcsVUFBSSxFQUFHLFFBQU9nRSxLQUFNLElBQUczRCxJQUFLLFNBQVF1WSxVQUFXLElBQUdDLFdBQVksUUFEL0I7QUFFL0I1TixRQUFFLEVBQUcsR0FBRWdMLEdBQUksSUFBRzJDLFVBQVcsT0FGTTtBQUcvQnRZLFdBQUssRUFBRSxNQUh3QjtBQUkvQkMsV0FBSyxFQUFFLEtBSndCO0FBSy9CSixjQUFRLEVBQUUsTUFDUjJELGFBQWEsQ0FDVixRQUFPRSxLQUFNLElBQUczRCxJQUFLLFNBQVF1WSxVQUFXLElBQUdDLFdBQVksUUFEN0MsRUFFWCxJQUZXLENBTmdCO0FBVy9CdkMsYUFBTyxFQUFFaFcsS0FBSyxLQUFLLElBWFk7QUFZL0JoRCxjQUFRLEVBQUV1RyxRQVpxQjtBQVlYaEQsWUFBTSxFQUFFLFNBWkc7QUFZR0MsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsa0JBQVUsRUFBRTtBQUFyQztBQVpiLEtBQS9CLENBREYsQ0FESixlQWlCSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQm9WLEtBQXBCLEVBQTJCO0FBQUNsVixZQUFNLEVBQUUsU0FBVDtBQUFlQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxrQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEtBQTNCLGVBQ0VOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IwVixzRUFBcEIsRUFBK0I7QUFDL0JyVyxVQUFJLEVBQUcsUUFBT2dFLEtBQU0sSUFBRzNELElBQUssU0FBUXVZLFVBQVcsSUFBR0MsV0FBWSxRQUQvQjtBQUUvQjVOLFFBQUUsRUFBRyxHQUFFZ0wsR0FBSSxJQUFHMkMsVUFBVyxRQUZNO0FBRy9CdFksV0FBSyxFQUFFLE9BSHdCO0FBSS9CQyxXQUFLLEVBQUUsSUFKd0I7QUFLL0JKLGNBQVEsRUFBRSxNQUNSMkQsYUFBYSxDQUNWLFFBQU9FLEtBQU0sSUFBRzNELElBQUssU0FBUXVZLFVBQVcsSUFBR0MsV0FBWSxRQUQ3QyxFQUVYLEtBRlcsQ0FOZ0I7QUFXL0J2QyxhQUFPLEVBQUVoVyxLQUFLLEtBQUssS0FYWTtBQVkvQmhELGNBQVEsRUFBRXVHLFFBWnFCO0FBWVhoRCxZQUFNLEVBQUUsU0FaRztBQVlHQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxrQkFBVSxFQUFFO0FBQXJDO0FBWmIsS0FBL0IsQ0FERixDQWpCSixDQWxFRixFQXFHRTZYLFdBQVcsS0FBS3RVLG9FQUFVLENBQUM0QixnQkFBM0IsaUJBQ0F6Riw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CK1gsSUFBcEIsRUFBMEI7QUFBQzdYLFlBQU0sRUFBRSxTQUFUO0FBQWVDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFBekIsS0FBMUIsRUFDSW9ZLFlBQVksQ0FBQ1AsV0FBRCxDQUFaLENBQTBCbk8sT0FBMUIsQ0FBa0NRLEdBQWxDLENBQXNDLENBQUNDLE1BQUQsRUFBU0MsV0FBVCxrQkFDdEMxSyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cb1YsS0FBcEIsRUFBMkI7QUFBRTFLLFNBQUcsRUFBRUQsV0FBUDtBQUFvQnZLLFlBQU0sRUFBRSxTQUE1QjtBQUFrQ0MsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsa0JBQVUsRUFBRTtBQUFyQztBQUE1QyxLQUEzQixlQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMFYsc0VBQXBCLEVBQStCO0FBQy9CclcsVUFBSSxFQUFHLFFBQU9nRSxLQUFNLElBQUczRCxJQUFLLFNBQVF1WSxVQUFXLElBQUdDLFdBQVksUUFEL0I7QUFFL0I1TixRQUFFLEVBQUcsR0FBRWpILEtBQU0sSUFBR29ILFdBQVksRUFGRztBQUcvQjlLLFdBQUssRUFBRTZLLE1BQU0sQ0FBQ0YsRUFIaUI7QUFJL0IxSyxXQUFLLEVBQUU0SyxNQUFNLENBQUNuTCxJQUppQjtBQUsvQkcsY0FBUSxFQUFFcUIsWUFMcUI7QUFNL0I4VSxhQUFPLEVBQUVuTCxNQUFNLENBQUNGLEVBQVAsS0FBYzNLLEtBTlE7QUFPL0JoRCxjQUFRLEVBQUV1RyxRQVBxQjtBQU9YaEQsWUFBTSxFQUFFLFNBUEc7QUFPR0MsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsa0JBQVUsRUFBRTtBQUFyQztBQVBiLEtBQS9CLENBREosQ0FEQSxDQURKLENBdEdGLEVBc0hFNlgsV0FBVyxLQUFLdFUsb0VBQVUsQ0FBQzhCLGtCQUEzQixpQkFDQTNGLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IrWCxJQUFwQixFQUEwQjtBQUFDN1gsWUFBTSxFQUFFLFNBQVQ7QUFBZUMsY0FBUSxFQUFFO0FBQUNDLGdCQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsa0JBQVUsRUFBRTtBQUFyQztBQUF6QixLQUExQixFQUNJb1ksWUFBWSxDQUFDUCxXQUFELENBQVosQ0FBMEJuTyxPQUExQixDQUFrQ1EsR0FBbEMsQ0FBc0MsQ0FBQ0MsTUFBRCxFQUFTQyxXQUFULGtCQUN0QzFLLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvVixLQUFwQixFQUEyQjtBQUFFMUssU0FBRyxFQUFFRCxXQUFQO0FBQW9CdkssWUFBTSxFQUFFLFNBQTVCO0FBQWtDQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxrQkFBVSxFQUFFO0FBQXJDO0FBQTVDLEtBQTNCLGVBQ0lOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J3WiwwRUFBcEIsRUFBa0M7QUFDbENuYSxVQUFJLEVBQUcsUUFBT2dFLEtBQU0sSUFBRzNELElBQUssU0FBUXVZLFVBQVcsSUFBR0MsV0FBWSxRQUQ1QjtBQUVsQzVOLFFBQUUsRUFBRyxHQUFFakgsS0FBTSxJQUFHb0gsV0FBWSxFQUZNO0FBR2xDOUssV0FBSyxFQUFFNkssTUFBTSxDQUFDRixFQUhvQjtBQUlsQzFLLFdBQUssRUFBRTRLLE1BQU0sQ0FBQ25MLElBSm9CO0FBS2xDRyxjQUFRLEVBQUVxQixZQUx3QjtBQU1sQzhVLGFBQU8sRUFBRWhXLEtBQUssSUFBSUEsS0FBSyxDQUFDdVosUUFBTixDQUFlMU8sTUFBTSxDQUFDRixFQUF0QixDQU5nQjtBQU9sQzNOLGNBQVEsRUFBRXVHLFFBUHdCO0FBT2RoRCxZQUFNLEVBQUUsU0FQTTtBQU9BQyxjQUFRLEVBQUU7QUFBQ0MsZ0JBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxrQkFBVSxFQUFFO0FBQXJDO0FBUFYsS0FBbEMsQ0FESixDQURBLENBREosQ0F2SEYsQ0FWRixDQURKLENBSDRCO0FBd0ozQkgsVUFBTSxFQUFFLFNBeEptQjtBQXdKYkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBeEpHLEdBQWhDLENBREY7QUE0SkQsQ0FoT3dCLENBQXpCO0FBa09ld0YsMkVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5VEEsTUFBTXJKLFlBQVksR0FBRyx1RkFBckI7QUFDQTs7QUFNQSxNQUFNZ1osZUFBZSxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUF4Qjs7QUFhZSxnRUFBQztBQUFDcE87QUFBRCxDQUFELGtCQUFnQnJILDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J3VixlQUFwQixFQUFxQztBQUFDdFYsUUFBTSxFQUFFLFNBQVQ7QUFBZUMsVUFBUSxFQUFFO0FBQUNDLFlBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxjQUFVLEVBQUU7QUFBckM7QUFBekIsQ0FBckMsRUFBeUcrRyxRQUF6RyxDQUEvQixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwQkEsTUFBTTVLLFlBQVksR0FBRyw2RUFBckI7QUFBbUc7QUFHbkc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVVBLE1BQU1pZCxTQUFTLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQWxCOztBQVFBLE1BQU0vVSxLQUFLLGdCQUFHM0UsMENBQUEsQ0FBWWhCLEtBQUQsSUFBVztBQUNsQyxRQUFNO0FBQUN1RSxTQUFEO0FBQVFDLFlBQVI7QUFBa0JFLFVBQWxCO0FBQTBCTDtBQUExQixNQUF1Q3JFLEtBQTdDO0FBQ0EsUUFBTTtBQUFDTSxRQUFEO0FBQU9LLFFBQVA7QUFBYTRLLE1BQWI7QUFBaUIwTDtBQUFqQixNQUEwQjFTLEtBQWhDO0FBQ0EsUUFBTTtBQUFDM0QsU0FBRDtBQUFRRjtBQUFSLE1BQXVCdVcsS0FBSyxJQUFJLEVBQXRDO0FBQ0EsUUFBTUQsV0FBVyxHQUFHM1MsU0FBUyxHQUFHekQsS0FBSyxJQUFJRixXQUFaLEdBQTBCRSxLQUF2RDtBQUVBLHNCQUNFSSxtREFBQSxDQUFvQndWLGdEQUFwQixrQ0FBa0N4VyxLQUFsQztBQUF5Q2MsU0FBSyxFQUFFO0FBQUNqRCxhQUFPLEVBQUUsT0FBVjtBQUFtQmtZLGNBQVEsRUFBRSxNQUE3QjtBQUFxQ25ULGNBQVEsRUFBRTtBQUEvQyxLQUFoRDtBQUF3R3pCLFVBQU0sRUFBRSxTQUFoSDtBQUFzSEMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQWhJLG1CQUNJTixtREFBQSxDQUFvQnlWLHdEQUFwQixFQUFxQztBQUFDdFYsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQXJDLEVBQ0VoQixJQUFJLGlCQUFJVSxtREFBQSxDQUFvQnZCLDhDQUFwQixFQUEyQjtBQUFDMEIsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTNCLEVBQStGaEIsSUFBL0YsQ0FEVixlQUVFVSxtREFBQSxDQUFvQnlHLHdFQUFwQixFQUFpQztBQUNqQ2pELFlBQVEsRUFBRUEsUUFEdUI7QUFFakNFLFVBQU0sRUFBRUEsTUFGeUI7QUFHakNMLGFBQVMsRUFBRUEsU0FIc0I7QUFJakNxRCxhQUFTLEVBQUU3QyxvRUFBVSxDQUFDYSxLQUpXO0FBSUp2RSxVQUFNLEVBQUUsU0FKSjtBQUlVQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFKcEIsR0FBakMsQ0FGRixDQURKLGVBVUlOLG1EQUFBLENBQW9CMFYsc0RBQXBCLEVBQW1DO0FBQUN2VixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBbkMsRUFDRTBWLFdBQVcsaUJBQ1hoVyxtREFBQSxDQUFvQjBaLFNBQXBCLEVBQStCO0FBQzdCL0gsT0FBRyxFQUFFcUUsV0FEd0I7QUFFN0IyRCxPQUFHLEVBQUVyYSxJQUFJLElBQUlLLElBRmdCO0FBRzdCaWEsU0FBSyxFQUFFdGEsSUFBSSxJQUFJSyxJQUhjO0FBSTdCc0ksZUFBVyxFQUFHbEgsQ0FBRCxJQUFPQSxDQUFDLENBQUNpTixjQUFGLEVBSlM7QUFJVzdOLFVBQU0sRUFBRSxTQUpuQjtBQUl5QkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBSm5DLEdBQS9CLENBRkYsQ0FWSixDQURGO0FBdUJELENBN0JhLENBQWQ7QUErQmVxRSxvRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7O0FDdkRBLE1BQU1sRyxLQUFLLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQWQ7O0FBS2VBLG9FQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQQSxNQUFNaEMsWUFBWSxHQUFHLDRFQUFyQjs7QUFBbUcsU0FBUzhGLGNBQVQsQ0FBd0JDLEdBQXhCLEVBQTZCO0FBQUUsTUFBSUMsYUFBYSxHQUFHQyxTQUFwQjtBQUErQixNQUFJOUMsS0FBSyxHQUFHNEMsR0FBRyxDQUFDLENBQUQsQ0FBZjtBQUFvQixNQUFJRyxDQUFDLEdBQUcsQ0FBUjs7QUFBVyxTQUFPQSxDQUFDLEdBQUdILEdBQUcsQ0FBQ0ksTUFBZixFQUF1QjtBQUFFLFVBQU1DLEVBQUUsR0FBR0wsR0FBRyxDQUFDRyxDQUFELENBQWQ7QUFBbUIsVUFBTUcsRUFBRSxHQUFHTixHQUFHLENBQUNHLENBQUMsR0FBRyxDQUFMLENBQWQ7QUFBdUJBLEtBQUMsSUFBSSxDQUFMOztBQUFRLFFBQUksQ0FBQ0UsRUFBRSxLQUFLLGdCQUFQLElBQTJCQSxFQUFFLEtBQUssY0FBbkMsS0FBc0RqRCxLQUFLLElBQUksSUFBbkUsRUFBeUU7QUFBRSxhQUFPOEMsU0FBUDtBQUFtQjs7QUFBQyxRQUFJRyxFQUFFLEtBQUssUUFBUCxJQUFtQkEsRUFBRSxLQUFLLGdCQUE5QixFQUFnRDtBQUFFSixtQkFBYSxHQUFHN0MsS0FBaEI7QUFBdUJBLFdBQUssR0FBR2tELEVBQUUsQ0FBQ2xELEtBQUQsQ0FBVjtBQUFvQixLQUE3RixNQUFtRyxJQUFJaUQsRUFBRSxLQUFLLE1BQVAsSUFBaUJBLEVBQUUsS0FBSyxjQUE1QixFQUE0QztBQUFFakQsV0FBSyxHQUFHa0QsRUFBRSxDQUFDLENBQUMsR0FBR0MsSUFBSixLQUFhbkQsS0FBSyxDQUFDb0QsSUFBTixDQUFXUCxhQUFYLEVBQTBCLEdBQUdNLElBQTdCLENBQWQsQ0FBVjtBQUE2RE4sbUJBQWEsR0FBR0MsU0FBaEI7QUFBNEI7QUFBRTs7QUFBQyxTQUFPOUMsS0FBUDtBQUFlOztBQUFBO0FBR3RtQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBY08sTUFBTTBYLFVBQVUsR0FBRztBQUFBO0FBQUEsR0FBUztBQUNqQ3haLFVBQVEsRUFBRSxFQUR1QjtBQUVqQ0MsWUFBVSxFQUFFLEdBRnFCO0FBR2pDSixZQUFVLEVBQUUsR0FIcUI7QUFJakNMLE9BQUssRUFBRUosZ0VBQU8sQ0FBQ29ILElBSmtCO0FBS2pDaVQsWUFBVSxFQUFFLFVBTHFCO0FBTWpDQyxVQUFRLEVBQUUsWUFOdUI7QUFPakNDLFdBQVMsRUFBRTtBQVBzQixDQUFULENBQW5CO0FBVVEsU0FBU2xULElBQVQsQ0FBY3ZGLEtBQWQsRUFBcUI7QUFDbEMsUUFBTTtBQUNKbUUsWUFESTtBQUVKSSxTQUZJO0FBR0pHLFVBSEk7QUFJSkYsWUFKSTtBQUtKSCxhQUxJO0FBTUpDLFNBTkk7QUFPSjNHLFNBUEk7QUFRSjhHLGNBUkk7QUFTSjNDO0FBVEksTUFVRjlCLEtBVko7QUFXQSxRQUFNO0FBQUN5RixRQUFEO0FBQU9uRjtBQUFQLE1BQWVpRSxLQUFyQjtBQUNBLFFBQU07QUFBQzdELGVBQUQ7QUFBY3lYLGFBQVMsRUFBRWpKLFFBQXpCO0FBQW1DdE8sU0FBSyxHQUFHO0FBQTNDLE1BQWlENkUsSUFBSSxJQUFJLEVBQS9EO0FBQ0EsUUFBTXVSLFdBQVcsR0FBRzNTLFNBQVMsR0FBRzNELFdBQUgsR0FBaUJFLEtBQTlDO0FBRUEsc0JBQ0VJLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1VixnREFBcEIsa0NBQWtDeFcsS0FBbEM7QUFBeUNtQixVQUFNLEVBQUUsSUFBakQ7QUFBdURDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUFqRSxtQkFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQndWLHdEQUFwQixFQUFxQztBQUFDdFYsVUFBTSxFQUFFLElBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQXJDLEVBQ0VoQixJQUFJLGlCQUFJVSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeEIsOENBQXBCLEVBQTJCO0FBQUMwQixVQUFNLEVBQUUsSUFBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBM0IsRUFBK0ZoQixJQUEvRixDQURWLGVBRUVVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J3Ryx3RUFBcEIsRUFBaUM7QUFDakNqRCxZQUFRLEVBQUVBLFFBRHVCO0FBRWpDRSxVQUFNLEVBQUVBLE1BRnlCO0FBR2pDTCxhQUFTLEVBQUVBLFNBSHNCO0FBSWpDcUQsYUFBUyxFQUFFN0Msb0VBQVUsQ0FBQ1MsSUFKVztBQUlMbkUsVUFBTSxFQUFFLElBSkg7QUFJU0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBSm5CLEdBQWpDLENBRkYsQ0FESixlQVVJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeVYsc0RBQXBCLEVBQW1DO0FBQUN2VixVQUFNLEVBQUUsSUFBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBbkMsRUFDRSxDQUFDNE4sUUFBRCxJQUFhLENBQUMvSyxRQUFkLGdCQUNBbkQsNENBQUssQ0FBQ0MsYUFBTixDQUFvQm5CLHVFQUFwQixFQUFnQztBQUM5QmEsUUFBSSxFQUFFLE1BRHdCO0FBRTlCTCxRQUFJLEVBQUcsUUFBT2dFLEtBQU0sYUFGVTtBQUc5QjFELFNBQUssRUFBRW9XLFdBQVcsSUFBSSxFQUhRO0FBSTlCMEIsb0JBQWdCLEVBQUUsSUFKWTtBQUs5Qi9hLFNBQUssRUFBRTRGLGNBQWMsQ0FBQyxDQUFDNUYsS0FBRCxFQUFRLGdCQUFSLEVBQTBCdUgsQ0FBQyxJQUFJQSxDQUFDLENBQUN0RSxLQUFqQyxDQUFELENBTFM7QUFNOUJULGFBQVMsRUFBRSxLQU5tQjtBQU85Qk0sWUFBUSxFQUFFcUIsWUFQb0I7QUFROUJ2QixVQUFNLEVBQUVrRSxVQVJzQjtBQVM5QnlLLFlBQVEsRUFBRUEsUUFUb0I7QUFTVi9OLFVBQU0sRUFBRSxJQVRFO0FBU0lDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQVRkLEdBQWhDLENBREEsZ0JBYUFOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JxWCxVQUFwQixFQUFnQztBQUFFSyxRQUFJLEVBQUcsR0FBRTNCLFdBQVksRUFBdkI7QUFBMEIvVSxVQUFNLEVBQUUsUUFBbEM7QUFBNENkLFVBQU0sRUFBRSxJQUFwRDtBQUEwREMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXBFLEdBQWhDLEVBQ0kwVixXQURKLENBZEYsQ0FWSixDQURGO0FBZ0NELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsRkQsTUFBTXZaLFlBQVksR0FBRyxrRkFBckI7QUFBd0c7QUFHeEc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQVVBLE1BQU11TixPQUFPLEdBQUc7QUFDZDZQLFVBQVEsRUFBRSxDQUFDLE1BQUQsRUFBUyxVQUFULEVBQXFCLGNBQXJCLEVBQXFDLE1BQXJDLEVBQTZDLFFBQTdDLEVBQXVELFVBQXZELEVBQW1FLFlBQW5FO0FBREksQ0FBaEI7O0FBSUEsTUFBTUMsV0FBVyxHQUFHO0FBQUE7QUFBQSxHQUFXLENBQUM7QUFBQ0MsTUFBRDtBQUFPQztBQUFQLENBQUQsTUFBMkI7QUFDeERuZCxTQUFPLEVBQUVrZCxJQUFJLEtBQUssS0FBVCxHQUFpQixNQUFqQixHQUEwQixPQURxQjtBQUV4RHZELFVBQVEsRUFBRXdELFlBQVksR0FBRyxRQUFILEdBQWMsU0FGb0I7QUFHeEQ3UyxRQUFNLEVBQUU7QUFIZ0QsQ0FBM0IsQ0FBWCxDQUFwQjs7QUFNQSxNQUFNdEMsVUFBVSxHQUFJN0YsS0FBRCxJQUFXO0FBQzVCLFFBQU07QUFBQ3VFLFNBQUQ7QUFBUUMsWUFBUjtBQUFrQkUsVUFBbEI7QUFBMEJMO0FBQTFCLE1BQXVDckUsS0FBN0M7QUFDQSxRQUFNO0FBQUNNLFFBQUQ7QUFBT0ssUUFBUDtBQUFhNEs7QUFBYixNQUFtQmhILEtBQXpCO0FBQ0EsUUFBTTtBQUFDM0QsU0FBRDtBQUFRRjtBQUFSLE1BQXVCNkQsS0FBSyxDQUFDNUQsSUFBRCxDQUFMLElBQWUsRUFBNUM7QUFDQSxRQUFNbVksU0FBUyxHQUFHelUsU0FBUyxHQUFHekQsS0FBSyxJQUFJRixXQUFaLEdBQTBCRSxLQUFyRDtBQUVBLFFBQU1xYSxhQUFhLEdBQUdDLDJFQUFXLENBQUNwQyxTQUFELENBQWpDO0FBRUEsUUFBTXFDLE9BQU8sR0FBRztBQUNkeGEsUUFBSSxFQUFFQSxJQURRO0FBRWR3YSxXQUFPLEVBQUUsQ0FBQztBQUFDeEksU0FBRyxFQUFFbUc7QUFBTixLQUFEO0FBRkssR0FBaEI7QUFLQXBILHlEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUl1SixhQUFhLEtBQUtuQyxTQUF0QixFQUFpQztBQUMvQixZQUFNc0MsRUFBRSxHQUFHMU8sUUFBUSxDQUFDeUIsY0FBVCxDQUF5QixRQUFPNUMsRUFBRyxFQUFuQyxDQUFYLENBRCtCLENBRS9COztBQUNBLFlBQU04UCxNQUFNLEdBQUcsSUFBSUMsMkNBQUosQ0FBU0YsRUFBVCxFQUFhcFEsT0FBYixDQUFmLENBSCtCLENBSS9COztBQUNBcVEsWUFBTSxDQUFDNUwsTUFBUCxHQUFnQjBMLE9BQWhCO0FBRUEsYUFBTyxNQUFNRSxNQUFNLENBQUNFLE9BQVAsRUFBYjtBQUNEOztBQUNEO0FBQ0QsR0FYUSxFQVdOLENBQUN6QyxTQUFELENBWE0sQ0FBVDtBQWFBLHNCQUNFOVgsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnVWLGdEQUFwQixrQ0FBa0N4VyxLQUFsQztBQUF5Q21CLFVBQU0sRUFBRSxTQUFqRDtBQUF1REMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQWpFLG1CQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd1Ysd0RBQXBCLEVBQXFDO0FBQUN0VixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBckMsRUFDRWhCLElBQUksaUJBQUlVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J4Qiw4Q0FBcEIsRUFBMkI7QUFBQzBCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEzQixFQUErRmhCLElBQS9GLENBRFYsZUFFRVUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQndHLG9EQUFwQixFQUFpQztBQUFFakQsWUFBUSxFQUFFQSxRQUFaO0FBQXNCRSxVQUFNLEVBQUVBLE1BQTlCO0FBQXNDTCxhQUFTLEVBQUVBLFNBQWpEO0FBQTREcUQsYUFBUyxFQUFFL0csSUFBdkU7QUFBNkVRLFVBQU0sRUFBRSxTQUFyRjtBQUEyRkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXJHLEdBQWpDLENBRkYsQ0FESixlQUtJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeVYsc0RBQXBCLEVBQW1DO0FBQUN2VixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBbkMsZUFDRU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjZaLFdBQXBCLEVBQWlDO0FBQUVDLFFBQUksRUFBRWpDLFNBQVMsS0FBSyxFQUFkLElBQW9CQSxTQUFTLEtBQUtwVixTQUExQztBQUFxRHNYLGdCQUFZLEVBQUVyYSxJQUFJLEtBQUssT0FBNUU7QUFBcUZRLFVBQU0sRUFBRSxTQUE3RjtBQUFtR0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQTdHLEdBQWpDLGVBQ0VOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsT0FBcEIsRUFBNkI7QUFBRXNLLE1BQUUsRUFBRyxRQUFPQSxFQUFHLEVBQWpCO0FBQW9CcEssVUFBTSxFQUFFLFNBQTVCO0FBQWtDQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBNUMsR0FBN0IsQ0FERixDQURGLENBTEosQ0FERjtBQWFELENBdkNEOztBQXlDZXVFLHlFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEVBLE1BQU1wSSxZQUFZLEdBQUcseUZBQXJCO0FBQStHO0FBRS9HO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBY0EsTUFBTStkLFFBQVEsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFBakI7O0FBSUEsTUFBTUMsVUFBVSxnQkFBR3ZYLGtEQUFJLENBQUVsRSxLQUFELElBQVc7QUFDakMsUUFBTTtBQUFDbUUsWUFBRDtBQUFXSSxTQUFYO0FBQWtCQyxZQUFsQjtBQUE0QjFDLGdCQUE1QjtBQUEwQ3dDLFNBQTFDO0FBQWlERCxhQUFqRDtBQUE0REs7QUFBNUQsTUFBc0UxRSxLQUE1RTtBQUNBLFFBQU07QUFBQ00sUUFBRDtBQUFPSztBQUFQLE1BQWU0RCxLQUFyQjtBQUNBLFFBQU07QUFBQzNEO0FBQUQsTUFBVTJELEtBQUssQ0FBQyxvQkFBRCxDQUFMLElBQStCLEVBQS9DO0FBQ0EsUUFBTTBJLE1BQU0sR0FBRyxDQUFDNUksU0FBRCxJQUFjLENBQUNGLFFBQTlCO0FBQ0EsUUFBTSxDQUFDeEMsSUFBRCxFQUFPQyxPQUFQLElBQWtCeVAsc0RBQVEsQ0FBQzlNLEtBQUssQ0FBQzVELElBQUQsQ0FBTCxDQUFZcUssT0FBYixDQUFoQztBQUNBLFFBQU1BLE9BQU8sR0FBRzNHLFNBQVMsR0FBR0UsS0FBSyxDQUFDNUQsSUFBRCxDQUFMLENBQVlxSyxPQUFmLEdBQXlCckosSUFBbEQ7QUFFQSxzQkFDRVgsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnVWLGdEQUFwQixrQ0FBa0N4VyxLQUFsQztBQUF5Q21CLFVBQU0sRUFBRSxTQUFqRDtBQUF1REMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQWpFLG1CQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd1Ysd0RBQXBCLEVBQXFDO0FBQUN0VixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBckMsRUFDRWhCLElBQUksaUJBQUlVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J4Qiw4Q0FBcEIsRUFBMkI7QUFBQzBCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEzQixFQUErRmhCLElBQS9GLENBRFYsZUFFRVUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQndHLHdFQUFwQixFQUFpQztBQUNqQ2pELFlBQVEsRUFBRUEsUUFEdUI7QUFFakNFLFVBQU0sRUFBRUEsTUFGeUI7QUFHakNMLGFBQVMsRUFBRUEsU0FIc0I7QUFJakNxRCxhQUFTLEVBQUU3QyxvRUFBVSxDQUFDOEIsa0JBSlc7QUFJU3hGLFVBQU0sRUFBRSxTQUpqQjtBQUl1QkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBSmpDLEdBQWpDLENBRkYsQ0FESixFQVVJMkwsTUFBTSxJQUFJbkIsS0FBSyxDQUFDQyxPQUFOLENBQWN4SCxLQUFLLENBQUM1RCxJQUFELENBQUwsQ0FBWXFLLE9BQTFCLENBQVYsSUFBZ0R6RyxLQUFLLENBQUM1RCxJQUFELENBQUwsQ0FBWXFLLE9BQVosQ0FBb0JwSCxNQUFwQixHQUE2QixFQUE3RSxpQkFBbUY1Qyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CUyxvRUFBcEIsRUFBZ0M7QUFBRUMsUUFBSSxFQUFFNEMsS0FBSyxDQUFDNUQsSUFBRCxDQUFMLENBQVlxSyxPQUFwQjtBQUE2QnBKLFdBQU8sRUFBRUEsT0FBdEM7QUFBK0NDLFFBQUksRUFBRSxDQUFDLE1BQUQsQ0FBckQ7QUFBK0RWLFVBQU0sRUFBRSxTQUF2RTtBQUE2RUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXZGLEdBQWhDLENBVnZGLGVBV0lOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5VixzREFBcEIsRUFBbUM7QUFBQ3ZWLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFuQyxFQUNFMEosT0FBTyxDQUFDUSxHQUFSLENBQVksQ0FBQ0MsTUFBRCxFQUFTQyxXQUFULGtCQUNaMUssNENBQUssQ0FBQ0MsYUFBTixDQUFvQnVhLFFBQXBCLEVBQThCO0FBQUU3UCxPQUFHLEVBQUVELFdBQVA7QUFBb0J2SyxVQUFNLEVBQUUsU0FBNUI7QUFBa0NDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUE1QyxHQUE5QixlQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd1oseUVBQXBCLEVBQWtDO0FBQ2xDbmEsUUFBSSxFQUFHLFFBQU9nRSxLQUFNLDJCQURjO0FBRWxDaUgsTUFBRSxFQUFHLEdBQUVqSCxLQUFNLElBQUdvSCxXQUFZLEVBRk07QUFHbEM5SyxTQUFLLEVBQUU2SyxNQUFNLENBQUNGLEVBSG9CO0FBSWxDMUssU0FBSyxFQUFFNEssTUFBTSxDQUFDbkwsSUFKb0I7QUFLbENHLFlBQVEsRUFBRXFCLFlBTHdCO0FBTWxDOFUsV0FBTyxFQUFFaFcsS0FBSyxJQUFJQSxLQUFLLENBQUN1WixRQUFOLENBQWUxTyxNQUFNLENBQUNGLEVBQXRCLENBTmdCO0FBT2xDM04sWUFBUSxFQUFFdUcsUUFQd0I7QUFPZGhELFVBQU0sRUFBRSxTQVBNO0FBT0FDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQVBWLEdBQWxDLENBREosQ0FEQSxDQURGLENBWEosQ0FERjtBQTZCRCxDQXJDc0IsQ0FBdkI7QUF1Q2VtYSx5RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuRUEsTUFBTWhlLFlBQVksR0FBRyw4RkFBckI7O0FBQXFILFNBQVM4RixjQUFULENBQXdCQyxHQUF4QixFQUE2QjtBQUFFLE1BQUlDLGFBQWEsR0FBR0MsU0FBcEI7QUFBK0IsTUFBSTlDLEtBQUssR0FBRzRDLEdBQUcsQ0FBQyxDQUFELENBQWY7QUFBb0IsTUFBSUcsQ0FBQyxHQUFHLENBQVI7O0FBQVcsU0FBT0EsQ0FBQyxHQUFHSCxHQUFHLENBQUNJLE1BQWYsRUFBdUI7QUFBRSxVQUFNQyxFQUFFLEdBQUdMLEdBQUcsQ0FBQ0csQ0FBRCxDQUFkO0FBQW1CLFVBQU1HLEVBQUUsR0FBR04sR0FBRyxDQUFDRyxDQUFDLEdBQUcsQ0FBTCxDQUFkO0FBQXVCQSxLQUFDLElBQUksQ0FBTDs7QUFBUSxRQUFJLENBQUNFLEVBQUUsS0FBSyxnQkFBUCxJQUEyQkEsRUFBRSxLQUFLLGNBQW5DLEtBQXNEakQsS0FBSyxJQUFJLElBQW5FLEVBQXlFO0FBQUUsYUFBTzhDLFNBQVA7QUFBbUI7O0FBQUMsUUFBSUcsRUFBRSxLQUFLLFFBQVAsSUFBbUJBLEVBQUUsS0FBSyxnQkFBOUIsRUFBZ0Q7QUFBRUosbUJBQWEsR0FBRzdDLEtBQWhCO0FBQXVCQSxXQUFLLEdBQUdrRCxFQUFFLENBQUNsRCxLQUFELENBQVY7QUFBb0IsS0FBN0YsTUFBbUcsSUFBSWlELEVBQUUsS0FBSyxNQUFQLElBQWlCQSxFQUFFLEtBQUssY0FBNUIsRUFBNEM7QUFBRWpELFdBQUssR0FBR2tELEVBQUUsQ0FBQyxDQUFDLEdBQUdDLElBQUosS0FBYW5ELEtBQUssQ0FBQ29ELElBQU4sQ0FBV1AsYUFBWCxFQUEwQixHQUFHTSxJQUE3QixDQUFkLENBQVY7QUFBNkROLG1CQUFhLEdBQUdDLFNBQWhCO0FBQTRCO0FBQUU7O0FBQUMsU0FBTzlDLEtBQVA7QUFBZTs7QUFBQTtBQUV4bkI7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQWFBLE1BQU1tWSxXQUFXLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQXBCOztBQVFBLE1BQU10WCxPQUFPLEdBQUc7QUFBQTtBQUFBLEdBQVcsQ0FBQztBQUFDaWE7QUFBRCxDQUFELHVCQUNyQkEsUUFBUSxJQUFJO0FBQ2Q3ZCxTQUFPLEVBQUUsTUFESztBQUVkOGQsa0JBQWdCLEVBQUU7QUFGSixDQURTLENBQVgsQ0FBaEI7O0FBT0EsTUFBTUMsV0FBVyxHQUFHO0FBQUE7QUFBQSxHQUNsQixDQUFDO0FBQUNDO0FBQUQsQ0FBRCxLQUF1QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCQSxjQUFlO0FBQ3JDO0FBQ0E7QUFDQSxDQXhDb0IsQ0FBcEI7O0FBMkNBLE1BQU0zVixzQkFBc0IsZ0JBQUdoQyxrREFBSSxDQUFFbEUsS0FBRCxJQUFXO0FBQzdDLFFBQU07QUFBQ3VFLFNBQUQ7QUFBUUMsWUFBUjtBQUFrQkgsYUFBbEI7QUFBNkJLLFVBQTdCO0FBQXFDTixpQkFBckM7QUFBb0RFLFNBQXBEO0FBQTJESDtBQUEzRCxNQUF1RW5FLEtBQTdFO0FBQ0EsUUFBTTtBQUFDTTtBQUFELE1BQVNpRSxLQUFmO0FBRUEsUUFBTTtBQUFDdVgsZUFBVyxFQUFFQyxVQUFkO0FBQTBCcmIsZUFBMUI7QUFBdUNzSyxXQUF2QztBQUFnRHBLLFNBQUssR0FBRyxFQUF4RDtBQUE0RG9iLFlBQVEsR0FBRztBQUF2RSxNQUNKelgsS0FBSyxDQUFDTSxxRUFBVSxDQUFDb0Isd0JBQVosQ0FBTCxJQUE4QyxFQURoRDtBQUdBLFFBQU0sQ0FBQ2dGLElBQUQsRUFBT2dSLE9BQVAsSUFBa0I1SyxzREFBUSxDQUFDMkssUUFBRCxDQUFoQztBQUNBLFFBQU0sQ0FBQ0UsVUFBRCxFQUFhQyxhQUFiLElBQThCOUssc0RBQVEsQ0FBQyxLQUFELENBQTVDO0FBQ0EsUUFBTSxDQUFDK0ssZ0JBQUQsRUFBbUJDLG1CQUFuQixJQUEwQ2hMLHNEQUFRLENBQUMsSUFBRCxDQUF4RDtBQUNBLFFBQU0sQ0FBQ3FLLFFBQUQsRUFBV1ksYUFBWCxJQUE0QmpMLHNEQUFRLENBQUMsS0FBRCxDQUExQztBQUVBLFFBQU0sQ0FBQ25HLGdCQUFELEVBQW1CcVIsbUJBQW5CLElBQTBDbEwsc0RBQVEsQ0FBQztBQUN2RHpGLE9BQUcsRUFBRVosT0FBTyxDQUFDLENBQUQsQ0FBUCxDQUFXTyxFQUR1QztBQUV2RGpOLFNBQUssRUFBRXVOLDhFQUFZLENBQUMsQ0FBRDtBQUZvQyxHQUFELENBQXhEO0FBS0EsUUFBTTJRLFVBQVUsR0FBR25ZLFNBQVMsSUFBSXpELEtBQUssS0FBSyxFQUF2QixHQUE0QkYsV0FBVyxJQUFJLEVBQTNDLEdBQWdERSxLQUFuRTtBQUNBLE1BQUk2YixhQUFhLEdBQUksUUFBT25ZLEtBQU0sSUFBR08scUVBQVUsQ0FBQ29CLHdCQUF5QixRQUF6RTs7QUFDQSxNQUFJNUIsU0FBUyxJQUFJekQsS0FBSyxLQUFLLEVBQTNCLEVBQStCO0FBQzdCNmIsaUJBQWEsR0FBSSxRQUFPblksS0FBTSxJQUFHTyxxRUFBVSxDQUFDb0Isd0JBQXlCLGNBQXJFO0FBQ0Q7O0FBRUQsUUFBTSxDQUFDeVcsY0FBRCxFQUFpQkMsaUJBQWpCLElBQXNDdEwsc0RBQVEsQ0FBQ21MLFVBQUQsQ0FBcEQ7QUFFQTlLLHlEQUFTLENBQUMsTUFBTTtBQUNkO0FBQ0EsUUFBSXJOLFNBQUosRUFBZTtBQUNiNFgsYUFBTyxDQUFDLEVBQUQsQ0FBUDtBQUNBN1gsbUJBQWEsQ0FBRSxRQUFPRSxLQUFNLEtBQUlPLHFFQUFVLENBQUNvQix3QkFBeUIsWUFBdkQsRUFBb0UsRUFBcEUsQ0FBYjtBQUNELEtBSEQsTUFHTztBQUNMZ1csYUFBTyxDQUFDRCxRQUFELENBQVA7QUFDQTVYLG1CQUFhLENBQUUsUUFBT0UsS0FBTSxLQUFJTyxxRUFBVSxDQUFDb0Isd0JBQXlCLFlBQXZELEVBQW9FK1YsUUFBcEUsQ0FBYjtBQUNEO0FBQ0YsR0FUUSxFQVNOLENBQUN0YixXQUFELEVBQWNzSyxPQUFkLENBVE0sQ0FBVDtBQVdBMEcseURBQVMsQ0FBQyxNQUFNO0FBQ2R0TixpQkFBYSxDQUNWLFFBQU9FLEtBQU0sS0FBSU8scUVBQVUsQ0FBQ29CLHdCQUF5QixZQUQzQyxFQUVYNUIsU0FBUyxHQUFHLEVBQUgsR0FBUTRHLElBRk4sQ0FBYjtBQUlELEdBTFEsRUFLTixDQUFDQSxJQUFELENBTE0sQ0FBVDtBQU9BeUcseURBQVMsQ0FBQyxNQUFNO0FBQ2Q2Syx1QkFBbUIsQ0FBQztBQUNsQjNRLFNBQUcsRUFBRVosT0FBTyxDQUFDLENBQUQsQ0FBUCxDQUFXTyxFQURFO0FBRWxCak4sV0FBSyxFQUFFdU4sOEVBQVksQ0FBQyxDQUFEO0FBRkQsS0FBRCxDQUFuQjtBQUlELEdBTFEsRUFLTixDQUFDYixPQUFELENBTE0sQ0FBVDtBQU9BLFFBQU00UixnQkFBZ0IsR0FBR3ROLHlEQUFXLENBQ2pDdk4sQ0FBRCxJQUFPO0FBQ0wsVUFBTTtBQUFDbkI7QUFBRCxRQUFVbUIsQ0FBQyxDQUFDRSxNQUFsQjtBQUNBMGEscUJBQWlCLENBQUMvYixLQUFELENBQWpCO0FBQ0QsR0FKaUMsRUFLbEMsQ0FBQzhiLGNBQUQsQ0FMa0MsQ0FBcEM7O0FBUUEsUUFBTUcsNEJBQTRCLEdBQUliLFFBQUQsSUFBYztBQUNqRCxVQUFNYyxnQkFBZ0IsR0FBR2QsUUFBekI7QUFDQSxXQUFPYyxnQkFBZ0IsQ0FBQ3ZGLE1BQWpCLENBQXlCd0YsR0FBRCxJQUFTO0FBQ3RDLFlBQU0sQ0FBQ0MsVUFBRCxFQUFhMVksS0FBYixJQUFzQjJZLG9CQUFvQixDQUFDRixHQUFHLENBQUNuUixHQUFMLENBQWhEOztBQUNBLFVBQUksQ0FBQ29SLFVBQUwsRUFBaUI7QUFDZixlQUFPLEtBQVA7QUFDRDs7QUFDREQsU0FBRyxDQUFDemUsS0FBSixHQUFZdU4sOEVBQVksQ0FBQ3ZILEtBQUQsQ0FBeEI7QUFDQSxhQUFPeVksR0FBUDtBQUNELEtBUE0sQ0FBUDtBQVFELEdBVkQ7O0FBWUEsUUFBTUUsb0JBQW9CLEdBQUkxUixFQUFELElBQVE7QUFDbkMsUUFBSWpMLElBQUo7QUFDQSxRQUFJZ0UsS0FBSjtBQUNBMEcsV0FBTyxDQUFDUSxHQUFSLENBQVksQ0FBQ0MsTUFBRCxFQUFTOUgsQ0FBVCxLQUFlO0FBQ3pCLFVBQUk4SCxNQUFNLENBQUNGLEVBQVAsS0FBY0EsRUFBbEIsRUFBc0I7QUFDcEJqTCxZQUFJLEdBQUdtTCxNQUFNLENBQUNuTCxJQUFkO0FBQ0FnRSxhQUFLLEdBQUdYLENBQVI7QUFDRDtBQUNGLEtBTEQ7QUFPQSxXQUFPLENBQUNyRCxJQUFELEVBQU9nRSxLQUFQLENBQVA7QUFDRCxHQVhEOztBQWFBLFFBQU00WSxjQUFjLEdBQUlqUyxJQUFELElBQVU7QUFDL0IsUUFBSWlSLFVBQUosRUFBZ0I7QUFDZEMsbUJBQWEsQ0FBQyxLQUFELENBQWI7QUFDQSxhQUFPLEtBQVA7QUFDRDs7QUFFRCxRQUFJLENBQUNoWSxRQUFMLEVBQWU7QUFDYjhYLGFBQU8sQ0FBQ2hSLElBQUQsQ0FBUDtBQUNBN0csbUJBQWEsQ0FDVixRQUFPRSxLQUFNLEtBQUlPLHFFQUFVLENBQUNvQix3QkFBeUIsWUFEM0MsRUFFWDVCLFNBQVMsR0FBRyxFQUFILEdBQVE0RyxJQUZOLENBQWI7QUFJQTdHLG1CQUFhLENBQUUsUUFBT0UsS0FBTSxLQUFJTyxxRUFBVSxDQUFDb0Isd0JBQXlCLFNBQXZELEVBQWlFdVcsVUFBakUsQ0FBYjtBQUNEO0FBQ0YsR0FkRDs7QUFnQkEsUUFBTXJILE1BQU0sR0FBRzFDLG9EQUFNLEVBQXJCO0FBQ0EsUUFBTTBLLFFBQVEsZ0JBQUduYyw0Q0FBSyxDQUFDb2MsU0FBTixFQUFqQjtBQUVBMUwseURBQVMsQ0FBQyxNQUFNO0FBQ2QsUUFBSXlELE1BQU0sS0FBS3pSLFNBQVgsSUFBd0J5UixNQUFNLENBQUNsQyxPQUFQLEtBQW1CdlAsU0FBL0MsRUFBMEQ7QUFDeER5UixZQUFNLENBQUNsQyxPQUFQLENBQWVnQixnQkFBZixDQUFnQyxTQUFoQyxFQUE0Q2xTLENBQUQsSUFBTztBQUNoRCxZQUFJQSxDQUFDLENBQUNzYixNQUFGLElBQVksQ0FBaEIsRUFBbUI7QUFDakJsQix1QkFBYSxDQUFDLElBQUQsQ0FBYjtBQUNBcGEsV0FBQyxDQUFDaU4sY0FBRjtBQUNEO0FBQ0YsT0FMRDtBQU1EO0FBQ0YsR0FUUSxFQVNOLENBQUNtRyxNQUFELENBVE0sQ0FBVDtBQVdBekQseURBQVMsQ0FBQyxNQUFNO0FBQ2QsUUFBSW5PLGNBQWMsQ0FBQyxDQUFDNFosUUFBRCxFQUFXLGdCQUFYLEVBQTZCalksQ0FBQyxJQUFJQSxDQUFDLENBQUMrTixPQUFwQyxDQUFELENBQWxCLEVBQWtFO0FBQ2hFMVAsb0JBQWMsQ0FBQyxDQUFDNFosUUFBRCxFQUFXLGdCQUFYLEVBQTZCM1gsRUFBRSxJQUFJQSxFQUFFLENBQUN5TixPQUF0QyxFQUErQyxnQkFBL0MsRUFBaUVqTCxFQUFFLElBQUlBLEVBQUUsQ0FBQ2xILEtBQTFFLEVBQWlGLFFBQWpGLEVBQTJGdU4sRUFBRSxJQUFJQSxFQUFFLENBQUNpUCxXQUFwRyxFQUFpSCxNQUFqSCxFQUF5SHJPLEVBQUUsSUFBSUEsRUFBRSxDQUFDLFFBQUQsRUFBVyxNQUFYLEVBQW1CLFdBQW5CLENBQWpJLENBQUQsQ0FBZDtBQUNEO0FBQ0YsR0FKUSxFQUlOLENBQUNrTyxRQUFELENBSk0sQ0FBVDtBQU1BLHNCQUNFbmMsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnVWLGdEQUFwQixrQ0FBa0N4VyxLQUFsQztBQUF5Q21CLFVBQU0sRUFBRSxTQUFqRDtBQUF1REMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQWpFLG1CQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd1Ysd0RBQXBCLEVBQXFDO0FBQUN0VixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBckMsRUFDRWhCLElBQUksaUJBQUlVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J4Qiw4Q0FBcEIsRUFBMkI7QUFBQzBCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEzQixFQUFnR2hCLElBQWhHLENBRFYsZUFFRVUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQndHLHdFQUFwQixFQUFpQztBQUNqQ2pELFlBQVEsRUFBRUEsUUFEdUI7QUFFakNFLFVBQU0sRUFBRUEsTUFGeUI7QUFHakNMLGFBQVMsRUFBRUEsU0FIc0I7QUFJakNxRCxhQUFTLEVBQUU3QyxxRUFBVSxDQUFDb0Isd0JBSlc7QUFJZTlFLFVBQU0sRUFBRSxTQUp2QjtBQUk2QkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBSnZDLEdBQWpDLENBRkYsQ0FESixlQVVJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeVYsc0RBQXBCLEVBQW1DO0FBQ25DVyxPQUFHLEVBQUUsSUFEOEI7QUFFbkN2VyxTQUFLLEVBQUU7QUFBQ2pELGFBQU8sRUFBRSxNQUFWO0FBQWtCMGYseUJBQW1CLEVBQUUsWUFBdkM7QUFBcURDLGFBQU8sRUFBRTtBQUE5RCxLQUY0QjtBQUV1Q3JjLFVBQU0sRUFBRSxTQUYvQztBQUVxREMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBRi9ELEdBQW5DLGVBSUVOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JRLE9BQXBCLEVBQTZCO0FBQUVpYSxZQUFRLEVBQUVBLFFBQVo7QUFBc0J2YSxVQUFNLEVBQUUsU0FBOUI7QUFBb0NDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUE5QyxHQUE3QixFQUNFb2EsUUFBUSxnQkFDUjFhLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IyTixrRUFBcEIsRUFBOEI7QUFDNUIzTyxPQUFHLEVBQUVrZCxRQUR1QjtBQUU1QnJjLFNBQUssRUFBRTtBQUFDN0IsWUFBTSxFQUFFO0FBQVQsS0FGcUI7QUFHNUJ3ZSxzQkFBa0IsRUFBRSxLQUhRO0FBSTVCN2MsU0FBSyxFQUFFOGIsY0FKcUI7QUFLNUJqYyxZQUFRLEVBQUVtYyxnQkFMa0I7QUFNNUJjLGNBQVUsRUFBRSxJQU5nQjtBQU1WdmMsVUFBTSxFQUFFLFNBTkU7QUFNSUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBTmQsR0FBOUIsQ0FEUSxnQkFVUk4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQjJhLFdBQXBCLEVBQWlDO0FBQy9CdEUsZUFBVyxFQUFHdlYsQ0FBRCxJQUFPO0FBQ2xCQSxPQUFDLENBQUNzSyxlQUFGO0FBQ0QsS0FIOEI7QUFJL0JGLGdCQUFZLEVBQUUsTUFBTTtBQUNsQmtRLHlCQUFtQixDQUFDLEtBQUQsQ0FBbkI7QUFDRCxLQU44QjtBQU8vQmpRLGdCQUFZLEVBQUUsTUFBTTtBQUNsQmlRLHlCQUFtQixDQUFDLElBQUQsQ0FBbkI7QUFDQXNCLFlBQU0sQ0FBQ0MsWUFBUCxHQUFzQkMsS0FBdEI7QUFDRCxLQVY4QjtBQVcvQi9jLFNBQUssRUFBRTtBQUFDb2IsZ0JBQVUsRUFBRUUsZ0JBQWdCLEdBQUcsTUFBSCxHQUFZO0FBQXpDLEtBWHdCO0FBWS9CUCxrQkFBYyxFQUFFM1EsZ0JBQWdCLENBQUM1TSxLQVpGO0FBYS9CMkIsT0FBRyxFQUFFa1YsTUFiMEI7QUFhbEJoVSxVQUFNLEVBQUUsU0FiVTtBQWFKQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFiTixHQUFqQyxlQWVJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CNmMsMEZBQXBCLEVBQW1DO0FBQ25DaGQsU0FBSyxFQUFFO0FBQ0xpZCxpQkFBVyxFQUFFO0FBRFIsS0FENEI7QUFJbkNDLFdBQU8sRUFBRXhCLFVBSjBCO0FBS25DNWIsU0FBSyxFQUFFaWMsNEJBQTRCLENBQUM1UixJQUFELENBTEE7QUFNbkN4SyxZQUFRLEVBQUV5YyxjQU55QjtBQU9uQ2UsV0FBTyxFQUFHQyxJQUFELG9DQUNKQSxJQURJLEdBRUpoVCxnQkFGSSxDQVAwQjtBQVUvQi9KLFVBQU0sRUFBRSxTQVZ1QjtBQVVqQkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBVk8sR0FBbkMsQ0FmSixDQVhGLEVBd0NFeWEsVUFBVSxpQkFDVi9hLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I4WCxXQUFwQixFQUFpQztBQUFDNVgsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQWpDLEVBQ0lvYSxRQUFRLGdCQUNSMWEsNENBQUssQ0FBQ0MsYUFBTixDQUFvQkQsNENBQUssQ0FBQ0UsUUFBMUIsRUFBb0MsSUFBcEMsZUFDSUYsNENBQUssQ0FBQ0MsYUFBTixDQUFvQjBQLDRFQUFwQixFQUFxQztBQUNyQzdQLFNBQUssRUFBRTtBQUFDMUIsV0FBSyxFQUFFLE1BQVI7QUFBZ0J5TCxpQkFBVyxFQUFFO0FBQTdCLEtBRDhCO0FBRXJDbEssUUFBSSxFQUFFLFFBRitCO0FBR3JDL0MsWUFBUSxFQUFFLEtBSDJCO0FBSXJDZ0ssV0FBTyxFQUFFLE1BQU07QUFDYjBVLG1CQUFhLENBQUMsS0FBRCxDQUFiO0FBQ0FLLHVCQUFpQixDQUFDSCxVQUFELENBQWpCO0FBQ0QsS0FQb0M7QUFRckMyQixhQUFTLEVBQUUsSUFSMEI7QUFRcEJoZCxVQUFNLEVBQUUsU0FSWTtBQVFOQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFSSixHQUFyQyxFQVNBLFFBVEEsQ0FESixlQWFJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cc1osMEVBQXBCLEVBQW1DO0FBQ25DelosU0FBSyxFQUFFO0FBQUMxQixXQUFLLEVBQUU7QUFBUixLQUQ0QjtBQUVuQ3VCLFFBQUksRUFBRSxRQUY2QjtBQUduQy9DLFlBQVEsRUFBRSxLQUh5QjtBQUluQ2dLLFdBQU8sRUFBRSxNQUFNO0FBQ2IsVUFBSSxDQUFDdkQsU0FBTCxFQUFnQjtBQUNkNFgsZUFBTyxDQUFDLEVBQUQsQ0FBUDtBQUNBN1gscUJBQWEsQ0FDVixRQUFPRSxLQUFNLEtBQUlPLHFFQUFVLENBQUNvQix3QkFBeUIsWUFEM0MsRUFFWCxFQUZXLENBQWI7QUFJRDs7QUFDRDdCLG1CQUFhLENBQUNxWSxhQUFELEVBQWdCQyxjQUFoQixDQUFiO0FBQ0FKLG1CQUFhLENBQUMsS0FBRCxDQUFiO0FBQ0QsS0Fka0M7QUFjaENuYixVQUFNLEVBQUUsU0Fkd0I7QUFjbEJDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQWRRLEdBQW5DLEVBZUEsTUFmQSxDQWJKLENBRFEsZ0JBa0NSTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMFAsNEVBQXBCLEVBQXFDO0FBQ25DN1AsU0FBSyxFQUFFO0FBQUMxQixXQUFLLEVBQUU7QUFBUixLQUQ0QjtBQUVuQ3VCLFFBQUksRUFBRSxRQUY2QjtBQUduQ2lILFdBQU8sRUFBRSxNQUFNMFUsYUFBYSxDQUFDLElBQUQsQ0FITztBQUluQzZCLGFBQVMsRUFBRSxJQUp3QjtBQUtuQ3ZnQixZQUFRLEVBQUV1RyxRQUx5QjtBQUtmaEQsVUFBTSxFQUFFLFNBTE87QUFLREMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBTFQsR0FBckMsRUFNRSxXQU5GLENBbkNKLENBekNGLENBSkYsZUE4RkVOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I4SixpRkFBcEIsRUFBeUM7QUFDekNDLFdBQU8sRUFBRUEsT0FEZ0M7QUFFekNHLFlBQVEsRUFBR2UsUUFBRCxJQUFjO0FBQ3RCcVEseUJBQW1CLENBQUNyUSxRQUFELENBQW5CO0FBQ0QsS0FKd0M7QUFLekNoQixvQkFBZ0IsRUFBRUEsZ0JBTHVCO0FBS0wvSixVQUFNLEVBQUUsU0FMSDtBQUtTQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFMbkIsR0FBekMsQ0E5RkYsQ0FWSixDQURGO0FBbUhELENBMU9rQyxDQUFuQztBQTRPZTRFLHFGQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDalVBLE1BQU16SSxZQUFZLEdBQUcsOEVBQXJCO0FBQW9HO0FBRXBHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWWUsU0FBUzJnQixXQUFULENBQXFCcGUsS0FBckIsRUFBNEI7QUFDekMsUUFBTTtBQUFDdUUsU0FBRDtBQUFRQyxZQUFSO0FBQWtCMUMsZ0JBQWxCO0FBQWdDd0MsU0FBaEM7QUFBdUNILFlBQXZDO0FBQWlERSxhQUFqRDtBQUE0REs7QUFBNUQsTUFBc0UxRSxLQUE1RTtBQUNBLFFBQU07QUFBQ3FlLFVBQUQ7QUFBUy9kO0FBQVQsTUFBaUJpRSxLQUF2QjtBQUNBLFFBQU07QUFBQzdELGVBQUQ7QUFBY3lYLGFBQVMsRUFBRWpKLFFBQXpCO0FBQW1DdE8sU0FBSyxHQUFHO0FBQTNDLE1BQWlEeWQsTUFBTSxJQUFJLEVBQWpFO0FBQ0EsUUFBTXJILFdBQVcsR0FBRzNTLFNBQVMsR0FBR3pELEtBQUssSUFBSUYsV0FBWixHQUEwQkUsS0FBdkQ7QUFFQSxzQkFDRUksbURBQUEsQ0FBb0J3VixnREFBcEIsa0NBQWtDeFcsS0FBbEM7QUFBeUNtQixVQUFNLEVBQUUsSUFBakQ7QUFBdURDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUFqRSxtQkFDSU4sbURBQUEsQ0FBb0J5Vix3REFBcEIsRUFBcUM7QUFBQ3RWLFVBQU0sRUFBRSxJQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFyQyxFQUNFaEIsSUFBSSxpQkFBSVUsbURBQUEsQ0FBb0J2Qiw4Q0FBcEIsRUFBMkI7QUFBQzBCLFVBQU0sRUFBRSxJQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEzQixFQUErRmhCLElBQS9GLENBRFYsZUFFRVUsbURBQUEsQ0FBb0J5Ryx3RUFBcEIsRUFBaUM7QUFDakNqRCxZQUFRLEVBQUVBLFFBRHVCO0FBRWpDRSxVQUFNLEVBQUVBLE1BRnlCO0FBR2pDTCxhQUFTLEVBQUVBLFNBSHNCO0FBSWpDcUQsYUFBUyxFQUFFN0Msb0VBQVUsQ0FBQ08sTUFKVztBQUlIakUsVUFBTSxFQUFFLElBSkw7QUFJV0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBSnJCLEdBQWpDLENBRkYsQ0FESixlQVVJTixtREFBQSxDQUFvQjBWLHNEQUFwQixFQUFtQztBQUFDdlYsVUFBTSxFQUFFLElBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQW5DLEVBQ0U0TixRQUFRLElBQUkvSyxRQUFaLGdCQUNBbkQsbURBQUEsQ0FBb0IsS0FBcEIsRUFBMkI7QUFBQ0csVUFBTSxFQUFFLElBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTNCLEVBQStGMFYsV0FBL0YsQ0FEQSxnQkFHQWhXLG1EQUFBLENBQW9CbEIsdUVBQXBCLEVBQWdDO0FBQzlCUSxRQUFJLEVBQUcsUUFBT2dFLEtBQU0sZUFEVTtBQUU5QjdELFlBQVEsRUFBRXFCLFlBRm9CO0FBRzlCbkIsUUFBSSxFQUFFLFFBSHdCO0FBSTlCUixhQUFTLEVBQUUsS0FKbUI7QUFLOUJTLFNBQUssRUFBRW9XLFdBQVcsSUFBSSxFQUxRO0FBS0o3VixVQUFNLEVBQUUsSUFMSjtBQUtVQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFMcEIsR0FBaEMsQ0FKRixDQVZKLENBREY7QUEwQkQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcERELE1BQU03RCxZQUFZLEdBQUcsaUZBQXJCO0FBQXVHO0FBR3ZHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFhQSxNQUFNbWIsTUFBTSxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFmOztBQU1BLE1BQU1wUyxTQUFTLEdBQUl4RyxLQUFELElBQVc7QUFDM0IsUUFBTTtBQUFDdUUsU0FBRDtBQUFRRyxVQUFSO0FBQWdCRixZQUFoQjtBQUEwQkgsYUFBMUI7QUFBcUMxRyxTQUFyQztBQUE0QzJHO0FBQTVDLE1BQXFEdEUsS0FBSyxJQUFJLEVBQXBFO0FBQ0EsUUFBTTtBQUFDc2UsT0FBRDtBQUFNaGU7QUFBTixNQUFjaUUsS0FBcEI7QUFDQSxRQUFNO0FBQUMzRCxTQUFEO0FBQVFGO0FBQVIsTUFBdUI0ZCxHQUFHLElBQUksRUFBcEM7QUFFQSxNQUFJeEYsU0FBUyxHQUFHelUsU0FBUyxHQUFHM0QsV0FBSCxHQUFpQkUsS0FBMUM7O0FBRUEsTUFBSWpELEtBQUssQ0FBQytQLElBQU4sSUFBYy9QLEtBQUssQ0FBQytQLElBQU4sQ0FBV3BKLEtBQVgsQ0FBZCxJQUFtQzNHLEtBQUssQ0FBQytQLElBQU4sQ0FBVzlKLE1BQWxELEVBQTBEO0FBQ3hEa1YsYUFBUyxHQUFHLEVBQVo7QUFDRDs7QUFFRCxzQkFDRTlYLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IrTCxnREFBcEIsa0NBQXlDaE4sS0FBekM7QUFBZ0R3WCxZQUFRLEVBQUcsUUFBM0Q7QUFBb0VyVyxVQUFNLEVBQUUsU0FBNUU7QUFBa0ZDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUE1RixtQkFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQndWLHdEQUFwQixFQUFxQztBQUFDdFYsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQXJDLEVBQ0VoQixJQUFJLGlCQUFJVSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeEIsOENBQXBCLEVBQTJCO0FBQUMwQixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBM0IsRUFBK0ZoQixJQUEvRixDQURWLGVBRUVVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J3Ryx3RUFBcEIsRUFBaUM7QUFDakNqRCxZQUFRLEVBQUVBLFFBRHVCO0FBRWpDRSxVQUFNLEVBQUVBLE1BRnlCO0FBR2pDTCxhQUFTLEVBQUVBLFNBSHNCO0FBSWpDcUQsYUFBUyxFQUFFN0Msb0VBQVUsQ0FBQzBCLEdBSlc7QUFJTnBGLFVBQU0sRUFBRSxTQUpGO0FBSVFDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUpsQixHQUFqQyxDQUZGLENBREosZUFVSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQnlWLHNEQUFwQixFQUFtQztBQUFDdlYsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQW5DLGVBQ0VOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IyWCxNQUFwQixFQUE0QjtBQUFFakcsT0FBRyxFQUFFbUcsU0FBUDtBQUFrQjNYLFVBQU0sRUFBRSxTQUExQjtBQUFnQ0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQTFDLEdBQTVCLENBREYsQ0FWSixDQURGO0FBZ0JELENBM0JEOztBQTZCZWtGLHdFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hEQSxNQUFNL0ksWUFBWSxHQUFHLHNGQUFyQjtBQUE0RztBQUM1RztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBYUEsTUFBTXVKLGNBQWMsR0FBSWhILEtBQUQsSUFBVztBQUNoQyxRQUFNO0FBQUNtRSxZQUFEO0FBQVdJLFNBQVg7QUFBa0JHLFVBQWxCO0FBQTBCRixZQUExQjtBQUFvQ0osaUJBQXBDO0FBQW1EQyxhQUFuRDtBQUE4REM7QUFBOUQsTUFBdUV0RSxLQUE3RTtBQUNBLFFBQU07QUFBQ3VlLGFBQVMsRUFBRUMsUUFBWjtBQUFzQmxlO0FBQXRCLE1BQThCaUUsS0FBcEM7QUFDQSxRQUFNO0FBQUM3RCxlQUFEO0FBQWN5WCxhQUFTLEVBQUVqSixRQUF6QjtBQUFtQ3RPLFNBQUssR0FBRyxFQUEzQztBQUErQzZkO0FBQS9DLE1BQXlERCxRQUFRLElBQUksRUFBM0U7QUFDQSxRQUFNeEgsV0FBVyxHQUFHM1MsU0FBUyxHQUFHM0QsV0FBSCxHQUFpQkUsS0FBOUM7QUFFQSxzQkFDRUksNENBQUssQ0FBQ0MsYUFBTixDQUFvQnVWLGdEQUFwQixrQ0FBa0N4VyxLQUFsQztBQUF5Q21CLFVBQU0sRUFBRSxTQUFqRDtBQUF1REMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQWpFLG1CQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd1Ysd0RBQXBCLEVBQXFDO0FBQUN0VixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBckMsRUFDRWhCLElBQUksaUJBQUlVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J4Qiw4Q0FBcEIsRUFBMkI7QUFBQzBCLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEzQixFQUErRmhCLElBQS9GLENBRFYsZUFFRVUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQndHLHdFQUFwQixFQUFpQztBQUNqQ2pELFlBQVEsRUFBRUEsUUFEdUI7QUFFakNFLFVBQU0sRUFBRUEsTUFGeUI7QUFHakNMLGFBQVMsRUFBRUEsU0FIc0I7QUFJakNxRCxhQUFTLEVBQUU3QyxvRUFBVSxDQUFDa0MsU0FKVztBQUlBNUYsVUFBTSxFQUFFLFNBSlI7QUFJY0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBSnhCLEdBQWpDLENBRkYsQ0FESixlQVdJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeWQsdUVBQXBCLEVBQWdDO0FBQ2hDcGUsUUFBSSxFQUFHLFFBQU9nRSxLQUFNLGtCQURZO0FBRWhDMUQsU0FBSyxFQUFFb1csV0FGeUI7QUFHaEM5SCxZQUFRLEVBQUVBLFFBQVEsSUFBSS9LLFFBSFU7QUFJaEN6RCxlQUFXLEVBQUVBLFdBSm1CO0FBS2hDMEQsaUJBQWEsRUFBRUEsYUFMaUI7QUFNaENxYSxVQUFNLEVBQUVBLE1BTndCO0FBTWhCdGQsVUFBTSxFQUFFLFNBTlE7QUFNRkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBTlIsR0FBaEMsQ0FYSixDQURGO0FBc0JELENBNUJEOztBQThCZTBGLDZFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbERBLE1BQU12SixZQUFZLEdBQUcsdUZBQXJCO0FBQTZHO0FBRTdHO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBWUEsTUFBTWtoQixLQUFLLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQWQ7O0FBSUEsTUFBTWpZLGVBQWUsZ0JBQUd4QyxrREFBSSxDQUFFbEUsS0FBRCxJQUFXO0FBQ3RDLFFBQU07QUFBQ3VFLFNBQUQ7QUFBUUMsWUFBUjtBQUFrQkwsWUFBbEI7QUFBNEJyQyxnQkFBNUI7QUFBMEN3QyxTQUExQztBQUFpREQsYUFBakQ7QUFBNERLO0FBQTVELE1BQXNFMUUsS0FBNUU7QUFDQSxRQUFNO0FBQUNNLFFBQUQ7QUFBT0s7QUFBUCxNQUFlNEQsS0FBckI7QUFDQSxRQUFNO0FBQUMzRDtBQUFELE1BQVUyRCxLQUFLLENBQUMsa0JBQUQsQ0FBTCxJQUE2QixFQUE3QztBQUNBLFFBQU0wSSxNQUFNLEdBQUcsQ0FBQzVJLFNBQUQsSUFBYyxDQUFDRixRQUE5QjtBQUNBLFFBQU0sQ0FBQ3hDLElBQUQsRUFBT0MsT0FBUCxJQUFrQnlQLHNEQUFRLENBQUM5TSxLQUFLLENBQUM1RCxJQUFELENBQUwsQ0FBWXFLLE9BQWIsQ0FBaEM7QUFDQSxRQUFNQSxPQUFPLEdBQUczRyxTQUFTLEdBQUdFLEtBQUssQ0FBQzVELElBQUQsQ0FBTCxDQUFZcUssT0FBZixHQUF5QnJKLElBQWxEO0FBRUEsc0JBQ0VYLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J1VixnREFBcEIsa0NBQWtDeFcsS0FBbEM7QUFBeUNtQixVQUFNLEVBQUUsU0FBakQ7QUFBdURDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUFqRSxtQkFDSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQndWLHdEQUFwQixFQUFxQztBQUFDdFYsVUFBTSxFQUFFLFNBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQXJDLEVBQ0VoQixJQUFJLGlCQUFJVSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CeEIsOENBQXBCLEVBQTJCO0FBQUMwQixVQUFNLEVBQUUsU0FBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBM0IsRUFBK0ZoQixJQUEvRixDQURWLGVBRUVVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J3Ryx3RUFBcEIsRUFBaUM7QUFDakNqRCxZQUFRLEVBQUVBLFFBRHVCO0FBRWpDRSxVQUFNLEVBQUVBLE1BRnlCO0FBR2pDTCxhQUFTLEVBQUVBLFNBSHNCO0FBSWpDcUQsYUFBUyxFQUFFN0Msb0VBQVUsQ0FBQzRCLGdCQUpXO0FBSU90RixVQUFNLEVBQUUsU0FKZjtBQUlxQkMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBSi9CLEdBQWpDLENBRkYsQ0FESixFQVVJMkwsTUFBTSxJQUFJbkIsS0FBSyxDQUFDQyxPQUFOLENBQWN4SCxLQUFLLENBQUM1RCxJQUFELENBQUwsQ0FBWXFLLE9BQTFCLENBQVYsSUFBZ0R6RyxLQUFLLENBQUM1RCxJQUFELENBQUwsQ0FBWXFLLE9BQVosQ0FBb0JwSCxNQUFwQixHQUE2QixFQUE3RSxpQkFBbUY1Qyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CUyxvRUFBcEIsRUFBZ0M7QUFBRUMsUUFBSSxFQUFFNEMsS0FBSyxDQUFDNUQsSUFBRCxDQUFMLENBQVlxSyxPQUFwQjtBQUE2QnBKLFdBQU8sRUFBRUEsT0FBdEM7QUFBK0NDLFFBQUksRUFBRSxDQUFDLE1BQUQsQ0FBckQ7QUFBK0RWLFVBQU0sRUFBRSxTQUF2RTtBQUE2RUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXZGLEdBQWhDLENBVnZGLGVBV0lOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5VixzREFBcEIsRUFBbUM7QUFBQ3ZWLFVBQU0sRUFBRSxTQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFuQyxFQUNFMEosT0FBTyxDQUFDUSxHQUFSLENBQVksQ0FBQ0MsTUFBRCxFQUFTQyxXQUFULGtCQUNaMUssNENBQUssQ0FBQ0MsYUFBTixDQUFvQjBkLEtBQXBCLEVBQTJCO0FBQUVoVCxPQUFHLEVBQUVELFdBQVA7QUFBb0J2SyxVQUFNLEVBQUUsU0FBNUI7QUFBa0NDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUE1QyxHQUEzQixlQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMFYsc0VBQXBCLEVBQStCO0FBQy9CclcsUUFBSSxFQUFHLFFBQU9nRSxLQUFNLHlCQURXO0FBRS9CaUgsTUFBRSxFQUFHLEdBQUVqSCxLQUFNLElBQUdvSCxXQUFZLEVBRkc7QUFHL0I5SyxTQUFLLEVBQUU2SyxNQUFNLENBQUNGLEVBSGlCO0FBSS9CMUssU0FBSyxFQUFFNEssTUFBTSxDQUFDbkwsSUFKaUI7QUFLL0JHLFlBQVEsRUFBRXFCLFlBTHFCO0FBTS9COFUsV0FBTyxFQUFFbkwsTUFBTSxDQUFDRixFQUFQLEtBQWMzSyxLQU5RO0FBTy9CaEQsWUFBUSxFQUFFdUcsUUFQcUI7QUFPWGhELFVBQU0sRUFBRSxTQVBHO0FBT0dDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQVBiLEdBQS9CLENBREosQ0FEQSxDQURGLENBWEosQ0FERjtBQTZCRCxDQXJDMkIsQ0FBNUI7QUF1Q2VvRiw4RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqRUEsTUFBTWpKLFlBQVksR0FBRyw0RUFBckI7QUFBa0c7QUFFbEc7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWU8sTUFBTW1oQixVQUFVLEdBQUc7QUFBQTtBQUFBLEdBQVM7QUFDakM5ZixVQUFRLEVBQUUsRUFEdUI7QUFFakNDLFlBQVUsRUFBRSxJQUZxQjtBQUdqQ0osWUFBVSxFQUFFLEdBSHFCO0FBSWpDTCxPQUFLLEVBQUVKLGdFQUFPLENBQUNLLFNBSmtCO0FBS2pDZ2EsWUFBVSxFQUFFLFVBTHFCO0FBTWpDQyxVQUFRLEVBQUUsWUFOdUI7QUFPakNDLFdBQVMsRUFBRSxZQVBzQjtBQVFqQzdaLFFBQU0sRUFBRTtBQVJ5QixDQUFULENBQW5CO0FBV1EsU0FBU21HLElBQVQsQ0FBYy9FLEtBQWQsRUFBcUI7QUFDbEMsUUFBTTtBQUFDbUUsWUFBRDtBQUFXSSxTQUFYO0FBQWtCRyxVQUFsQjtBQUEwQkYsWUFBMUI7QUFBb0MxQyxnQkFBcEM7QUFBa0R1QyxhQUFsRDtBQUE2REM7QUFBN0QsTUFBc0V0RSxLQUE1RTtBQUNBLFFBQU07QUFBQ2lMLFFBQUQ7QUFBTzNLO0FBQVAsTUFBZWlFLEtBQXJCO0FBQ0EsUUFBTTtBQUFDN0QsZUFBRDtBQUFjeVgsYUFBUyxFQUFFakosUUFBekI7QUFBbUN0TyxTQUFLLEdBQUc7QUFBM0MsTUFBaURxSyxJQUFJLElBQUksRUFBL0Q7QUFDQSxRQUFNK0wsV0FBVyxHQUFHM1MsU0FBUyxHQUFHM0QsV0FBSCxHQUFpQkUsS0FBOUM7QUFFQSxRQUFNaWUsU0FBUyxHQUFHdlAseURBQVcsQ0FDM0IsQ0FBQ3FKLElBQUQsRUFBTzFOLElBQVAsRUFBYVUsR0FBYixLQUFxQjtBQUNuQix3QkFDRTNLLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsR0FBcEIsRUFBeUI7QUFDdkIwWCxVQUFJLEVBQUVBLElBRGlCO0FBRXZCaE4sU0FBRyxFQUFFQSxHQUZrQjtBQUd2QjFKLFlBQU0sRUFBRSxRQUhlO0FBSXZCNmMsU0FBRyxFQUFFLHFCQUprQjtBQUt2QmhlLFdBQUssRUFBRTtBQUFDeEMsYUFBSyxFQUFFSixnRUFBTyxDQUFDb0g7QUFBSzs7QUFBckIsT0FMZ0I7QUFLeUNuRSxZQUFNLEVBQUUsSUFMakQ7QUFLdURDLGNBQVEsRUFBRTtBQUFDQyxnQkFBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGtCQUFVLEVBQUU7QUFBckM7QUFMakUsS0FBekIsRUFPSTJKLElBUEosQ0FERjtBQVdELEdBYjBCLEVBYzNCLENBQUMrTCxXQUFELENBZDJCLENBQTdCO0FBaUJBLHNCQUNFaFcsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnVWLGdEQUFwQixrQ0FBa0N4VyxLQUFsQztBQUF5Q21CLFVBQU0sRUFBRSxJQUFqRDtBQUF1REMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQWpFLG1CQUNJTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd1Ysd0RBQXBCLEVBQXFDO0FBQUN0VixVQUFNLEVBQUUsSUFBVDtBQUFlQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBekIsR0FBckMsRUFDRWhCLElBQUksaUJBQUlVLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J4Qiw4Q0FBcEIsRUFBMkI7QUFBQzBCLFVBQU0sRUFBRSxJQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUEzQixFQUErRmhCLElBQS9GLENBRFYsZUFFRVUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQndHLHdFQUFwQixFQUFpQztBQUNqQ2pELFlBQVEsRUFBRUEsUUFEdUI7QUFFakNFLFVBQU0sRUFBRUEsTUFGeUI7QUFHakNMLGFBQVMsRUFBRUEsU0FIc0I7QUFJakNxRCxhQUFTLEVBQUU3QyxxRUFBVSxDQUFDQyxJQUpXO0FBSUwzRCxVQUFNLEVBQUUsSUFKSDtBQUlTQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFKbkIsR0FBakMsQ0FGRixDQURKLGVBVUlOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J5VixzREFBcEIsRUFBbUM7QUFBQ3ZWLFVBQU0sRUFBRSxJQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFuQyxFQUNFLENBQUM0TixRQUFELElBQWEsQ0FBQy9LLFFBQWQsZ0JBQ0FuRCw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CdVosMEVBQXBCLEVBQW1DO0FBQ2pDbGEsUUFBSSxFQUFHLFFBQU9nRSxLQUFNLGFBRGE7QUFFakM3RCxZQUFRLEVBQUVxQixZQUZ1QjtBQUdqQzNCLGFBQVMsRUFBRSxLQUhzQjtBQUlqQ1csU0FBSyxFQUFFO0FBQ0w3QixZQUFNLEVBQUU7QUFESCxLQUowQjtBQU9qQzJCLFNBQUssRUFBRW9XLFdBQVcsSUFBSXBXLEtBUFc7QUFRakNzTyxZQUFRLEVBQUVBLFFBUnVCO0FBUWIvTixVQUFNLEVBQUUsSUFSSztBQVFDQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFSWCxHQUFuQyxDQURBLGdCQVlBTiw0Q0FBSyxDQUFDQyxhQUFOLENBQW9COGQsb0RBQXBCLEVBQTZCO0FBQUVDLHNCQUFrQixFQUFFSCxTQUF0QjtBQUFpQzFkLFVBQU0sRUFBRSxJQUF6QztBQUErQ0MsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpELEdBQTdCLGVBQ0lOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IyZCxVQUFwQixFQUFnQztBQUFDemQsVUFBTSxFQUFFLElBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQWhDLEVBQW9HMFYsV0FBcEcsQ0FESixDQWJGLENBVkosQ0FERjtBQStCRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hGRCxNQUFNdlosWUFBWSxHQUFHLG9GQUFyQjs7QUFBMkcsU0FBUzhGLGNBQVQsQ0FBd0JDLEdBQXhCLEVBQTZCO0FBQUUsTUFBSUMsYUFBYSxHQUFHQyxTQUFwQjtBQUErQixNQUFJOUMsS0FBSyxHQUFHNEMsR0FBRyxDQUFDLENBQUQsQ0FBZjtBQUFvQixNQUFJRyxDQUFDLEdBQUcsQ0FBUjs7QUFBVyxTQUFPQSxDQUFDLEdBQUdILEdBQUcsQ0FBQ0ksTUFBZixFQUF1QjtBQUFFLFVBQU1DLEVBQUUsR0FBR0wsR0FBRyxDQUFDRyxDQUFELENBQWQ7QUFBbUIsVUFBTUcsRUFBRSxHQUFHTixHQUFHLENBQUNHLENBQUMsR0FBRyxDQUFMLENBQWQ7QUFBdUJBLEtBQUMsSUFBSSxDQUFMOztBQUFRLFFBQUksQ0FBQ0UsRUFBRSxLQUFLLGdCQUFQLElBQTJCQSxFQUFFLEtBQUssY0FBbkMsS0FBc0RqRCxLQUFLLElBQUksSUFBbkUsRUFBeUU7QUFBRSxhQUFPOEMsU0FBUDtBQUFtQjs7QUFBQyxRQUFJRyxFQUFFLEtBQUssUUFBUCxJQUFtQkEsRUFBRSxLQUFLLGdCQUE5QixFQUFnRDtBQUFFSixtQkFBYSxHQUFHN0MsS0FBaEI7QUFBdUJBLFdBQUssR0FBR2tELEVBQUUsQ0FBQ2xELEtBQUQsQ0FBVjtBQUFvQixLQUE3RixNQUFtRyxJQUFJaUQsRUFBRSxLQUFLLE1BQVAsSUFBaUJBLEVBQUUsS0FBSyxjQUE1QixFQUE0QztBQUFFakQsV0FBSyxHQUFHa0QsRUFBRSxDQUFDLENBQUMsR0FBR0MsSUFBSixLQUFhbkQsS0FBSyxDQUFDb0QsSUFBTixDQUFXUCxhQUFYLEVBQTBCLEdBQUdNLElBQTdCLENBQWQsQ0FBVjtBQUE2RE4sbUJBQWEsR0FBR0MsU0FBaEI7QUFBNEI7QUFBRTs7QUFBQyxTQUFPOUMsS0FBUDtBQUFlOztBQUFBO0FBRzltQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFhQSxNQUFNeVYsS0FBSyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUFkOztBQVFlLFNBQVNuUCxZQUFULENBQXNCbEgsS0FBdEIsRUFBNkI7QUFDMUMsUUFBTTtBQUFDbUUsWUFBRDtBQUFXSSxTQUFYO0FBQWtCRyxVQUFsQjtBQUEwQkYsWUFBMUI7QUFBb0MxQyxnQkFBcEM7QUFBa0R1QyxhQUFsRDtBQUE2REMsU0FBN0Q7QUFBb0VGO0FBQXBFLE1BQXFGcEUsS0FBM0Y7QUFDQSxRQUFNO0FBQUNNLFFBQUQ7QUFBT0s7QUFBUCxNQUFlNEQsS0FBSyxJQUFJLEVBQTlCO0FBQ0EsUUFBTW1KLElBQUksR0FBR3JKLFNBQVMsR0FBR0UsS0FBSyxDQUFDNUQsSUFBRCxDQUFMLENBQVlELFdBQWYsR0FBNkI2RCxLQUFLLENBQUM1RCxJQUFELENBQUwsQ0FBWUMsS0FBL0Q7QUFDQSxRQUFNO0FBQ0pxZSxtQkFBZSxFQUFFOVIsY0FEYjtBQUVKK1IsaUJBQWEsRUFBRS9QLFlBRlg7QUFHSmdRLHFCQUFpQixFQUFFalM7QUFIZixNQUlGM0ksS0FBSyxDQUFDNUQsSUFBRCxDQUpUO0FBS0EsUUFBTWtOLFFBQVEsR0FBRztBQUNmVixrQkFEZTtBQUVmZ0MsZ0JBRmU7QUFHZmpDO0FBSGUsR0FBakI7QUFNQSxRQUFNUyxVQUFVLEdBQUd0SixTQUFTLEdBQ3ZCLFFBQU9DLEtBQU0sS0FBSTNELElBQUssZUFEQyxHQUV2QixRQUFPMkQsS0FBTSxLQUFJM0QsSUFBSyxTQUYzQjtBQUlBLHNCQUNFSyw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CdVYsZ0RBQXBCLGtDQUFrQ3hXLEtBQWxDO0FBQXlDbUIsVUFBTSxFQUFFLElBQWpEO0FBQXVEQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFBakUsbUJBQ0lOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0J3Vix3REFBcEIsRUFBcUM7QUFBQ3RWLFVBQU0sRUFBRSxJQUFUO0FBQWVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF6QixHQUFyQyxFQUNFaEIsSUFBSSxpQkFBSVUsNENBQUssQ0FBQ0MsYUFBTixDQUFvQnhCLDhDQUFwQixFQUEyQjtBQUFDMEIsVUFBTSxFQUFFLElBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTNCLEVBQStGaEIsSUFBL0YsQ0FEVixlQUVFVSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9Cd0csd0VBQXBCLEVBQWlDO0FBQ2pDakQsWUFBUSxFQUFFQSxRQUR1QjtBQUVqQ0UsVUFBTSxFQUFFQSxNQUZ5QjtBQUdqQ0wsYUFBUyxFQUFFQSxTQUhzQjtBQUlqQ3FELGFBQVMsRUFBRTdDLG9FQUFVLENBQUNDLElBSlc7QUFJTDNELFVBQU0sRUFBRSxJQUpIO0FBSVNDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUpuQixHQUFqQyxDQUZGLENBREosZUFVSU4sNENBQUssQ0FBQ0MsYUFBTixDQUFvQnlWLHNEQUFwQixFQUFtQztBQUFDdlYsVUFBTSxFQUFFLElBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQW5DLGVBQ0VOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JvVixLQUFwQixFQUEyQjtBQUFDbFYsVUFBTSxFQUFFLElBQVQ7QUFBZUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQXpCLEdBQTNCLGVBQ0VOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0JtZSx5RUFBcEIsRUFBOEI7QUFDOUI5ZSxRQUFJLEVBQUVxTixVQUR3QjtBQUU5QkEsY0FBVSxFQUFFQSxVQUZrQjtBQUc5QkQsUUFBSSxFQUFFQSxJQUh3QjtBQUk5Qi9NLFFBQUksRUFBRUEsSUFKd0I7QUFLOUJ5RCxpQkFBYSxFQUFFQSxhQUxlO0FBTTlCRSxTQUFLLEVBQUVBLEtBTnVCO0FBTzlCeEMsZ0JBQVksRUFBRUEsWUFQZ0I7QUFROUJ1QyxhQUFTLEVBQUVBLFNBUm1CO0FBUzlCRixZQUFRLEVBQUVBLFFBVG9CO0FBVTlCekQsZUFBVyxFQUFFNkMsY0FBYyxDQUFDLENBQUNnQixLQUFELEVBQVEsUUFBUixFQUFrQlcsQ0FBQyxJQUFJQSxDQUFDLENBQUN2RSxJQUFELENBQXhCLEVBQWdDLGdCQUFoQyxFQUFrRDZFLEVBQUUsSUFBSUEsRUFBRSxDQUFDOUUsV0FBM0QsQ0FBRCxDQUFkLElBQTJGLEVBVjFFO0FBVzlCbU4sWUFBUSxFQUFFQSxRQVhvQjtBQVdWMU0sVUFBTSxFQUFFLElBWEU7QUFXSUMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBWGQsR0FBOUIsQ0FERixDQURGLENBVkosQ0FERjtBQThCRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0VEO0FBT08sTUFBTStkLGdCQUFnQixHQUFHLENBQUNwVSxJQUFELEVBQU9xVSxPQUFQLEtBQW1CO0FBQ2pELE1BQUlDLE9BQU8sR0FBRyxDQUFkO0FBQ0EsUUFBTUMsTUFBTSxHQUFHLEVBQWY7O0FBRUEsT0FBSyxJQUFJbE8sTUFBVCxJQUFtQm1PLG9EQUFNLENBQUNILE9BQUQsRUFBV0ksQ0FBRCxJQUFPQSxDQUFDLENBQUNDLEtBQW5CLENBQXpCLEVBQW9EO0FBQ2xELFVBQU07QUFBQ0EsV0FBRDtBQUFRQztBQUFSLFFBQWV0TyxNQUFyQjs7QUFDQSxRQUFJaU8sT0FBTyxHQUFHSSxLQUFkLEVBQXFCO0FBQ25CSCxZQUFNLENBQUM1TyxJQUFQLENBQVk7QUFDVitPLGFBQUssRUFBRUosT0FERztBQUVWSyxXQUFHLEVBQUVELEtBRks7QUFHVjNCLGVBQU8sRUFBRS9TLElBQUksQ0FBQzRVLEtBQUwsQ0FBV04sT0FBWCxFQUFvQkksS0FBcEI7QUFIQyxPQUFaO0FBS0Q7O0FBQ0RILFVBQU0sQ0FBQzVPLElBQVAsaUNBQ0tVLE1BREw7QUFFRXdPLFVBQUksRUFBRSxJQUZSO0FBR0U5QixhQUFPLEVBQUUvUyxJQUFJLENBQUM0VSxLQUFMLENBQVdGLEtBQVgsRUFBa0JDLEdBQWxCO0FBSFg7QUFLQUwsV0FBTyxHQUFHSyxHQUFWO0FBQ0Q7O0FBQ0QsTUFBSUwsT0FBTyxHQUFHdFUsSUFBSSxDQUFDckgsTUFBbkIsRUFBMkI7QUFDekI0YixVQUFNLENBQUM1TyxJQUFQLENBQVk7QUFDVitPLFdBQUssRUFBRUosT0FERztBQUVWSyxTQUFHLEVBQUUzVSxJQUFJLENBQUNySCxNQUZBO0FBR1ZvYSxhQUFPLEVBQUUvUyxJQUFJLENBQUM0VSxLQUFMLENBQVdOLE9BQVgsRUFBb0J0VSxJQUFJLENBQUNySCxNQUF6QjtBQUhDLEtBQVo7QUFLRDs7QUFFRCxTQUFPNGIsTUFBUDtBQUNELENBN0JNO0FBK0JBLE1BQU1PLHNCQUFzQixHQUFHLENBQUM5VSxJQUFELEVBQU9xVSxPQUFQLEtBQW1CO0FBQ3ZELE1BQUlDLE9BQU8sR0FBRyxDQUFkO0FBQ0EsUUFBTUMsTUFBTSxHQUFHLEVBQWY7O0FBRUEsT0FBSyxJQUFJbE8sTUFBVCxJQUFtQm1PLG9EQUFNLENBQUNILE9BQUQsRUFBV0ksQ0FBRCxJQUFPQSxDQUFDLENBQUNDLEtBQW5CLENBQXpCLEVBQW9EO0FBQ2xELFVBQU07QUFBQ0EsV0FBRDtBQUFRQztBQUFSLFFBQWV0TyxNQUFyQjs7QUFDQSxRQUFJaU8sT0FBTyxHQUFHSSxLQUFkLEVBQXFCO0FBQ25CLFdBQUssSUFBSWhjLENBQUMsR0FBRzRiLE9BQWIsRUFBc0I1YixDQUFDLEdBQUdnYyxLQUExQixFQUFpQ2hjLENBQUMsRUFBbEMsRUFBc0M7QUFDcEM2YixjQUFNLENBQUM1TyxJQUFQLENBQVk7QUFDVmpOLFdBRFU7QUFFVnFhLGlCQUFPLEVBQUUvUyxJQUFJLENBQUN0SCxDQUFEO0FBRkgsU0FBWjtBQUlEO0FBQ0Y7O0FBQ0Q2YixVQUFNLENBQUM1TyxJQUFQLGlDQUNLVSxNQURMO0FBRUV3TyxVQUFJLEVBQUUsSUFGUjtBQUdFOUIsYUFBTyxFQUFFL1MsSUFBSSxDQUFDNFUsS0FBTCxDQUFXRixLQUFYLEVBQWtCQyxHQUFsQixFQUF1QkksSUFBdkIsQ0FBNEIsR0FBNUI7QUFIWDtBQUtBVCxXQUFPLEdBQUdLLEdBQVY7QUFDRDs7QUFFRCxPQUFLLElBQUlqYyxDQUFDLEdBQUc0YixPQUFiLEVBQXNCNWIsQ0FBQyxHQUFHc0gsSUFBSSxDQUFDckgsTUFBL0IsRUFBdUNELENBQUMsRUFBeEMsRUFBNEM7QUFDMUM2YixVQUFNLENBQUM1TyxJQUFQLENBQVk7QUFDVmpOLE9BRFU7QUFFVnFhLGFBQU8sRUFBRS9TLElBQUksQ0FBQ3RILENBQUQ7QUFGSCxLQUFaO0FBSUQ7O0FBRUQsU0FBTzZiLE1BQVA7QUFDRCxDQTlCTTtBQWdDQSxNQUFNUyxnQkFBZ0IsR0FBSUMsU0FBRCxJQUFlO0FBQzdDLE1BQUk1VCxRQUFRLEdBQUc0VCxTQUFTLENBQUNDLFVBQVYsQ0FBcUJDLHVCQUFyQixDQUE2Q0YsU0FBUyxDQUFDRyxTQUF2RCxDQUFmO0FBRUEsU0FBTy9ULFFBQVEsS0FBSyxDQUFiLElBQWtCNFQsU0FBUyxDQUFDSSxXQUFWLEtBQTBCSixTQUFTLENBQUNLLFlBQTdEO0FBQ0QsQ0FKTTtBQU1BLE1BQU1DLG9CQUFvQixHQUFJTixTQUFELElBQWU7QUFDakQsTUFBSUQsZ0JBQWdCLENBQUNDLFNBQUQsQ0FBcEIsRUFBaUMsT0FBTyxLQUFQO0FBRWpDLE1BQUk1VCxRQUFRLEdBQUc0VCxTQUFTLENBQUNDLFVBQVYsQ0FBcUJDLHVCQUFyQixDQUE2Q0YsU0FBUyxDQUFDRyxTQUF2RCxDQUFmO0FBRUEsTUFBSUksUUFBUSxHQUFHLEtBQWY7QUFDQSxNQUNHLENBQUNuVSxRQUFELElBQWE0VCxTQUFTLENBQUNLLFlBQVYsR0FBeUJMLFNBQVMsQ0FBQ0ksV0FBakQsSUFDQWhVLFFBQVEsS0FBS29VLElBQUksQ0FBQ0MsMkJBRnBCLEVBSUVGLFFBQVEsR0FBRyxJQUFYO0FBRUYsU0FBT0EsUUFBUDtBQUNELENBYk0sQzs7Ozs7Ozs7Ozs7O0FDNUVQO0FBQUE7QUFBQTtBQUFBLE1BQU1oakIsWUFBWSxHQUFHLG9GQUFyQjtBQUEwRzs7QUFZMUcsTUFBTW1qQixJQUFJLEdBQUk1Z0IsS0FBRCxJQUFXO0FBQ3RCLFFBQU07QUFBQzFCLFNBQUQ7QUFBUXFoQixTQUFSO0FBQWVDLE9BQWY7QUFBb0I1QixXQUFwQjtBQUE2QnBTLE9BQTdCO0FBQWtDaEU7QUFBbEMsTUFBNkM1SCxLQUFuRDtBQUVBLHNCQUNFZ0IsNENBQUssQ0FBQ0MsYUFBTixDQUFvQixNQUFwQixFQUE0QjtBQUMxQkgsU0FBSyxFQUFFO0FBQUM5QixxQkFBZSxFQUFFVixLQUFLLElBQUksU0FBM0I7QUFBc0NZLGFBQU8sRUFBRTtBQUEvQyxLQURtQjtBQUUxQixrQkFBY3lnQixLQUZZO0FBRzFCLGdCQUFZQyxHQUhjO0FBSTFCaFksV0FBTyxFQUFFLE1BQU1BLE9BQU8sQ0FBQztBQUFDK1gsV0FBRDtBQUFRQztBQUFSLEtBQUQsQ0FKSTtBQUlZemUsVUFBTSxFQUFFLFNBSnBCO0FBSTBCQyxZQUFRLEVBQUU7QUFBQ0MsY0FBUSxFQUFFNUQsWUFBWDtBQUF5QjZELGdCQUFVLEVBQUU7QUFBckM7QUFKcEMsR0FBNUIsRUFNSTBjLE9BTkosRUFPSXBTLEdBQUcsaUJBQUk1Syw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CLE1BQXBCLEVBQTRCO0FBQUVILFNBQUssRUFBRTtBQUFDaEMsY0FBUSxFQUFFLE9BQVg7QUFBb0JILGdCQUFVLEVBQUUsR0FBaEM7QUFBcUNrQixnQkFBVSxFQUFFO0FBQWpELEtBQVQ7QUFBOERzQixVQUFNLEVBQUUsU0FBdEU7QUFBNEVDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUF0RixHQUE1QixFQUE2SnNLLEdBQTdKLENBUFgsQ0FERjtBQVdELENBZEQ7O0FBZ0JlZ1YsbUVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1QkEsTUFBTW5qQixZQUFZLEdBQUcsNkZBQXJCO0FBQW1IO0FBRW5IO0FBQ0E7O0FBR0EsTUFBTW9qQixLQUFLLEdBQUk3Z0IsS0FBRCxJQUFXO0FBQ3ZCLE1BQUlBLEtBQUssQ0FBQzhmLElBQVYsRUFBZ0Isb0JBQU85ZSw0Q0FBSyxDQUFDQyxhQUFOLENBQW9CMmYsNkNBQXBCLGtDQUErQjVnQixLQUEvQjtBQUFzQ21CLFVBQU0sRUFBRSxTQUE5QztBQUFvREMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQTlELEtBQVA7QUFFaEIsc0JBQ0VOLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0IsTUFBcEIsRUFBNEI7QUFDMUIsa0JBQWNqQixLQUFLLENBQUMyZixLQURNO0FBRTFCLGdCQUFZM2YsS0FBSyxDQUFDNGYsR0FGUTtBQUcxQmhZLFdBQU8sRUFBRSxNQUFNNUgsS0FBSyxDQUFDNEgsT0FBTixDQUFjO0FBQUMrWCxXQUFLLEVBQUUzZixLQUFLLENBQUMyZixLQUFkO0FBQXFCQyxTQUFHLEVBQUU1ZixLQUFLLENBQUM0ZjtBQUFoQyxLQUFkLENBSFc7QUFHMEN6ZSxVQUFNLEVBQUUsU0FIbEQ7QUFHd0RDLFlBQVEsRUFBRTtBQUFDQyxjQUFRLEVBQUU1RCxZQUFYO0FBQXlCNkQsZ0JBQVUsRUFBRTtBQUFyQztBQUhsRSxHQUE1QixFQUtJdEIsS0FBSyxDQUFDZ2UsT0FMVixDQURGO0FBU0QsQ0FaRDs7QUE0QkEsTUFBTUYsYUFBYSxHQUFJOWQsS0FBRCxJQUFXO0FBQy9CLFFBQU1pZSxPQUFPLEdBQUlDLElBQUQsSUFBVTtBQUN4QjtBQUNBLFFBQUlsZSxLQUFLLENBQUNpZSxPQUFWLEVBQW1CLE9BQU9qZSxLQUFLLENBQUNpZSxPQUFOLENBQWNDLElBQWQsQ0FBUDtBQUNuQixXQUFPO0FBQUN5QixXQUFLLEVBQUV6QixJQUFJLENBQUN5QixLQUFiO0FBQW9CQyxTQUFHLEVBQUUxQixJQUFJLENBQUMwQjtBQUE5QixLQUFQO0FBQ0QsR0FKRDs7QUFNQSxRQUFNa0IsYUFBYSxHQUFHLE1BQU07QUFDMUIsUUFBSSxDQUFDOWdCLEtBQUssQ0FBQ1MsUUFBWCxFQUFxQjtBQUVyQixVQUFNeWYsU0FBUyxHQUFHdkMsTUFBTSxDQUFDQyxZQUFQLEVBQWxCO0FBRUEsUUFBSSxDQUFDc0MsU0FBUyxDQUFDQyxVQUFYLElBQXlCLENBQUNELFNBQVMsQ0FBQ0csU0FBcEMsSUFBaURKLG1FQUFnQixDQUFDQyxTQUFELENBQXJFLEVBQWtGO0FBRWxGLFFBQUlQLEtBQUssR0FDUG9CLFFBQVEsQ0FBQ2IsU0FBUyxDQUFDQyxVQUFWLENBQXFCYSxhQUFyQixDQUFtQ0MsWUFBbkMsQ0FBZ0QsWUFBaEQsQ0FBRCxFQUFnRSxFQUFoRSxDQUFSLEdBQ0FmLFNBQVMsQ0FBQ0ssWUFGWjtBQUdBLFFBQUlYLEdBQUcsR0FDTG1CLFFBQVEsQ0FBQ2IsU0FBUyxDQUFDRyxTQUFWLENBQW9CVyxhQUFwQixDQUFrQ0MsWUFBbEMsQ0FBK0MsWUFBL0MsQ0FBRCxFQUErRCxFQUEvRCxDQUFSLEdBQ0FmLFNBQVMsQ0FBQ0ksV0FGWjs7QUFJQSxRQUNFLENBQUNqYixNQUFNLENBQUM2YixTQUFQLENBQWlCdkIsS0FBakIsQ0FBRCxJQUNBLENBQUN0YSxNQUFNLENBQUM2YixTQUFQLENBQWlCdEIsR0FBakIsQ0FERCxJQUVBTSxTQUFTLENBQUNDLFVBQVYsQ0FBcUJDLHVCQUFyQixDQUE2Q0YsU0FBUyxDQUFDRyxTQUF2RCxNQUFzRSxDQUh4RSxFQUlFO0FBQ0ExQyxZQUFNLENBQUNDLFlBQVAsR0FBc0JDLEtBQXRCO0FBQ0E7QUFDRDs7QUFFRCxRQUFJMkMsdUVBQW9CLENBQUNOLFNBQUQsQ0FBeEIsRUFBcUM7QUFDbkM7QUFBQyxPQUFDUCxLQUFELEVBQVFDLEdBQVIsSUFBZSxDQUFDQSxHQUFELEVBQU1ELEtBQU4sQ0FBZjtBQUNGOztBQUVEM2YsU0FBSyxDQUFDUyxRQUFOLENBQWUsQ0FBQyxHQUFHVCxLQUFLLENBQUNZLEtBQVYsRUFBaUJxZCxPQUFPLENBQUM7QUFBQzBCLFdBQUQ7QUFBUUMsU0FBUjtBQUFhM1UsVUFBSSxFQUFFK1MsT0FBTyxDQUFDNkIsS0FBUixDQUFjRixLQUFkLEVBQXFCQyxHQUFyQjtBQUFuQixLQUFELENBQXhCLENBQWY7QUFFQWpDLFVBQU0sQ0FBQ0MsWUFBUCxHQUFzQkMsS0FBdEI7QUFDRCxHQTlCRDs7QUFnQ0EsUUFBTXNELGdCQUFnQixHQUFHLENBQUM7QUFBQ3hCLFNBQUQ7QUFBUUM7QUFBUixHQUFELEtBQWtCO0FBQ3pDO0FBQ0EsVUFBTXdCLFVBQVUsR0FBR3BoQixLQUFLLENBQUNZLEtBQU4sQ0FBWWtaLFNBQVosQ0FBdUJ1SCxDQUFELElBQU9BLENBQUMsQ0FBQzFCLEtBQUYsS0FBWUEsS0FBWixJQUFxQjBCLENBQUMsQ0FBQ3pCLEdBQUYsS0FBVUEsR0FBNUQsQ0FBbkI7O0FBQ0EsUUFBSXdCLFVBQVUsSUFBSSxDQUFsQixFQUFxQjtBQUNuQnBoQixXQUFLLENBQUNTLFFBQU4sQ0FBZSxDQUFDLEdBQUdULEtBQUssQ0FBQ1ksS0FBTixDQUFZaWYsS0FBWixDQUFrQixDQUFsQixFQUFxQnVCLFVBQXJCLENBQUosRUFBc0MsR0FBR3BoQixLQUFLLENBQUNZLEtBQU4sQ0FBWWlmLEtBQVosQ0FBa0J1QixVQUFVLEdBQUcsQ0FBL0IsQ0FBekMsQ0FBZjtBQUNEO0FBQ0YsR0FORDs7QUFRQSxRQUFNO0FBQUNwRCxXQUFEO0FBQVVwZCxTQUFWO0FBQWlCRTtBQUFqQixNQUEwQmQsS0FBaEM7QUFDQSxRQUFNd2YsTUFBTSxHQUFHSCxtRUFBZ0IsQ0FBQ3JCLE9BQUQsRUFBVXBkLEtBQVYsQ0FBL0I7QUFFQSxzQkFDRUksNENBQUssQ0FBQ0MsYUFBTixDQUFvQixLQUFwQixFQUEyQjtBQUFFSCxTQUFLLEVBQUVBLEtBQVQ7QUFBZ0JrWCxhQUFTLEVBQUU4SSxhQUEzQjtBQUEwQzNmLFVBQU0sRUFBRSxTQUFsRDtBQUF3REMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQWxFLEdBQTNCLEVBQ0lrZSxNQUFNLENBQUNoVSxHQUFQLENBQVk4VixLQUFELGlCQUNYdGdCLDRDQUFLLENBQUNDLGFBQU4sQ0FBb0I0ZixLQUFwQjtBQUE2QmxWLE9BQUcsRUFBRyxHQUFFMlYsS0FBSyxDQUFDM0IsS0FBTSxJQUFHMkIsS0FBSyxDQUFDMUIsR0FBSTtBQUE5RCxLQUFvRTBCLEtBQXBFO0FBQTJFMVosV0FBTyxFQUFFdVosZ0JBQXBGO0FBQXNHaGdCLFVBQU0sRUFBRSxTQUE5RztBQUFvSEMsWUFBUSxFQUFFO0FBQUNDLGNBQVEsRUFBRTVELFlBQVg7QUFBeUI2RCxnQkFBVSxFQUFFO0FBQXJDO0FBQTlILEtBREEsQ0FESixDQURGO0FBT0QsQ0F6REQ7O0FBMkRld2MsNEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDN0ZBO0FBQUE7QUFBQTtBQUFBOztBQUVBLE1BQU01QyxXQUFXLEdBQUl0YSxLQUFELElBQVc7QUFDN0IsUUFBTVgsR0FBRyxHQUFHd1Msb0RBQU0sRUFBbEI7QUFDQWYseURBQVMsQ0FBQyxNQUFNO0FBQ2R6UixPQUFHLENBQUNnVCxPQUFKLEdBQWNyUyxLQUFkO0FBQ0QsR0FGUSxDQUFUO0FBR0EsU0FBT1gsR0FBRyxDQUFDZ1QsT0FBWDtBQUNELENBTkQ7O0FBUWVpSSwwRUFBZixFOzs7Ozs7Ozs7OztBQ1ZBLFVBQVUsbUJBQU8sQ0FBQyw0SkFBaUY7QUFDbkcsMEJBQTBCLG1CQUFPLENBQUMsd0tBQTJFOztBQUU3Rzs7QUFFQTtBQUNBLDBCQUEwQixRQUFTO0FBQ25DOztBQUVBOztBQUVBO0FBQ0E7O0FBRUE7Ozs7QUFJQSxzQzs7Ozs7Ozs7Ozs7QUNsQkEsVUFBVSxtQkFBTyxDQUFDLDRKQUFpRjtBQUNuRywwQkFBMEIsbUJBQU8sQ0FBQyxvS0FBeUU7O0FBRTNHOztBQUVBO0FBQ0EsMEJBQTBCLFFBQVM7QUFDbkM7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTs7OztBQUlBLHNDOzs7Ozs7Ozs7OztBQ2xCQSxVQUFVLG1CQUFPLENBQUMsNEpBQWlGO0FBQ25HLDBCQUEwQixtQkFBTyxDQUFDLDRKQUFxRTs7QUFFdkc7O0FBRUE7QUFDQSwwQkFBMEIsUUFBUztBQUNuQzs7QUFFQTs7QUFFQTtBQUNBOztBQUVBOzs7O0FBSUEsc0M7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsQkEsTUFBTXpNLFlBQVksR0FBRyxDQUFDOFMsV0FBRCxFQUFjQyxjQUFkLEtBQWlDO0FBQ3BELFFBQU07QUFBQ0M7QUFBRCxNQUFjRCxjQUFwQjtBQUNBLE1BQUlFLGVBQWUsR0FBRyxFQUF0Qjs7QUFDQSxNQUFJRCxTQUFKLEVBQWU7QUFDYkMsbUJBQWUsR0FBRztBQUNoQkQsZUFBUyxFQUFHLGdCQUFlQSxTQUFTLENBQUNFLFNBQVYsQ0FDekJGLFNBQVMsQ0FBQ0csT0FBVixDQUFrQixHQUFsQixJQUF5QixDQURBLEVBRXpCSCxTQUFTLENBQUNHLE9BQVYsQ0FBa0IsR0FBbEIsQ0FGeUIsQ0FHekI7QUFKYyxLQUFsQjtBQU1EOztBQUNEO0FBQ0UxRixjQUFVLEVBQUUsTUFEZDtBQUVFO0FBQ0ExUixjQUFVLEVBQUUsTUFIZDtBQUlFek0sV0FBTyxFQUFFLE1BSlg7QUFLRXFCLFNBQUssRUFBRSxNQUxUO0FBTUVILFVBQU0sRUFBRTtBQU5WLEtBT0t1aUIsY0FQTCxHQVFLRSxlQVJMO0FBVUQsQ0FyQkQ7O0FBdUJlalQsMkVBQWYsRTs7Ozs7Ozs7Ozs7O0FDdkJBO0FBQUEsTUFBTW5MLFlBQVksR0FBSTFDLEtBQUQsSUFBVztBQUM5QixNQUFJQSxLQUFLLEtBQUssSUFBVixJQUFrQkEsS0FBSyxLQUFLOEMsU0FBaEMsRUFBMkMsT0FBTyxJQUFQOztBQUMzQyxNQUFJb0ksS0FBSyxDQUFDQyxPQUFOLENBQWNuTCxLQUFkLEtBQXdCLE9BQU9BLEtBQVAsS0FBaUIsUUFBekMsSUFBcUQsT0FBT0EsS0FBSyxDQUFDa1AsTUFBYixLQUF3QixVQUFqRixFQUE2RjtBQUMzRixXQUFPLENBQUNsUCxLQUFLLENBQUNnRCxNQUFkO0FBQ0Q7O0FBQ0QsU0FBTyxLQUFQO0FBQ0QsQ0FORDs7QUFRZU4sMkVBQWYsRSIsImZpbGUiOiJRdWV1ZX5UYXNrUm9vdF8zYWI1N2IxYTc4ODdiYTNmOTMyMi5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIEltcG9ydHNcbnZhciBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gPSByZXF1aXJlKFwiLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiKTtcbmV4cG9ydHMgPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oZmFsc2UpO1xuLy8gTW9kdWxlXG5leHBvcnRzLnB1c2goW21vZHVsZS5pZCwgXCIucmVhY3QtZ3JpZC1sYXlvdXQge1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgdHJhbnNpdGlvbjogaGVpZ2h0IDIwMG1zIGVhc2U7XFxufVxcbi5yZWFjdC1ncmlkLWl0ZW0ge1xcbiAgdHJhbnNpdGlvbjogYWxsIDIwMG1zIGVhc2U7XFxuICB0cmFuc2l0aW9uLXByb3BlcnR5OiBsZWZ0LCB0b3A7XFxufVxcbi5yZWFjdC1ncmlkLWl0ZW0uY3NzVHJhbnNmb3JtcyB7XFxuICB0cmFuc2l0aW9uLXByb3BlcnR5OiB0cmFuc2Zvcm07XFxufVxcbi5yZWFjdC1ncmlkLWl0ZW0ucmVzaXppbmcge1xcbiAgei1pbmRleDogMTtcXG4gIHdpbGwtY2hhbmdlOiB3aWR0aCwgaGVpZ2h0O1xcbn1cXG5cXG4ucmVhY3QtZ3JpZC1pdGVtLnJlYWN0LWRyYWdnYWJsZS1kcmFnZ2luZyB7XFxuICB0cmFuc2l0aW9uOiBub25lO1xcbiAgei1pbmRleDogMztcXG4gIHdpbGwtY2hhbmdlOiB0cmFuc2Zvcm07XFxufVxcblxcbi5yZWFjdC1ncmlkLWl0ZW0uZHJvcHBpbmcge1xcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xcbn1cXG5cXG4ucmVhY3QtZ3JpZC1pdGVtLnJlYWN0LWdyaWQtcGxhY2Vob2xkZXIge1xcbiAgYmFja2dyb3VuZDogcmVkO1xcbiAgb3BhY2l0eTogMC4yO1xcbiAgdHJhbnNpdGlvbi1kdXJhdGlvbjogMTAwbXM7XFxuICB6LWluZGV4OiAyO1xcbiAgLXdlYmtpdC11c2VyLXNlbGVjdDogbm9uZTtcXG4gIC1tb3otdXNlci1zZWxlY3Q6IG5vbmU7XFxuICAtbXMtdXNlci1zZWxlY3Q6IG5vbmU7XFxuICAtby11c2VyLXNlbGVjdDogbm9uZTtcXG4gIHVzZXItc2VsZWN0OiBub25lO1xcbn1cXG5cXG4ucmVhY3QtZ3JpZC1pdGVtID4gLnJlYWN0LXJlc2l6YWJsZS1oYW5kbGUge1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgd2lkdGg6IDIwcHg7XFxuICBoZWlnaHQ6IDIwcHg7XFxuICBib3R0b206IC0xMHB4O1xcbiAgcmlnaHQ6IC0xMHB4O1xcbiAgY3Vyc29yOiBzZS1yZXNpemU7XFxuICBvcGFjaXR5OiAwO1xcbn1cXG5cXG4ucmVhY3QtZ3JpZC1pdGVtID4gLnJlYWN0LXJlc2l6YWJsZS1oYW5kbGU6OmFmdGVyIHtcXG4gIGNvbnRlbnQ6IFxcXCJcXFwiO1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgcmlnaHQ6IDNweDtcXG4gIGJvdHRvbTogM3B4O1xcbiAgd2lkdGg6IDVweDtcXG4gIGhlaWdodDogNXB4O1xcbiAgYm9yZGVyLXJpZ2h0OiAycHggc29saWQgcmdiYSgwLCAwLCAwLCAwLjQpO1xcbiAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkIHJnYmEoMCwgMCwgMCwgMC40KTtcXG59XFxuXFxuLnJlYWN0LXJlc2l6YWJsZS1oaWRlID4gLnJlYWN0LXJlc2l6YWJsZS1oYW5kbGUge1xcbiAgZGlzcGxheTogbm9uZTtcXG59XFxuXCIsIFwiXCJdKTtcbi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0gZXhwb3J0cztcbiIsIi8vIEltcG9ydHNcbnZhciBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gPSByZXF1aXJlKFwiLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiKTtcbmV4cG9ydHMgPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oZmFsc2UpO1xuLy8gTW9kdWxlXG5leHBvcnRzLnB1c2goW21vZHVsZS5pZCwgXCIucmVhY3QtcmVzaXphYmxlIHtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG59XFxuLnJlYWN0LXJlc2l6YWJsZS1oYW5kbGUge1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgd2lkdGg6IDIwcHg7XFxuICBoZWlnaHQ6IDIwcHg7XFxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xcbiAgYmFja2dyb3VuZC1vcmlnaW46IGNvbnRlbnQtYm94O1xcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcXG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnZGF0YTppbWFnZS9zdmcreG1sO2Jhc2U2NCxQSE4yWnlCNGJXeHVjejBpYUhSMGNEb3ZMM2QzZHk1M015NXZjbWN2TWpBd01DOXpkbWNpSUhacFpYZENiM2c5SWpBZ01DQTJJRFlpSUhOMGVXeGxQU0ppWVdOclozSnZkVzVrTFdOdmJHOXlPaU5tWm1abVptWXdNQ0lnZUQwaU1IQjRJaUI1UFNJd2NIZ2lJSGRwWkhSb1BTSTJjSGdpSUdobGFXZG9kRDBpTm5CNElqNDhaeUJ2Y0dGamFYUjVQU0l3TGpNd01pSStQSEJoZEdnZ1pEMGlUU0EySURZZ1RDQXdJRFlnVENBd0lEUXVNaUJNSURRZ05DNHlJRXdnTkM0eUlEUXVNaUJNSURRdU1pQXdJRXdnTmlBd0lFd2dOaUEySUV3Z05pQTJJRm9pSUdacGJHdzlJaU13TURBd01EQWlMejQ4TDJjK1BDOXpkbWMrJyk7XFxuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBib3R0b20gcmlnaHQ7XFxuICBwYWRkaW5nOiAwIDNweCAzcHggMDtcXG59XFxuLnJlYWN0LXJlc2l6YWJsZS1oYW5kbGUtc3cge1xcbiAgYm90dG9tOiAwO1xcbiAgbGVmdDogMDtcXG4gIGN1cnNvcjogc3ctcmVzaXplO1xcbiAgdHJhbnNmb3JtOiByb3RhdGUoOTBkZWcpO1xcbn1cXG4ucmVhY3QtcmVzaXphYmxlLWhhbmRsZS1zZSB7XFxuICBib3R0b206IDA7XFxuICByaWdodDogMDtcXG4gIGN1cnNvcjogc2UtcmVzaXplO1xcbn1cXG4ucmVhY3QtcmVzaXphYmxlLWhhbmRsZS1udyB7XFxuICB0b3A6IDA7XFxuICBsZWZ0OiAwO1xcbiAgY3Vyc29yOiBudy1yZXNpemU7XFxuICB0cmFuc2Zvcm06IHJvdGF0ZSgxODBkZWcpO1xcbn1cXG4ucmVhY3QtcmVzaXphYmxlLWhhbmRsZS1uZSB7XFxuICB0b3A6IDA7XFxuICByaWdodDogMDtcXG4gIGN1cnNvcjogbmUtcmVzaXplO1xcbiAgdHJhbnNmb3JtOiByb3RhdGUoMjcwZGVnKTtcXG59XFxuLnJlYWN0LXJlc2l6YWJsZS1oYW5kbGUtdyxcXG4ucmVhY3QtcmVzaXphYmxlLWhhbmRsZS1lIHtcXG4gIHRvcDogNTAlO1xcbiAgbWFyZ2luLXRvcDogLTEwcHg7XFxuICBjdXJzb3I6IGV3LXJlc2l6ZTtcXG59XFxuLnJlYWN0LXJlc2l6YWJsZS1oYW5kbGUtdyB7XFxuICBsZWZ0OiAwO1xcbiAgdHJhbnNmb3JtOiByb3RhdGUoMTM1ZGVnKTtcXG59XFxuLnJlYWN0LXJlc2l6YWJsZS1oYW5kbGUtZSB7XFxuICByaWdodDogMDtcXG4gIHRyYW5zZm9ybTogcm90YXRlKDMxNWRlZyk7XFxufVxcbi5yZWFjdC1yZXNpemFibGUtaGFuZGxlLW4sXFxuLnJlYWN0LXJlc2l6YWJsZS1oYW5kbGUtcyB7XFxuICBsZWZ0OiA1MCU7XFxuICBtYXJnaW4tbGVmdDogLTEwcHg7XFxuICBjdXJzb3I6IG5zLXJlc2l6ZTtcXG59XFxuLnJlYWN0LXJlc2l6YWJsZS1oYW5kbGUtbiB7XFxuICB0b3A6IDA7XFxuICB0cmFuc2Zvcm06IHJvdGF0ZSgyMjVkZWcpO1xcbn1cXG4ucmVhY3QtcmVzaXphYmxlLWhhbmRsZS1zIHtcXG4gIGJvdHRvbTogMDtcXG4gIHRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcXG59XFxuXCIsIFwiXCJdKTtcbi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0gZXhwb3J0cztcbiIsIi8vIEltcG9ydHNcbnZhciBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gPSByZXF1aXJlKFwiLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiKTtcbmV4cG9ydHMgPSBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18oZmFsc2UpO1xuLy8gTW9kdWxlXG5leHBvcnRzLnB1c2goW21vZHVsZS5pZCwgXCIucmVhY3QtZ3JpZC1pdGVtLnJlYWN0LWdyaWQtcGxhY2Vob2xkZXIge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogIzY2NDhlZTtcXG4gIG9wYWNpdHk6IDAuMTU7XFxuICB6LWluZGV4OiAxMDtcXG59XFxuXFxuLnJlYWN0LWRyYWdnYWJsZS1kcmFnZ2luZywgLnJlYWN0LWRyYWdnYWJsZS5yZXNpemluZyB7XFxuICB6LWluZGV4OiAxMDAgIWltcG9ydGFudDtcXG59XFxuXFxuLnJlYWN0LWdyaWQtaXRlbTpob3ZlciA+IC5yZWFjdC1yZXNpemFibGUtaGFuZGxlIHtcXG4gIG9wYWNpdHk6IDE7XFxufVxcblxcbi5yZWFjdC1ncmlkLWl0ZW0uY3NzVHJhbnNmb3JtcyB7XFxuICB0cmFuc2l0aW9uLXByb3BlcnR5OiBub25lO1xcbn1cXG4uYW5pbWF0ZWQgLnJlYWN0LWdyaWQtaXRlbS5jc3NUcmFuc2Zvcm1zIHtcXG4gIHRyYW5zaXRpb24tcHJvcGVydHk6IHRyYW5zZm9ybTtcXG59XFxuXCIsIFwiXCJdKTtcbi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0gZXhwb3J0cztcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy9jbGllbnQvY29tcG9uZW50cy9JbnB1dEZpZWxkLnRzeFwiO2ltcG9ydCBSZWFjdCwge2ZvcndhcmRSZWYsfSBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICdzdHlsZXMvcGFsZXR0ZSdcbmltcG9ydCB7Rk9OVF9GQU1JTFl9IGZyb20gJ3N0eWxlcy90eXBvZ3JhcGh5J1xuaW1wb3J0IFN0eWxlZEVycm9yIGZyb20gJ2NvbXBvbmVudHMvU3R5bGVkRXJyb3InXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cbmNvbnN0IElucHV0ID0gc3R5bGVkLmlucHV0KCh7ZXJyb3IsIGRpc2FibGVkfSkgPT4gKHtcbiAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgYXBwZWFyYW5jZTogJ25vbmUnLFxuICBvdXRsaW5lOiAnbm9uZScsXG4gIG1hcmdpbjogMCxcbiAgYm9yZGVyOiBgMXB4IHNvbGlkICR7ZXJyb3IgPyBQQUxFVFRFLkVSUk9SX01BSU4gOiBQQUxFVFRFLkJPUkRFUl9NQUlOX0dSQVl9YCxcbiAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gIGNvbG9yOiBQQUxFVFRFLlRFWFRfTUFJTixcbiAgZm9udEZhbWlseTogRk9OVF9GQU1JTFkuU0FOU19TRVJJRixcbiAgZm9udFdlaWdodDogNDAwLFxuICBjdXJzb3I6IGRpc2FibGVkID8gJ25vdC1hbGxvd2VkJyA6ICdpbnB1dCcsXG4gIGJvcmRlclJhZGl1czogNCxcbiAgZm9udFNpemU6IDE1LFxuICBsaW5lSGVpZ2h0OiAnMzJweCcsXG4gIGJhY2tncm91bmRDb2xvcjogJyNmZmYnLFxuICBoZWlnaHQ6IDMyLFxuICBwYWRkaW5nOiAnMCAxMHB4JyxcbiAgdHJhbnNpdGlvbjogJ2JvcmRlci1jb2xvciAyMDBtcyBlYXNlLWluJyxcbiAgd2lkdGg6ICcxMDAlJyxcbiAgJzpmb2N1cyc6IHtcbiAgICBib3hTaGFkb3c6IGAwIDAgMCAzcHggJHtlcnJvciA/ICcjZmZkYWNjJyA6IFBBTEVUVEUuQk9YX1NIQURPV19QUklNQVJZfWAsXG4gICAgYm9yZGVyQ29sb3I6IGVycm9yID8gUEFMRVRURS5FUlJPUl9NQUlOIDogUEFMRVRURS5QUklNQVJZX01BSU5cbiAgfVxufSkpXG5cbmNvbnN0IExhYmVsID0gc3R5bGVkLmRpdih7XG4gIGZvbnRTaXplOiAxNSxcbiAgZm9udFdlaWdodDogNTAwLFxuICBsaW5lSGVpZ2h0OiAnMzJweCcsXG4gIGNvbG9yOiBQQUxFVFRFLlRFWFRfTUFJTlxufSlcblxuY29uc3QgU3R5bGVkTGFiZWwgPSBzdHlsZWQuZGl2KHtcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBmbGV4RGlyZWN0aW9uOiAncm93JyxcbiAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gIG1hcmdpbkxlZnQ6IDVcbn0pXG5cbmNvbnN0IExhYmVsSGVscGVyID0gc3R5bGVkLmRpdih7XG4gIGZvbnRTaXplOiAxMixcbiAgZm9udFdlaWdodDogNDAwLFxuICBjb2xvcjogUEFMRVRURS5URVhUX0dSQVksXG4gIG1hcmdpbkxlZnQ6IDZcbn0pXG5cbmNvbnN0IElucHV0RmllbGQgPSBmb3J3YXJkUmVmKChwcm9wcywgcmVmKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBhdXRvQ29tcGxldGUsXG4gICAgYXV0b0ZvY3VzLFxuICAgIGRpc2FibGVkLFxuICAgIGVycm9yLFxuICAgIGlzT3B0aW9uYWwsXG4gICAgaXNSZXF1aXJlZCxcbiAgICBuYW1lLFxuICAgIG9uQmx1cixcbiAgICBvbkZvY3VzLFxuICAgIG9uQ2hhbmdlLFxuICAgIHBsYWNlaG9sZGVyLFxuICAgIHR5cGUgPSAndGV4dCcsXG4gICAgdmFsdWUsXG4gICAgbGFiZWwsXG4gICAgc3R5bGUsXG4gICAgc3BlbGxDaGVja1xuICB9ID0gcHJvcHNcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGxcbiAgICAgICwgbGFiZWwgJiYgKFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEwMH19XG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEwMX19LCBsYWJlbClcbiAgICAgICAgICAsIGlzUmVxdWlyZWQgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbEhlbHBlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMDJ9fSwgXCJSZXF1aXJlZFwiKVxuICAgICAgICAgICwgaXNPcHRpb25hbCAmJiBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsSGVscGVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEwM319LCBcIk9wdGlvbmFsXCIpXG4gICAgICAgIClcbiAgICAgIClcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChJbnB1dCwge1xuICAgICAgICBhdXRvQ29tcGxldGU6IGF1dG9Db21wbGV0ZSxcbiAgICAgICAgYXV0b0ZvY3VzOiBhdXRvRm9jdXMsXG4gICAgICAgIGRpc2FibGVkOiBCb29sZWFuKGRpc2FibGVkKSxcbiAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgcGxhY2Vob2xkZXI6IHBsYWNlaG9sZGVyLFxuICAgICAgICBvbkJsdXI6IG9uQmx1cixcbiAgICAgICAgb25Gb2N1czogb25Gb2N1cyxcbiAgICAgICAgb25DaGFuZ2U6IG9uQ2hhbmdlLFxuICAgICAgICByZWY6IHJlZixcbiAgICAgICAgdHlwZTogdHlwZSxcbiAgICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgICBlcnJvcjogQm9vbGVhbihlcnJvciksXG4gICAgICAgIHNwZWxsQ2hlY2s6IHNwZWxsQ2hlY2ssXG4gICAgICAgIHN0eWxlOiBzdHlsZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEwNn19XG4gICAgICApXG4gICAgICAsIGVycm9yICYmIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3R5bGVkRXJyb3IsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTIyfX0sIGVycm9yKVxuICAgIClcbiAgKVxufSlcblxuZXhwb3J0IGRlZmF1bHQgSW5wdXRGaWVsZFxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL2NsaWVudC9jb21wb25lbnRzL0xpc3RGaWx0ZXIudHN4XCI7aW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5pbXBvcnQge21hdGNoU29ydGVyfSBmcm9tICdtYXRjaC1zb3J0ZXInXG5pbXBvcnQgSW5wdXRGaWVsZCBmcm9tICcuL0lucHV0RmllbGQnXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIG1hcmdpbjogMTBweCAwcHg7XG5gXG5cbmNvbnN0IExpc3RGaWx0ZXIgPSAoe2xpc3QsIHNldExpc3QsIGtleXN9KSA9PiB7XG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XG4gICAgY29uc3QgdGVybSA9IGUudGFyZ2V0LnZhbHVlXG4gICAgc2V0TGlzdChtYXRjaFNvcnRlcihsaXN0LCB0ZXJtLCB7a2V5c30pKVxuICB9XG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChXcmFwcGVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDM1fX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChJbnB1dEZpZWxkLCB7IHBsYWNlaG9sZGVyOiBcIkZpbHRlclwiLCBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzZ9fSApXG4gICAgKVxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IExpc3RGaWx0ZXJcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9BcHBIZWFkZXIudHN4XCI7aW1wb3J0IFJlYWN0LCB7fSBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICd1bml2ZXJzYWwvc3R5bGVzL3BhbGV0dGUnXG5pbXBvcnQgaXNFbXB0eUFycmF5IGZyb20gJ3VuaXZlcnNhbC91dGlscy9pc0VtcHR5QXJyYXknXG5cbmV4cG9ydCBjb25zdCBBUFBfSEVBREVSX0hFSUdIVCA9IDUwXG5cblxuXG5cblxuXG5cbmNvbnN0IENvbnRhaW5lciA9IHN0eWxlZC5kaXYoe1xuICBkaXNwbGF5OiAnZmxleCcsXG4gIGZsZXhEaXJlY3Rpb246ICdyb3ctcmV2ZXJzZScsXG4gIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLFxuICBwYWRkaW5nOiAnMCAyNXB4JyxcbiAgYmFja2dyb3VuZENvbG9yOiBQQUxFVFRFLkJBQ0tHUk9VTkRfTUFJTixcbiAgYm9yZGVyQm90dG9tOiBgMXB4IHNvbGlkICR7UEFMRVRURS5CT1JERVJfR1JBWV9ORVd9YCxcbiAgbWluSGVpZ2h0OiBBUFBfSEVBREVSX0hFSUdIVCxcbiAgbWluV2lkdGg6ICcxMDAlJ1xufSlcblxuY29uc3QgRmxleEl0ZW0gPSBzdHlsZWQuZGl2KChwcm9wKSA9PiB7XG4gIHJldHVybiB7XG4gICAgZmxleDogJzEgMSAwJyxcbiAgICB0ZXh0QWxpZ246IHByb3AuY2VudGVyID8gJ2NlbnRlcic6ICdpbmhlcml0JyBcbiAgfVxufSlcblxuY29uc3QgQXBwSGVhZGVyID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtsZWZ0QmFySXRlbXMsIHJpZ2h0QmFySXRlbXMsIG1pZEJhckl0ZW1zfSA9IHByb3BzXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzZ9fVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEZsZXhJdGVtLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDM3fX0sIHJpZ2h0QmFySXRlbXMpXG4gICAgICAsICFpc0VtcHR5QXJyYXkocmlnaHRCYXJJdGVtcykgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChGbGV4SXRlbSwgeyBjZW50ZXI6IHRydWUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzOH19LCBtaWRCYXJJdGVtcylcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChGbGV4SXRlbSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzOX19LCBsZWZ0QmFySXRlbXMpXG4gICAgKVxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcEhlYWRlclxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL0Jsb2NrQ29tcG9uZW50LnRzeFwiOyBmdW5jdGlvbiBfb3B0aW9uYWxDaGFpbihvcHMpIHsgbGV0IGxhc3RBY2Nlc3NMSFMgPSB1bmRlZmluZWQ7IGxldCB2YWx1ZSA9IG9wc1swXTsgbGV0IGkgPSAxOyB3aGlsZSAoaSA8IG9wcy5sZW5ndGgpIHsgY29uc3Qgb3AgPSBvcHNbaV07IGNvbnN0IGZuID0gb3BzW2kgKyAxXTsgaSArPSAyOyBpZiAoKG9wID09PSAnb3B0aW9uYWxBY2Nlc3MnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgJiYgdmFsdWUgPT0gbnVsbCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9IGlmIChvcCA9PT0gJ2FjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbEFjY2VzcycpIHsgbGFzdEFjY2Vzc0xIUyA9IHZhbHVlOyB2YWx1ZSA9IGZuKHZhbHVlKTsgfSBlbHNlIGlmIChvcCA9PT0gJ2NhbGwnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgeyB2YWx1ZSA9IGZuKCguLi5hcmdzKSA9PiB2YWx1ZS5jYWxsKGxhc3RBY2Nlc3NMSFMsIC4uLmFyZ3MpKTsgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgfSB9IHJldHVybiB2YWx1ZTsgfWltcG9ydCBSZWFjdCwge21lbW99IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtCTE9DS19UWVBFfSBmcm9tICd1bml2ZXJzYWwvdXRpbHMvY29uc3RhbnRzJ1xuXG5pbXBvcnQgSW1hZ2UgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL0ltYWdlJ1xuaW1wb3J0IE51bWJlciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvTnVtYmVyJ1xuaW1wb3J0IFRleHQgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL1RleHQnXG5pbXBvcnQgRW1haWwgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL0VtYWlsJ1xuaW1wb3J0IExpbmsgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL0xpbmsnXG5pbXBvcnQgTWVkaWFCbG9jayBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvTWVkaWFCbG9jaydcbmltcG9ydCBCaW5hcnkgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL0JpbmFyeSdcbmltcG9ydCBFbWJlZCBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvRW1iZWQnXG5pbXBvcnQgUGRmUmVhZGVyIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9QZGZSZWFkZXInXG5pbXBvcnQgU2luZ2xlU2VsZWN0aW9uIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9TaW5nbGVTZWxlY3Rpb24nXG5pbXBvcnQgTmFtZWRFbnRpdHlSZWNvZ25pdGlvbiBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvTmFtZWRFbnRpdHlSZWNvZ25pdGlvbidcbmltcG9ydCBNdWx0aXBsZVNlbGVjdGlvbiBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvTXVsdGlwbGVTZWxlY3Rpb24nXG5pbXBvcnQgRm9ybVNlcXVlbmNlIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9Gb3JtU2VxdWVuY2UnXG5pbXBvcnQgUmljaFRleHRFZGl0b3IgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL1JpY2hUZXh0RWRpdG9yJ1xuaW1wb3J0IEJvdW5kaW5nQm94ZXMgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL0JvdW5kaW5nQm94ZXMnXG5pbXBvcnQgVGV4dFNlcXVlbmNlIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9UZXh0U2VxdWVuY2UnXG5pbXBvcnQgRGF0ZSBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvRGF0ZSdcblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5jb25zdCBCbG9ja0NvbXBvbmVudCA9IG1lbW8oKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBpc0F1ZGl0cyxcbiAgICBzZXRGaWVsZFZhbHVlLFxuICAgIGlzRWRpdGluZyxcbiAgICBpbmRleCxcbiAgICBibG9jayxcbiAgICBvbkRlbGV0ZSxcbiAgICBoYW5kbGVDaGFuZ2UsXG4gICAgaGFuZGxlQmx1cixcbiAgICBvbkVkaXQsXG4gICAgZXJyb3JzXG4gIH0gPSBwcm9wcyB8fCB7fVxuICBsZXQgcmVuZGVyQ21wXG5cbiAgc3dpdGNoIChibG9jay50eXBlKSB7XG4gICAgY2FzZSBCTE9DS19UWVBFLlRFWFQ6XG4gICAgICByZW5kZXJDbXAgPSAoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGV4dCwge1xuICAgICAgICAgIGlzQXVkaXRzOiBpc0F1ZGl0cyxcbiAgICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgICBpbmRleDogaW5kZXgsXG4gICAgICAgICAgYmxvY2s6IGJsb2NrLFxuICAgICAgICAgIG9uRGVsZXRlOiBvbkRlbGV0ZSxcbiAgICAgICAgICBvbkVkaXQ6IG9uRWRpdCxcbiAgICAgICAgICBoYW5kbGVDaGFuZ2U6IGhhbmRsZUNoYW5nZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUzfX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgYnJlYWtcbiAgICBjYXNlIEJMT0NLX1RZUEUuRU1BSUw6XG4gICAgICByZW5kZXJDbXAgPSAoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRW1haWwsIHtcbiAgICAgICAgICBpc0F1ZGl0czogaXNBdWRpdHMsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgaW5kZXg6IGluZGV4LFxuICAgICAgICAgIGJsb2NrOiBibG9jayxcbiAgICAgICAgICBlcnJvcjogX29wdGlvbmFsQ2hhaW4oW2Vycm9ycywgJ29wdGlvbmFsQWNjZXNzJywgXyA9PiBfLmVtYWlsXSksXG4gICAgICAgICAgb25EZWxldGU6IG9uRGVsZXRlLFxuICAgICAgICAgIG9uRWRpdDogb25FZGl0LFxuICAgICAgICAgIGhhbmRsZUNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgIGhhbmRsZUJsdXI6IGhhbmRsZUJsdXIsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2Nn19XG4gICAgICAgIClcbiAgICAgIClcbiAgICAgIGJyZWFrXG4gICAgY2FzZSBCTE9DS19UWVBFLk5VTUJFUjpcbiAgICAgIHJlbmRlckNtcCA9IChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChOdW1iZXIsIHtcbiAgICAgICAgICBpc0F1ZGl0czogaXNBdWRpdHMsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgaW5kZXg6IGluZGV4LFxuICAgICAgICAgIGJsb2NrOiBibG9jayxcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgaGFuZGxlQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA4MX19XG4gICAgICAgIClcbiAgICAgIClcbiAgICAgIGJyZWFrXG4gICAgY2FzZSBCTE9DS19UWVBFLkxJTks6XG4gICAgICByZW5kZXJDbXAgPSAoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGluaywge1xuICAgICAgICAgIGlzQXVkaXRzOiBpc0F1ZGl0cyxcbiAgICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgICBpbmRleDogaW5kZXgsXG4gICAgICAgICAgYmxvY2s6IGJsb2NrLFxuICAgICAgICAgIGVycm9yOiBfb3B0aW9uYWxDaGFpbihbZXJyb3JzLCAnb3B0aW9uYWxBY2Nlc3MnLCBfMiA9PiBfMi5saW5rXSksXG4gICAgICAgICAgb25EZWxldGU6IG9uRGVsZXRlLFxuICAgICAgICAgIG9uRWRpdDogb25FZGl0LFxuICAgICAgICAgIGhhbmRsZUNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgIGhhbmRsZUJsdXI6IGhhbmRsZUJsdXIsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA5NH19XG4gICAgICAgIClcbiAgICAgIClcbiAgICAgIGJyZWFrXG4gICAgY2FzZSBCTE9DS19UWVBFLklNQUdFOlxuICAgICAgcmVuZGVyQ21wID0gKFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEltYWdlLCB7XG4gICAgICAgICAgaXNBdWRpdHM6IGlzQXVkaXRzLFxuICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgIGJsb2NrOiBibG9jayxcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMDl9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICBicmVha1xuICAgIGNhc2UgQkxPQ0tfVFlQRS5BVURJTzpcbiAgICAgIHJlbmRlckNtcCA9IChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChNZWRpYUJsb2NrLCB7XG4gICAgICAgICAgaXNBdWRpdHM6IGlzQXVkaXRzLFxuICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgIGJsb2NrOiBibG9jayxcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMjB9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICBicmVha1xuICAgIGNhc2UgQkxPQ0tfVFlQRS5WSURFTzpcbiAgICAgIHJlbmRlckNtcCA9IChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChNZWRpYUJsb2NrLCB7XG4gICAgICAgICAgaXNBdWRpdHM6IGlzQXVkaXRzLFxuICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgIGJsb2NrOiBibG9jayxcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMzF9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICBicmVha1xuICAgIGNhc2UgQkxPQ0tfVFlQRS5CSU5BUlk6XG4gICAgICByZW5kZXJDbXAgPSAoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmluYXJ5LCB7XG4gICAgICAgICAgaXNBdWRpdHM6IGlzQXVkaXRzLFxuICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgIGluZGV4OiBpbmRleCxcbiAgICAgICAgICBibG9jazogYmxvY2ssXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgb25EZWxldGU6IG9uRGVsZXRlLFxuICAgICAgICAgIGhhbmRsZUNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgIHNldEZpZWxkVmFsdWU6IHNldEZpZWxkVmFsdWUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNDJ9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICBicmVha1xuICAgIGNhc2UgQkxPQ0tfVFlQRS5OQU1FRF9FTlRJVFlfUkVDT0dOSVRJT046XG4gICAgICByZW5kZXJDbXAgPSAoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTmFtZWRFbnRpdHlSZWNvZ25pdGlvbiwge1xuICAgICAgICAgIGlzQXVkaXRzOiBpc0F1ZGl0cyxcbiAgICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgICBpbmRleDogaW5kZXgsXG4gICAgICAgICAgYmxvY2s6IGJsb2NrLFxuICAgICAgICAgIG9uRWRpdDogb25FZGl0LFxuICAgICAgICAgIGVycm9yOiBlcnJvcnMsXG4gICAgICAgICAgb25EZWxldGU6IG9uRGVsZXRlLFxuICAgICAgICAgIGhhbmRsZUNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgIHNldEZpZWxkVmFsdWU6IHNldEZpZWxkVmFsdWUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNTZ9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICBicmVha1xuICAgIGNhc2UgQkxPQ0tfVFlQRS5CT1VORElOR19CT1hFUzpcbiAgICAgIHJlbmRlckNtcCA9IChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChCb3VuZGluZ0JveGVzLCB7XG4gICAgICAgICAgaXNBdWRpdHM6IGlzQXVkaXRzLFxuICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgIGJsb2NrOiBibG9jayxcbiAgICAgICAgICBpbmRleDogaW5kZXgsXG4gICAgICAgICAgb25EZWxldGU6IG9uRGVsZXRlLFxuICAgICAgICAgIG9uRWRpdDogb25FZGl0LFxuICAgICAgICAgIGhhbmRsZUNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgIHNldEZpZWxkVmFsdWU6IHNldEZpZWxkVmFsdWUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNzF9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICBicmVha1xuICAgIGNhc2UgQkxPQ0tfVFlQRS5FTUJFRDpcbiAgICAgIHJlbmRlckNtcCA9IChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChFbWJlZCwge1xuICAgICAgICAgIGlzQXVkaXRzOiBpc0F1ZGl0cyxcbiAgICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgICBpbmRleDogaW5kZXgsXG4gICAgICAgICAgYmxvY2s6IGJsb2NrLFxuICAgICAgICAgIG9uRWRpdDogb25FZGl0LFxuICAgICAgICAgIGVycm9yOiBlcnJvcnMsXG4gICAgICAgICAgb25EZWxldGU6IG9uRGVsZXRlLFxuICAgICAgICAgIGhhbmRsZUNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgIHNldEZpZWxkVmFsdWU6IHNldEZpZWxkVmFsdWUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxODV9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICBicmVha1xuICAgIGNhc2UgQkxPQ0tfVFlQRS5QREY6XG4gICAgICByZW5kZXJDbXAgPSAoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUGRmUmVhZGVyLCB7XG4gICAgICAgICAgaXNBdWRpdHM6IGlzQXVkaXRzLFxuICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgIGluZGV4OiBpbmRleCxcbiAgICAgICAgICBibG9jazogYmxvY2ssXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgZXJyb3I6IGVycm9ycyxcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgaGFuZGxlQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsXG4gICAgICAgICAgc2V0RmllbGRWYWx1ZTogc2V0RmllbGRWYWx1ZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIwMH19XG4gICAgICAgIClcbiAgICAgIClcbiAgICAgIGJyZWFrXG4gICAgY2FzZSBCTE9DS19UWVBFLlNJTkdMRV9TRUxFQ1RJT046XG4gICAgICByZW5kZXJDbXAgPSAoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU2luZ2xlU2VsZWN0aW9uLCB7XG4gICAgICAgICAgaXNBdWRpdHM6IGlzQXVkaXRzLFxuICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgIGluZGV4OiBpbmRleCxcbiAgICAgICAgICBibG9jazogYmxvY2ssXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgb25EZWxldGU6IG9uRGVsZXRlLFxuICAgICAgICAgIGhhbmRsZUNoYW5nZTogaGFuZGxlQ2hhbmdlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjE1fX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgYnJlYWtcbiAgICBjYXNlIEJMT0NLX1RZUEUuTVVMVElQTEVfU0VMRUNUSU9OOlxuICAgICAgcmVuZGVyQ21wID0gKFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KE11bHRpcGxlU2VsZWN0aW9uLCB7XG4gICAgICAgICAgaXNBdWRpdHM6IGlzQXVkaXRzLFxuICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgIGluZGV4OiBpbmRleCxcbiAgICAgICAgICBibG9jazogYmxvY2ssXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgb25EZWxldGU6IG9uRGVsZXRlLFxuICAgICAgICAgIGhhbmRsZUNoYW5nZTogaGFuZGxlQ2hhbmdlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjI4fX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgYnJlYWtcbiAgICBjYXNlIEJMT0NLX1RZUEUuRk9STV9TRVFVRU5DRTpcbiAgICAgIHJlbmRlckNtcCA9IChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChGb3JtU2VxdWVuY2UsIHtcbiAgICAgICAgICBpc0F1ZGl0czogaXNBdWRpdHMsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgaW5kZXg6IGluZGV4LFxuICAgICAgICAgIGJsb2NrOiBibG9jayxcbiAgICAgICAgICBvbkVkaXQ6IG9uRWRpdCxcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgaGFuZGxlQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsXG4gICAgICAgICAgc2V0RmllbGRWYWx1ZTogc2V0RmllbGRWYWx1ZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI0MX19XG4gICAgICAgIClcbiAgICAgIClcbiAgICAgIGJyZWFrXG4gICAgY2FzZSBCTE9DS19UWVBFLlJJQ0hfVEVYVDpcbiAgICAgIHJlbmRlckNtcCA9IChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChSaWNoVGV4dEVkaXRvciwge1xuICAgICAgICAgIGlzQXVkaXRzOiBpc0F1ZGl0cyxcbiAgICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgICBpbmRleDogaW5kZXgsXG4gICAgICAgICAgYmxvY2s6IGJsb2NrLFxuICAgICAgICAgIG9uRGVsZXRlOiBvbkRlbGV0ZSxcbiAgICAgICAgICBvbkVkaXQ6IG9uRWRpdCxcbiAgICAgICAgICBzZXRGaWVsZFZhbHVlOiBzZXRGaWVsZFZhbHVlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjU1fX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgYnJlYWtcbiAgICBjYXNlIEJMT0NLX1RZUEUuVEVYVF9TRVFVRU5DRTpcbiAgICAgIHJlbmRlckNtcCA9IChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0U2VxdWVuY2UsIHtcbiAgICAgICAgICBpc0F1ZGl0czogaXNBdWRpdHMsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgaW5kZXg6IGluZGV4LFxuICAgICAgICAgIGJsb2NrOiBibG9jayxcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgaGFuZGxlQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsXG4gICAgICAgICAgc2V0RmllbGRWYWx1ZTogc2V0RmllbGRWYWx1ZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI2OH19XG4gICAgICAgIClcbiAgICAgIClcbiAgICAgIGJyZWFrXG4gICAgY2FzZSBCTE9DS19UWVBFLkRBVEU6XG4gICAgICByZW5kZXJDbXAgPSAoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRGF0ZSwge1xuICAgICAgICAgIGlzQXVkaXRzOiBpc0F1ZGl0cyxcbiAgICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgICBpbmRleDogaW5kZXgsXG4gICAgICAgICAgYmxvY2s6IGJsb2NrLFxuICAgICAgICAgIG9uRGVsZXRlOiBvbkRlbGV0ZSxcbiAgICAgICAgICBvbkVkaXQ6IG9uRWRpdCxcbiAgICAgICAgICBoYW5kbGVDaGFuZ2U6IGhhbmRsZUNoYW5nZSxcbiAgICAgICAgICBzZXRGaWVsZFZhbHVlOiBzZXRGaWVsZFZhbHVlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjgyfX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgYnJlYWtcbiAgICBkZWZhdWx0OlxuICAgICAgcmVuZGVyQ21wID0gbnVsbFxuICB9XG4gIHJldHVybiByZW5kZXJDbXBcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IEJsb2NrQ29tcG9uZW50XG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvQmxvY2tIZWFkZXIudHN4XCI7IGZ1bmN0aW9uIF9vcHRpb25hbENoYWluKG9wcykgeyBsZXQgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgbGV0IHZhbHVlID0gb3BzWzBdOyBsZXQgaSA9IDE7IHdoaWxlIChpIDwgb3BzLmxlbmd0aCkgeyBjb25zdCBvcCA9IG9wc1tpXTsgY29uc3QgZm4gPSBvcHNbaSArIDFdOyBpICs9IDI7IGlmICgob3AgPT09ICdvcHRpb25hbEFjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSAmJiB2YWx1ZSA9PSBudWxsKSB7IHJldHVybiB1bmRlZmluZWQ7IH0gaWYgKG9wID09PSAnYWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJykgeyBsYXN0QWNjZXNzTEhTID0gdmFsdWU7IHZhbHVlID0gZm4odmFsdWUpOyB9IGVsc2UgaWYgKG9wID09PSAnY2FsbCcgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSB7IHZhbHVlID0gZm4oKC4uLmFyZ3MpID0+IHZhbHVlLmNhbGwobGFzdEFjY2Vzc0xIUywgLi4uYXJncykpOyBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyB9IH0gcmV0dXJuIHZhbHVlOyB9aW1wb3J0IFJlYWN0LCB7IEZyYWdtZW50IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcblxuaW1wb3J0IEljb25CdXR0b24gZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvSWNvbkJ1dHRvbidcbmltcG9ydCBJY29uIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0ljb24nXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ2NsaWVudC9zdHlsZXMvcGFsZXR0ZSdcbmltcG9ydCB7QkxPQ0tTLH0gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcblxuXG5cblxuXG5cblxuXG5leHBvcnQgY29uc3QgQ29udGFpbmVyID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdncmlkJyxcbiAgZ3JpZFRlbXBsYXRlQ29sdW1uczogJzI1cHggMjVweCcsXG4gIHZpc2liaWxpdHk6ICdoaWRkZW4nLFxuICBvcGFjaXR5OiAwLFxuICB0cmFuc2l0aW9uOiAndmlzaWJpbGl0eSAwcywgb3BhY2l0eSAwLjI1MHMgbGluZWFyJyxcbiAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gIHJpZ2h0OiAnLTVweCcsXG4gIGJhY2tncm91bmRDb2xvcjogJyNmZmYnXG59KVxuXG5jb25zdCBTdHlsZWRJY29uID0gc3R5bGVkKEljb24pKHtcbiAgdGV4dEFsaWduOiAnY2VudGVyJyxcbiAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgZm9udFNpemU6IDE4LFxuICBjb2xvcjogUEFMRVRURS5QUklNQVJZX01BSU5cbn0pXG5cbmNvbnN0IFR5cGVJY29uID0gc3R5bGVkKFN0eWxlZEljb24pKHtcbiAgY29sb3I6IFBBTEVUVEUuQkFDS0dST1VORF9HUkFZX01JRCxcbiAgY3Vyc29yOiAnZGVmYXVsdCdcbn0pXG5cbmNvbnN0IEJsb2NrSGVhZGVyID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtvbkRlbGV0ZSwgb25FZGl0LCBpc0VkaXRpbmcsIGJsb2NrVHlwZX0gPSBwcm9wc1xuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRnJhZ21lbnQsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDJ9fVxuICAgICAgLCBpc0VkaXRpbmcgJiYgKFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KENvbnRhaW5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0NH19XG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEljb25CdXR0b24sIHsgdHlwZTogXCJidXR0b25cIiwgb25DbGljazogb25FZGl0LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDV9fVxuICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZEljb24sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDZ9fSwgXCJzZXR0aW5nc1wiKVxuICAgICAgICAgIClcbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSWNvbkJ1dHRvbiwgeyB0eXBlOiBcImJ1dHRvblwiLCBvbkNsaWNrOiBvbkRlbGV0ZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ4fX1cbiAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTdHlsZWRJY29uLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ5fX0sIFwiZGVsZXRlXCIpXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVHlwZUljb24sIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTN9fSwgX29wdGlvbmFsQ2hhaW4oW0JMT0NLUywgJ2FjY2VzcycsIF8gPT4gXy5maW5kLCAnY2FsbCcsIF8yID0+IF8yKGIgPT4gYi50eXBlID09PSBibG9ja1R5cGUpLCAnb3B0aW9uYWxBY2Nlc3MnLCBfMyA9PiBfMy5pY29uXSkpXG4gICAgKVxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJsb2NrSGVhZGVyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcblxuY29uc3QgQmxvY2tXcmFwcGVyID0gc3R5bGVkLmRpdigoe3R5cGUsIGluZGV4fSkgPT4gKHtcbiAgd2lkdGg6ICcxMDAlJyxcbiAgYmFja2dyb3VuZENvbG9yOiAnI2ZmZiAhaW1wb3J0YW50JyxcbiAgYm9yZGVyUmFkaXVzOiA0LFxuICBib3JkZXI6ICcxcHggc29saWQgI2U3ZTllYycsXG4gIGJveFNoYWRvdzogJ3JnYmEoMCwgMCwgMCwgMC4wMjUpIDBweCAycHggNHB4JyxcbiAgekluZGV4OiB0eXBlID09PSAnZGF0ZScgPyAxMCAtIGluZGV4IDogMVxufSkpXG5cbmV4cG9ydCBkZWZhdWx0IEJsb2NrV3JhcHBlclxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL0ljb25CdXR0b24udHN4XCI7aW1wb3J0IFJlYWN0LCB7Zm9yd2FyZFJlZix9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3VuaXZlcnNhbC9zdHlsZXMvcGFsZXR0ZSdcbmltcG9ydCBQbGFpbkJ1dHRvbiBmcm9tICdjbGllbnQvY29tcG9uZW50cy9QbGFpbkJ1dHRvbidcblxuXG5cblxuXG5cblxuXG5jb25zdCBDb250YWluZXIgPSBzdHlsZWQoUGxhaW5CdXR0b24pKHtcbiAgY3Vyc29yOiAncG9pbnRlcicsXG4gIGJhY2tncm91bmRDb2xvcjogJ2luaGVyaXQnLFxuICBkaXNwbGF5OiAnZmxleCcsXG4gIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gIGJvcmRlclJhZGl1czogNTAsXG4gIHdpZHRoOiAyNSxcbiAgaGVpZ2h0OiAyNSxcbiAgcGFkZGluZzogMCxcbiAgbWFyZ2luOiAwLFxuICB0cmFuc2l0aW9uOiAnYWxsIDIwMG1zIGVhc2UtaW4nLFxuICAnOmhvdmVyJzoge1xuICAgIGNvbG9yOiBQQUxFVFRFLlBSSU1BUllfTUFJTlxuICB9XG59KVxuXG5jb25zdCBJY29uQnV0dG9uID0gZm9yd2FyZFJlZigocHJvcHMsIHJlZikgPT4ge1xuICBjb25zdCB7b25DbGljaywgdHlwZSwgY2hpbGRyZW4sIHN0eWxlfSA9IHByb3BzXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb250YWluZXIsIHsgcmVmOiByZWYsIG9uQ2xpY2s6IG9uQ2xpY2ssIHR5cGU6IHR5cGUsIHN0eWxlOiBzdHlsZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDMzfX1cbiAgICAgICwgY2hpbGRyZW5cbiAgICApXG4gIClcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IEljb25CdXR0b25cbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9SR0wudHN4XCI7aW1wb3J0IFJlYWN0LCB7fSBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IHtSZXNwb25zaXZlLCBXaWR0aFByb3ZpZGVyLH0gZnJvbSAncmVhY3QtZ3JpZC1sYXlvdXQnXG5cblxuaW1wb3J0ICd1bml2ZXJzYWwvc3R5bGVzL2Nzcy9yZWFjdC1ncmlkLWxheW91dC5jc3MnXG5pbXBvcnQgJ3VuaXZlcnNhbC9zdHlsZXMvY3NzL3JlYWN0LXJlc2l6YWJsZS5jc3MnXG5pbXBvcnQgJ3VuaXZlcnNhbC9zdHlsZXMvY3NzL3JnbC1vdmVyaWRlLmNzcydcblxuY29uc3QgUkdMV2lkdGhQcm92aWRlciA9IFdpZHRoUHJvdmlkZXIoUmVzcG9uc2l2ZSlcbmV4cG9ydCBjb25zdCBSR0xfQ09MVU1OUyA9IDIwXG5leHBvcnQgY29uc3QgUkdMX1JPV1MgPSA0MFxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cbmNvbnN0IFJHTENvbnRhaW5lciA9IHN0eWxlZChSR0xXaWR0aFByb3ZpZGVyKSh7XG4gIHdpZHRoOiAnMTAwJScsXG4gIG1pbkhlaWdodDogJ2NhbGMoMTAwdmggLSA1MHB4KScsXG4gIGJhY2tncm91bmRDb2xvcjogJyNmOGY4ZmEnXG59KVxuXG5jb25zdCBSR0xXcmFwcGVyID0gc3R5bGVkLmRpdih7XG4gIGhlaWdodDogJzEwMCUnLFxuICB3aWR0aDogJzEwMCUnLFxuICBvdmVyZmxvdzogJ3Njcm9sbCdcbn0pXG5cbmNvbnN0IFJHTCA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7XG4gICAgY2hpbGRyZW4sXG4gICAgaXNEcmFnZ2FibGUsXG4gICAgaXNEcm9wcGFibGUsXG4gICAgaXNSZXNpemFibGUsXG4gICAgb25EcmFnU3RhcnQsXG4gICAgb25EcmFnU3RvcCxcbiAgICBvbkRyb3AsXG4gICAgb25MYXlvdXRDaGFuZ2UsXG4gICAgbGF5b3V0cyxcbiAgICBkcm9wcGluZ0l0ZW1cbiAgfSA9IHByb3BzXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChSR0xXcmFwcGVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUzfX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChSR0xDb250YWluZXIsIHtcbiAgICAgICAgLi4ucHJvcHMsXG4gICAgICAgIGF1dG9TaXplOiB0cnVlLFxuICAgICAgICBicmVha3BvaW50czoge2FsbDogUkdMX0NPTFVNTlN9LFxuICAgICAgICBjb2xzOiB7YWxsOiBSR0xfQ09MVU1OU30sXG4gICAgICAgIGNvbXBhY3RUeXBlOiAndmVydGljYWwnLFxuICAgICAgICBpc0RyYWdnYWJsZTogaXNEcmFnZ2FibGUsXG4gICAgICAgIGlzRHJvcHBhYmxlOiBpc0Ryb3BwYWJsZSxcbiAgICAgICAgaXNCb3VuZGVkOiB0cnVlLFxuICAgICAgICBkcm9wcGluZ0l0ZW06IGRyb3BwaW5nSXRlbSxcbiAgICAgICAgaXNSZXNpemFibGU6IGlzUmVzaXphYmxlLFxuICAgICAgICBsYXlvdXRzOiB7YWxsOiBsYXlvdXRzfSxcbiAgICAgICAgbWVhc3VyZUJlZm9yZU1vdW50OiB0cnVlLFxuICAgICAgICB1c2VDU1NUcmFuc2Zvcm1zOiB0cnVlLFxuICAgICAgICBwcmV2ZW50Q29sbGlzaW9uOiBmYWxzZSxcbiAgICAgICAgY29udGFpbmVyUGFkZGluZzogWzEwLCAxMF0sXG4gICAgICAgIG1hcmdpbjogWzEwLCAxMF0sXG4gICAgICAgIG9uRHJhZ1N0YXJ0OiBvbkRyYWdTdGFydCxcbiAgICAgICAgb25EcmFnU3RvcDogb25EcmFnU3RvcCxcbiAgICAgICAgb25Ecm9wOiBvbkRyb3AsXG4gICAgICAgIHJvd0hlaWdodDogUkdMX1JPV1MsXG4gICAgICAgIG9uTGF5b3V0Q2hhbmdlOiBvbkxheW91dENoYW5nZSxcbiAgICAgICAgZHJhZ2dhYmxlSGFuZGxlOiBcIi5kcmFnLWhhbmRsZVwiLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTR9fVxuICAgICAgXG4gICAgICAgICwgY2hpbGRyZW5cbiAgICAgIClcbiAgICApXG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgUkdMXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvVGFnZ2FibGVMaXN0V3JhcHBlci50c3hcIjsgZnVuY3Rpb24gX29wdGlvbmFsQ2hhaW4ob3BzKSB7IGxldCBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyBsZXQgdmFsdWUgPSBvcHNbMF07IGxldCBpID0gMTsgd2hpbGUgKGkgPCBvcHMubGVuZ3RoKSB7IGNvbnN0IG9wID0gb3BzW2ldOyBjb25zdCBmbiA9IG9wc1tpICsgMV07IGkgKz0gMjsgaWYgKChvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQ2FsbCcpICYmIHZhbHVlID09IG51bGwpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfSBpZiAob3AgPT09ICdhY2Nlc3MnIHx8IG9wID09PSAnb3B0aW9uYWxBY2Nlc3MnKSB7IGxhc3RBY2Nlc3NMSFMgPSB2YWx1ZTsgdmFsdWUgPSBmbih2YWx1ZSk7IH0gZWxzZSBpZiAob3AgPT09ICdjYWxsJyB8fCBvcCA9PT0gJ29wdGlvbmFsQ2FsbCcpIHsgdmFsdWUgPSBmbigoLi4uYXJncykgPT4gdmFsdWUuY2FsbChsYXN0QWNjZXNzTEhTLCAuLi5hcmdzKSk7IGxhc3RBY2Nlc3NMSFMgPSB1bmRlZmluZWQ7IH0gfSByZXR1cm4gdmFsdWU7IH1pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcbmltcG9ydCB7ZGFya2VufSBmcm9tICdwb2xpc2hlZCdcbmltcG9ydCBJY29uIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0ljb24nXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3VuaXZlcnNhbC9zdHlsZXMvcGFsZXR0ZSdcbmltcG9ydCB7Y29sb3JCeUluZGV4fSBmcm9tICd1bml2ZXJzYWwvdXRpbHMvZ2V0Q29sb3InXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5jb25zdCBMaXN0V3JhcHBlciA9IHN0eWxlZC5kaXYoe1xuICB3aWR0aDogJzE5NXB4JyxcbiAgbWluV2lkdGg6ICcxOTVweCcsXG4gIHVzZXJTZWxlY3Q6ICdub25lJ1xufSlcblxuY29uc3QgTGlzdCA9IHN0eWxlZC5kaXYoe1xuICBjdXJzb3I6ICdhdXRvJ1xufSlcblxuY29uc3QgTGlzdExhYmVsID0gc3R5bGVkLmRpdih7XG4gIGZvbnRXZWlnaHQ6ICc0MDAnLFxuICBtYXJnaW5Ub3A6ICcyMHB4J1xufSlcblxuY29uc3QgQ2F0ZWdvcnlCdXR0b24gPSBzdHlsZWQuc3Bhbigoe2FjdGl2ZX0pID0+ICh7XG4gIGN1cnNvcjogJ3BvaW50ZXInLFxuICBiYWNrZ3JvdW5kOiAnd2hpdGUnLFxuICBjbGVhcjogJ2JvdGgnLFxuICB3aWR0aDogJzEwMCUnLFxuICBtYXJnaW5Cb3R0b206ICc1cHgnLFxuICBwYWRkaW5nOiAnMTBweCAxMHB4JyxcbiAgdGV4dEFsaWduOiAnbGVmdCcsXG4gIGJvcmRlcjogYWN0aXZlID8gJzFweCBzb2xpZCAjNjY0OEVFICFpbXBvcnRhbnQnIDogJzFweCBzb2xpZCAjRThFQ0VFJyxcbiAgYm9yZGVyUmFkaXVzOiAnNHB4JyxcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBmbGV4RGlyZWN0aW9uOiAncm93JyxcbiAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICc6aG92ZXInOiB7XG4gICAgYm94U2hhZG93OiAnMHB4IDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjAyNCknXG4gIH1cbn0pKVxuXG5jb25zdCBFbnRpdHlUZXh0ID0gc3R5bGVkLnNwYW5gXG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBjbGVhcjogYm90aDtcbiAgd2lkdGg6IDEwMCU7XG4gIG1hcmdpbmJvdHRvbTogNXB4O1xuICBwYWRkaW5nOiAxMHB4IDEwcHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdGV4dGFsaWduOiBsZWZ0O1xuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgYm94c2hhZG93OiAwcHggMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMDI0KTtcbiAgYm9yZGVycmFkaXVzOiA0cHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXhkaXJlY3Rpb246IHJvdztcbiAgYWxpZ25pdGVtczogY2VudGVyO1xuICBjdXJzb3I6IGRlZmF1bHQ7XG5cbiAgJjo6c2VsZWN0aW9uIHsgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7IH1cblxuICAmOmhvdmVyIHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZThlY2VlICFpbXBvcnRhbnQ7XG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAgIGkge1xuICAgICAgZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcbiAgICAgIG9wYWNpdHk6IDAuNiAhaW1wb3J0YW50O1xuICAgIH1cbiAgfVxuXG4gIGkge1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuYFxuXG5jb25zdCBDb2xvckFydGlmYWN0ID0gc3R5bGVkLnNwYW4oKHtjb2xvcn0pID0+ICh7XG4gIGJhY2tncm91bmQ6IGNvbG9yLFxuICBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJyxcbiAgd2lkdGg6ICcyMHB4JyxcbiAgaGVpZ2h0OiAnMjBweCcsXG4gIG1hcmdpblJpZ2h0OiAnMTBweCcsXG4gIGJvcmRlcjogYDFweCBzb2xpZCAke2RhcmtlbigwLjMsIGNvbG9yKX1gXG59KSlcblxuY29uc3QgVGFnZ2FibGVMaXN0V3JhcHBlciA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7b3B0aW9ucywgdGV4dCwgc2VsZWN0ZWRDYXRlZ29yeSwgb25TZWxlY3QsIGRpc2FibGVkLCBvYmplY3RzLCBvbkhvdmVyLCBvbkNsaWNrfSA9IHByb3BzXG4gIGNvbnN0IGdldE9wdGlvbkluZGV4ID0gKGlkKSA9PiB7XG4gICAgbGV0IGluZGV4XG4gICAgb3B0aW9ucy5tYXAoKG9wdGlvbiwgaSkgPT4ge1xuICAgICAgaWYgKG9wdGlvbi5pZCA9PT0gaWQpIHtcbiAgICAgICAgaW5kZXggPSBpXG4gICAgICB9XG4gICAgfSlcblxuICAgIHJldHVybiBpbmRleFxuICB9XG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChMaXN0V3JhcHBlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMDZ9fVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KExpc3QsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTA3fX1cbiAgICAgICAgLCBvcHRpb25zLm1hcCgob3B0aW9uLCBvcHRpb25JbmRleCkgPT4gKFxuICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ2F0ZWdvcnlCdXR0b24sIHtcbiAgICAgICAgICAgIGtleTogb3B0aW9uSW5kZXgsXG4gICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgIGlmICghZGlzYWJsZWQpIHtcbiAgICAgICAgICAgICAgICBvblNlbGVjdCh7dGFnOiBvcHRpb24uaWQsIGNvbG9yOiBjb2xvckJ5SW5kZXgob3B0aW9uSW5kZXgpfSlcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHR5cGU6IFwiYnV0dG9uXCIsXG4gICAgICAgICAgICBhY3RpdmU6ICFkaXNhYmxlZCAmJiBzZWxlY3RlZENhdGVnb3J5LnRhZyA9PT0gb3B0aW9uLmlkLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTA5fX1cbiAgICAgICAgICBcbiAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChDb2xvckFydGlmYWN0LCB7IGNvbG9yOiBjb2xvckJ5SW5kZXgob3B0aW9uSW5kZXgpLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTE5fX0gKVxuICAgICAgICAgICAgLCBvcHRpb24ubmFtZVxuICAgICAgICAgIClcbiAgICAgICAgKSlcbiAgICAgIClcblxuICAgICAgLCBBcnJheS5pc0FycmF5KHRleHQpICYmIHRleHQubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGlzdCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxMjZ9fVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChMaXN0TGFiZWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTI3fX0sIFwiRW50aXRpZXNcIilcbiAgICAgICAgICAsIHRleHQubWFwKChpdGVtLCBrZXkpID0+IHtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRW50aXR5VGV4dCwgeyBrZXk6IGtleSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEzMH19XG4gICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KENvbG9yQXJ0aWZhY3QsIHsga2V5OiBrZXksIGNvbG9yOiBpdGVtLmNvbG9yLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTMxfX0gKVxuICAgICAgICAgICAgICAgICwgaXRlbS50ZXh0XG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIClcbiAgICAgICAgICB9KVxuICAgICAgICApXG4gICAgICApXG5cbiAgICAgICwgQXJyYXkuaXNBcnJheShvYmplY3RzKSAmJiBvYmplY3RzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KExpc3QsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTQwfX1cbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGlzdExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE0MX19LCBcIk9iamVjdHNcIilcbiAgICAgICAgICAsIG9iamVjdHMubWFwKChpdGVtLCBrZXkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5hbWUgPSBfb3B0aW9uYWxDaGFpbihbb3B0aW9ucywgJ2FjY2VzcycsIF8gPT4gXy5maW5kLCAnY2FsbCcsIF8yID0+IF8yKChvcHQpID0+IG9wdC5pZCA9PT0gaXRlbS5jYXRlZ29yeSksICdvcHRpb25hbEFjY2VzcycsIF8zID0+IF8zLm5hbWVdKVxuICAgICAgICAgICAgaWYgKCFuYW1lKSByZXR1cm4gbnVsbFxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChFbnRpdHlUZXh0LCB7XG4gICAgICAgICAgICAgICAga2V5OiBrZXksXG4gICAgICAgICAgICAgICAgb25Nb3VzZUVudGVyOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBvbkhvdmVyKGtleSlcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIG9uTW91c2VMZWF2ZTogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgb25Ib3ZlcihudWxsKVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgb25DbGljazogKGUpID0+IHtcbiAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgICAgICAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTQ2fX1cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KENvbG9yQXJ0aWZhY3QsIHsga2V5OiBrZXksIGNvbG9yOiBjb2xvckJ5SW5kZXgoZ2V0T3B0aW9uSW5kZXgoaXRlbS5jYXRlZ29yeSkpLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTU4fX0gKVxuICAgICAgICAgICAgICAgICwgbmFtZVxuXG4gICAgICAgICAgICAgICAgLCAhZGlzYWJsZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJY29uLCB7XG4gICAgICAgICAgICAgICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDE4LFxuICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgICAgICAgICAgICAgICAgICAgIHJpZ2h0OiAnNXB4JyxcbiAgICAgICAgICAgICAgICAgICAgICB0b3A6ICcxMXB4JyxcbiAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiAnbm9uZScsXG4gICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFBBTEVUVEUuVEVYVF9NQUlOXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrKGtleSlcbiAgICAgICAgICAgICAgICAgICAgfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE2Mn19XG4gICAgICAgICAgICAgICAgICAsIFwiY2xvc2VcIlxuXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApXG4gICAgICAgICAgfSlcbiAgICAgICAgKVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBUYWdnYWJsZUxpc3RXcmFwcGVyXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvVGV4dFNlcXVlbmNlLnRzeFwiOyBmdW5jdGlvbiBfb3B0aW9uYWxDaGFpbihvcHMpIHsgbGV0IGxhc3RBY2Nlc3NMSFMgPSB1bmRlZmluZWQ7IGxldCB2YWx1ZSA9IG9wc1swXTsgbGV0IGkgPSAxOyB3aGlsZSAoaSA8IG9wcy5sZW5ndGgpIHsgY29uc3Qgb3AgPSBvcHNbaV07IGNvbnN0IGZuID0gb3BzW2kgKyAxXTsgaSArPSAyOyBpZiAoKG9wID09PSAnb3B0aW9uYWxBY2Nlc3MnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgJiYgdmFsdWUgPT0gbnVsbCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9IGlmIChvcCA9PT0gJ2FjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbEFjY2VzcycpIHsgbGFzdEFjY2Vzc0xIUyA9IHZhbHVlOyB2YWx1ZSA9IGZuKHZhbHVlKTsgfSBlbHNlIGlmIChvcCA9PT0gJ2NhbGwnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgeyB2YWx1ZSA9IGZuKCguLi5hcmdzKSA9PiB2YWx1ZS5jYWxsKGxhc3RBY2Nlc3NMSFMsIC4uLmFyZ3MpKTsgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgfSB9IHJldHVybiB2YWx1ZTsgfWltcG9ydCBSZWFjdCwge3VzZUNhbGxiYWNrfSBmcm9tICdyZWFjdCdcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20nXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcbmltcG9ydCB7RmllbGRBcnJheX0gZnJvbSAnZm9ybWlrJ1xuaW1wb3J0IHtEcmFnRHJvcENvbnRleHQsIERyb3BwYWJsZSwgRHJhZ2dhYmxlfSBmcm9tICdyZWFjdC1iZWF1dGlmdWwtZG5kJ1xuaW1wb3J0IFRleHRBcmVhIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL1RleHRBcmVhJ1xuaW1wb3J0IFNlY29uZGFyeUJ1dHRvbiBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9TZWNvbmRhcnlCdXR0b24nXG5pbXBvcnQgUm9vdEJ1dHRvbiBmcm9tICdjbGllbnQvY29tcG9uZW50cy9Sb290QnV0dG9uJ1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICd1bml2ZXJzYWwvc3R5bGVzL3BhbGV0dGUnXG5pbXBvcnQgSWNvbiBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9JY29uJ1xuaW1wb3J0IGdldEl0ZW1TdHlsZSBmcm9tICd1bml2ZXJzYWwvdXRpbHMvZ2V0SXRlbVN0eWxlJ1xuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5jb25zdCBwb3J0YWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuXG5pZiAoIWRvY3VtZW50LmJvZHkpIHtcbiAgdGhyb3cgbmV3IEVycm9yKCdib2R5IG5vdCByZWFkeSBmb3IgcG9ydGFsIGNyZWF0aW9uIScpXG59XG5cbmRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQocG9ydGFsKVxuXG5jb25zdCBJY29uQnV0dG9uID0gc3R5bGVkKFJvb3RCdXR0b24pKHtcbiAgY29sb3I6IFBBTEVUVEUuUFJJTUFSWV9NQUlOXG59KVxuXG5jb25zdCBGaWVsZFdyYXBwZXIgPSBzdHlsZWQuZGl2KHtcbiAgZGlzcGxheTogJ2dyaWQnLFxuICBtYXJnaW5Cb3R0b206IDIuNSxcbiAgbWFyZ2luVG9wOiAyLjUsXG4gIGFsaWduSXRlbXM6ICdjZW50ZXInXG59KVxuXG5jb25zdCBDb250ZW50V3JhcHBlciA9IHN0eWxlZChGaWVsZFdyYXBwZXIpYFxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmcjtcbiAgJHsoe2lzVGFzaywgb3JkZXJpbmdEaXNhYmxlZCwgZGVsZXRlRGlzYWJsZWR9KSA9PlxuICAgIGlzVGFzayAmJiAhb3JkZXJpbmdEaXNhYmxlZCAmJiAhZGVsZXRlRGlzYWJsZWRcbiAgICAgID8gYFxuICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogYXV0byAxZnIgYXV0bztcbiAgICBncmlkLWdhcDogMTBweDtcbiAgICAmLmZvY3VzZWQge1xuICAgICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiBhdXRvIDFmciBhdXRvO1xuICAgICAgZ3JpZC1nYXA6IDEwcHg7XG4gICAgfVxuICAgICY6aG92ZXIge1xuICAgICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiBhdXRvIDFmciBhdXRvO1xuICAgICAgZ3JpZC1nYXA6IDEwcHg7XG4gICAgfVxuYFxuICAgICAgOiBgYH1cblxuICAkeyh7aXNFZGl0aW5nfSkgPT5cbiAgICBpc0VkaXRpbmdcbiAgICAgID8gYFxuICAmLmZvY3VzZWQge1xuICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogMWZyIGF1dG87XG4gIH1cbiAgJjpob3ZlciB7XG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgYXV0bztcbiAgfVxuYFxuICAgICAgOiBgYH1cbiAgJHsoe2lzVGFzaywgb3JkZXJpbmdEaXNhYmxlZCwgZGVsZXRlRGlzYWJsZWR9KSA9PlxuICAgIGlzVGFzayAmJiBvcmRlcmluZ0Rpc2FibGVkICYmICFkZWxldGVEaXNhYmxlZFxuICAgICAgPyBgXG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgYXV0bztcbiAgICBncmlkLWdhcDogMTBweDtcbiAgYFxuICAgICAgOiBgYH1cblxuICAkeyh7aXNUYXNrLCBkZWxldGVEaXNhYmxlZCwgb3JkZXJpbmdEaXNhYmxlZH0pID0+XG4gICAgaXNUYXNrICYmIGRlbGV0ZURpc2FibGVkICYmICFvcmRlcmluZ0Rpc2FibGVkXG4gICAgICA/IGBcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiBhdXRvIDFmcjtcbiAgZ3JpZC1nYXA6IDEwcHg7XG5gXG4gICAgICA6IGBgfVxuICAkeyh7aXNBdWRpdHN9KSA9PlxuICAgIGlzQXVkaXRzXG4gICAgICA/IGBcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmcjtcbiAgYFxuICAgICAgOiBgYH1cbmBcblxuY29uc3QgQ29udGVudEJsb2NrID0gc3R5bGVkLmRpdih7XG4gIHBhZGRpbmc6ICc1cHggMCcsXG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgZmxleERpcmVjdGlvbjogJ2NvbHVtbidcbn0pXG5cbmNvbnN0IElucHV0V3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gICR7KHtpc1Rhc2ssIG9yZGVyaW5nRGlzYWJsZWQsIGRlbGV0ZURpc2FibGVkfSkgPT5cbiAgICBpc1Rhc2sgJiYgIW9yZGVyaW5nRGlzYWJsZWQgJiYgIWRlbGV0ZURpc2FibGVkXG4gICAgICA/IGBcbiAgICAgIG1hcmdpbjogMHB4O1xuICAgICAgYFxuICAgICAgOiBgYH1cblxuICAkeyh7aXNUYXNrLCBkZWxldGVEaXNhYmxlZCwgb3JkZXJpbmdEaXNhYmxlZH0pID0+XG4gICAgaXNUYXNrICYmIGRlbGV0ZURpc2FibGVkICYmIG9yZGVyaW5nRGlzYWJsZWRcbiAgICAgID8gYFxuICAgICAgbWFyZ2luOiAwcHg7XG4gICAgICBgXG4gICAgICA6IGBgfVxuXG4gICR7KHtpc0VkaXRpbmcsIGRlbGV0ZURpc2FibGVkfSkgPT5cbiAgICBpc0VkaXRpbmcgJiYgIWRlbGV0ZURpc2FibGVkXG4gICAgICA/IGBcbiAgICAgIG1hcmdpbi1yaWdodDogMjVweDtcbiAgICAgICR7Q29udGVudFdyYXBwZXJ9OmhvdmVyICYge1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICB9XG4gICAgICAmLmZvY3VzZWQge1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICB9XG4gICAgICBgXG4gICAgICA6IGBgfVxuYFxuXG5jb25zdCBTdHlsZWRJY29uID0gc3R5bGVkKEljb24pYFxuICAkeyh7aXNUYXNrLCBvcmRlcmluZ0Rpc2FibGVkfSkgPT5cbiAgICBpc1Rhc2sgJiYgIW9yZGVyaW5nRGlzYWJsZWRcbiAgICAgID8gYFxuICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcbiAgICAmLmZvY3VzZWQge1xuICAgICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcbiAgICB9XG4gICAgJHtDb250ZW50V3JhcHBlcn06aG92ZXIgJiB7XG4gICAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xuICAgIH1cbiAgYFxuICAgICAgOiBgYH1cbiAgJHsoe2lzVGFzaywgb3JkZXJpbmdEaXNhYmxlZH0pID0+XG4gICAgaXNUYXNrICYmIG9yZGVyaW5nRGlzYWJsZWRcbiAgICAgID8gYFxuICAgIGRpc3BsYXk6IG5vbmU7XG4gIGBcbiAgICAgIDogYGB9XG4gICR7KHtpc0VkaXRpbmd9KSA9PlxuICAgIGlzRWRpdGluZ1xuICAgICAgPyBgXG4gICAgICBkaXNwbGF5OiBub25lO1xuICAgICAgJi5mb2N1c2VkIHtcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICB9XG5cbiAgICAgICR7Q29udGVudFdyYXBwZXJ9OmhvdmVyICYge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgIH1cbiAgICBgXG4gICAgICA6IGBgfVxuYFxuXG5jb25zdCBCbG9ja0lucHV0ID0gKHtcbiAgcHJvdmlkZWQsXG4gIHNuYXBzaG90LFxuICBzZXFJZHgsXG4gIGRhdGEsXG4gIGluZGV4LFxuICB0eXBlLFxuICBzZXRGaWVsZFZhbHVlLFxuICB0YXJnZXROYW1lLFxuICBwbGFjZWhvbGRlcixcbiAgaXNBdWRpdHMsXG4gIGFycmF5SGVscGVycyxcbiAgaXNFZGl0aW5nLFxuICBzZXR0aW5nc1xufSkgPT4ge1xuICBjb25zdCBzZXRGb2N1c1N0eWxlcyA9IChlbGVtZW50cywgYWN0aW9uKSA9PiB7XG4gICAgZWxlbWVudHMuZm9yRWFjaCgoaWQpID0+IHtcbiAgICAgIGNvbnN0IGVsZW1lbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZClcbiAgICAgIF9vcHRpb25hbENoYWluKFtlbGVtZW50LCAnb3B0aW9uYWxBY2Nlc3MnLCBfMiA9PiBfMi5jbGFzc0xpc3QsICdhY2Nlc3MnLCBfMyA9PiBfM1thY3Rpb25dLCAnY2FsbCcsIF80ID0+IF80KCdmb2N1c2VkJyldKVxuICAgIH0pXG4gIH1cbiAgY29uc3QgaXNUYXNrID0gIWlzRWRpdGluZyAmJiAhaXNBdWRpdHNcbiAgY29uc3Qgc2hvd0RlbGV0ZSA9IGlzQXVkaXRzID8gZmFsc2UgOiAhc2V0dGluZ3MuZGVsZXRlRGlzYWJsZWRcbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KENvbnRlbnRCbG9jaywge1xuICAgICAgLi4ucHJvdmlkZWQuZHJhZ2dhYmxlUHJvcHMsXG4gICAgICByZWY6IHByb3ZpZGVkLmlubmVyUmVmLFxuICAgICAgc3R5bGU6IGdldEl0ZW1TdHlsZShzbmFwc2hvdC5pc0RyYWdnaW5nLCBwcm92aWRlZC5kcmFnZ2FibGVQcm9wcy5zdHlsZSksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMDF9fVxuICAgIFxuICAgICAgLCBkYXRhLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KENvbnRlbnRXcmFwcGVyLCB7XG4gICAgICAgICAgaWQ6IGBjb250ZW50LXdyYXBwZXItJHtzZXFJZHh9YCxcbiAgICAgICAgICBpc0F1ZGl0czogaXNBdWRpdHMsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgaXNUYXNrOiBpc1Rhc2ssXG4gICAgICAgICAgb3JkZXJpbmdEaXNhYmxlZDogc2V0dGluZ3Mub3JkZXJpbmdEaXNhYmxlZCxcbiAgICAgICAgICBkZWxldGVEaXNhYmxlZDogc2V0dGluZ3MuZGVsZXRlRGlzYWJsZWQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMDd9fVxuICAgICAgICBcbiAgICAgICAgICAsIGlzVGFzayAmJiAhc2V0dGluZ3Mub3JkZXJpbmdEaXNhYmxlZCA/IChcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3R5bGVkSWNvbiwge1xuICAgICAgICAgICAgICAuLi5wcm92aWRlZC5kcmFnSGFuZGxlUHJvcHMsXG4gICAgICAgICAgICAgIGlzQXVkaXRzOiBpc0F1ZGl0cyxcbiAgICAgICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgICAgIGlzVGFzazogaXNUYXNrLFxuICAgICAgICAgICAgICBpZDogYGRyYWctaWNvbi0ke3NlcUlkeH1gLFxuICAgICAgICAgICAgICBvcmRlcmluZ0Rpc2FibGVkOiBzZXR0aW5ncy5vcmRlcmluZ0Rpc2FibGVkLFxuICAgICAgICAgICAgICBzdHlsZToge2ZvbnRTaXplOiAxNSwgY29sb3I6IFBBTEVUVEUuVEVYVF9NQUlOfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIxNn19XG4gICAgICAgICAgICAsIFwiZHJhZ19pbmRpY2F0b3JcIlxuXG4gICAgICAgICAgICApXG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICcnXG4gICAgICAgICAgKVxuXG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KElucHV0V3JhcHBlciwge1xuICAgICAgICAgICAgaWQ6IGBpbnB1dC13cmFwcGVyLSR7c2VxSWR4fWAsXG4gICAgICAgICAgICBpc0F1ZGl0czogaXNBdWRpdHMsXG4gICAgICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgICAgIGlzVGFzazogaXNUYXNrLFxuICAgICAgICAgICAgb3JkZXJpbmdEaXNhYmxlZDogc2V0dGluZ3Mub3JkZXJpbmdEaXNhYmxlZCxcbiAgICAgICAgICAgIGRlbGV0ZURpc2FibGVkOiBzZXR0aW5ncy5kZWxldGVEaXNhYmxlZCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIzMX19XG4gICAgICAgICAgXG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGV4dEFyZWEsIHtcbiAgICAgICAgICAgICAgbmFtZTogYGRhdGFbJHtpbmRleH1dWyR7dHlwZX1dLnZhbHVlWyR7c2VxSWR4fV1gLFxuICAgICAgICAgICAgICBjYWNoZU1lYXN1cmVtZW50czogdHJ1ZSxcbiAgICAgICAgICAgICAgdHlwZTogXCJ0ZXh0XCIsXG4gICAgICAgICAgICAgIG9uRm9jdXM6ICgpID0+XG4gICAgICAgICAgICAgICAgc2V0Rm9jdXNTdHlsZXMoXG4gICAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICAgIGBjb250ZW50LXdyYXBwZXItJHtzZXFJZHh9YCxcbiAgICAgICAgICAgICAgICAgICAgYGRyYWctaWNvbi0ke3NlcUlkeH1gLFxuICAgICAgICAgICAgICAgICAgICBgY2xvc2UtaWNvbi0ke3NlcUlkeH1gLFxuICAgICAgICAgICAgICAgICAgICBgaW5wdXQtd3JhcHBlci0ke3NlcUlkeH1gXG4gICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgJ2FkZCdcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICxcbiAgICAgICAgICAgICAgb25CbHVyOiAoKSA9PlxuICAgICAgICAgICAgICAgIHNldEZvY3VzU3R5bGVzKFxuICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICBgY29udGVudC13cmFwcGVyLSR7c2VxSWR4fWAsXG4gICAgICAgICAgICAgICAgICAgIGBkcmFnLWljb24tJHtzZXFJZHh9YCxcbiAgICAgICAgICAgICAgICAgICAgYGNsb3NlLWljb24tJHtzZXFJZHh9YCxcbiAgICAgICAgICAgICAgICAgICAgYGlucHV0LXdyYXBwZXItJHtzZXFJZHh9YFxuICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICdyZW1vdmUnXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAsXG4gICAgICAgICAgICAgIG9uS2V5RG93bjogKGUpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoZS5rZXlDb2RlID09PSAxMykge1xuICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBvbkNoYW5nZTogKGUpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB7dmFsdWV9ID0gZS50YXJnZXRcbiAgICAgICAgICAgICAgICBzZXRGaWVsZFZhbHVlKGAke3RhcmdldE5hbWV9WyR7c2VxSWR4fV1gLCB2YWx1ZSlcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdmFsdWU6IGRhdGFbc2VxSWR4XSxcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI6IF9vcHRpb25hbENoYWluKFtwbGFjZWhvbGRlciwgJ29wdGlvbmFsQWNjZXNzJywgXzUgPT4gXzVbc2VxSWR4XV0pIHx8ICdUZXh0JyxcbiAgICAgICAgICAgICAgcmVhZE9ubHk6IGlzQXVkaXRzLFxuICAgICAgICAgICAgICBkaXNhYmxlZDogc2V0dGluZ3MuZWRpdERpc2FibGVkLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjM5fX1cbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG4gICAgICAgICAgLCBzaG93RGVsZXRlICYmIChcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSWNvbkJ1dHRvbiwge1xuICAgICAgICAgICAgICB0eXBlOiBcImJ1dHRvblwiLFxuICAgICAgICAgICAgICBkaXNhYmxlZDogaXNBdWRpdHMsXG4gICAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IGFycmF5SGVscGVycy5yZW1vdmUoc2VxSWR4KSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI4MX19XG4gICAgICAgICAgICBcbiAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZEljb24sIHtcbiAgICAgICAgICAgICAgICBpc0F1ZGl0czogaXNBdWRpdHMsXG4gICAgICAgICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgICAgICAgZGVsZXRlRGlzYWJsZWQ6IHNldHRpbmdzLmRlbGV0ZURpc2FibGVkLFxuICAgICAgICAgICAgICAgIGlkOiBgY2xvc2UtaWNvbi0ke3NlcUlkeH1gLFxuICAgICAgICAgICAgICAgIHN0eWxlOiB7Zm9udFNpemU6IDE1LCBjb2xvcjogUEFMRVRURS5URVhUX01BSU59LFxuICAgICAgICAgICAgICAgIGlzVGFzazogaXNUYXNrLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjg2fX1cbiAgICAgICAgICAgICAgLCBcImNsb3NlXCJcblxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICApXG4gICAgKVxuICApXG59XG5cbmNvbnN0IFRleHRTZXF1ZW5jZSA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7XG4gICAgbmFtZSxcbiAgICBkYXRhLFxuICAgIGluZGV4LFxuICAgIGlzRWRpdGluZyxcbiAgICB0eXBlLFxuICAgIGlzQXVkaXRzLFxuICAgIHRhcmdldE5hbWUsXG4gICAgc2V0RmllbGRWYWx1ZSxcbiAgICBwbGFjZWhvbGRlcixcbiAgICBzZXR0aW5nc1xuICB9ID0gcHJvcHNcbiAgY29uc3Qgb25EcmFnRW5kID0gdXNlQ2FsbGJhY2soXG4gICAgKHJlc3VsdCkgPT4ge1xuICAgICAgY29uc3Qge2Rlc3RpbmF0aW9uLCBzb3VyY2UsIGRyYWdnYWJsZUlkfSA9IHJlc3VsdFxuICAgICAgaWYgKFxuICAgICAgICAhZGVzdGluYXRpb24gfHxcbiAgICAgICAgKGRlc3RpbmF0aW9uLmRyb3BwYWJsZUlkID09PSBzb3VyY2UuZHJvcHBhYmxlSWQgJiYgZGVzdGluYXRpb24uaW5kZXggPT09IHNvdXJjZS5pbmRleClcbiAgICAgICkge1xuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgY29uc3QgY2hhbmdlZEl0ZW0gPSBkYXRhW2RyYWdnYWJsZUlkXVxuXG4gICAgICBjb25zdCBuZXdMaXN0ID0gZGF0YVxuICAgICAgbmV3TGlzdC5zcGxpY2Uoc291cmNlLmluZGV4LCAxKVxuICAgICAgbmV3TGlzdC5zcGxpY2UoZGVzdGluYXRpb24uaW5kZXgsIDAsIGNoYW5nZWRJdGVtKVxuICAgICAgc2V0RmllbGRWYWx1ZShgZGF0YVske2luZGV4fV1bJHt0eXBlfV0udmFsdWVgLCBuZXdMaXN0KVxuICAgIH0sXG4gICAgW2RhdGEsIGluZGV4XVxuICApXG5cbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEZpZWxkQXJyYXksIHtcbiAgICAgIG5hbWU6IG5hbWUsXG4gICAgICByZW5kZXI6IChhcnJheUhlbHBlcnMpID0+IHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KERyYWdEcm9wQ29udGV4dCwgeyBvbkRyYWdFbmQ6IG9uRHJhZ0VuZCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDM0Mn19XG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRHJvcHBhYmxlLCB7IGRyb3BwYWJsZUlkOiBcImRyb3BhYmxlLWxpc3RcIiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDM0M319XG4gICAgICAgICAgICAgICwgKHByb3ZpZGVkKSA9PiAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudCgnZGl2JywgeyAuLi5wcm92aWRlZC5kcm9wcGFibGVQcm9wcywgcmVmOiBwcm92aWRlZC5pbm5lclJlZiwgc3R5bGU6IHt3aWR0aDogJzEwMCUnfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDM0NX19XG4gICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRmllbGRXcmFwcGVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDM0Nn19XG4gICAgICAgICAgICAgICAgICAgICwgQXJyYXkuaXNBcnJheShkYXRhKSAmJlxuICAgICAgICAgICAgICAgICAgICAgIGRhdGEubWFwKChfLCBzZXFJZHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRHJhZ2dhYmxlLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBzZXFJZHgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZHJhZ2dhYmxlSWQ6IFN0cmluZyhzZXFJZHgpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRHJhZ0Rpc2FibGVkOiBpc0VkaXRpbmcgfHwgaXNBdWRpdHMgfHwgc2V0dGluZ3Mub3JkZXJpbmdEaXNhYmxlZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleDogc2VxSWR4LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzUwfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLCAocHJvdmlkZWQsIHNuYXBzaG90KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1c2VQb3J0YWwgPSBzbmFwc2hvdC5pc0RyYWdnaW5nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGlsZCA9IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChCbG9ja0lucHV0LCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvdmlkZWQ6IHByb3ZpZGVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNuYXBzaG90OiBzbmFwc2hvdCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXFJZHg6IHNlcUlkeCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiBkYXRhLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4OiBpbmRleCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiB0eXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZpZWxkVmFsdWU6IHNldEZpZWxkVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0TmFtZTogdGFyZ2V0TmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcjogcGxhY2Vob2xkZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBdWRpdHM6IGlzQXVkaXRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFycmF5SGVscGVyczogYXJyYXlIZWxwZXJzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldHRpbmdzOiBzZXR0aW5ncywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDM1OX19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdXNlUG9ydGFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjaGlsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gUmVhY3RET00uY3JlYXRlUG9ydGFsKGNoaWxkLCBwb3J0YWwpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICwgcHJvdmlkZWQucGxhY2Vob2xkZXJcbiAgICAgICAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChDb250ZW50QmxvY2ssIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzg2fX1cbiAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFNlY29uZGFyeUJ1dHRvbiwge1xuICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGlzQXVkaXRzIHx8IHNldHRpbmdzLmVkaXREaXNhYmxlZCxcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhcnJheUhlbHBlcnMucHVzaCgnJylcbiAgICAgICAgICAgICAgICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzg3fX1cbiAgICAgICAgICAgICAgICAgICAgLCBcIkFkZCBJdGVtXCJcblxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzM4fX1cbiAgICApXG4gIClcbn1cblxuVGV4dFNlcXVlbmNlLmRlZmF1bHRQcm9wcyA9IHtcbiAgc2V0dGluZ3M6IHtcbiAgICBkZWxldGVEaXNhYmxlZDogZmFsc2UsXG4gICAgZWRpdERpc2FibGVkOiBmYWxzZSxcbiAgICBvcmRlcmluZ0Rpc2FibGVkOiBmYWxzZVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFRleHRTZXF1ZW5jZVxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jib3gtYW5ub3RhdG9yL0JCb3hBbm5vdGF0b3IudHN4XCI7IGZ1bmN0aW9uIF9vcHRpb25hbENoYWluKG9wcykgeyBsZXQgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgbGV0IHZhbHVlID0gb3BzWzBdOyBsZXQgaSA9IDE7IHdoaWxlIChpIDwgb3BzLmxlbmd0aCkgeyBjb25zdCBvcCA9IG9wc1tpXTsgY29uc3QgZm4gPSBvcHNbaSArIDFdOyBpICs9IDI7IGlmICgob3AgPT09ICdvcHRpb25hbEFjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSAmJiB2YWx1ZSA9PSBudWxsKSB7IHJldHVybiB1bmRlZmluZWQ7IH0gaWYgKG9wID09PSAnYWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJykgeyBsYXN0QWNjZXNzTEhTID0gdmFsdWU7IHZhbHVlID0gZm4odmFsdWUpOyB9IGVsc2UgaWYgKG9wID09PSAnY2FsbCcgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSB7IHZhbHVlID0gZm4oKC4uLmFyZ3MpID0+IHZhbHVlLmNhbGwobGFzdEFjY2Vzc0xIUywgLi4uYXJncykpOyBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyB9IH0gcmV0dXJuIHZhbHVlOyB9aW1wb3J0IFJlYWN0LCB7dXNlUmVmLCB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VDYWxsYmFja30gZnJvbSAncmVhY3QnXG5pbXBvcnQgQkJveFNlbGVjdG9yIGZyb20gJy4vQkJveFNlbGVjdG9yJ1xuaW1wb3J0IHtjb2xvckJ5SW5kZXh9IGZyb20gJ3VuaXZlcnNhbC91dGlscy9nZXRDb2xvcidcbmltcG9ydCBfIGZyb20gJ2xvZGFzaCdcblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cbmNvbnN0IEJCb3hBbm5vdGF0b3IgPSAoe1xuICB1cmwsXG4gIGJvcmRlcldpZHRoID0gMixcbiAgc2VsZWN0ZWRMYWJlbCxcbiAgb25DaGFuZ2UsXG4gIG9iamVjdHMsXG4gIGRpc2FibGVkLFxuICBoaWdobGlnaHRJbmRleFxufSkgPT4ge1xuICBjb25zdCBbcG9pbnRlciwgc2V0UG9pbnRlcl0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbb2Zmc2V0LCBzZXRPZmZzZXRdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2VudHJpZXMsIHNldEVudHJpZXNdID0gdXNlU3RhdGUob2JqZWN0cylcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIG9uQ2hhbmdlKFxuICAgICAgZW50cmllcy5tYXAoKGVudHJ5KSA9PiAoe1xuICAgICAgICB3OiArcGFyc2VGbG9hdChlbnRyeS53KS50b0ZpeGVkKDIpLFxuICAgICAgICBoOiArcGFyc2VGbG9hdChlbnRyeS5oKS50b0ZpeGVkKDIpLFxuICAgICAgICB5OiArcGFyc2VGbG9hdChlbnRyeS55KS50b0ZpeGVkKDIpLFxuICAgICAgICB4OiArcGFyc2VGbG9hdChlbnRyeS54KS50b0ZpeGVkKDIpLFxuICAgICAgICBjYXRlZ29yeTogZW50cnkuY2F0ZWdvcnksXG4gICAgICAgIGNvbG9yOiBlbnRyeS5jb2xvclxuICAgICAgfSkpXG4gICAgKVxuICB9LCBbZW50cmllc10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoXG4gICAgICBBcnJheS5pc0FycmF5KG9iamVjdHMpICYmXG4gICAgICBBcnJheS5pc0FycmF5KGVudHJpZXMpICYmXG4gICAgICAhXy5pc0VxdWFsKG9iamVjdHMuc29ydCgpLCBlbnRyaWVzLnNvcnQoKSlcbiAgICApIHtcbiAgICAgIHNldEVudHJpZXMob2JqZWN0cylcbiAgICB9XG4gIH0sIFtvYmplY3RzXSlcblxuICBjb25zdCBbc3RhdHVzLCBzZXRTdGF0dXNdID0gdXNlU3RhdGUoJ2ZyZWUnKVxuICBjb25zdCBbaW1hZ2VGcmFtZVN0eWxlLCBzZXRJbWFnZUZyYW1lU3R5bGVdID0gdXNlU3RhdGVcblxuXG5cbih7fSlcblxuICBjb25zdCBiQm94SW1hZ2VSZWYgPSB1c2VSZWYobnVsbClcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBpbWFnZUVsZW1lbnQgPSBuZXcgSW1hZ2UoKVxuICAgIGltYWdlRWxlbWVudC5zcmMgPSB1cmxcbiAgICBpbWFnZUVsZW1lbnQub25sb2FkID0gKCkgPT4ge1xuICAgICAgY29uc3Qgd2lkdGggPSBpbWFnZUVsZW1lbnQud2lkdGhcbiAgICAgIGNvbnN0IGhlaWdodCA9IGltYWdlRWxlbWVudC5oZWlnaHRcbiAgICAgIHNldEltYWdlRnJhbWVTdHlsZSh7XG4gICAgICAgIGJhY2tncm91bmRJbWFnZVNyYzogaW1hZ2VFbGVtZW50LnNyYyxcbiAgICAgICAgd2lkdGg6IHdpZHRoLFxuICAgICAgICBoZWlnaHQ6IGhlaWdodFxuICAgICAgfSlcbiAgICB9XG4gIH0sIFtiQm94SW1hZ2VSZWYsIHVybF0pXG5cbiAgY29uc3QgY3JvcCA9IChwYWdlWCwgcGFnZVkpID0+IHtcbiAgICBjb25zdCB4ID1cbiAgICAgIGJCb3hJbWFnZVJlZi5jdXJyZW50ICYmIGltYWdlRnJhbWVTdHlsZS53aWR0aFxuICAgICAgICA/IChNYXRoLm1pbihcbiAgICAgICAgICAgIE1hdGgubWF4KE1hdGgucm91bmQocGFnZVggLSBiQm94SW1hZ2VSZWYuY3VycmVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS54KSwgMCksXG4gICAgICAgICAgICBfb3B0aW9uYWxDaGFpbihbYkJveEltYWdlUmVmLCAnYWNjZXNzJywgXzIgPT4gXzIuY3VycmVudCwgJ29wdGlvbmFsQWNjZXNzJywgXzMgPT4gXzMub2Zmc2V0V2lkdGhdKVxuICAgICAgICAgICkgL1xuICAgICAgICAgICAgX29wdGlvbmFsQ2hhaW4oW2JCb3hJbWFnZVJlZiwgJ2FjY2VzcycsIF80ID0+IF80LmN1cnJlbnQsICdvcHRpb25hbEFjY2VzcycsIF81ID0+IF81Lm9mZnNldFdpZHRoXSkpICpcbiAgICAgICAgICAxMDBcbiAgICAgICAgOiAwXG5cbiAgICBjb25zdCB5ID1cbiAgICAgIGJCb3hJbWFnZVJlZi5jdXJyZW50ICYmIGltYWdlRnJhbWVTdHlsZS5oZWlnaHRcbiAgICAgICAgPyAoTWF0aC5taW4oXG4gICAgICAgICAgICBNYXRoLm1heChNYXRoLnJvdW5kKHBhZ2VZIC0gYkJveEltYWdlUmVmLmN1cnJlbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkueSksIDApLFxuICAgICAgICAgICAgX29wdGlvbmFsQ2hhaW4oW2JCb3hJbWFnZVJlZiwgJ2FjY2VzcycsIF82ID0+IF82LmN1cnJlbnQsICdvcHRpb25hbEFjY2VzcycsIF83ID0+IF83Lm9mZnNldEhlaWdodF0pXG4gICAgICAgICAgKSAvXG4gICAgICAgICAgICBfb3B0aW9uYWxDaGFpbihbYkJveEltYWdlUmVmLCAnYWNjZXNzJywgXzggPT4gXzguY3VycmVudCwgJ29wdGlvbmFsQWNjZXNzJywgXzkgPT4gXzkub2Zmc2V0SGVpZ2h0XSkpICpcbiAgICAgICAgICAxMDBcbiAgICAgICAgOiAwXG5cbiAgICByZXR1cm4ge3gsIHl9XG4gIH1cbiAgY29uc3QgdXBkYXRlUmVjdGFuZ2xlID0gKHBhZ2VYLCBwYWdlWSkgPT4ge1xuICAgIHNldFBvaW50ZXIoY3JvcChwYWdlWCwgcGFnZVkpKVxuICB9XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWRpc2FibGVkKSB7XG4gICAgICBjb25zdCBtb3VzZU1vdmVIYW5kbGVyID0gKGUpID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIGlmIChzdGF0dXMgPT09ICdtb3ZlZCcpIHtcbiAgICAgICAgICB1cGRhdGVSZWN0YW5nbGUoZS5wYWdlWCwgZS5wYWdlWSlcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBfb3B0aW9uYWxDaGFpbihbYkJveEltYWdlUmVmLCAnYWNjZXNzJywgXzEwID0+IF8xMC5jdXJyZW50LCAnb3B0aW9uYWxBY2Nlc3MnLCBfMTEgPT4gXzExLmFkZEV2ZW50TGlzdGVuZXIsICdjYWxsJywgXzEyID0+IF8xMignbW91c2Vtb3ZlJywgbW91c2VNb3ZlSGFuZGxlcildKVxuICAgICAgcmV0dXJuICgpID0+IF9vcHRpb25hbENoYWluKFtiQm94SW1hZ2VSZWYsICdhY2Nlc3MnLCBfMTMgPT4gXzEzLmN1cnJlbnQsICdvcHRpb25hbEFjY2VzcycsIF8xNCA9PiBfMTQucmVtb3ZlRXZlbnRMaXN0ZW5lciwgJ2NhbGwnLCBfMTUgPT4gXzE1KCdtb3VzZW1vdmUnLCBtb3VzZU1vdmVIYW5kbGVyKV0pXG4gICAgfVxuICB9LCBbc3RhdHVzXSlcblxuICBjb25zdCBtb3VzZURvd25IYW5kbGVyID0gKGUpID0+IHtcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG4gICAgaWYgKGUuYnV0dG9uICE9PSAyICYmICFkaXNhYmxlZCkge1xuICAgICAgc2V0T2Zmc2V0KGNyb3AoZS5wYWdlWCwgZS5wYWdlWSkpXG4gICAgICBzZXRQb2ludGVyKGNyb3AoZS5wYWdlWCwgZS5wYWdlWSkpXG4gICAgICBzZXRTdGF0dXMoJ2hvbGQnKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IG1vdXNlTW92ZUhhbmRsZXIgPSAoZSkgPT4ge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgICBjb25zdCBjdXJyZW50UG9pbnRlciA9IGNyb3AoZS5wYWdlWCwgZS5wYWdlWSlcbiAgICBzZXRQb2ludGVyKGN1cnJlbnRQb2ludGVyKVxuICAgIGNvbnN0IGhhc01vdmVkID0gY3VycmVudFBvaW50ZXIueCAhPT0gX29wdGlvbmFsQ2hhaW4oW29mZnNldCwgJ29wdGlvbmFsQWNjZXNzJywgXzE2ID0+IF8xNi54XSkgJiYgY3VycmVudFBvaW50ZXIueSAhPT0gX29wdGlvbmFsQ2hhaW4oW29mZnNldCwgJ29wdGlvbmFsQWNjZXNzJywgXzE3ID0+IF8xNy55XSlcbiAgICBpZiAoc3RhdHVzID09PSAnaG9sZCcgJiYgaGFzTW92ZWQpIHtcbiAgICAgIHNldFN0YXR1cygnbW92ZWQnKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHJlY3RhbmdsZSA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCB4MSA9IG9mZnNldCAmJiBwb2ludGVyID8gTWF0aC5taW4ob2Zmc2V0LngsIHBvaW50ZXIueCkgOiAwXG4gICAgY29uc3QgeDIgPSBvZmZzZXQgJiYgcG9pbnRlciA/IE1hdGgubWF4KG9mZnNldC54LCBwb2ludGVyLngpIDogMFxuICAgIGNvbnN0IHkxID0gb2Zmc2V0ICYmIHBvaW50ZXIgPyBNYXRoLm1pbihvZmZzZXQueSwgcG9pbnRlci55KSA6IDBcbiAgICBjb25zdCB5MiA9IG9mZnNldCAmJiBwb2ludGVyID8gTWF0aC5tYXgob2Zmc2V0LnksIHBvaW50ZXIueSkgOiAwXG5cbiAgICByZXR1cm4ge1xuICAgICAgeDogeDEsXG4gICAgICB5OiB5MSxcbiAgICAgIHc6IHgyIC0geDEsXG4gICAgICBoOiB5MiAtIHkxXG4gICAgfVxuICB9LCBbcG9pbnRlciwgb2Zmc2V0XSlcblxuICBjb25zdCByZWN0ID0gcmVjdGFuZ2xlKClcbiAgY29uc3QgYm94UmVmID0gdXNlUmVmKClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZGlzYWJsZWQpIHtcbiAgICAgIGNvbnN0IG1vdXNlVXBIYW5kbGVyID0gKGUpID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgICAgICAgaWYgKHN0YXR1cyA9PT0gJ21vdmVkJykge1xuICAgICAgICAgIHVwZGF0ZVJlY3RhbmdsZShlLnBhZ2VYLCBlLnBhZ2VZKVxuICAgICAgICAgIHNldEVudHJpZXMoW1xuICAgICAgICAgICAgLi4uZW50cmllcyxcbiAgICAgICAgICAgIHsuLi5yZWN0LCBjYXRlZ29yeTogc2VsZWN0ZWRMYWJlbC50YWcsIGNvbG9yOiBzZWxlY3RlZExhYmVsLmNvbG9yfVxuICAgICAgICAgIF0pXG4gICAgICAgIH1cbiAgICAgICAgc2V0U3RhdHVzKCdmcmVlJylcbiAgICAgIH1cbiAgICAgIF9vcHRpb25hbENoYWluKFtib3hSZWYsICdvcHRpb25hbEFjY2VzcycsIF8xOCA9PiBfMTguY3VycmVudCwgJ29wdGlvbmFsQWNjZXNzJywgXzE5ID0+IF8xOS5hZGRFdmVudExpc3RlbmVyLCAnY2FsbCcsIF8yMCA9PiBfMjAoJ21vdXNldXAnLCBtb3VzZVVwSGFuZGxlcildKVxuICAgICAgcmV0dXJuICgpID0+IF9vcHRpb25hbENoYWluKFtib3hSZWYsICdvcHRpb25hbEFjY2VzcycsIF8yMSA9PiBfMjEuY3VycmVudCwgJ29wdGlvbmFsQWNjZXNzJywgXzIyID0+IF8yMi5yZW1vdmVFdmVudExpc3RlbmVyLCAnY2FsbCcsIF8yMyA9PiBfMjMoJ21vdXNldXAnLCBtb3VzZVVwSGFuZGxlcildKVxuICAgIH1cbiAgfSwgW2JveFJlZiwgc3RhdHVzLCByZWN0XSlcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ2RpdicsIHtcbiAgICAgIG9uTW91c2VEb3duQ2FwdHVyZTogbW91c2VEb3duSGFuZGxlcixcbiAgICAgIG9uTW91c2VNb3ZlQ2FwdHVyZTogbW91c2VNb3ZlSGFuZGxlcixcbiAgICAgIGRyYWdnYWJsZTogZmFsc2UsXG4gICAgICByZWY6IGJveFJlZiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE3OH19XG4gICAgXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ2RpdicsIHtcbiAgICAgICAgZHJhZ2dhYmxlOiBmYWxzZSxcbiAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICB3aWR0aDogYDEwMCVgLFxuICAgICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgICAgICAgIGZsb2F0OiBgbGVmdGAsXG4gICAgICAgICAgY3Vyc29yOiAhZGlzYWJsZWQgPyAnY3Jvc3NoYWlyJyA6ICdhdXRvJ1xuICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTg0fX1cbiAgICAgIFxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ2ltZycsIHtcbiAgICAgICAgICBkcmFnZ2FibGU6IGZhbHNlLFxuICAgICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgICBtYXhXaWR0aDogYDEwMCVgLFxuICAgICAgICAgICAgbWF4SGVpZ2h0OiBgMTAwJWAsXG4gICAgICAgICAgICBmbG9hdDogYGxlZnRgXG4gICAgICAgICAgfSxcbiAgICAgICAgICByZWY6IGJCb3hJbWFnZVJlZixcbiAgICAgICAgICBzcmM6IGltYWdlRnJhbWVTdHlsZS5iYWNrZ3JvdW5kSW1hZ2VTcmMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxOTN9fVxuICAgICAgICApXG4gICAgICAgICwgc3RhdHVzID09PSAnbW92ZWQnID8gUmVhY3QuY3JlYXRlRWxlbWVudChCQm94U2VsZWN0b3IsIHsgcmVjdGFuZ2xlOiByZWN0LCBjb2xvcjogc2VsZWN0ZWRMYWJlbC5jb2xvciwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIwM319ICkgOiBudWxsXG4gICAgICAgICwgZW50cmllcy5tYXAoKGVudHJ5LCBpKSA9PiAoXG4gICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudCgnZGl2Jywge1xuICAgICAgICAgICAgZHJhZ2dhYmxlOiBmYWxzZSxcbiAgICAgICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgICAgIGJvcmRlcjogYCR7Ym9yZGVyV2lkdGh9cHggc29saWQgJHtlbnRyeS5jb2xvciB8fCBjb2xvckJ5SW5kZXgoaSl9YCxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICAgICAgICAgIHRvcDogYCR7ZW50cnkueX0lYCxcbiAgICAgICAgICAgICAgbGVmdDogYCR7ZW50cnkueH0lYCxcbiAgICAgICAgICAgICAgd2lkdGg6IGAke2VudHJ5Lnd9JWAsXG4gICAgICAgICAgICAgIGhlaWdodDogYCR7ZW50cnkuaH0lYCxcbiAgICAgICAgICAgICAgcG9pbnRlckV2ZW50czogJ25vbmUnXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAga2V5OiBpLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjA1fX1cbiAgICAgICAgICBcbiAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgnZGl2Jywge1xuICAgICAgICAgICAgICBkcmFnZ2FibGU6IGZhbHNlLFxuICAgICAgICAgICAgICBzdHlsZToge1xuICAgICAgICAgICAgICAgIHdpZHRoOiBgMTAwJWAsXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiBgMTAwJWAsXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogYCR7ZW50cnkuY29sb3IgfHwgY29sb3JCeUluZGV4KGkpfWAsXG4gICAgICAgICAgICAgICAgb3BhY2l0eTogaGlnaGxpZ2h0SW5kZXggPT09IGkgPyBgMC41YCA6IGAwLjJgXG4gICAgICAgICAgICAgIH0sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMTh9fVxuICAgICAgICAgICAgKVxuICAgICAgICAgIClcbiAgICAgICAgKSlcbiAgICAgIClcbiAgICApXG4gIClcbn1cbmV4cG9ydCBkZWZhdWx0IEJCb3hBbm5vdGF0b3JcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9iYm94LWFubm90YXRvci9CQm94U2VsZWN0b3IudHN4XCI7aW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuXG5cblxuXG5cblxuY29uc3QgQkJveFNlbGVjdG9yID0gKHtyZWN0YW5nbGUsIGJvcmRlcldpZHRoID0gMiwgY29sb3J9KSA9PiB7XG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudCgnZGl2Jywge1xuICAgICAgZHJhZ2dhYmxlOiBmYWxzZSxcbiAgICAgIHN0eWxlOiB7XG4gICAgICAgIGxlZnQ6IGAke3JlY3RhbmdsZS54fSVgLFxuICAgICAgICB0b3A6IGAke3JlY3RhbmdsZS55fSVgLFxuICAgICAgICB3aWR0aDogYCR7cmVjdGFuZ2xlLnd9JWAsXG4gICAgICAgIGhlaWdodDogYCR7cmVjdGFuZ2xlLmh9JWAsXG4gICAgICAgIGJvcmRlcjogYCR7Ym9yZGVyV2lkdGggfHwgMn1weCBzb2xpZCAke2NvbG9yfWAsXG4gICAgICAgIGJvcmRlcldpZHRoOiBgJHtib3JkZXJXaWR0aCB8fCAyfXB4YCxcbiAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICAgIHBvaW50ZXJFdmVudHM6ICdub25lJ1xuICAgICAgfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDEwfX1cbiAgICBcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgnZGl2Jywge1xuICAgICAgICBkcmFnZ2FibGU6IGZhbHNlLFxuICAgICAgICBzdHlsZToge1xuICAgICAgICAgIHdpZHRoOiBgMTAwJWAsXG4gICAgICAgICAgaGVpZ2h0OiBgMTAwJWAsXG4gICAgICAgICAgYmFja2dyb3VuZDogYCR7Y29sb3J9YCxcbiAgICAgICAgICBvcGFjaXR5OiBgMC4yYFxuICAgICAgICB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjN9fVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuZXhwb3J0IGRlZmF1bHQgQkJveFNlbGVjdG9yXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL0JpbmFyeS50c3hcIjtpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcbmltcG9ydCBUYXNrUmFkaW8gZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvVGFza1JhZGlvJ1xuXG5pbXBvcnQgQmxvY2tIZWFkZXIgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvQmxvY2tIZWFkZXInXG5pbXBvcnQgSGVhZGVyQ29udGFpbmVyIGZyb20gJy4vSGVhZGVyQ29udGFpbmVyJ1xuaW1wb3J0IEJvZHlDb250YWluZXIgZnJvbSAnLi9Cb2R5Q29udGFpbmVyJ1xuaW1wb3J0IExhYmVsIGZyb20gJy4vTGFiZWwnXG5pbXBvcnQgQ29udGVudCBmcm9tICcuL0NvbnRlbnQnXG5pbXBvcnQge0JMT0NLX1RZUEV9IGZyb20gJ3VuaXZlcnNhbC91dGlscy9jb25zdGFudHMnXG5cblxuXG5cblxuXG5cblxuXG5cblxuY29uc3QgQmxvY2sgPSBzdHlsZWQuZGl2KHtcbiAgbWFyZ2luQm90dG9tOiAxMFxufSlcblxuY29uc3QgQmluYXJ5ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtpc0F1ZGl0cywgYmxvY2ssIG9uRWRpdCwgb25EZWxldGUsIGlzRWRpdGluZywgc2V0RmllbGRWYWx1ZSwgaW5kZXh9ID0gcHJvcHMgfHwge31cbiAgY29uc3Qge2JpbmFyeSwgbmFtZSwgaWQsIF9pZH0gPSBibG9ja1xuICBjb25zdCB7dmFsdWV9ID0gYmluYXJ5IHx8IHt9XG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb250ZW50LCB7IC4uLnByb3BzLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzF9fVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEhlYWRlckNvbnRhaW5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzMn19XG4gICAgICAgICwgbmFtZSAmJiBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDMzfX0sIG5hbWUpXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChCbG9ja0hlYWRlciwge1xuICAgICAgICAgIG9uRGVsZXRlOiBvbkRlbGV0ZSxcbiAgICAgICAgICBvbkVkaXQ6IG9uRWRpdCxcbiAgICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgICBibG9ja1R5cGU6IEJMT0NLX1RZUEUuQklOQVJZLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzR9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQm9keUNvbnRhaW5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0MX19XG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChCbG9jaywge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0Mn19XG4gICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRhc2tSYWRpbywge1xuICAgICAgICAgICAgYXV0b0ZvY3VzOiBmYWxzZSxcbiAgICAgICAgICAgIG5hbWU6IGBkYXRhLiR7aW5kZXh9LmJpbmFyeS52YWx1ZWAsXG4gICAgICAgICAgICBpZDogYCR7X2lkfS10cnVlYCxcbiAgICAgICAgICAgIHZhbHVlOiBcInRydWVcIixcbiAgICAgICAgICAgIGxhYmVsOiBcIlllc1wiLFxuICAgICAgICAgICAgb25DaGFuZ2U6ICgpID0+IHNldEZpZWxkVmFsdWUoYGRhdGEuJHtpbmRleH0uYmluYXJ5LnZhbHVlYCwgdHJ1ZSksXG4gICAgICAgICAgICBjaGVja2VkOiB2YWx1ZSA9PT0gdHJ1ZSxcbiAgICAgICAgICAgIGRpc2FibGVkOiBpc0F1ZGl0cywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQzfX1cbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJsb2NrLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDU0fX1cbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGFza1JhZGlvLCB7XG4gICAgICAgICAgICBhdXRvRm9jdXM6IGZhbHNlLFxuICAgICAgICAgICAgbmFtZTogYGRhdGEuJHtpbmRleH0uYmluYXJ5LnZhbHVlYCxcbiAgICAgICAgICAgIGlkOiBgJHtfaWR9LWZhbHNlYCxcbiAgICAgICAgICAgIHZhbHVlOiBcImZhbHNlXCIsXG4gICAgICAgICAgICBsYWJlbDogXCJOb1wiLFxuICAgICAgICAgICAgb25DaGFuZ2U6ICgpID0+IHNldEZpZWxkVmFsdWUoYGRhdGEuJHtpbmRleH0uYmluYXJ5LnZhbHVlYCwgZmFsc2UpLFxuICAgICAgICAgICAgY2hlY2tlZDogdmFsdWUgPT09IGZhbHNlLFxuICAgICAgICAgICAgZGlzYWJsZWQ6IGlzQXVkaXRzLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTV9fVxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBCaW5hcnlcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvQm91bmRpbmdCb3hlcy50c3hcIjsgZnVuY3Rpb24gX29wdGlvbmFsQ2hhaW4ob3BzKSB7IGxldCBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyBsZXQgdmFsdWUgPSBvcHNbMF07IGxldCBpID0gMTsgd2hpbGUgKGkgPCBvcHMubGVuZ3RoKSB7IGNvbnN0IG9wID0gb3BzW2ldOyBjb25zdCBmbiA9IG9wc1tpICsgMV07IGkgKz0gMjsgaWYgKChvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQ2FsbCcpICYmIHZhbHVlID09IG51bGwpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfSBpZiAob3AgPT09ICdhY2Nlc3MnIHx8IG9wID09PSAnb3B0aW9uYWxBY2Nlc3MnKSB7IGxhc3RBY2Nlc3NMSFMgPSB2YWx1ZTsgdmFsdWUgPSBmbih2YWx1ZSk7IH0gZWxzZSBpZiAob3AgPT09ICdjYWxsJyB8fCBvcCA9PT0gJ29wdGlvbmFsQ2FsbCcpIHsgdmFsdWUgPSBmbigoLi4uYXJncykgPT4gdmFsdWUuY2FsbChsYXN0QWNjZXNzTEhTLCAuLi5hcmdzKSk7IGxhc3RBY2Nlc3NMSFMgPSB1bmRlZmluZWQ7IH0gfSByZXR1cm4gdmFsdWU7IH1pbXBvcnQgUmVhY3QsIHt1c2VTdGF0ZSwgdXNlRWZmZWN0fSBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuXG5pbXBvcnQgQmxvY2tIZWFkZXIgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvQmxvY2tIZWFkZXInXG5pbXBvcnQgQ29udGVudCBmcm9tICcuL0NvbnRlbnQnXG5pbXBvcnQgTGFiZWwgZnJvbSAnLi9MYWJlbCdcbmltcG9ydCBIZWFkZXJDb250YWluZXIgZnJvbSAnLi9IZWFkZXJDb250YWluZXInXG5pbXBvcnQge0JMT0NLX1RZUEV9IGZyb20gJ3VuaXZlcnNhbC91dGlscy9jb25zdGFudHMnXG5pbXBvcnQgQm9keUNvbnRhaW5lciBmcm9tICcuL0JvZHlDb250YWluZXInXG5pbXBvcnQgVGFnZ2FibGVMaXN0V3JhcHBlciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9UYWdnYWJsZUxpc3RXcmFwcGVyJ1xuaW1wb3J0IEJCb3hBbm5vdGF0b3IsIHt9IGZyb20gJy4uL2Jib3gtYW5ub3RhdG9yL0JCb3hBbm5vdGF0b3InXG5pbXBvcnQge2NvbG9yQnlJbmRleH0gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2dldENvbG9yJ1xuXG5cblxuXG5cblxuXG5cblxuXG5cbmNvbnN0IEltYWdlV3JhcHBlciA9IHN0eWxlZCgnZGl2JylgXG4gIGZsZXgtZ3JvdzogMTtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiAxMDAlO1xuYFxuXG5jb25zdCBCb3VuZGluZ0JveGVzID0gUmVhY3QubWVtbygocHJvcHMpID0+IHtcbiAgY29uc3Qge2Jsb2NrLCBvbkRlbGV0ZSwgb25FZGl0LCBpc0VkaXRpbmcsIHNldEZpZWxkVmFsdWUsIGluZGV4LCBpc0F1ZGl0c30gPSBwcm9wc1xuICBjb25zdCB7bmFtZX0gPSBibG9ja1xuXG4gIGNvbnN0IHtwbGFjZWhvbGRlciwgb3B0aW9ucywgdmFsdWV9ID0gYmxvY2tbQkxPQ0tfVFlQRS5CT1VORElOR19CT1hFU10gfHwge31cblxuICBjb25zdCBbb2JqZWN0cywgc2V0T2JqZWN0c10gPSB1c2VTdGF0ZShfb3B0aW9uYWxDaGFpbihbdmFsdWUsICdvcHRpb25hbEFjY2VzcycsIF8yID0+IF8yLm9iamVjdHNdKSB8fCBbXSlcbiAgY29uc3QgW2hpZ2hsaWdodEluZGV4LCBzZXRIaWdobGlnaHRJbmRleF0gPSB1c2VTdGF0ZShudWxsKVxuXG4gIGNvbnN0IHJlbmRlclZhbHVlID0gaXNFZGl0aW5nIHx8IHZhbHVlLmltYWdlID09PSAnJyA/IHBsYWNlaG9sZGVyIHx8ICcnIDogdmFsdWUuaW1hZ2VcblxuICBjb25zdCBbc2VsZWN0ZWRMYWJlbCwgc2V0U2VsZWN0ZWRMYWJlbF0gPSB1c2VTdGF0ZSh7XG4gICAgdGFnOiBvcHRpb25zWzBdLmlkLFxuICAgIGNvbG9yOiBjb2xvckJ5SW5kZXgoMClcbiAgfSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldE9iamVjdHMoX29wdGlvbmFsQ2hhaW4oW3ZhbHVlLCAnb3B0aW9uYWxBY2Nlc3MnLCBfMyA9PiBfMy5vYmplY3RzXSkpXG4gIH0sIFtibG9ja1tCTE9DS19UWVBFLkJPVU5ESU5HX0JPWEVTXV0pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRGaWVsZFZhbHVlKFxuICAgICAgYGRhdGFbJHtpbmRleH1dWyR7QkxPQ0tfVFlQRS5CT1VORElOR19CT1hFU31dLnZhbHVlLm9iamVjdHNgLFxuICAgICAgaXNFZGl0aW5nID8gW10gOiBfb3B0aW9uYWxDaGFpbihbdmFsdWUsICdvcHRpb25hbEFjY2VzcycsIF80ID0+IF80Lm9iamVjdHNdKVxuICAgIClcbiAgICBzZXRPYmplY3RzKGlzRWRpdGluZyA/IFtdIDogX29wdGlvbmFsQ2hhaW4oW3ZhbHVlLCAnb3B0aW9uYWxBY2Nlc3MnLCBfNSA9PiBfNS5vYmplY3RzXSkpXG4gIH0sIFtwbGFjZWhvbGRlciwgb3B0aW9uc10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgc2VsZWN0ZWRJbmRleCA9IDBcbiAgICBvcHRpb25zLmZvckVhY2goKG9wdGlvbiwgaWR4KSA9PiB7XG4gICAgICBpZiAob3B0aW9uLmlkID09PSBzZWxlY3RlZExhYmVsLnRhZykge1xuICAgICAgICBzZWxlY3RlZEluZGV4ID0gaWR4XG4gICAgICB9XG4gICAgfSlcbiAgICBzZXRTZWxlY3RlZExhYmVsKHtcbiAgICAgIHRhZzogb3B0aW9uc1tzZWxlY3RlZEluZGV4XS5pZCxcbiAgICAgIGNvbG9yOiBjb2xvckJ5SW5kZXgoc2VsZWN0ZWRJbmRleClcbiAgICB9KVxuICB9LCBbb3B0aW9uc10pXG5cbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KENvbnRlbnQsIHsgLi4ucHJvcHMsIHN0eWxlOiB7ZGlzcGxheTogJ2Jsb2NrJywgbWF4V2lkdGg6ICcxMDAlJywgbWluV2lkdGg6ICcxMDAlJ30sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA3NX19XG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSGVhZGVyQ29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDc2fX1cbiAgICAgICAgLCBuYW1lICYmIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNzd9fSwgbmFtZSlcbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJsb2NrSGVhZGVyLCB7XG4gICAgICAgICAgb25EZWxldGU6IG9uRGVsZXRlLFxuICAgICAgICAgIG9uRWRpdDogb25FZGl0LFxuICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgIGJsb2NrVHlwZTogQkxPQ0tfVFlQRS5CT1VORElOR19CT1hFUywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDc4fX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJvZHlDb250YWluZXIsIHsgcm93OiB0cnVlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogODV9fVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSW1hZ2VXcmFwcGVyLCB7XG4gICAgICAgICAgb25Nb3VzZURvd246IChlKSA9PiB7XG4gICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG4gICAgICAgICAgfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDg2fX1cbiAgICAgICAgXG4gICAgICAgICAgLCByZW5kZXJWYWx1ZSAmJiAoXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJCb3hBbm5vdGF0b3IsIHtcbiAgICAgICAgICAgICAgdXJsOiByZW5kZXJWYWx1ZSxcbiAgICAgICAgICAgICAgc2VsZWN0ZWRMYWJlbDogc2VsZWN0ZWRMYWJlbCxcbiAgICAgICAgICAgICAgb2JqZWN0czogb2JqZWN0cyxcbiAgICAgICAgICAgICAgaGlnaGxpZ2h0SW5kZXg6IGhpZ2hsaWdodEluZGV4LFxuICAgICAgICAgICAgICBkaXNhYmxlZDogaXNBdWRpdHMsXG4gICAgICAgICAgICAgIG9uQ2hhbmdlOiAoZSkgPT4ge1xuICAgICAgICAgICAgICAgIHNldE9iamVjdHMoZSlcbiAgICAgICAgICAgICAgICBzZXRGaWVsZFZhbHVlKGBkYXRhWyR7aW5kZXh9XVske0JMT0NLX1RZUEUuQk9VTkRJTkdfQk9YRVN9XS52YWx1ZS5vYmplY3RzYCwgZSlcbiAgICAgICAgICAgICAgfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDkyfX1cbiAgICAgICAgICAgIClcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRhZ2dhYmxlTGlzdFdyYXBwZXIsIHtcbiAgICAgICAgICBvcHRpb25zOiBvcHRpb25zLFxuICAgICAgICAgIG9iamVjdHM6IG9iamVjdHMsXG4gICAgICAgICAgZGlzYWJsZWQ6IGlzQXVkaXRzLFxuICAgICAgICAgIG9uU2VsZWN0OiAobGFiZWwpID0+IHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkTGFiZWwobGFiZWwpXG4gICAgICAgICAgfSxcbiAgICAgICAgICBvbkhvdmVyOiAoaW5kZXgpID0+IHtcbiAgICAgICAgICAgIHNldEhpZ2hsaWdodEluZGV4KGluZGV4KVxuICAgICAgICAgIH0sXG4gICAgICAgICAgb25DbGljazogKGluZGV4KSA9PiB7XG4gICAgICAgICAgICBzZXRPYmplY3RzKG9iamVjdHMuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpbmRleCkpXG4gICAgICAgICAgfSxcbiAgICAgICAgICBzZWxlY3RlZENhdGVnb3J5OiBzZWxlY3RlZExhYmVsLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTA1fX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgIClcbiAgKVxufSlcblxuZXhwb3J0IGRlZmF1bHQgQm91bmRpbmdCb3hlc1xuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9Db250ZW50LnRzeFwiO2ltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IHtDb250YWluZXJ9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvQmxvY2tIZWFkZXInXG5pbXBvcnQgSWNvbiBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9JY29uJ1xuXG5cblxuXG5cblxuY29uc3QgQ29udGVudCA9IHN0eWxlZC5kaXZgXG4gIGhlaWdodDogMTAwJTtcbiAgcGFkZGluZzogMTBweDtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgei1pbmRleDogMTtcbiAgb3ZlcmZsb3c6ICR7KHtvdmVyZmxvd30pID0+IChvdmVyZmxvdyA/IG92ZXJmbG93IDogJ2F1dG8nKX07XG4gICY6aG92ZXIgJHtDb250YWluZXJ9IHtcbiAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbmBcbmNvbnN0IENvbnRlbnRDb250YWluZXIgPSBzdHlsZWQuZGl2YFxuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBoZWlnaHQ6IDEwMCU7XG5gXG5cbmNvbnN0IERyYWdIYW5kbGUgPSBzdHlsZWQoSWNvbilgXG4gIGhlaWdodDogMzBweDtcbiAgd2lkdGg6IDMwcHg7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgbGVmdDogNTAlO1xuICB6LWluZGV4OiAxMDtcbiAgdG9wOiAtMTVweDtcbiAgY3Vyc29yOiAkeyh7aXNFZGl0aW5nfSkgPT4gKGlzRWRpdGluZyA/ICdncmFiJyA6ICdpbmhlcml0Jyl9O1xuICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XG4gIGRpc3BsYXk6ICR7KHtpc0VkaXRpbmd9KSA9PiAoaXNFZGl0aW5nID8gJ2Jsb2NrJyA6ICdub25lJyl9O1xuICAke0NvbnRlbnRDb250YWluZXJ9OmhvdmVyICYge1xuICAgIGRpc3BsYXk6ICR7KHtpc0VkaXRpbmd9KSA9PiAoaXNFZGl0aW5nID8gJ2Jsb2NrJyA6ICdub25lJyl9ICFpbXBvcnRhbnQ7XG4gIH1cbiAgJi5kcmFnZ2luZyB7XG4gICAgY3Vyc29yOiBncmFiYmluZztcbiAgfVxuYFxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb250ZW50V3JhcHBlcih7Y2hpbGRyZW4sIGlzRWRpdGluZywgb3ZlcmZsb3d9KSB7XG4gIGNvbnN0IGFkZERyYWdnaW5nU3R5bGVzID0gKGUpID0+IHtcbiAgICBlLnRhcmdldC5jbGFzc0xpc3QuYWRkKCdkcmFnZ2luZycpXG4gIH1cblxuICBjb25zdCByZW1vdmVEcmFnZ2luZ1N0eWxlcyA9IChlKSA9PiB7XG4gICAgZS50YXJnZXQuY2xhc3NMaXN0LnJlbW92ZSgnZHJhZ2dpbmcnKVxuICB9XG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb250ZW50Q29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDU2fX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChEcmFnSGFuZGxlLCB7XG4gICAgICAgIGNsYXNzTmFtZTogXCJkcmFnLWhhbmRsZVwiLFxuICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICBmb250U2l6ZTogMTgsXG4gICAgICAgICAgY29sb3I6ICcjNjg2ODY5J1xuICAgICAgICB9LFxuICAgICAgICBvbk1vdXNlT3V0OiByZW1vdmVEcmFnZ2luZ1N0eWxlcyxcbiAgICAgICAgb25Nb3VzZURvd246IGFkZERyYWdnaW5nU3R5bGVzLFxuICAgICAgICBvbk1vdXNlVXA6IHJlbW92ZURyYWdnaW5nU3R5bGVzLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTd9fVxuICAgICAgLCBcImRyYWdfaGFuZGxlXCJcblxuICAgICAgKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KENvbnRlbnQsIHsgaXNFZGl0aW5nOiBpc0VkaXRpbmcsIG92ZXJmbG93OiBvdmVyZmxvdywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDcwfX1cbiAgICAgICAgLCBjaGlsZHJlblxuICAgICAgKVxuICAgIClcbiAgKVxufVxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9EYXRlLnRzeFwiO2ltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBEYXRlUGlja2VyIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0RhdGVQaWNrZXInXG5cbmltcG9ydCBCbG9ja0hlYWRlciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9CbG9ja0hlYWRlcidcbmltcG9ydCBMYWJlbCBmcm9tICcuL0xhYmVsJ1xuaW1wb3J0IEhlYWRlckNvbnRhaW5lciBmcm9tICcuL0hlYWRlckNvbnRhaW5lcidcbmltcG9ydCBDb250ZW50IGZyb20gJy4vQ29udGVudCdcbmltcG9ydCB7QkxPQ0tfVFlQRX0gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcbmltcG9ydCBCb2R5Q29udGFpbmVyIGZyb20gJy4vQm9keUNvbnRhaW5lcidcbmltcG9ydCB7Z2V0RGlzcGxheUZvcm1hdH0gZnJvbSAnY2xpZW50L3V0aWxzL2RhdGVIZWxwZXJzJ1xuXG5cblxuXG5cblxuXG5cblxuXG5cblxuY29uc3QgRGF0ZUJsb2NrID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtpc0F1ZGl0cywgYmxvY2ssIG9uRWRpdCwgb25EZWxldGUsIHNldEZpZWxkVmFsdWUsIGlzRWRpdGluZywgaW5kZXh9ID0gcHJvcHNcbiAgY29uc3Qge2RhdGUsIG5hbWV9ID0gYmxvY2tcbiAgY29uc3Qge3BsYWNlaG9sZGVyLCByZWFkX29ubHk6IHJlYWRPbmx5LCB2YWx1ZSA9ICcnfSA9IGRhdGUgfHwge31cblxuICBjb25zdCByZW5kZXJWYWx1ZSA9IGlzRWRpdGluZyA/IHZhbHVlIHx8IHBsYWNlaG9sZGVyIDogdmFsdWVcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29udGVudCwgeyAuLi5wcm9wcywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDMxfX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChIZWFkZXJDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzJ9fVxuICAgICAgICAsIG5hbWUgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzM319LCBuYW1lKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmxvY2tIZWFkZXIsIHtcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgYmxvY2tUeXBlOiBCTE9DS19UWVBFLkRBVEUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzNH19XG4gICAgICAgIClcbiAgICAgIClcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChCb2R5Q29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQxfX1cbiAgICAgICAgLCByZWFkT25seSB8fCBpc0F1ZGl0cyA/IChcbiAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KCdkaXYnLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQzfX0sIGdldERpc3BsYXlGb3JtYXQocmVuZGVyVmFsdWUpKVxuICAgICAgICApIDogKFxuICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRGF0ZVBpY2tlciwge1xuICAgICAgICAgICAgbmFtZTogYGRhdGEuJHtpbmRleH0uZGF0ZS52YWx1ZWAsXG4gICAgICAgICAgICB2YWx1ZTogcmVuZGVyVmFsdWUsXG4gICAgICAgICAgICByZWFkT25seTogcmVhZE9ubHkgfHwgaXNBdWRpdHMsXG4gICAgICAgICAgICBwbGFjZWhvbGRlcjogcGxhY2Vob2xkZXIsXG4gICAgICAgICAgICBzZXRGaWVsZFZhbHVlOiBzZXRGaWVsZFZhbHVlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDV9fVxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBEYXRlQmxvY2tcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvRW1haWwudHN4XCI7IGZ1bmN0aW9uIF9vcHRpb25hbENoYWluKG9wcykgeyBsZXQgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgbGV0IHZhbHVlID0gb3BzWzBdOyBsZXQgaSA9IDE7IHdoaWxlIChpIDwgb3BzLmxlbmd0aCkgeyBjb25zdCBvcCA9IG9wc1tpXTsgY29uc3QgZm4gPSBvcHNbaSArIDFdOyBpICs9IDI7IGlmICgob3AgPT09ICdvcHRpb25hbEFjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSAmJiB2YWx1ZSA9PSBudWxsKSB7IHJldHVybiB1bmRlZmluZWQ7IH0gaWYgKG9wID09PSAnYWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJykgeyBsYXN0QWNjZXNzTEhTID0gdmFsdWU7IHZhbHVlID0gZm4odmFsdWUpOyB9IGVsc2UgaWYgKG9wID09PSAnY2FsbCcgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSB7IHZhbHVlID0gZm4oKC4uLmFyZ3MpID0+IHZhbHVlLmNhbGwobGFzdEFjY2Vzc0xIUywgLi4uYXJncykpOyBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyB9IH0gcmV0dXJuIHZhbHVlOyB9aW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5cbmltcG9ydCBCbG9ja0hlYWRlciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9CbG9ja0hlYWRlcidcbmltcG9ydCBMYWJlbCBmcm9tICcuL0xhYmVsJ1xuaW1wb3J0IEhlYWRlckNvbnRhaW5lciBmcm9tICcuL0hlYWRlckNvbnRhaW5lcidcbmltcG9ydCBCb2R5Q29udGFpbmVyIGZyb20gJy4vQm9keUNvbnRhaW5lcidcbmltcG9ydCBDb250ZW50IGZyb20gJy4vQ29udGVudCdcbmltcG9ydCB7UEFMRVRURX0gZnJvbSAndW5pdmVyc2FsL3N0eWxlcy9wYWxldHRlJ1xuaW1wb3J0IElucHV0RmllbGQgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvSW5wdXRGaWVsZCdcbmltcG9ydCB7QkxPQ0tfVFlQRX0gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuZXhwb3J0IGNvbnN0IFN0eWxlZExpbmsgPSBzdHlsZWQuYSh7XG4gIGZvbnRTaXplOiAxNixcbiAgbGluZUhlaWdodDogMS41LFxuICBmb250V2VpZ2h0OiA0MDAsXG4gIGNvbG9yOiBQQUxFVFRFLkxJTkssXG4gIHdoaXRlU3BhY2U6ICdwcmUtd3JhcCcsXG4gIHdvcmRXcmFwOiAnYnJlYWstd29yZCcsXG4gIHdvcmRCcmVhazogJ2JyZWFrLXdvcmQnXG59KVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBFbWFpbChwcm9wcykge1xuICBjb25zdCB7XG4gICAgaXNBdWRpdHMsXG4gICAgYmxvY2ssXG4gICAgb25FZGl0LFxuICAgIG9uRGVsZXRlLFxuICAgIGlzRWRpdGluZyxcbiAgICBpbmRleCxcbiAgICBlcnJvcixcbiAgICBoYW5kbGVCbHVyLFxuICAgIGhhbmRsZUNoYW5nZVxuICB9ID0gcHJvcHNcbiAgY29uc3Qge2VtYWlsLCBuYW1lfSA9IGJsb2NrXG4gIGNvbnN0IHtwbGFjZWhvbGRlciwgcmVhZF9vbmx5OiByZWFkT25seSwgdmFsdWUgPSAnJ30gPSBlbWFpbCB8fCB7fVxuICBjb25zdCByZW5kZXJWYWx1ZSA9IGlzRWRpdGluZyA/IHBsYWNlaG9sZGVyIDogdmFsdWVcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29udGVudCwgeyAuLi5wcm9wcywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUyfX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChIZWFkZXJDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTN9fVxuICAgICAgICAsIG5hbWUgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1NH19LCBuYW1lKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmxvY2tIZWFkZXIsIHtcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgYmxvY2tUeXBlOiBCTE9DS19UWVBFLkVNQUlMLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTV9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQm9keUNvbnRhaW5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2Mn19XG4gICAgICAgICwgIXJlYWRPbmx5ICYmICFpc0F1ZGl0cyA/IChcbiAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KElucHV0RmllbGQsIHtcbiAgICAgICAgICAgIHR5cGU6IFwiZW1haWxcIixcbiAgICAgICAgICAgIG5hbWU6IGBkYXRhLiR7aW5kZXh9LmVtYWlsLnZhbHVlYCxcbiAgICAgICAgICAgIHZhbHVlOiByZW5kZXJWYWx1ZSB8fCBcIlwiLFxuICAgICAgICAgICAgaGlkZUVycm9yTWVzc2FnZTogdHJ1ZSxcbiAgICAgICAgICAgIGVycm9yOiBfb3B0aW9uYWxDaGFpbihbZXJyb3IsICdvcHRpb25hbEFjY2VzcycsIF8gPT4gXy52YWx1ZV0pLFxuICAgICAgICAgICAgYXV0b0ZvY3VzOiBmYWxzZSxcbiAgICAgICAgICAgIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsXG4gICAgICAgICAgICBvbkJsdXI6IGhhbmRsZUJsdXIsXG4gICAgICAgICAgICByZWFkT25seTogcmVhZE9ubHksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2NH19XG4gICAgICAgICAgKVxuICAgICAgICApIDogKFxuICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3R5bGVkTGluaywgeyBocmVmOiBgbWFpbHRvOiR7cmVuZGVyVmFsdWV9YCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDc2fX0sIHJlbmRlclZhbHVlKVxuICAgICAgICApXG4gICAgICApXG4gICAgKVxuICApXG59XG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL0VtYmVkLnRzeFwiO2ltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuXG5pbXBvcnQgQmxvY2tIZWFkZXIgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvQmxvY2tIZWFkZXInXG5pbXBvcnQgSGVhZGVyQ29udGFpbmVyIGZyb20gJy4vSGVhZGVyQ29udGFpbmVyJ1xuaW1wb3J0IExhYmVsIGZyb20gJy4vTGFiZWwnXG5pbXBvcnQgQ29udGVudFdyYXBwZXIgZnJvbSAnLi9Db250ZW50J1xuaW1wb3J0IHtCTE9DS19UWVBFfSBmcm9tICd1bml2ZXJzYWwvdXRpbHMvY29uc3RhbnRzJ1xuaW1wb3J0IEJvZHlDb250YWluZXIgZnJvbSAnLi9Cb2R5Q29udGFpbmVyJ1xuXG5cblxuXG5cblxuXG5cblxuXG5cblxuY29uc3QgSUZyYW1lID0gc3R5bGVkLmlmcmFtZSh7XG4gIHdpZHRoOiAnMTAwJScsXG4gIGhlaWdodDogJzEwMCUnLFxuICBib3JkZXI6IDBcbn0pXG5cbmNvbnN0IEVtYmVkID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtibG9jaywgb25FZGl0LCBvbkRlbGV0ZSwgaXNFZGl0aW5nLCBlcnJvciwgaW5kZXh9ID0gcHJvcHMgfHwge31cbiAgY29uc3Qge2VtYmVkLCBuYW1lfSA9IGJsb2NrXG4gIGNvbnN0IHt2YWx1ZSwgcGxhY2Vob2xkZXJ9ID0gZW1iZWQgfHwge31cblxuICBsZXQgc291cmNlVXJsID0gaXNFZGl0aW5nID8gcGxhY2Vob2xkZXIgOiB2YWx1ZVxuXG4gIGlmIChlcnJvci5kYXRhICYmIGVycm9yLmRhdGFbaW5kZXhdICYmIGVycm9yLmRhdGEubGVuZ3RoKSB7XG4gICAgc291cmNlVXJsID0gJydcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb250ZW50V3JhcHBlciwgeyAuLi5wcm9wcywgb3ZlcmZsb3c6IGBoaWRkZW5gLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDB9fVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEhlYWRlckNvbnRhaW5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0MX19XG4gICAgICAgICwgbmFtZSAmJiBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQyfX0sIG5hbWUpXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChCbG9ja0hlYWRlciwge1xuICAgICAgICAgIG9uRGVsZXRlOiBvbkRlbGV0ZSxcbiAgICAgICAgICBvbkVkaXQ6IG9uRWRpdCxcbiAgICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgICBibG9ja1R5cGU6IEJMT0NLX1RZUEUuRU1CRUQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0M319XG4gICAgICAgIClcbiAgICAgIClcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChCb2R5Q29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUwfX1cbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KElGcmFtZSwgeyBzcmM6IHNvdXJjZVVybCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUxfX0gKVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBFbWJlZFxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9Gb3JtU2VxdWVuY2UudHN4XCI7IGZ1bmN0aW9uIF9vcHRpb25hbENoYWluKG9wcykgeyBsZXQgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgbGV0IHZhbHVlID0gb3BzWzBdOyBsZXQgaSA9IDE7IHdoaWxlIChpIDwgb3BzLmxlbmd0aCkgeyBjb25zdCBvcCA9IG9wc1tpXTsgY29uc3QgZm4gPSBvcHNbaSArIDFdOyBpICs9IDI7IGlmICgob3AgPT09ICdvcHRpb25hbEFjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSAmJiB2YWx1ZSA9PSBudWxsKSB7IHJldHVybiB1bmRlZmluZWQ7IH0gaWYgKG9wID09PSAnYWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJykgeyBsYXN0QWNjZXNzTEhTID0gdmFsdWU7IHZhbHVlID0gZm4odmFsdWUpOyB9IGVsc2UgaWYgKG9wID09PSAnY2FsbCcgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSB7IHZhbHVlID0gZm4oKC4uLmFyZ3MpID0+IHZhbHVlLmNhbGwobGFzdEFjY2Vzc0xIUywgLi4uYXJncykpOyBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyB9IH0gcmV0dXJuIHZhbHVlOyB9aW1wb3J0IFJlYWN0LCB7bWVtbywgdXNlU3RhdGUsIHVzZUVmZmVjdH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcbmltcG9ydCB7RmllbGRBcnJheSx9IGZyb20gJ2Zvcm1paydcbmltcG9ydCBCbG9ja0hlYWRlciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9CbG9ja0hlYWRlcidcblxuaW1wb3J0IEJhc2ljVGV4dEFyZWEgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvQmFzaWNUZXh0QXJlYSdcbmltcG9ydCB7QkxPQ0tfVFlQRX0gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcbmltcG9ydCBQcmltYXJ5QnV0dG9uIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL1ByaW1hcnlCdXR0b24nXG5pbXBvcnQgU2Vjb25kYXJ5QnV0dG9uIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL1NlY29uZGFyeUJ1dHRvbidcbmltcG9ydCBJbnB1dEZpZWxkIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0lucHV0RmllbGQnXG5pbXBvcnQgVGFza1JhZGlvIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL1Rhc2tSYWRpbydcbmltcG9ydCBUYXNrQ2hlY2tib3ggZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvVGFza0NoZWNrYm94J1xuaW1wb3J0IExhYmVsIGZyb20gJy4vTGFiZWwnXG5pbXBvcnQgSGVhZGVyQ29udGFpbmVyIGZyb20gJy4vSGVhZGVyQ29udGFpbmVyJ1xuaW1wb3J0IEJvZHlDb250YWluZXIgZnJvbSAnLi9Cb2R5Q29udGFpbmVyJ1xuaW1wb3J0IENvbnRlbnQgZnJvbSAnLi9Db250ZW50J1xuXG5cblxuXG5cblxuXG5cblxuXG5cblxuY29uc3QgQnV0dG9uQmxvY2sgPSBzdHlsZWQuZGl2KHtcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBmbGV4RGlyZWN0aW9uOiAncm93JyxcbiAganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJyxcbiAgbWFyZ2luQm90dG9tOiAxMCxcbiAgZmxleDogJzAgMCBhdXRvJ1xufSlcblxuY29uc3QgQmxvY2sgPSBzdHlsZWQuZGl2KHtcbiAgcGFkZGluZzogJzVweCAwJ1xufSlcblxuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXYoe1xuICBoZWlnaHQ6ICcxMDAlJyxcbiAgd2lkdGg6ICcxMDAlJyxcbiAgZGlzcGxheTogJ2ZsZXgnLFxuICBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJ1xufSlcblxuY29uc3QgSXRlbSA9IHN0eWxlZC5kaXYoe1xuICBmbGV4OiAxXG59KVxuXG5jb25zdCBhc3NpZ25OZXh0QW5kQmFja1Zpc2liaWxpdHkgPSAoXG4gIGN1cnJlbnRJZHgsXG4gIGN1cnJlbnRUeXBlLFxuICBuZXh0QmxvY2tJZCxcbiAgbmV4dEJsb2NrSW5kZXgsXG4gIHZhbHVlLFxuICBkYXRhXG4pID0+IHtcbiAgbGV0IGlzTmV4dERpc2FibGVkID0gZmFsc2VcbiAgbGV0IGlzQmFja0Rpc2FibGVkID0gZmFsc2VcblxuICBpc0JhY2tEaXNhYmxlZCA9IGN1cnJlbnRJZHggPT09IDBcblxuICBpZiAoY3VycmVudElkeCA9PT0gZGF0YS5sZW5ndGggLSAxKSB7XG4gICAgaWYgKG5leHRCbG9ja0luZGV4ID09PSAtMSkge1xuICAgICAgaXNOZXh0RGlzYWJsZWQgPSB0cnVlXG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGlmIChjdXJyZW50VHlwZSA9PT0gQkxPQ0tfVFlQRS5TSU5HTEVfU0VMRUNUSU9OIHx8IGN1cnJlbnRUeXBlID09PSBCTE9DS19UWVBFLkJJTkFSWSkge1xuICAgICAgaWYgKCF2YWx1ZSkgaXNOZXh0RGlzYWJsZWQgPSB0cnVlXG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICh2YWx1ZSA9PT0gJycgfHwgdmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgaXNOZXh0RGlzYWJsZWQgPSB0cnVlXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpc05leHREaXNhYmxlZCA9IGZhbHNlXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaWYgKCFuZXh0QmxvY2tJZCAhPT0gbnVsbCAmJiBuZXh0QmxvY2tJZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgaXNOZXh0RGlzYWJsZWQgPSBmYWxzZVxuICB9IGVsc2UgaWYgKG5leHRCbG9ja0lkID09PSBudWxsKSB7XG4gICAgaXNOZXh0RGlzYWJsZWQgPSB0cnVlXG4gIH1cblxuICByZXR1cm4ge1xuICAgIGlzTmV4dERpc2FibGVkLFxuICAgIGlzQmFja0Rpc2FibGVkXG4gIH1cbn1cblxuY29uc3QgRm9ybVNlcXVlbmNlID0gbWVtbygocHJvcHMpID0+IHtcbiAgY29uc3QgW2N1cnJlbnRJZHgsIHNldEN1cnJlbnRJZHhdID0gdXNlU3RhdGUoMClcbiAgY29uc3Qge2lzQXVkaXRzLCBibG9jaywgb25EZWxldGUsIGhhbmRsZUNoYW5nZSwgaW5kZXgsIGlzRWRpdGluZywgb25FZGl0LCBzZXRGaWVsZFZhbHVlfSA9IHByb3BzXG4gIGNvbnN0IHtuYW1lLCB0eXBlLCBfaWR9ID0gYmxvY2sgfHwge31cbiAgY29uc3Qge2RhdGEsIGhpc3RvcnkgPSBbXX0gPSBibG9ja1t0eXBlXVxuXG4gIGNvbnN0IGN1cnJlbnRCbG9jayA9IGRhdGFbY3VycmVudElkeF1cblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc0F1ZGl0cykgcmV0dXJuXG4gICAgaWYgKGN1cnJlbnRCbG9jayAmJiBfb3B0aW9uYWxDaGFpbihbaGlzdG9yeSwgJ29wdGlvbmFsQWNjZXNzJywgXyA9PiBfLmxlbmd0aF0pID4gMCkge1xuICAgICAgY29uc3QgbGFzdEJsb2NrSWQgPSBoaXN0b3J5LnBvcCgpXG4gICAgICBjb25zdCBsYXN0QmxvY2tJZHggPSBkYXRhLmZpbmRJbmRleCgoe2lkfSkgPT4gaWQgPT09IGxhc3RCbG9ja0lkKVxuICAgICAgc2V0Q3VycmVudElkeChsYXN0QmxvY2tJZHggKyAxKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgaWYgKCFjdXJyZW50QmxvY2spIHJldHVybiBudWxsXG5cbiAgY29uc3Qge3R5cGU6IGN1cnJlbnRUeXBlLCBuYW1lOiBjdXJyZW50QmxvY2tOYW1lfSA9IGN1cnJlbnRCbG9ja1xuICBjb25zdCB7dmFsdWUgPSAnJ30gPSBjdXJyZW50QmxvY2tbY3VycmVudFR5cGVdXG4gIGNvbnN0IG5leHRCbG9ja0lkID0gX29wdGlvbmFsQ2hhaW4oW2N1cnJlbnRCbG9jaywgJ29wdGlvbmFsQWNjZXNzJywgXzIgPT4gXzIubG9naWNfanVtcF0pID8gY3VycmVudEJsb2NrLmxvZ2ljX2p1bXBbdmFsdWVdIDogdW5kZWZpbmVkXG4gIGNvbnN0IG5leHRCbG9ja0luZGV4ID0gZGF0YS5maW5kSW5kZXgoKGJsb2NrKSA9PiBibG9jay5pZCA9PT0gbmV4dEJsb2NrSWQpXG4gIGNvbnN0IGxvZ2ljQmxvY2tzID0gW0JMT0NLX1RZUEUuQklOQVJZLCBCTE9DS19UWVBFLlNJTkdMRV9TRUxFQ1RJT05dXG5cbiAgY29uc3QgaGFuZGxlTmV4dCA9IChhcnJheUhlbHBlcnMpID0+IHtcbiAgICBpZiAobG9naWNCbG9ja3MuaW5jbHVkZXMoY3VycmVudFR5cGUpKSB7XG4gICAgICBpZiAoIW5leHRCbG9ja0lkKSB7XG4gICAgICAgIGFycmF5SGVscGVycy5wdXNoKGN1cnJlbnRCbG9jay5pZClcbiAgICAgICAgc2V0Q3VycmVudElkeChjdXJyZW50SWR4ICsgMSlcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChuZXh0QmxvY2tJbmRleCAhPT0gLTEpIHtcbiAgICAgICAgICBhcnJheUhlbHBlcnMucHVzaChjdXJyZW50QmxvY2suaWQpXG4gICAgICAgICAgc2V0Q3VycmVudElkeChuZXh0QmxvY2tJbmRleClcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvcjogdW5hYmxlIHRvIGZpbmQgbmV4dCBibG9jayBJRCcpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgLy8gcG9wIGN1cnJlbnQgaW5kZXggaW50byBoaXN0b3J5XG4gICAgICBhcnJheUhlbHBlcnMucHVzaChjdXJyZW50QmxvY2suaWQpXG4gICAgICBzZXRDdXJyZW50SWR4KGN1cnJlbnRJZHggKyAxKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUJhY2sgPSAoKSA9PiB7XG4gICAgaWYgKF9vcHRpb25hbENoYWluKFtoaXN0b3J5LCAnb3B0aW9uYWxBY2Nlc3MnLCBfMyA9PiBfMy5sZW5ndGhdKSA8PSAwKSB7XG4gICAgICBzZXRDdXJyZW50SWR4KDApXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHN0YWNrZWRJZCA9IGhpc3RvcnkucG9wKClcbiAgICAgIGNvbnN0IG5leHRCbG9ja0luZGV4ID0gZGF0YS5maW5kSW5kZXgoKGJsb2NrKSA9PiBibG9jay5pZCA9PT0gc3RhY2tlZElkKVxuICAgICAgaWYgKG5leHRCbG9ja0luZGV4ICE9PSAtMSkge1xuICAgICAgICBzZXRDdXJyZW50SWR4KG5leHRCbG9ja0luZGV4KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0Q3VycmVudElkeCgwKVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHtpc05leHREaXNhYmxlZCwgaXNCYWNrRGlzYWJsZWR9ID0gYXNzaWduTmV4dEFuZEJhY2tWaXNpYmlsaXR5KFxuICAgIGN1cnJlbnRJZHgsXG4gICAgY3VycmVudFR5cGUsXG4gICAgbmV4dEJsb2NrSWQsXG4gICAgbmV4dEJsb2NrSW5kZXgsXG4gICAgdmFsdWUsXG4gICAgZGF0YVxuICApXG5cbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEZpZWxkQXJyYXksIHtcbiAgICAgIG5hbWU6IGBkYXRhLiR7aW5kZXh9LiR7dHlwZX0uaGlzdG9yeWAsXG4gICAgICByZW5kZXI6IChhcnJheUhlbHBlcnMpID0+IChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb250ZW50LCB7IC4uLnByb3BzLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTY1fX1cbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoV3JhcHBlciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNjZ9fVxuICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEhlYWRlckNvbnRhaW5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNjd9fVxuICAgICAgICAgICAgICAsIG5hbWUgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNjh9fSwgbmFtZSlcbiAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJsb2NrSGVhZGVyLCB7XG4gICAgICAgICAgICAgICAgb25EZWxldGU6IG9uRGVsZXRlLFxuICAgICAgICAgICAgICAgIG9uRWRpdDogb25FZGl0LFxuICAgICAgICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgICAgICAgIGJsb2NrVHlwZTogQkxPQ0tfVFlQRS5GT1JNX1NFUVVFTkNFLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTY5fX1cbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJvZHlDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTc2fX1cbiAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbkJsb2NrLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE3N319XG4gICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFByaW1hcnlCdXR0b24sIHtcbiAgICAgICAgICAgICAgICAgIHR5cGU6IFwiYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZDogaXNCYWNrRGlzYWJsZWQsXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiBoYW5kbGVCYWNrKGFycmF5SGVscGVycyksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxNzh9fVxuICAgICAgICAgICAgICAgICwgXCJCYWNrXCJcblxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU2Vjb25kYXJ5QnV0dG9uLCB7XG4gICAgICAgICAgICAgICAgICB0eXBlOiBcImJ1dHRvblwiLFxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGlzTmV4dERpc2FibGVkLFxuICAgICAgICAgICAgICAgICAgb25DbGljazogKCkgPT4gaGFuZGxlTmV4dChhcnJheUhlbHBlcnMpLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTg1fX1cbiAgICAgICAgICAgICAgICAsIFwiTmV4dFwiXG5cbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgLCBjdXJyZW50QmxvY2tOYW1lICYmIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMTkzfX0sIGN1cnJlbnRCbG9ja05hbWUpXG4gICAgICAgICAgICAgICwgY3VycmVudFR5cGUgPT09IEJMT0NLX1RZUEUuVEVYVCAmJiAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChCYXNpY1RleHRBcmVhLCB7XG4gICAgICAgICAgICAgICAgICBuYW1lOiBgZGF0YS4ke2luZGV4fS4ke3R5cGV9LmRhdGEuJHtjdXJyZW50SWR4fS4ke2N1cnJlbnRUeXBlfS52YWx1ZWAsXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgIHZhbHVlOiB2YWx1ZSxcbiAgICAgICAgICAgICAgICAgIHN0eWxlOiB7ZmxleDogMX0sXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZDogaXNBdWRpdHMsXG4gICAgICAgICAgICAgICAgICBrZXk6IF9vcHRpb25hbENoYWluKFtjdXJyZW50QmxvY2ssICdvcHRpb25hbEFjY2VzcycsIF80ID0+IF80LmlkXSksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAxOTV9fVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAsIGN1cnJlbnRUeXBlID09PSBCTE9DS19UWVBFLk5VTUJFUiAmJiAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJdGVtLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIwNn19XG4gICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSW5wdXRGaWVsZCwge1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBgZGF0YS4ke2luZGV4fS4ke3R5cGV9LmRhdGEuJHtjdXJyZW50SWR4fS4ke2N1cnJlbnRUeXBlfS52YWx1ZWAsXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwibnVtYmVyXCIsXG4gICAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1czogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlOiB2YWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGlzQXVkaXRzLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjA3fX1cbiAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgLCBjdXJyZW50VHlwZSA9PT0gQkxPQ0tfVFlQRS5FTUFJTCAmJiAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJdGVtLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIxOH19XG4gICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSW5wdXRGaWVsZCwge1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBgZGF0YS4ke2luZGV4fS4ke3R5cGV9LmRhdGEuJHtjdXJyZW50SWR4fS4ke2N1cnJlbnRUeXBlfS52YWx1ZWAsXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiZW1haWxcIixcbiAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZDogaXNBdWRpdHMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMTl9fVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAsIGN1cnJlbnRUeXBlID09PSBCTE9DS19UWVBFLkxJTksgJiYgKFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSXRlbSwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzB9fVxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KElucHV0RmllbGQsIHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogYGRhdGEuJHtpbmRleH0uJHt0eXBlfS5kYXRhLiR7Y3VycmVudElkeH0uJHtjdXJyZW50VHlwZX0udmFsdWVgLFxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcInRleHRcIixcbiAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZDogaXNBdWRpdHMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMzF9fVxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAsIGN1cnJlbnRUeXBlID09PSBCTE9DS19UWVBFLkJJTkFSWSAmJiAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJdGVtLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI0Mn19XG4gICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmxvY2ssIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjQzfX1cbiAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRhc2tSYWRpbywge1xuICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IGBkYXRhLiR7aW5kZXh9LiR7dHlwZX0uZGF0YS4ke2N1cnJlbnRJZHh9LiR7Y3VycmVudFR5cGV9LnZhbHVlYCxcbiAgICAgICAgICAgICAgICAgICAgICBpZDogYCR7X2lkfS0ke2N1cnJlbnRJZHh9LXRydWVgLFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBcInRydWVcIixcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogXCJZZXNcIixcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZTogKCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZpZWxkVmFsdWUoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGBkYXRhLiR7aW5kZXh9LiR7dHlwZX0uZGF0YS4ke2N1cnJlbnRJZHh9LiR7Y3VycmVudFR5cGV9LnZhbHVlYCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICxcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkOiB2YWx1ZSA9PT0gdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZDogaXNBdWRpdHMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNDR9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmxvY2ssIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjU5fX1cbiAgICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRhc2tSYWRpbywge1xuICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IGBkYXRhLiR7aW5kZXh9LiR7dHlwZX0uZGF0YS4ke2N1cnJlbnRJZHh9LiR7Y3VycmVudFR5cGV9LnZhbHVlYCxcbiAgICAgICAgICAgICAgICAgICAgICBpZDogYCR7X2lkfS0ke2N1cnJlbnRJZHh9LWZhbHNlYCxcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogXCJmYWxzZVwiLFxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBcIk5vXCIsXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U6ICgpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZFZhbHVlKFxuICAgICAgICAgICAgICAgICAgICAgICAgICBgZGF0YS4ke2luZGV4fS4ke3R5cGV9LmRhdGEuJHtjdXJyZW50SWR4fS4ke2N1cnJlbnRUeXBlfS52YWx1ZWAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZhbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgLFxuICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ6IHZhbHVlID09PSBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZDogaXNBdWRpdHMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNjB9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICwgY3VycmVudFR5cGUgPT09IEJMT0NLX1RZUEUuU0lOR0xFX1NFTEVDVElPTiAmJiAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJdGVtLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI3OH19XG4gICAgICAgICAgICAgICAgICAsIGN1cnJlbnRCbG9ja1tjdXJyZW50VHlwZV0ub3B0aW9ucy5tYXAoKG9wdGlvbiwgb3B0aW9uSW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChCbG9jaywgeyBrZXk6IG9wdGlvbkluZGV4LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjgwfX1cbiAgICAgICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGFza1JhZGlvLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBgZGF0YS4ke2luZGV4fS4ke3R5cGV9LmRhdGEuJHtjdXJyZW50SWR4fS4ke2N1cnJlbnRUeXBlfS52YWx1ZWAsXG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogYCR7aW5kZXh9LSR7b3B0aW9uSW5kZXh9YCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBvcHRpb24uaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogb3B0aW9uLm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZDogb3B0aW9uLmlkID09PSB2YWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkOiBpc0F1ZGl0cywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI4MX19XG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAsIGN1cnJlbnRUeXBlID09PSBCTE9DS19UWVBFLk1VTFRJUExFX1NFTEVDVElPTiAmJiAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJdGVtLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI5NX19XG4gICAgICAgICAgICAgICAgICAsIGN1cnJlbnRCbG9ja1tjdXJyZW50VHlwZV0ub3B0aW9ucy5tYXAoKG9wdGlvbiwgb3B0aW9uSW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChCbG9jaywgeyBrZXk6IG9wdGlvbkluZGV4LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjk3fX1cbiAgICAgICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGFza0NoZWNrYm94LCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBgZGF0YS4ke2luZGV4fS4ke3R5cGV9LmRhdGEuJHtjdXJyZW50SWR4fS4ke2N1cnJlbnRUeXBlfS52YWx1ZWAsXG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogYCR7aW5kZXh9LSR7b3B0aW9uSW5kZXh9YCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBvcHRpb24uaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogb3B0aW9uLm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZDogdmFsdWUgJiYgdmFsdWUuaW5jbHVkZXMob3B0aW9uLmlkKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkOiBpc0F1ZGl0cywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI5OH19XG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKVxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgKSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE2Mn19XG4gICAgKVxuICApXG59KVxuXG5leHBvcnQgZGVmYXVsdCBGb3JtU2VxdWVuY2VcbiIsImNvbnN0IF9qc3hGaWxlTmFtZSA9IFwiL1VzZXJzL2EvZ2l0L0h1bWFuLUxhbWJkYXMvaGwtd2ViL3NyYy91bml2ZXJzYWwvY29tcG9uZW50cy9ibG9ja3MvSGVhZGVyQ29udGFpbmVyLnRzeFwiO2ltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IFJlYWN0LCB7fSBmcm9tICdyZWFjdCdcblxuXG5cblxuXG5jb25zdCBIZWFkZXJDb250YWluZXIgPSBzdHlsZWQuZGl2KHtcbiAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgZmxleERpcmVjdGlvbjogJ3JvdycsXG4gIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsXG4gIGZsZXg6ICcwIDAgYXV0bycsXG4gIGhlaWdodDogJ2F1dG8nLFxuICBiYWNrZ3JvdW5kOiAnd2hpdGUnLFxuICB6SW5kZXg6IDExLFxuICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgdXNlclNlbGVjdDogJ25vbmUnXG59KVxuXG5leHBvcnQgZGVmYXVsdCAoe2NoaWxkcmVufSkgPT4gUmVhY3QuY3JlYXRlRWxlbWVudChIZWFkZXJDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjF9fSwgY2hpbGRyZW4pXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL0ltYWdlLnRzeFwiO2ltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5cbmltcG9ydCBCbG9ja0hlYWRlciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9CbG9ja0hlYWRlcidcbmltcG9ydCBDb250ZW50IGZyb20gJy4vQ29udGVudCdcbmltcG9ydCBMYWJlbCBmcm9tICcuL0xhYmVsJ1xuaW1wb3J0IEhlYWRlckNvbnRhaW5lciBmcm9tICcuL0hlYWRlckNvbnRhaW5lcidcbmltcG9ydCB7QkxPQ0tfVFlQRX0gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcbmltcG9ydCBCb2R5Q29udGFpbmVyIGZyb20gJy4vQm9keUNvbnRhaW5lcidcblxuXG5cblxuXG5cblxuXG5cbmNvbnN0IFN0eWxlZEltZyA9IHN0eWxlZC5pbWcoe1xuICBvYmplY3RGaXQ6ICdjb250YWluJyxcbiAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgbWF4SGVpZ2h0OiAnMTAwJScsXG4gIHdpZHRoOiAnYXV0bycsXG4gIGhlaWdodDogJ2F1dG8nXG59KVxuXG5jb25zdCBJbWFnZSA9IFJlYWN0Lm1lbW8oKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtibG9jaywgb25EZWxldGUsIG9uRWRpdCwgaXNFZGl0aW5nfSA9IHByb3BzXG4gIGNvbnN0IHtuYW1lLCB0eXBlLCBpZCwgaW1hZ2V9ID0gYmxvY2tcbiAgY29uc3Qge3ZhbHVlLCBwbGFjZWhvbGRlcn0gPSBpbWFnZSB8fCB7fVxuICBjb25zdCByZW5kZXJWYWx1ZSA9IGlzRWRpdGluZyA/IHZhbHVlIHx8IHBsYWNlaG9sZGVyIDogdmFsdWVcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29udGVudCwgeyAuLi5wcm9wcywgc3R5bGU6IHtkaXNwbGF5OiAnYmxvY2snLCBtYXhXaWR0aDogJzEwMCUnLCBtaW5XaWR0aDogJzEwMCUnfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDM0fX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChIZWFkZXJDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzV9fVxuICAgICAgICAsIG5hbWUgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzNn19LCBuYW1lKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmxvY2tIZWFkZXIsIHtcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgYmxvY2tUeXBlOiBCTE9DS19UWVBFLklNQUdFLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzd9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQm9keUNvbnRhaW5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0NH19XG4gICAgICAgICwgcmVuZGVyVmFsdWUgJiYgKFxuICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3R5bGVkSW1nLCB7XG4gICAgICAgICAgICBzcmM6IHJlbmRlclZhbHVlLFxuICAgICAgICAgICAgYWx0OiBuYW1lIHx8IHR5cGUsXG4gICAgICAgICAgICB0aXRsZTogbmFtZSB8fCB0eXBlLFxuICAgICAgICAgICAgb25EcmFnU3RhcnQ6IChlKSA9PiBlLnByZXZlbnREZWZhdWx0KCksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0Nn19XG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICApXG4gICAgKVxuICApXG59KVxuXG5leHBvcnQgZGVmYXVsdCBJbWFnZVxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5cbmNvbnN0IExhYmVsID0gc3R5bGVkLmRpdih7XG4gIGZvbnRXZWlnaHQ6IDUwMCxcbiAgZm9udFNpemU6IDE1XG59KVxuXG5leHBvcnQgZGVmYXVsdCBMYWJlbFxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9MaW5rLnRzeFwiOyBmdW5jdGlvbiBfb3B0aW9uYWxDaGFpbihvcHMpIHsgbGV0IGxhc3RBY2Nlc3NMSFMgPSB1bmRlZmluZWQ7IGxldCB2YWx1ZSA9IG9wc1swXTsgbGV0IGkgPSAxOyB3aGlsZSAoaSA8IG9wcy5sZW5ndGgpIHsgY29uc3Qgb3AgPSBvcHNbaV07IGNvbnN0IGZuID0gb3BzW2kgKyAxXTsgaSArPSAyOyBpZiAoKG9wID09PSAnb3B0aW9uYWxBY2Nlc3MnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgJiYgdmFsdWUgPT0gbnVsbCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9IGlmIChvcCA9PT0gJ2FjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbEFjY2VzcycpIHsgbGFzdEFjY2Vzc0xIUyA9IHZhbHVlOyB2YWx1ZSA9IGZuKHZhbHVlKTsgfSBlbHNlIGlmIChvcCA9PT0gJ2NhbGwnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgeyB2YWx1ZSA9IGZuKCguLi5hcmdzKSA9PiB2YWx1ZS5jYWxsKGxhc3RBY2Nlc3NMSFMsIC4uLmFyZ3MpKTsgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgfSB9IHJldHVybiB2YWx1ZTsgfWltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuXG5pbXBvcnQgQmxvY2tIZWFkZXIgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvQmxvY2tIZWFkZXInXG5pbXBvcnQgTGFiZWwgZnJvbSAnLi9MYWJlbCdcbmltcG9ydCBIZWFkZXJDb250YWluZXIgZnJvbSAnLi9IZWFkZXJDb250YWluZXInXG5pbXBvcnQgQm9keUNvbnRhaW5lciBmcm9tICcuL0JvZHlDb250YWluZXInXG5pbXBvcnQgQ29udGVudCBmcm9tICcuL0NvbnRlbnQnXG5pbXBvcnQge1BBTEVUVEV9IGZyb20gJ3VuaXZlcnNhbC9zdHlsZXMvcGFsZXR0ZSdcbmltcG9ydCBJbnB1dEZpZWxkIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0lucHV0RmllbGQnXG5pbXBvcnQge0JMT0NLX1RZUEV9IGZyb20gJ3VuaXZlcnNhbC91dGlscy9jb25zdGFudHMnXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cbmV4cG9ydCBjb25zdCBTdHlsZWRMaW5rID0gc3R5bGVkLmEoe1xuICBmb250U2l6ZTogMTYsXG4gIGxpbmVIZWlnaHQ6IDEuNSxcbiAgZm9udFdlaWdodDogNDAwLFxuICBjb2xvcjogUEFMRVRURS5MSU5LLFxuICB3aGl0ZVNwYWNlOiAncHJlLXdyYXAnLFxuICB3b3JkV3JhcDogJ2JyZWFrLXdvcmQnLFxuICB3b3JkQnJlYWs6ICdicmVhay13b3JkJ1xufSlcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGluayhwcm9wcykge1xuICBjb25zdCB7XG4gICAgaXNBdWRpdHMsXG4gICAgYmxvY2ssXG4gICAgb25FZGl0LFxuICAgIG9uRGVsZXRlLFxuICAgIGlzRWRpdGluZyxcbiAgICBpbmRleCxcbiAgICBlcnJvcixcbiAgICBoYW5kbGVCbHVyLFxuICAgIGhhbmRsZUNoYW5nZVxuICB9ID0gcHJvcHNcbiAgY29uc3Qge2xpbmssIG5hbWV9ID0gYmxvY2tcbiAgY29uc3Qge3BsYWNlaG9sZGVyLCByZWFkX29ubHk6IHJlYWRPbmx5LCB2YWx1ZSA9ICcnfSA9IGxpbmsgfHwge31cbiAgY29uc3QgcmVuZGVyVmFsdWUgPSBpc0VkaXRpbmcgPyBwbGFjZWhvbGRlciA6IHZhbHVlXG5cbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KENvbnRlbnQsIHsgLi4ucHJvcHMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1Mn19XG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSGVhZGVyQ29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUzfX1cbiAgICAgICAgLCBuYW1lICYmIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTR9fSwgbmFtZSlcbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJsb2NrSGVhZGVyLCB7XG4gICAgICAgICAgb25EZWxldGU6IG9uRGVsZXRlLFxuICAgICAgICAgIG9uRWRpdDogb25FZGl0LFxuICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgIGJsb2NrVHlwZTogQkxPQ0tfVFlQRS5MSU5LLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTV9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQm9keUNvbnRhaW5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2Mn19XG4gICAgICAgICwgIXJlYWRPbmx5ICYmICFpc0F1ZGl0cyA/IChcbiAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KElucHV0RmllbGQsIHtcbiAgICAgICAgICAgIHR5cGU6IFwidGV4dFwiLFxuICAgICAgICAgICAgbmFtZTogYGRhdGEuJHtpbmRleH0ubGluay52YWx1ZWAsXG4gICAgICAgICAgICB2YWx1ZTogcmVuZGVyVmFsdWUgfHwgXCJcIixcbiAgICAgICAgICAgIGhpZGVFcnJvck1lc3NhZ2U6IHRydWUsXG4gICAgICAgICAgICBlcnJvcjogX29wdGlvbmFsQ2hhaW4oW2Vycm9yLCAnb3B0aW9uYWxBY2Nlc3MnLCBfID0+IF8udmFsdWVdKSxcbiAgICAgICAgICAgIGF1dG9Gb2N1czogZmFsc2UsXG4gICAgICAgICAgICBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgICAgb25CbHVyOiBoYW5kbGVCbHVyLFxuICAgICAgICAgICAgcmVhZE9ubHk6IHJlYWRPbmx5LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNjR9fVxuICAgICAgICAgIClcbiAgICAgICAgKSA6IChcbiAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFN0eWxlZExpbmssIHsgaHJlZjogYCR7cmVuZGVyVmFsdWV9YCwgdGFyZ2V0OiBcIl9ibGFua1wiLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNzZ9fVxuICAgICAgICAgICAgLCByZW5kZXJWYWx1ZVxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9NZWRpYUJsb2NrLnRzeFwiO2ltcG9ydCBSZWFjdCwge3VzZUVmZmVjdH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcblxuaW1wb3J0IHVzZVByZXZpb3VzIGZyb20gJ3VuaXZlcnNhbC9ob29rcy91c2VQcmV2aW91cydcbmltcG9ydCBCbG9ja0hlYWRlciBmcm9tICcuLi9CbG9ja0hlYWRlcidcbmltcG9ydCBIZWFkZXJDb250YWluZXIgZnJvbSAnLi9IZWFkZXJDb250YWluZXInXG5pbXBvcnQgQm9keUNvbnRhaW5lciBmcm9tICcuL0JvZHlDb250YWluZXInXG5pbXBvcnQgTGFiZWwgZnJvbSAnLi9MYWJlbCdcbmltcG9ydCBDb250ZW50IGZyb20gJy4vQ29udGVudCdcbmltcG9ydCBQbHlyIGZyb20gJ3BseXInXG5cbmltcG9ydCAncGx5ci9kaXN0L3BseXIuY3NzJ1xuXG5cblxuXG5cblxuXG5cblxuY29uc3Qgb3B0aW9ucyA9IHtcbiAgY29udHJvbHM6IFsncGxheScsICdwcm9ncmVzcycsICdjdXJyZW50LXRpbWUnLCAnbXV0ZScsICd2b2x1bWUnLCAnc2V0dGluZ3MnLCAnZnVsbHNjcmVlbiddXG59XG5cbmNvbnN0IFZpZGVvUGxheWVyID0gc3R5bGVkLmRpdigoe3Nob3csIGhpZGVPdmVyZmxvd30pID0+ICh7XG4gIGRpc3BsYXk6IHNob3cgPT09IGZhbHNlID8gJ25vbmUnIDogJ2Jsb2NrJyxcbiAgb3ZlcmZsb3c6IGhpZGVPdmVyZmxvdyA/ICdoaWRkZW4nIDogJ3Zpc2libGUnLFxuICB6SW5kZXg6IDFcbn0pKVxuXG5jb25zdCBNZWRpYUJsb2NrID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtibG9jaywgb25EZWxldGUsIG9uRWRpdCwgaXNFZGl0aW5nfSA9IHByb3BzXG4gIGNvbnN0IHtuYW1lLCB0eXBlLCBpZH0gPSBibG9ja1xuICBjb25zdCB7dmFsdWUsIHBsYWNlaG9sZGVyfSA9IGJsb2NrW3R5cGVdIHx8IHt9XG4gIGNvbnN0IHNvdXJjZVVybCA9IGlzRWRpdGluZyA/IHZhbHVlIHx8IHBsYWNlaG9sZGVyIDogdmFsdWVcblxuICBjb25zdCBwcmV2U291cmNlVXJsID0gdXNlUHJldmlvdXMoc291cmNlVXJsKVxuXG4gIGNvbnN0IHNvdXJjZXMgPSB7XG4gICAgdHlwZTogdHlwZSxcbiAgICBzb3VyY2VzOiBbe3NyYzogc291cmNlVXJsfV1cbiAgfVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHByZXZTb3VyY2VVcmwgIT09IHNvdXJjZVVybCkge1xuICAgICAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChgcGx5ci0ke2lkfWApXG4gICAgICAvLyBAdHMtaWdub3JlXG4gICAgICBjb25zdCBwbGF5ZXIgPSBuZXcgUGx5cihlbCwgb3B0aW9ucylcbiAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgIHBsYXllci5zb3VyY2UgPSBzb3VyY2VzXG5cbiAgICAgIHJldHVybiAoKSA9PiBwbGF5ZXIuZGVzdHJveSgpXG4gICAgfVxuICAgIHJldHVyblxuICB9LCBbc291cmNlVXJsXSlcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29udGVudCwgeyAuLi5wcm9wcywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDU5fX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChIZWFkZXJDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNjB9fVxuICAgICAgICAsIG5hbWUgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2MX19LCBuYW1lKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmxvY2tIZWFkZXIsIHsgb25EZWxldGU6IG9uRGVsZXRlLCBvbkVkaXQ6IG9uRWRpdCwgaXNFZGl0aW5nOiBpc0VkaXRpbmcsIGJsb2NrVHlwZTogdHlwZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDYyfX0gKVxuICAgICAgKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJvZHlDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNjR9fVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVmlkZW9QbGF5ZXIsIHsgc2hvdzogc291cmNlVXJsICE9PSAnJyAmJiBzb3VyY2VVcmwgIT09IHVuZGVmaW5lZCwgaGlkZU92ZXJmbG93OiB0eXBlID09PSAndmlkZW8nLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNjV9fVxuICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudCgndmlkZW8nLCB7IGlkOiBgcGx5ci0ke2lkfWAsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2Nn19IClcbiAgICAgICAgKVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBNZWRpYUJsb2NrXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL011bHRpcGxlU2VsZWN0aW9uLnRzeFwiO2ltcG9ydCBSZWFjdCwge21lbW8sIHVzZVN0YXRlfSBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZWQgZnJvbSAnQGVtb3Rpb24vc3R5bGVkJ1xuaW1wb3J0IFRhc2tDaGVja2JveCBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9UYXNrQ2hlY2tib3gnXG5pbXBvcnQgQmxvY2tIZWFkZXIgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvQmxvY2tIZWFkZXInXG5cbmltcG9ydCBIZWFkZXJDb250YWluZXIgZnJvbSAnLi9IZWFkZXJDb250YWluZXInXG5pbXBvcnQgQm9keUNvbnRhaW5lciBmcm9tICcuL0JvZHlDb250YWluZXInXG5pbXBvcnQgTGFiZWwgZnJvbSAnLi9MYWJlbCdcbmltcG9ydCBDb250ZW50IGZyb20gJy4vQ29udGVudCdcbmltcG9ydCB7QkxPQ0tfVFlQRX0gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcbmltcG9ydCBMaXN0RmlsdGVyIGZyb20gJ2NsaWVudC9jb21wb25lbnRzL0xpc3RGaWx0ZXInXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cbmNvbnN0IENoZWNrYm94ID0gc3R5bGVkLmRpdih7XG4gIG1hcmdpbkJvdHRvbTogMTBcbn0pXG5cbmNvbnN0IE11bHRpQ2xhc3MgPSBtZW1vKChwcm9wcykgPT4ge1xuICBjb25zdCB7aXNBdWRpdHMsIGJsb2NrLCBvbkRlbGV0ZSwgaGFuZGxlQ2hhbmdlLCBpbmRleCwgaXNFZGl0aW5nLCBvbkVkaXR9ID0gcHJvcHNcbiAgY29uc3Qge25hbWUsIHR5cGV9ID0gYmxvY2tcbiAgY29uc3Qge3ZhbHVlfSA9IGJsb2NrWydtdWx0aXBsZV9zZWxlY3Rpb24nXSB8fCB7fVxuICBjb25zdCBpc1Rhc2sgPSAhaXNFZGl0aW5nICYmICFpc0F1ZGl0c1xuICBjb25zdCBbbGlzdCwgc2V0TGlzdF0gPSB1c2VTdGF0ZShibG9ja1t0eXBlXS5vcHRpb25zKVxuICBjb25zdCBvcHRpb25zID0gaXNFZGl0aW5nID8gYmxvY2tbdHlwZV0ub3B0aW9ucyA6IGxpc3RcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29udGVudCwgeyAuLi5wcm9wcywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDM4fX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChIZWFkZXJDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzl9fVxuICAgICAgICAsIG5hbWUgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0MH19LCBuYW1lKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmxvY2tIZWFkZXIsIHtcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgYmxvY2tUeXBlOiBCTE9DS19UWVBFLk1VTFRJUExFX1NFTEVDVElPTiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQxfX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgLCBpc1Rhc2sgJiYgQXJyYXkuaXNBcnJheShibG9ja1t0eXBlXS5vcHRpb25zKSAmJiBibG9ja1t0eXBlXS5vcHRpb25zLmxlbmd0aCA+IDEwICYmIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGlzdEZpbHRlciwgeyBsaXN0OiBibG9ja1t0eXBlXS5vcHRpb25zLCBzZXRMaXN0OiBzZXRMaXN0LCBrZXlzOiBbJ25hbWUnXSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ4fX0gKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJvZHlDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDl9fVxuICAgICAgICAsIG9wdGlvbnMubWFwKChvcHRpb24sIG9wdGlvbkluZGV4KSA9PiAoXG4gICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChDaGVja2JveCwgeyBrZXk6IG9wdGlvbkluZGV4LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTF9fVxuICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRhc2tDaGVja2JveCwge1xuICAgICAgICAgICAgICBuYW1lOiBgZGF0YS4ke2luZGV4fS5tdWx0aXBsZV9zZWxlY3Rpb24udmFsdWVgLFxuICAgICAgICAgICAgICBpZDogYCR7aW5kZXh9LSR7b3B0aW9uSW5kZXh9YCxcbiAgICAgICAgICAgICAgdmFsdWU6IG9wdGlvbi5pZCxcbiAgICAgICAgICAgICAgbGFiZWw6IG9wdGlvbi5uYW1lLFxuICAgICAgICAgICAgICBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgICAgICBjaGVja2VkOiB2YWx1ZSAmJiB2YWx1ZS5pbmNsdWRlcyhvcHRpb24uaWQpLFxuICAgICAgICAgICAgICBkaXNhYmxlZDogaXNBdWRpdHMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1Mn19XG4gICAgICAgICAgICApXG4gICAgICAgICAgKVxuICAgICAgICApKVxuICAgICAgKVxuICAgIClcbiAgKVxufSlcblxuZXhwb3J0IGRlZmF1bHQgTXVsdGlDbGFzc1xuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9OYW1lZEVudGl0eVJlY29nbml0aW9uLnRzeFwiOyBmdW5jdGlvbiBfb3B0aW9uYWxDaGFpbihvcHMpIHsgbGV0IGxhc3RBY2Nlc3NMSFMgPSB1bmRlZmluZWQ7IGxldCB2YWx1ZSA9IG9wc1swXTsgbGV0IGkgPSAxOyB3aGlsZSAoaSA8IG9wcy5sZW5ndGgpIHsgY29uc3Qgb3AgPSBvcHNbaV07IGNvbnN0IGZuID0gb3BzW2kgKyAxXTsgaSArPSAyOyBpZiAoKG9wID09PSAnb3B0aW9uYWxBY2Nlc3MnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgJiYgdmFsdWUgPT0gbnVsbCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9IGlmIChvcCA9PT0gJ2FjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbEFjY2VzcycpIHsgbGFzdEFjY2Vzc0xIUyA9IHZhbHVlOyB2YWx1ZSA9IGZuKHZhbHVlKTsgfSBlbHNlIGlmIChvcCA9PT0gJ2NhbGwnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgeyB2YWx1ZSA9IGZuKCguLi5hcmdzKSA9PiB2YWx1ZS5jYWxsKGxhc3RBY2Nlc3NMSFMsIC4uLmFyZ3MpKTsgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgfSB9IHJldHVybiB2YWx1ZTsgfWltcG9ydCBSZWFjdCwge21lbW8sIHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlQ2FsbGJhY2t9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5pbXBvcnQgQmxvY2tIZWFkZXIgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvQmxvY2tIZWFkZXInXG5pbXBvcnQgVGV4dEFyZWEgZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvVGV4dEFyZWEnXG5cbmltcG9ydCBDb250ZW50IGZyb20gJy4vQ29udGVudCdcbmltcG9ydCBIZWFkZXJDb250YWluZXIgZnJvbSAnLi9IZWFkZXJDb250YWluZXInXG5pbXBvcnQgQm9keUNvbnRhaW5lciBmcm9tICcuL0JvZHlDb250YWluZXInXG5pbXBvcnQgTGFiZWwgZnJvbSAnLi9MYWJlbCdcbmltcG9ydCBQcmltYXJ5QnV0dG9uIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL1ByaW1hcnlCdXR0b24nXG5pbXBvcnQgU2Vjb25kYXJ5QnV0dG9uIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL1NlY29uZGFyeUJ1dHRvbidcbmltcG9ydCBUYWdnYWJsZUxpc3RXcmFwcGVyIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL1RhZ2dhYmxlTGlzdFdyYXBwZXInXG5pbXBvcnQge0JMT0NLX1RZUEV9IGZyb20gJ3VuaXZlcnNhbC91dGlscy9jb25zdGFudHMnXG5pbXBvcnQgVGV4dEFubm90YXRvciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy90ZXh0LWFubm90YXRvci9UZXh0QW5ub3RhdG9yJ1xuaW1wb3J0IHtjb2xvckJ5SW5kZXh9IGZyb20gJ3VuaXZlcnNhbC91dGlscy9nZXRDb2xvcidcblxuXG5cblxuXG5cblxuXG5cblxuXG5cbmNvbnN0IEJ1dHRvbkJsb2NrID0gc3R5bGVkLmRpdih7XG4gIGRpc3BsYXk6ICdncmlkJyxcbiAgbWFyZ2luQm90dG9tOiAxMCxcbiAgbWFyZ2luVG9wOiAxMCxcbiAgZ3JpZFRlbXBsYXRlQ29sdW1uczogJzgwcHggODBweCcsXG4gIGdyaWRHYXA6IDEwXG59KVxuXG5jb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdigoe2VkaXRNb2RlfSkgPT4gKHtcbiAgLi4uKGVkaXRNb2RlICYmIHtcbiAgICBkaXNwbGF5OiAnZ3JpZCcsXG4gICAgZ3JpZFRlbXBsYXRlUm93czogJ2F1dG8gNTBweCdcbiAgfSlcbn0pKVxuXG5jb25zdCBUZXh0V3JhcHBlciA9IHN0eWxlZC5kaXYoXG4gICh7aGlnaGxpZ2h0Q29sb3J9KSA9PiBgXG4gICAgY3Vyc29yOiBhdXRvO1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyNXB4O1xuICAgIG1hcmdpbi1sZWZ0OiAtMTBweDtcbiAgICB3aGl0ZS1zcGFjZTogcHJlLXdyYXA7XG4gICAgJiBtYXJrIHtcbiAgICAgIHBhZGRpbmc6IDRweCAhaW1wb3J0YW50O1xuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgJjpob3ZlcjphZnRlciB7XG4gICAgICAgIGZvbnQtc2l6ZTogOHB4O1xuICAgICAgICBjb2xvcjogIzAwMDtcbiAgICAgICAgd2hpdGUtc3BhY2U6bm93cmFwO1xuICAgICAgICB0b3A6IDA7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxMXB4O1xuICAgICAgICBsZWZ0OiAwO1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIGNvbnRlbnQ6ICd4JztcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgIHotaW5kZXg6IDExO1xuICAgICAgICB3aWR0aDogMTFweDtcbiAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgb3BhY2l0eTogMC41O1xuICAgICAgfVxuICAgIH1cbiAgICAmIG1hcmsgPiBzcGFuIHtcbiAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgfVxuXG4gICAgJiBzcGFuIHtcblxuICAgICAgJjo6c2VsZWN0aW9uIHtcbiAgICAgICAgYmFja2dyb3VuZDogJHtoaWdobGlnaHRDb2xvcn07XG4gICAgICB9XG4gICAgfVxuYFxuKVxuXG5jb25zdCBOYW1lZEVudGl0eVJlY29nbml0aW9uID0gbWVtbygocHJvcHMpID0+IHtcbiAgY29uc3Qge2Jsb2NrLCBvbkRlbGV0ZSwgaXNFZGl0aW5nLCBvbkVkaXQsIHNldEZpZWxkVmFsdWUsIGluZGV4LCBpc0F1ZGl0c30gPSBwcm9wc1xuICBjb25zdCB7bmFtZX0gPSBibG9ja1xuXG4gIGNvbnN0IHthbGxvd19lZGl0czogYWxsb3dFZGl0cywgcGxhY2Vob2xkZXIsIG9wdGlvbnMsIHZhbHVlID0gJycsIGVudGl0aWVzID0gW119ID1cbiAgICBibG9ja1tCTE9DS19UWVBFLk5BTUVEX0VOVElUWV9SRUNPR05JVElPTl0gfHwge31cblxuICBjb25zdCBbdGV4dCwgc2V0VGV4dF0gPSB1c2VTdGF0ZShlbnRpdGllcylcbiAgY29uc3QgW3VzZXJTZWxlY3QsIHNldFVzZXJTZWxlY3RdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtkaXNhYmxlU2VsZWN0aW9uLCBzZXREaXNhYmxlU2VsZWN0aW9uXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtlZGl0TW9kZSwgdG9nZ2xFZGl0TW9kZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBbc2VsZWN0ZWRDYXRlZ29yeSwgc2V0U2VsZWN0ZWRDYXRlZ29yeV0gPSB1c2VTdGF0ZSh7XG4gICAgdGFnOiBvcHRpb25zWzBdLmlkLFxuICAgIGNvbG9yOiBjb2xvckJ5SW5kZXgoMClcbiAgfSlcblxuICBjb25zdCByZW5kZXJUZXh0ID0gaXNFZGl0aW5nIHx8IHZhbHVlID09PSAnJyA/IHBsYWNlaG9sZGVyIHx8ICcnIDogdmFsdWVcbiAgbGV0IHRleHRGaWVsZE5hbWUgPSBgZGF0YS4ke2luZGV4fS4ke0JMT0NLX1RZUEUuTkFNRURfRU5USVRZX1JFQ09HTklUSU9OfS52YWx1ZWBcbiAgaWYgKGlzRWRpdGluZyB8fCB2YWx1ZSA9PT0gJycpIHtcbiAgICB0ZXh0RmllbGROYW1lID0gYGRhdGEuJHtpbmRleH0uJHtCTE9DS19UWVBFLk5BTUVEX0VOVElUWV9SRUNPR05JVElPTn0ucGxhY2Vob2xkZXJgXG4gIH1cblxuICBjb25zdCBbdGV4dEZpZWxkVmFsdWUsIHNldFRleHRGaWVsZFZhbHVlXSA9IHVzZVN0YXRlKHJlbmRlclRleHQpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAvLyByZXNldCB0YWdzIHdoZW4gcGxhY2Vob2xkZXIgYW5kIG9wdGlvbnMgY2hhbmdlZFxuICAgIGlmIChpc0VkaXRpbmcpIHtcbiAgICAgIHNldFRleHQoW10pXG4gICAgICBzZXRGaWVsZFZhbHVlKGBkYXRhWyR7aW5kZXh9XVske0JMT0NLX1RZUEUuTkFNRURfRU5USVRZX1JFQ09HTklUSU9OfV0uZW50aXRpZXNgLCBbXSlcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0VGV4dChlbnRpdGllcylcbiAgICAgIHNldEZpZWxkVmFsdWUoYGRhdGFbJHtpbmRleH1dWyR7QkxPQ0tfVFlQRS5OQU1FRF9FTlRJVFlfUkVDT0dOSVRJT059XS5lbnRpdGllc2AsIGVudGl0aWVzKVxuICAgIH1cbiAgfSwgW3BsYWNlaG9sZGVyLCBvcHRpb25zXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldEZpZWxkVmFsdWUoXG4gICAgICBgZGF0YVske2luZGV4fV1bJHtCTE9DS19UWVBFLk5BTUVEX0VOVElUWV9SRUNPR05JVElPTn1dLmVudGl0aWVzYCxcbiAgICAgIGlzRWRpdGluZyA/IFtdIDogdGV4dFxuICAgIClcbiAgfSwgW3RleHRdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRDYXRlZ29yeSh7XG4gICAgICB0YWc6IG9wdGlvbnNbMF0uaWQsXG4gICAgICBjb2xvcjogY29sb3JCeUluZGV4KDApXG4gICAgfSlcbiAgfSwgW29wdGlvbnNdKVxuXG4gIGNvbnN0IGhhbmRsZVRleHRDaGFuZ2UgPSB1c2VDYWxsYmFjayhcbiAgICAoZSkgPT4ge1xuICAgICAgY29uc3Qge3ZhbHVlfSA9IGUudGFyZ2V0XG4gICAgICBzZXRUZXh0RmllbGRWYWx1ZSh2YWx1ZSlcbiAgICB9LFxuICAgIFt0ZXh0RmllbGRWYWx1ZV1cbiAgKVxuXG4gIGNvbnN0IGZvcm1hdEVudGl0aWVzRm9yVUlSZW5kZXJpbmcgPSAoZW50aXRpZXMpID0+IHtcbiAgICBjb25zdCBlbnRpdGllc0luc3RhbmNlID0gZW50aXRpZXNcbiAgICByZXR1cm4gZW50aXRpZXNJbnN0YW5jZS5maWx0ZXIoKGl0bSkgPT4ge1xuICAgICAgY29uc3QgW29wdGlvbk5hbWUsIGluZGV4XSA9IGZpbmRPcHRpb25OYW1lRnJvbUlkKGl0bS50YWcpXG4gICAgICBpZiAoIW9wdGlvbk5hbWUpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG4gICAgICBpdG0uY29sb3IgPSBjb2xvckJ5SW5kZXgoaW5kZXgpXG4gICAgICByZXR1cm4gaXRtXG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IGZpbmRPcHRpb25OYW1lRnJvbUlkID0gKGlkKSA9PiB7XG4gICAgbGV0IG5hbWVcbiAgICBsZXQgaW5kZXhcbiAgICBvcHRpb25zLm1hcCgob3B0aW9uLCBpKSA9PiB7XG4gICAgICBpZiAob3B0aW9uLmlkID09PSBpZCkge1xuICAgICAgICBuYW1lID0gb3B0aW9uLm5hbWVcbiAgICAgICAgaW5kZXggPSBpXG4gICAgICB9XG4gICAgfSlcblxuICAgIHJldHVybiBbbmFtZSwgaW5kZXhdXG4gIH1cblxuICBjb25zdCBoYW5kbGVBbm5vdGF0ZSA9ICh0ZXh0KSA9PiB7XG4gICAgaWYgKHVzZXJTZWxlY3QpIHtcbiAgICAgIHNldFVzZXJTZWxlY3QoZmFsc2UpXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG5cbiAgICBpZiAoIWlzQXVkaXRzKSB7XG4gICAgICBzZXRUZXh0KHRleHQpXG4gICAgICBzZXRGaWVsZFZhbHVlKFxuICAgICAgICBgZGF0YVske2luZGV4fV1bJHtCTE9DS19UWVBFLk5BTUVEX0VOVElUWV9SRUNPR05JVElPTn1dLmVudGl0aWVzYCxcbiAgICAgICAgaXNFZGl0aW5nID8gW10gOiB0ZXh0XG4gICAgICApXG4gICAgICBzZXRGaWVsZFZhbHVlKGBkYXRhWyR7aW5kZXh9XVske0JMT0NLX1RZUEUuTkFNRURfRU5USVRZX1JFQ09HTklUSU9OfV0udmFsdWVgLCByZW5kZXJUZXh0KVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGJveFJlZiA9IHVzZVJlZigpXG4gIGNvbnN0IGlucHV0UmVmID0gUmVhY3QuY3JlYXRlUmVmKClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChib3hSZWYgIT09IHVuZGVmaW5lZCAmJiBib3hSZWYuY3VycmVudCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBib3hSZWYuY3VycmVudC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZXVwJywgKGUpID0+IHtcbiAgICAgICAgaWYgKGUuZGV0YWlsID49IDMpIHtcbiAgICAgICAgICBzZXRVc2VyU2VsZWN0KHRydWUpXG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuICB9LCBbYm94UmVmXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChfb3B0aW9uYWxDaGFpbihbaW5wdXRSZWYsICdvcHRpb25hbEFjY2VzcycsIF8gPT4gXy5jdXJyZW50XSkpIHtcbiAgICAgIF9vcHRpb25hbENoYWluKFtpbnB1dFJlZiwgJ29wdGlvbmFsQWNjZXNzJywgXzIgPT4gXzIuY3VycmVudCwgJ29wdGlvbmFsQWNjZXNzJywgXzMgPT4gXzMuc3R5bGUsICdhY2Nlc3MnLCBfNCA9PiBfNC5zZXRQcm9wZXJ0eSwgJ2NhbGwnLCBfNSA9PiBfNSgnaGVpZ2h0JywgJzEwMCUnLCAnaW1wb3J0YW50JyldKVxuICAgIH1cbiAgfSwgW2lucHV0UmVmXSlcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29udGVudCwgeyAuLi5wcm9wcywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIwNn19XG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSGVhZGVyQ29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIwN319XG4gICAgICAgICwgbmFtZSAmJiBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIwOH19LCBuYW1lKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmxvY2tIZWFkZXIsIHtcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgYmxvY2tUeXBlOiBCTE9DS19UWVBFLk5BTUVEX0VOVElUWV9SRUNPR05JVElPTiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIwOX19XG4gICAgICAgIClcbiAgICAgIClcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChCb2R5Q29udGFpbmVyLCB7XG4gICAgICAgIHJvdzogdHJ1ZSxcbiAgICAgICAgc3R5bGU6IHtkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICdhdXRvIDE5NXB4JywgZ3JpZEdhcDogMjB9LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjE2fX1cbiAgICAgIFxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoV3JhcHBlciwgeyBlZGl0TW9kZTogZWRpdE1vZGUsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyMjB9fVxuICAgICAgICAgICwgZWRpdE1vZGUgPyAoXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFRleHRBcmVhLCB7XG4gICAgICAgICAgICAgIHJlZjogaW5wdXRSZWYsXG4gICAgICAgICAgICAgIHN0eWxlOiB7aGVpZ2h0OiAnOTAlICFpbXBvcnRhbnQnfSxcbiAgICAgICAgICAgICAgcG9zaXRpb25FcnJvckJlbG93OiBmYWxzZSxcbiAgICAgICAgICAgICAgdmFsdWU6IHRleHRGaWVsZFZhbHVlLFxuICAgICAgICAgICAgICBvbkNoYW5nZTogaGFuZGxlVGV4dENoYW5nZSxcbiAgICAgICAgICAgICAgc2Nyb2xsYWJsZTogdHJ1ZSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDIyMn19XG4gICAgICAgICAgICApXG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGV4dFdyYXBwZXIsIHtcbiAgICAgICAgICAgICAgb25Nb3VzZURvd246IChlKSA9PiB7XG4gICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBvbk1vdXNlRW50ZXI6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBzZXREaXNhYmxlU2VsZWN0aW9uKGZhbHNlKVxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBvbk1vdXNlTGVhdmU6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBzZXREaXNhYmxlU2VsZWN0aW9uKHRydWUpXG4gICAgICAgICAgICAgICAgd2luZG93LmdldFNlbGVjdGlvbigpLmVtcHR5KClcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt1c2VyU2VsZWN0OiBkaXNhYmxlU2VsZWN0aW9uID8gJ25vbmUnIDogJ2F1dG8nfSxcbiAgICAgICAgICAgICAgaGlnaGxpZ2h0Q29sb3I6IHNlbGVjdGVkQ2F0ZWdvcnkuY29sb3IsXG4gICAgICAgICAgICAgIHJlZjogYm94UmVmLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjMxfX1cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGV4dEFubm90YXRvciwge1xuICAgICAgICAgICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgICAgICAgICBwYWRkaW5nTGVmdDogJzEwcHgnXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBjb250ZW50OiByZW5kZXJUZXh0LFxuICAgICAgICAgICAgICAgIHZhbHVlOiBmb3JtYXRFbnRpdGllc0ZvclVJUmVuZGVyaW5nKHRleHQpLFxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlOiBoYW5kbGVBbm5vdGF0ZSxcbiAgICAgICAgICAgICAgICBnZXRTcGFuOiAoc3BhbikgPT4gKHtcbiAgICAgICAgICAgICAgICAgIC4uLnNwYW4sXG4gICAgICAgICAgICAgICAgICAuLi5zZWxlY3RlZENhdGVnb3J5XG4gICAgICAgICAgICAgICAgfSksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNDZ9fVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApXG4gICAgICAgICAgKVxuICAgICAgICAgICwgYWxsb3dFZGl0cyAmJiAoXG4gICAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEJ1dHRvbkJsb2NrLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI2MX19XG4gICAgICAgICAgICAgICwgZWRpdE1vZGUgPyAoXG4gICAgICAgICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwgbnVsbFxuICAgICAgICAgICAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFNlY29uZGFyeUJ1dHRvbiwge1xuICAgICAgICAgICAgICAgICAgICBzdHlsZToge3dpZHRoOiAnMTAwJScsIG1hcmdpblJpZ2h0OiAxMH0sXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgb25DbGljazogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIHRvZ2dsRWRpdE1vZGUoZmFsc2UpXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VGV4dEZpZWxkVmFsdWUocmVuZGVyVGV4dClcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgaGlkZUZvY3VzOiB0cnVlLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjY0fX1cbiAgICAgICAgICAgICAgICAgICwgXCJDYW5jZWxcIlxuXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUHJpbWFyeUJ1dHRvbiwge1xuICAgICAgICAgICAgICAgICAgICBzdHlsZToge3dpZHRoOiAnMTAwJSd9LFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcImJ1dHRvblwiLFxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzRWRpdGluZykge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGV4dChbXSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZpZWxkVmFsdWUoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGBkYXRhWyR7aW5kZXh9XVske0JMT0NLX1RZUEUuTkFNRURfRU5USVRZX1JFQ09HTklUSU9OfV0uZW50aXRpZXNgLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBbXVxuICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZFZhbHVlKHRleHRGaWVsZE5hbWUsIHRleHRGaWVsZFZhbHVlKVxuICAgICAgICAgICAgICAgICAgICAgIHRvZ2dsRWRpdE1vZGUoZmFsc2UpXG4gICAgICAgICAgICAgICAgICAgIH0sIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyNzZ9fVxuICAgICAgICAgICAgICAgICAgLCBcIlNhdmVcIlxuXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU2Vjb25kYXJ5QnV0dG9uLCB7XG4gICAgICAgICAgICAgICAgICBzdHlsZToge3dpZHRoOiAnMTAwJSd9LFxuICAgICAgICAgICAgICAgICAgdHlwZTogXCJidXR0b25cIixcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IHRvZ2dsRWRpdE1vZGUodHJ1ZSksXG4gICAgICAgICAgICAgICAgICBoaWRlRm9jdXM6IHRydWUsXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZDogaXNBdWRpdHMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyOTZ9fVxuICAgICAgICAgICAgICAgICwgXCJFZGl0IFRleHRcIlxuXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApXG4gICAgICAgICAgKVxuICAgICAgICApXG5cbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KFRhZ2dhYmxlTGlzdFdyYXBwZXIsIHtcbiAgICAgICAgICBvcHRpb25zOiBvcHRpb25zLFxuICAgICAgICAgIG9uU2VsZWN0OiAoY2F0ZWdvcnkpID0+IHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkQ2F0ZWdvcnkoY2F0ZWdvcnkpXG4gICAgICAgICAgfSxcbiAgICAgICAgICBzZWxlY3RlZENhdGVnb3J5OiBzZWxlY3RlZENhdGVnb3J5LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzEwfX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgIClcbiAgKVxufSlcblxuZXhwb3J0IGRlZmF1bHQgTmFtZWRFbnRpdHlSZWNvZ25pdGlvblxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9OdW1iZXIudHN4XCI7aW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnXG5cbmltcG9ydCBJbnB1dEZpZWxkIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0lucHV0RmllbGQnXG5pbXBvcnQgQmxvY2tIZWFkZXIgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvQmxvY2tIZWFkZXInXG5pbXBvcnQgSGVhZGVyQ29udGFpbmVyIGZyb20gJy4vSGVhZGVyQ29udGFpbmVyJ1xuaW1wb3J0IEJvZHlDb250YWluZXIgZnJvbSAnLi9Cb2R5Q29udGFpbmVyJ1xuaW1wb3J0IExhYmVsIGZyb20gJy4vTGFiZWwnXG5pbXBvcnQgQ29udGVudCBmcm9tICcuL0NvbnRlbnQnXG5pbXBvcnQge0JMT0NLX1RZUEV9IGZyb20gJ3VuaXZlcnNhbC91dGlscy9jb25zdGFudHMnXG5cblxuXG5cblxuXG5cblxuXG5cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTnVtYmVyQmxvY2socHJvcHMpIHtcbiAgY29uc3Qge2Jsb2NrLCBvbkRlbGV0ZSwgaGFuZGxlQ2hhbmdlLCBpbmRleCwgaXNBdWRpdHMsIGlzRWRpdGluZywgb25FZGl0fSA9IHByb3BzXG4gIGNvbnN0IHtudW1iZXIsIG5hbWV9ID0gYmxvY2tcbiAgY29uc3Qge3BsYWNlaG9sZGVyLCByZWFkX29ubHk6IHJlYWRPbmx5LCB2YWx1ZSA9ICcnfSA9IG51bWJlciB8fCB7fVxuICBjb25zdCByZW5kZXJWYWx1ZSA9IGlzRWRpdGluZyA/IHZhbHVlIHx8IHBsYWNlaG9sZGVyIDogdmFsdWVcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29udGVudCwgeyAuLi5wcm9wcywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI4fX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChIZWFkZXJDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjl9fVxuICAgICAgICAsIG5hbWUgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzMH19LCBuYW1lKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmxvY2tIZWFkZXIsIHtcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgYmxvY2tUeXBlOiBCTE9DS19UWVBFLk5VTUJFUiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDMxfX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJvZHlDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzh9fVxuICAgICAgICAsIHJlYWRPbmx5IHx8IGlzQXVkaXRzID8gKFxuICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ2RpdicsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDB9fSwgcmVuZGVyVmFsdWUpXG4gICAgICAgICkgOiAoXG4gICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChJbnB1dEZpZWxkLCB7XG4gICAgICAgICAgICBuYW1lOiBgZGF0YS4ke2luZGV4fS5udW1iZXIudmFsdWVgLFxuICAgICAgICAgICAgb25DaGFuZ2U6IGhhbmRsZUNoYW5nZSxcbiAgICAgICAgICAgIHR5cGU6IFwibnVtYmVyXCIsXG4gICAgICAgICAgICBhdXRvRm9jdXM6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWU6IHJlbmRlclZhbHVlIHx8IFwiXCIsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0Mn19XG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICApXG4gICAgKVxuICApXG59XG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL1BkZlJlYWRlci50c3hcIjtpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgc3R5bGVkIGZyb20gJ0BlbW90aW9uL3N0eWxlZCdcblxuaW1wb3J0IEJsb2NrSGVhZGVyIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0Jsb2NrSGVhZGVyJ1xuaW1wb3J0IEhlYWRlckNvbnRhaW5lciBmcm9tICcuL0hlYWRlckNvbnRhaW5lcidcbmltcG9ydCBMYWJlbCBmcm9tICcuL0xhYmVsJ1xuaW1wb3J0IENvbnRlbnRXcmFwcGVyIGZyb20gJy4vQ29udGVudCdcbmltcG9ydCB7QkxPQ0tfVFlQRX0gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcbmltcG9ydCBCb2R5Q29udGFpbmVyIGZyb20gJy4vQm9keUNvbnRhaW5lcidcblxuXG5cblxuXG5cblxuXG5cblxuXG5cbmNvbnN0IElGcmFtZSA9IHN0eWxlZC5pZnJhbWUoe1xuICB3aWR0aDogJzEwMCUnLFxuICBoZWlnaHQ6ICcxMDAlJyxcbiAgYm9yZGVyOiAwXG59KVxuXG5jb25zdCBQZGZSZWFkZXIgPSAocHJvcHMpID0+IHtcbiAgY29uc3Qge2Jsb2NrLCBvbkVkaXQsIG9uRGVsZXRlLCBpc0VkaXRpbmcsIGVycm9yLCBpbmRleH0gPSBwcm9wcyB8fCB7fVxuICBjb25zdCB7cGRmLCBuYW1lfSA9IGJsb2NrXG4gIGNvbnN0IHt2YWx1ZSwgcGxhY2Vob2xkZXJ9ID0gcGRmIHx8IHt9XG5cbiAgbGV0IHNvdXJjZVVybCA9IGlzRWRpdGluZyA/IHBsYWNlaG9sZGVyIDogdmFsdWVcblxuICBpZiAoZXJyb3IuZGF0YSAmJiBlcnJvci5kYXRhW2luZGV4XSAmJiBlcnJvci5kYXRhLmxlbmd0aCkge1xuICAgIHNvdXJjZVVybCA9ICcnXG4gIH1cblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29udGVudFdyYXBwZXIsIHsgLi4ucHJvcHMsIG92ZXJmbG93OiBgaGlkZGVuYCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQwfX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChIZWFkZXJDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDF9fVxuICAgICAgICAsIG5hbWUgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0Mn19LCBuYW1lKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmxvY2tIZWFkZXIsIHtcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgYmxvY2tUeXBlOiBCTE9DS19UWVBFLlBERiwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQzfX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJvZHlDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTB9fVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSUZyYW1lLCB7IHNyYzogc291cmNlVXJsLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTF9fSApXG4gICAgICApXG4gICAgKVxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFBkZlJlYWRlclxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9SaWNoVGV4dEVkaXRvci50c3hcIjtpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgVGV4dEVkaXRvciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9UZXh0RWRpdG9yJ1xuXG5pbXBvcnQgQmxvY2tIZWFkZXIgZnJvbSAndW5pdmVyc2FsL2NvbXBvbmVudHMvQmxvY2tIZWFkZXInXG5pbXBvcnQgTGFiZWwgZnJvbSAnLi9MYWJlbCdcbmltcG9ydCBIZWFkZXJDb250YWluZXIgZnJvbSAnLi9IZWFkZXJDb250YWluZXInXG5pbXBvcnQgQ29udGVudCBmcm9tICcuL0NvbnRlbnQnXG5pbXBvcnQge0JMT0NLX1RZUEV9IGZyb20gJ3VuaXZlcnNhbC91dGlscy9jb25zdGFudHMnXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5jb25zdCBSaWNoVGV4dEVkaXRvciA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7aXNBdWRpdHMsIGJsb2NrLCBvbkVkaXQsIG9uRGVsZXRlLCBzZXRGaWVsZFZhbHVlLCBpc0VkaXRpbmcsIGluZGV4fSA9IHByb3BzXG4gIGNvbnN0IHtyaWNoX3RleHQ6IHJpY2hUZXh0LCBuYW1lfSA9IGJsb2NrXG4gIGNvbnN0IHtwbGFjZWhvbGRlciwgcmVhZF9vbmx5OiByZWFkT25seSwgdmFsdWUgPSAnJywgZm9ybWF0fSA9IHJpY2hUZXh0IHx8IHt9XG4gIGNvbnN0IHJlbmRlclZhbHVlID0gaXNFZGl0aW5nID8gcGxhY2Vob2xkZXIgOiB2YWx1ZVxuXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb250ZW50LCB7IC4uLnByb3BzLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMjh9fVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEhlYWRlckNvbnRhaW5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAyOX19XG4gICAgICAgICwgbmFtZSAmJiBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDMwfX0sIG5hbWUpXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChCbG9ja0hlYWRlciwge1xuICAgICAgICAgIG9uRGVsZXRlOiBvbkRlbGV0ZSxcbiAgICAgICAgICBvbkVkaXQ6IG9uRWRpdCxcbiAgICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgICBibG9ja1R5cGU6IEJMT0NLX1RZUEUuUklDSF9URVhULCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzF9fVxuICAgICAgICApXG4gICAgICApXG5cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChUZXh0RWRpdG9yLCB7XG4gICAgICAgIG5hbWU6IGBkYXRhLiR7aW5kZXh9LnJpY2hfdGV4dC52YWx1ZWAsXG4gICAgICAgIHZhbHVlOiByZW5kZXJWYWx1ZSxcbiAgICAgICAgcmVhZE9ubHk6IHJlYWRPbmx5IHx8IGlzQXVkaXRzLFxuICAgICAgICBwbGFjZWhvbGRlcjogcGxhY2Vob2xkZXIsXG4gICAgICAgIHNldEZpZWxkVmFsdWU6IHNldEZpZWxkVmFsdWUsXG4gICAgICAgIGZvcm1hdDogZm9ybWF0LCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzl9fVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBSaWNoVGV4dEVkaXRvclxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9TaW5nbGVTZWxlY3Rpb24udHN4XCI7aW1wb3J0IFJlYWN0LCB7bWVtbywgdXNlU3RhdGV9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5pbXBvcnQgVGFza1JhZGlvIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL1Rhc2tSYWRpbydcbmltcG9ydCBCbG9ja0hlYWRlciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9CbG9ja0hlYWRlcidcblxuaW1wb3J0IENvbnRlbnQgZnJvbSAnLi9Db250ZW50J1xuaW1wb3J0IEhlYWRlckNvbnRhaW5lciBmcm9tICcuL0hlYWRlckNvbnRhaW5lcidcbmltcG9ydCBCb2R5Q29udGFpbmVyIGZyb20gJy4vQm9keUNvbnRhaW5lcidcbmltcG9ydCBMYWJlbCBmcm9tICcuL0xhYmVsJ1xuaW1wb3J0IHtCTE9DS19UWVBFfSBmcm9tICd1bml2ZXJzYWwvdXRpbHMvY29uc3RhbnRzJ1xuaW1wb3J0IExpc3RGaWx0ZXIgZnJvbSAnY2xpZW50L2NvbXBvbmVudHMvTGlzdEZpbHRlcidcblxuXG5cblxuXG5cblxuXG5cblxuXG5jb25zdCBSYWRpbyA9IHN0eWxlZC5kaXYoe1xuICBtYXJnaW5Cb3R0b206IDEwXG59KVxuXG5jb25zdCBTaW5nbGVTZWxlY3Rpb24gPSBtZW1vKChwcm9wcykgPT4ge1xuICBjb25zdCB7YmxvY2ssIG9uRGVsZXRlLCBpc0F1ZGl0cywgaGFuZGxlQ2hhbmdlLCBpbmRleCwgaXNFZGl0aW5nLCBvbkVkaXR9ID0gcHJvcHNcbiAgY29uc3Qge25hbWUsIHR5cGV9ID0gYmxvY2tcbiAgY29uc3Qge3ZhbHVlfSA9IGJsb2NrWydzaW5nbGVfc2VsZWN0aW9uJ10gfHwge31cbiAgY29uc3QgaXNUYXNrID0gIWlzRWRpdGluZyAmJiAhaXNBdWRpdHNcbiAgY29uc3QgW2xpc3QsIHNldExpc3RdID0gdXNlU3RhdGUoYmxvY2tbdHlwZV0ub3B0aW9ucylcbiAgY29uc3Qgb3B0aW9ucyA9IGlzRWRpdGluZyA/IGJsb2NrW3R5cGVdLm9wdGlvbnMgOiBsaXN0XG5cbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KENvbnRlbnQsIHsgLi4ucHJvcHMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiAzNn19XG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSGVhZGVyQ29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDM3fX1cbiAgICAgICAgLCBuYW1lICYmIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzh9fSwgbmFtZSlcbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJsb2NrSGVhZGVyLCB7XG4gICAgICAgICAgb25EZWxldGU6IG9uRGVsZXRlLFxuICAgICAgICAgIG9uRWRpdDogb25FZGl0LFxuICAgICAgICAgIGlzRWRpdGluZzogaXNFZGl0aW5nLFxuICAgICAgICAgIGJsb2NrVHlwZTogQkxPQ0tfVFlQRS5TSU5HTEVfU0VMRUNUSU9OLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogMzl9fVxuICAgICAgICApXG4gICAgICApXG4gICAgICAsIGlzVGFzayAmJiBBcnJheS5pc0FycmF5KGJsb2NrW3R5cGVdLm9wdGlvbnMpICYmIGJsb2NrW3R5cGVdLm9wdGlvbnMubGVuZ3RoID4gMTAgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChMaXN0RmlsdGVyLCB7IGxpc3Q6IGJsb2NrW3R5cGVdLm9wdGlvbnMsIHNldExpc3Q6IHNldExpc3QsIGtleXM6IFsnbmFtZSddLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNDZ9fSApXG4gICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQm9keUNvbnRhaW5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0N319XG4gICAgICAgICwgb3B0aW9ucy5tYXAoKG9wdGlvbiwgb3B0aW9uSW5kZXgpID0+IChcbiAgICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KFJhZGlvLCB7IGtleTogb3B0aW9uSW5kZXgsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA0OX19XG4gICAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoVGFza1JhZGlvLCB7XG4gICAgICAgICAgICAgIG5hbWU6IGBkYXRhLiR7aW5kZXh9LnNpbmdsZV9zZWxlY3Rpb24udmFsdWVgLFxuICAgICAgICAgICAgICBpZDogYCR7aW5kZXh9LSR7b3B0aW9uSW5kZXh9YCxcbiAgICAgICAgICAgICAgdmFsdWU6IG9wdGlvbi5pZCxcbiAgICAgICAgICAgICAgbGFiZWw6IG9wdGlvbi5uYW1lLFxuICAgICAgICAgICAgICBvbkNoYW5nZTogaGFuZGxlQ2hhbmdlLFxuICAgICAgICAgICAgICBjaGVja2VkOiBvcHRpb24uaWQgPT09IHZhbHVlLFxuICAgICAgICAgICAgICBkaXNhYmxlZDogaXNBdWRpdHMsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1MH19XG4gICAgICAgICAgICApXG4gICAgICAgICAgKVxuICAgICAgICApKVxuICAgICAgKVxuICAgIClcbiAgKVxufSlcblxuZXhwb3J0IGRlZmF1bHQgU2luZ2xlU2VsZWN0aW9uXG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvYmxvY2tzL1RleHQudHN4XCI7aW1wb3J0IFJlYWN0LCB7dXNlQ2FsbGJhY2t9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5pbXBvcnQgTGlua2lmeSBmcm9tICdyZWFjdC1saW5raWZ5J1xuXG5pbXBvcnQgQmFzaWNUZXh0QXJlYSBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9CYXNpY1RleHRBcmVhJ1xuaW1wb3J0IEJsb2NrSGVhZGVyIGZyb20gJ3VuaXZlcnNhbC9jb21wb25lbnRzL0Jsb2NrSGVhZGVyJ1xuaW1wb3J0IExhYmVsIGZyb20gJy4vTGFiZWwnXG5pbXBvcnQgSGVhZGVyQ29udGFpbmVyIGZyb20gJy4vSGVhZGVyQ29udGFpbmVyJ1xuaW1wb3J0IEJvZHlDb250YWluZXIgZnJvbSAnLi9Cb2R5Q29udGFpbmVyJ1xuaW1wb3J0IENvbnRlbnQgZnJvbSAnLi9Db250ZW50J1xuaW1wb3J0IHtQQUxFVFRFfSBmcm9tICd1bml2ZXJzYWwvc3R5bGVzL3BhbGV0dGUnXG5pbXBvcnQge0JMT0NLX1RZUEV9IGZyb20gJ3VuaXZlcnNhbC91dGlscy9jb25zdGFudHMnXG5cblxuXG5cblxuXG5cblxuXG5cblxuZXhwb3J0IGNvbnN0IFN0eWxlZFRleHQgPSBzdHlsZWQucCh7XG4gIGZvbnRTaXplOiAxNixcbiAgbGluZUhlaWdodDogMS4zNSxcbiAgZm9udFdlaWdodDogNDAwLFxuICBjb2xvcjogUEFMRVRURS5URVhUX01BSU4sXG4gIHdoaXRlU3BhY2U6ICdwcmUtd3JhcCcsXG4gIHdvcmRXcmFwOiAnYnJlYWstd29yZCcsXG4gIHdvcmRCcmVhazogJ2JyZWFrLXdvcmQnLFxuICBjdXJzb3I6ICd0ZXh0J1xufSlcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVGV4dChwcm9wcykge1xuICBjb25zdCB7aXNBdWRpdHMsIGJsb2NrLCBvbkVkaXQsIG9uRGVsZXRlLCBoYW5kbGVDaGFuZ2UsIGlzRWRpdGluZywgaW5kZXh9ID0gcHJvcHNcbiAgY29uc3Qge3RleHQsIG5hbWV9ID0gYmxvY2tcbiAgY29uc3Qge3BsYWNlaG9sZGVyLCByZWFkX29ubHk6IHJlYWRPbmx5LCB2YWx1ZSA9ICcnfSA9IHRleHQgfHwge31cbiAgY29uc3QgcmVuZGVyVmFsdWUgPSBpc0VkaXRpbmcgPyBwbGFjZWhvbGRlciA6IHZhbHVlXG5cbiAgY29uc3QgZGVjb3JhdG9yID0gdXNlQ2FsbGJhY2soXG4gICAgKGhyZWYsIHRleHQsIGtleSkgPT4ge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudCgnYScsIHtcbiAgICAgICAgICBocmVmOiBocmVmLFxuICAgICAgICAgIGtleToga2V5LFxuICAgICAgICAgIHRhcmdldDogXCJfYmxhbmtcIixcbiAgICAgICAgICByZWw6IFwibm9vcGVuZXIgbm9yZWZlcnJlclwiICxcbiAgICAgICAgICBzdHlsZToge2NvbG9yOiBQQUxFVFRFLkxJTksgLyogdGV4dERlY29yYXRpb246ICd1bmRlcmxpbmUnICovfSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDQ0fX1cbiAgICAgICAgXG4gICAgICAgICAgLCB0ZXh0XG4gICAgICAgIClcbiAgICAgIClcbiAgICB9LFxuICAgIFtyZW5kZXJWYWx1ZV1cbiAgKVxuXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChDb250ZW50LCB7IC4uLnByb3BzLCBfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTl9fVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEhlYWRlckNvbnRhaW5lciwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2MH19XG4gICAgICAgICwgbmFtZSAmJiBSZWFjdC5jcmVhdGVFbGVtZW50KExhYmVsLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDYxfX0sIG5hbWUpXG4gICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChCbG9ja0hlYWRlciwge1xuICAgICAgICAgIG9uRGVsZXRlOiBvbkRlbGV0ZSxcbiAgICAgICAgICBvbkVkaXQ6IG9uRWRpdCxcbiAgICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgICBibG9ja1R5cGU6IEJMT0NLX1RZUEUuVEVYVCwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDYyfX1cbiAgICAgICAgKVxuICAgICAgKVxuICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJvZHlDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNjl9fVxuICAgICAgICAsICFyZWFkT25seSAmJiAhaXNBdWRpdHMgPyAoXG4gICAgICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChCYXNpY1RleHRBcmVhLCB7XG4gICAgICAgICAgICBuYW1lOiBgZGF0YS4ke2luZGV4fS50ZXh0LnZhbHVlYCxcbiAgICAgICAgICAgIG9uQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsXG4gICAgICAgICAgICBhdXRvRm9jdXM6IGZhbHNlLFxuICAgICAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAgICAgaGVpZ2h0OiAnMTAwJSdcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB2YWx1ZTogcmVuZGVyVmFsdWUgfHwgdmFsdWUsXG4gICAgICAgICAgICByZWFkT25seTogcmVhZE9ubHksIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA3MX19XG4gICAgICAgICAgKVxuICAgICAgICApIDogKFxuICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTGlua2lmeSwgeyBjb21wb25lbnREZWNvcmF0b3I6IGRlY29yYXRvciwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDgyfX1cbiAgICAgICAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChTdHlsZWRUZXh0LCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDgzfX0sIHJlbmRlclZhbHVlKVxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL2Jsb2Nrcy9UZXh0U2VxdWVuY2UudHN4XCI7IGZ1bmN0aW9uIF9vcHRpb25hbENoYWluKG9wcykgeyBsZXQgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgbGV0IHZhbHVlID0gb3BzWzBdOyBsZXQgaSA9IDE7IHdoaWxlIChpIDwgb3BzLmxlbmd0aCkgeyBjb25zdCBvcCA9IG9wc1tpXTsgY29uc3QgZm4gPSBvcHNbaSArIDFdOyBpICs9IDI7IGlmICgob3AgPT09ICdvcHRpb25hbEFjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSAmJiB2YWx1ZSA9PSBudWxsKSB7IHJldHVybiB1bmRlZmluZWQ7IH0gaWYgKG9wID09PSAnYWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJykgeyBsYXN0QWNjZXNzTEhTID0gdmFsdWU7IHZhbHVlID0gZm4odmFsdWUpOyB9IGVsc2UgaWYgKG9wID09PSAnY2FsbCcgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSB7IHZhbHVlID0gZm4oKC4uLmFyZ3MpID0+IHZhbHVlLmNhbGwobGFzdEFjY2Vzc0xIUywgLi4uYXJncykpOyBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyB9IH0gcmV0dXJuIHZhbHVlOyB9aW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHN0eWxlZCBmcm9tICdAZW1vdGlvbi9zdHlsZWQnXG5cbmltcG9ydCBCbG9ja0hlYWRlciBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9CbG9ja0hlYWRlcidcbmltcG9ydCBMYWJlbCBmcm9tICcuL0xhYmVsJ1xuaW1wb3J0IEhlYWRlckNvbnRhaW5lciBmcm9tICcuL0hlYWRlckNvbnRhaW5lcidcbmltcG9ydCBCb2R5Q29udGFpbmVyIGZyb20gJy4vQm9keUNvbnRhaW5lcidcbmltcG9ydCBDb250ZW50IGZyb20gJy4vQ29udGVudCdcbmltcG9ydCB7QkxPQ0tfVFlQRX0gZnJvbSAndW5pdmVyc2FsL3V0aWxzL2NvbnN0YW50cydcbmltcG9ydCBTZXF1ZW5jZSBmcm9tICd1bml2ZXJzYWwvY29tcG9uZW50cy9UZXh0U2VxdWVuY2UnXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5jb25zdCBCbG9jayA9IHN0eWxlZC5kaXYoe1xuICBkaXNwbGF5OiAnZmxleCcsXG4gIGZsZXhEaXJlY3Rpb246ICdyb3cnLFxuICBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLFxuICBtYXJnaW5Cb3R0b206IDEwLFxuICBmbGV4OiAnMCAwIGF1dG8nXG59KVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBUZXh0U2VxdWVuY2UocHJvcHMpIHtcbiAgY29uc3Qge2lzQXVkaXRzLCBibG9jaywgb25FZGl0LCBvbkRlbGV0ZSwgaGFuZGxlQ2hhbmdlLCBpc0VkaXRpbmcsIGluZGV4LCBzZXRGaWVsZFZhbHVlfSA9IHByb3BzXG4gIGNvbnN0IHtuYW1lLCB0eXBlfSA9IGJsb2NrIHx8IHt9XG4gIGNvbnN0IGRhdGEgPSBpc0VkaXRpbmcgPyBibG9ja1t0eXBlXS5wbGFjZWhvbGRlciA6IGJsb2NrW3R5cGVdLnZhbHVlXG4gIGNvbnN0IHtcbiAgICBkZWxldGVfZGlzYWJsZWQ6IGRlbGV0ZURpc2FibGVkLFxuICAgIGVkaXRfZGlzYWJsZWQ6IGVkaXREaXNhYmxlZCxcbiAgICBvcmRlcmluZ19kaXNhYmxlZDogb3JkZXJpbmdEaXNhYmxlZFxuICB9ID0gYmxvY2tbdHlwZV1cbiAgY29uc3Qgc2V0dGluZ3MgPSB7XG4gICAgZGVsZXRlRGlzYWJsZWQsXG4gICAgZWRpdERpc2FibGVkLFxuICAgIG9yZGVyaW5nRGlzYWJsZWRcbiAgfVxuXG4gIGNvbnN0IHRhcmdldE5hbWUgPSBpc0VkaXRpbmdcbiAgICA/IGBkYXRhWyR7aW5kZXh9XVske3R5cGV9XS5wbGFjZWhvbGRlcmBcbiAgICA6IGBkYXRhWyR7aW5kZXh9XVske3R5cGV9XS52YWx1ZWBcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29udGVudCwgeyAuLi5wcm9wcywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDUxfX1cbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChIZWFkZXJDb250YWluZXIsIHtfX3NlbGY6IHRoaXMsIF9fc291cmNlOiB7ZmlsZU5hbWU6IF9qc3hGaWxlTmFtZSwgbGluZU51bWJlcjogNTJ9fVxuICAgICAgICAsIG5hbWUgJiYgUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwge19fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1M319LCBuYW1lKVxuICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoQmxvY2tIZWFkZXIsIHtcbiAgICAgICAgICBvbkRlbGV0ZTogb25EZWxldGUsXG4gICAgICAgICAgb25FZGl0OiBvbkVkaXQsXG4gICAgICAgICAgaXNFZGl0aW5nOiBpc0VkaXRpbmcsXG4gICAgICAgICAgYmxvY2tUeXBlOiBCTE9DS19UWVBFLlRFWFQsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA1NH19XG4gICAgICAgIClcbiAgICAgIClcbiAgICAgICwgUmVhY3QuY3JlYXRlRWxlbWVudChCb2R5Q29udGFpbmVyLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDYxfX1cbiAgICAgICAgLCBSZWFjdC5jcmVhdGVFbGVtZW50KEJsb2NrLCB7X19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDYyfX1cbiAgICAgICAgICAsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU2VxdWVuY2UsIHtcbiAgICAgICAgICAgIG5hbWU6IHRhcmdldE5hbWUsXG4gICAgICAgICAgICB0YXJnZXROYW1lOiB0YXJnZXROYW1lLFxuICAgICAgICAgICAgZGF0YTogZGF0YSxcbiAgICAgICAgICAgIHR5cGU6IHR5cGUsXG4gICAgICAgICAgICBzZXRGaWVsZFZhbHVlOiBzZXRGaWVsZFZhbHVlLFxuICAgICAgICAgICAgaW5kZXg6IGluZGV4LFxuICAgICAgICAgICAgaGFuZGxlQ2hhbmdlOiBoYW5kbGVDaGFuZ2UsXG4gICAgICAgICAgICBpc0VkaXRpbmc6IGlzRWRpdGluZyxcbiAgICAgICAgICAgIGlzQXVkaXRzOiBpc0F1ZGl0cyxcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyOiBfb3B0aW9uYWxDaGFpbihbYmxvY2ssICdhY2Nlc3MnLCBfID0+IF9bdHlwZV0sICdvcHRpb25hbEFjY2VzcycsIF8yID0+IF8yLnBsYWNlaG9sZGVyXSkgfHwgW10sXG4gICAgICAgICAgICBzZXR0aW5nczogc2V0dGluZ3MsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA2M319XG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICApXG4gICAgKVxuICApXG59XG4iLCJpbXBvcnQgc29ydEJ5IGZyb20gJ2xvZGFzaC5zb3J0YnknXG5cblxuXG5cblxuXG5leHBvcnQgY29uc3Qgc3BsaXRXaXRoT2Zmc2V0cyA9ICh0ZXh0LCBvZmZzZXRzKSA9PiB7XG4gIGxldCBsYXN0RW5kID0gMFxuICBjb25zdCBzcGxpdHMgPSBbXVxuXG4gIGZvciAobGV0IG9mZnNldCBvZiBzb3J0Qnkob2Zmc2V0cywgKG8pID0+IG8uc3RhcnQpKSB7XG4gICAgY29uc3Qge3N0YXJ0LCBlbmR9ID0gb2Zmc2V0XG4gICAgaWYgKGxhc3RFbmQgPCBzdGFydCkge1xuICAgICAgc3BsaXRzLnB1c2goe1xuICAgICAgICBzdGFydDogbGFzdEVuZCxcbiAgICAgICAgZW5kOiBzdGFydCxcbiAgICAgICAgY29udGVudDogdGV4dC5zbGljZShsYXN0RW5kLCBzdGFydClcbiAgICAgIH0pXG4gICAgfVxuICAgIHNwbGl0cy5wdXNoKHtcbiAgICAgIC4uLm9mZnNldCxcbiAgICAgIG1hcms6IHRydWUsXG4gICAgICBjb250ZW50OiB0ZXh0LnNsaWNlKHN0YXJ0LCBlbmQpXG4gICAgfSlcbiAgICBsYXN0RW5kID0gZW5kXG4gIH1cbiAgaWYgKGxhc3RFbmQgPCB0ZXh0Lmxlbmd0aCkge1xuICAgIHNwbGl0cy5wdXNoKHtcbiAgICAgIHN0YXJ0OiBsYXN0RW5kLFxuICAgICAgZW5kOiB0ZXh0Lmxlbmd0aCxcbiAgICAgIGNvbnRlbnQ6IHRleHQuc2xpY2UobGFzdEVuZCwgdGV4dC5sZW5ndGgpXG4gICAgfSlcbiAgfVxuXG4gIHJldHVybiBzcGxpdHNcbn1cblxuZXhwb3J0IGNvbnN0IHNwbGl0VG9rZW5zV2l0aE9mZnNldHMgPSAodGV4dCwgb2Zmc2V0cykgPT4ge1xuICBsZXQgbGFzdEVuZCA9IDBcbiAgY29uc3Qgc3BsaXRzID0gW11cblxuICBmb3IgKGxldCBvZmZzZXQgb2Ygc29ydEJ5KG9mZnNldHMsIChvKSA9PiBvLnN0YXJ0KSkge1xuICAgIGNvbnN0IHtzdGFydCwgZW5kfSA9IG9mZnNldFxuICAgIGlmIChsYXN0RW5kIDwgc3RhcnQpIHtcbiAgICAgIGZvciAobGV0IGkgPSBsYXN0RW5kOyBpIDwgc3RhcnQ7IGkrKykge1xuICAgICAgICBzcGxpdHMucHVzaCh7XG4gICAgICAgICAgaSxcbiAgICAgICAgICBjb250ZW50OiB0ZXh0W2ldXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgfVxuICAgIHNwbGl0cy5wdXNoKHtcbiAgICAgIC4uLm9mZnNldCxcbiAgICAgIG1hcms6IHRydWUsXG4gICAgICBjb250ZW50OiB0ZXh0LnNsaWNlKHN0YXJ0LCBlbmQpLmpvaW4oJyAnKVxuICAgIH0pXG4gICAgbGFzdEVuZCA9IGVuZFxuICB9XG5cbiAgZm9yIChsZXQgaSA9IGxhc3RFbmQ7IGkgPCB0ZXh0Lmxlbmd0aDsgaSsrKSB7XG4gICAgc3BsaXRzLnB1c2goe1xuICAgICAgaSxcbiAgICAgIGNvbnRlbnQ6IHRleHRbaV1cbiAgICB9KVxuICB9XG5cbiAgcmV0dXJuIHNwbGl0c1xufVxuXG5leHBvcnQgY29uc3Qgc2VsZWN0aW9uSXNFbXB0eSA9IChzZWxlY3Rpb24pID0+IHtcbiAgbGV0IHBvc2l0aW9uID0gc2VsZWN0aW9uLmFuY2hvck5vZGUuY29tcGFyZURvY3VtZW50UG9zaXRpb24oc2VsZWN0aW9uLmZvY3VzTm9kZSlcblxuICByZXR1cm4gcG9zaXRpb24gPT09IDAgJiYgc2VsZWN0aW9uLmZvY3VzT2Zmc2V0ID09PSBzZWxlY3Rpb24uYW5jaG9yT2Zmc2V0XG59XG5cbmV4cG9ydCBjb25zdCBzZWxlY3Rpb25Jc0JhY2t3YXJkcyA9IChzZWxlY3Rpb24pID0+IHtcbiAgaWYgKHNlbGVjdGlvbklzRW1wdHkoc2VsZWN0aW9uKSkgcmV0dXJuIGZhbHNlXG5cbiAgbGV0IHBvc2l0aW9uID0gc2VsZWN0aW9uLmFuY2hvck5vZGUuY29tcGFyZURvY3VtZW50UG9zaXRpb24oc2VsZWN0aW9uLmZvY3VzTm9kZSlcblxuICBsZXQgYmFja3dhcmQgPSBmYWxzZVxuICBpZiAoXG4gICAgKCFwb3NpdGlvbiAmJiBzZWxlY3Rpb24uYW5jaG9yT2Zmc2V0ID4gc2VsZWN0aW9uLmZvY3VzT2Zmc2V0KSB8fFxuICAgIHBvc2l0aW9uID09PSBOb2RlLkRPQ1VNRU5UX1BPU0lUSU9OX1BSRUNFRElOR1xuICApXG4gICAgYmFja3dhcmQgPSB0cnVlXG5cbiAgcmV0dXJuIGJhY2t3YXJkXG59XG4iLCJjb25zdCBfanN4RmlsZU5hbWUgPSBcIi9Vc2Vycy9hL2dpdC9IdW1hbi1MYW1iZGFzL2hsLXdlYi9zcmMvdW5pdmVyc2FsL2NvbXBvbmVudHMvdGV4dC1hbm5vdGF0b3IvTWFyay50c3hcIjtpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5cblxuXG5cblxuXG5cblxuXG5cblxuY29uc3QgTWFyayA9IChwcm9wcykgPT4ge1xuICBjb25zdCB7Y29sb3IsIHN0YXJ0LCBlbmQsIGNvbnRlbnQsIHRhZywgb25DbGlja30gPSBwcm9wc1xuXG4gIHJldHVybiAoXG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudCgnbWFyaycsIHtcbiAgICAgIHN0eWxlOiB7YmFja2dyb3VuZENvbG9yOiBjb2xvciB8fCAnIzg0ZDJmZicsIHBhZGRpbmc6ICcwIDRweCd9LFxuICAgICAgJ2RhdGEtc3RhcnQnOiBzdGFydCxcbiAgICAgICdkYXRhLWVuZCc6IGVuZCxcbiAgICAgIG9uQ2xpY2s6ICgpID0+IG9uQ2xpY2soe3N0YXJ0LCBlbmR9KSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDE3fX1cbiAgICBcbiAgICAgICwgY29udGVudFxuICAgICAgLCB0YWcgJiYgUmVhY3QuY3JlYXRlRWxlbWVudCgnc3BhbicsIHsgc3R5bGU6IHtmb250U2l6ZTogJzAuN2VtJywgZm9udFdlaWdodDogNTAwLCBtYXJnaW5MZWZ0OiA2fSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDI0fX0sIHRhZylcbiAgICApXG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgTWFya1xuIiwiY29uc3QgX2pzeEZpbGVOYW1lID0gXCIvVXNlcnMvYS9naXQvSHVtYW4tTGFtYmRhcy9obC13ZWIvc3JjL3VuaXZlcnNhbC9jb21wb25lbnRzL3RleHQtYW5ub3RhdG9yL1RleHRBbm5vdGF0b3IudHN4XCI7aW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuXG5pbXBvcnQgTWFyayBmcm9tICcuL01hcmsnXG5pbXBvcnQge3NlbGVjdGlvbklzRW1wdHksIHNlbGVjdGlvbklzQmFja3dhcmRzLCBzcGxpdFdpdGhPZmZzZXRzfSBmcm9tICcuL0Z1bmN0aW9ucydcblxuXG5jb25zdCBTcGxpdCA9IChwcm9wcykgPT4ge1xuICBpZiAocHJvcHMubWFyaykgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoTWFyaywgeyAuLi5wcm9wcywgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDh9fSApXG5cbiAgcmV0dXJuIChcbiAgICBSZWFjdC5jcmVhdGVFbGVtZW50KCdzcGFuJywge1xuICAgICAgJ2RhdGEtc3RhcnQnOiBwcm9wcy5zdGFydCxcbiAgICAgICdkYXRhLWVuZCc6IHByb3BzLmVuZCxcbiAgICAgIG9uQ2xpY2s6ICgpID0+IHByb3BzLm9uQ2xpY2soe3N0YXJ0OiBwcm9wcy5zdGFydCwgZW5kOiBwcm9wcy5lbmR9KSwgX19zZWxmOiB0aGlzLCBfX3NvdXJjZToge2ZpbGVOYW1lOiBfanN4RmlsZU5hbWUsIGxpbmVOdW1iZXI6IDExfX1cbiAgICBcbiAgICAgICwgcHJvcHMuY29udGVudFxuICAgIClcbiAgKVxufVxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuY29uc3QgVGV4dEFubm90YXRvciA9IChwcm9wcykgPT4ge1xuICBjb25zdCBnZXRTcGFuID0gKHNwYW4pID0+IHtcbiAgICAvLyBUT0RPOiBCZXR0ZXIgdHlwaW5ncyBoZXJlLlxuICAgIGlmIChwcm9wcy5nZXRTcGFuKSByZXR1cm4gcHJvcHMuZ2V0U3BhbihzcGFuKSBcbiAgICByZXR1cm4ge3N0YXJ0OiBzcGFuLnN0YXJ0LCBlbmQ6IHNwYW4uZW5kfSBcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZU1vdXNlVXAgPSAoKSA9PiB7XG4gICAgaWYgKCFwcm9wcy5vbkNoYW5nZSkgcmV0dXJuXG5cbiAgICBjb25zdCBzZWxlY3Rpb24gPSB3aW5kb3cuZ2V0U2VsZWN0aW9uKClcblxuICAgIGlmICghc2VsZWN0aW9uLmFuY2hvck5vZGUgfHwgIXNlbGVjdGlvbi5mb2N1c05vZGUgfHwgc2VsZWN0aW9uSXNFbXB0eShzZWxlY3Rpb24pKSByZXR1cm5cblxuICAgIGxldCBzdGFydCA9XG4gICAgICBwYXJzZUludChzZWxlY3Rpb24uYW5jaG9yTm9kZS5wYXJlbnRFbGVtZW50LmdldEF0dHJpYnV0ZSgnZGF0YS1zdGFydCcpLCAxMCkgK1xuICAgICAgc2VsZWN0aW9uLmFuY2hvck9mZnNldFxuICAgIGxldCBlbmQgPVxuICAgICAgcGFyc2VJbnQoc2VsZWN0aW9uLmZvY3VzTm9kZS5wYXJlbnRFbGVtZW50LmdldEF0dHJpYnV0ZSgnZGF0YS1zdGFydCcpLCAxMCkgK1xuICAgICAgc2VsZWN0aW9uLmZvY3VzT2Zmc2V0XG5cbiAgICBpZiAoXG4gICAgICAhTnVtYmVyLmlzSW50ZWdlcihzdGFydCkgfHxcbiAgICAgICFOdW1iZXIuaXNJbnRlZ2VyKGVuZCkgfHxcbiAgICAgIHNlbGVjdGlvbi5hbmNob3JOb2RlLmNvbXBhcmVEb2N1bWVudFBvc2l0aW9uKHNlbGVjdGlvbi5mb2N1c05vZGUpICE9PSAwXG4gICAgKSB7XG4gICAgICB3aW5kb3cuZ2V0U2VsZWN0aW9uKCkuZW1wdHkoKVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgaWYgKHNlbGVjdGlvbklzQmFja3dhcmRzKHNlbGVjdGlvbikpIHtcbiAgICAgIDtbc3RhcnQsIGVuZF0gPSBbZW5kLCBzdGFydF1cbiAgICB9XG5cbiAgICBwcm9wcy5vbkNoYW5nZShbLi4ucHJvcHMudmFsdWUsIGdldFNwYW4oe3N0YXJ0LCBlbmQsIHRleHQ6IGNvbnRlbnQuc2xpY2Uoc3RhcnQsIGVuZCl9KV0pXG5cbiAgICB3aW5kb3cuZ2V0U2VsZWN0aW9uKCkuZW1wdHkoKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlU3BsaXRDbGljayA9ICh7c3RhcnQsIGVuZH0pID0+IHtcbiAgICAvLyBGaW5kIGFuZCByZW1vdmUgdGhlIG1hdGNoaW5nIHNwbGl0LlxuICAgIGNvbnN0IHNwbGl0SW5kZXggPSBwcm9wcy52YWx1ZS5maW5kSW5kZXgoKHMpID0+IHMuc3RhcnQgPT09IHN0YXJ0ICYmIHMuZW5kID09PSBlbmQpXG4gICAgaWYgKHNwbGl0SW5kZXggPj0gMCkge1xuICAgICAgcHJvcHMub25DaGFuZ2UoWy4uLnByb3BzLnZhbHVlLnNsaWNlKDAsIHNwbGl0SW5kZXgpLCAuLi5wcm9wcy52YWx1ZS5zbGljZShzcGxpdEluZGV4ICsgMSldKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHtjb250ZW50LCB2YWx1ZSwgc3R5bGV9ID0gcHJvcHNcbiAgY29uc3Qgc3BsaXRzID0gc3BsaXRXaXRoT2Zmc2V0cyhjb250ZW50LCB2YWx1ZSlcblxuICByZXR1cm4gKFxuICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoJ2RpdicsIHsgc3R5bGU6IHN0eWxlLCBvbk1vdXNlVXA6IGhhbmRsZU1vdXNlVXAsIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA4Nn19XG4gICAgICAsIHNwbGl0cy5tYXAoKHNwbGl0KSA9PiAoXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3BsaXQsIHsga2V5OiBgJHtzcGxpdC5zdGFydH0tJHtzcGxpdC5lbmR9YCwgLi4uc3BsaXQsIG9uQ2xpY2s6IGhhbmRsZVNwbGl0Q2xpY2ssIF9fc2VsZjogdGhpcywgX19zb3VyY2U6IHtmaWxlTmFtZTogX2pzeEZpbGVOYW1lLCBsaW5lTnVtYmVyOiA4OH19IClcbiAgICAgICkpXG4gICAgKVxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IFRleHRBbm5vdGF0b3JcbiIsImltcG9ydCB7dXNlRWZmZWN0LCB1c2VSZWZ9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCB1c2VQcmV2aW91cyA9ICh2YWx1ZSkgPT4ge1xuICBjb25zdCByZWYgPSB1c2VSZWYoKVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJlZi5jdXJyZW50ID0gdmFsdWVcbiAgfSlcbiAgcmV0dXJuIHJlZi5jdXJyZW50XG59XG5cbmV4cG9ydCBkZWZhdWx0IHVzZVByZXZpb3VzIiwidmFyIGFwaSA9IHJlcXVpcmUoXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5qZWN0U3R5bGVzSW50b1N0eWxlVGFnLmpzXCIpO1xuICAgICAgICAgICAgdmFyIGNvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL3JlYWN0LWdyaWQtbGF5b3V0LmNzc1wiKTtcblxuICAgICAgICAgICAgY29udGVudCA9IGNvbnRlbnQuX19lc01vZHVsZSA/IGNvbnRlbnQuZGVmYXVsdCA6IGNvbnRlbnQ7XG5cbiAgICAgICAgICAgIGlmICh0eXBlb2YgY29udGVudCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgY29udGVudCA9IFtbbW9kdWxlLmlkLCBjb250ZW50LCAnJ11dO1xuICAgICAgICAgICAgfVxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLmluc2VydCA9IFwiaGVhZFwiO1xub3B0aW9ucy5zaW5nbGV0b24gPSBmYWxzZTtcblxudmFyIHVwZGF0ZSA9IGFwaShjb250ZW50LCBvcHRpb25zKTtcblxuXG5cbm1vZHVsZS5leHBvcnRzID0gY29udGVudC5sb2NhbHMgfHwge307IiwidmFyIGFwaSA9IHJlcXVpcmUoXCIhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5qZWN0U3R5bGVzSW50b1N0eWxlVGFnLmpzXCIpO1xuICAgICAgICAgICAgdmFyIGNvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL3JlYWN0LXJlc2l6YWJsZS5jc3NcIik7XG5cbiAgICAgICAgICAgIGNvbnRlbnQgPSBjb250ZW50Ll9fZXNNb2R1bGUgPyBjb250ZW50LmRlZmF1bHQgOiBjb250ZW50O1xuXG4gICAgICAgICAgICBpZiAodHlwZW9mIGNvbnRlbnQgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgIGNvbnRlbnQgPSBbW21vZHVsZS5pZCwgY29udGVudCwgJyddXTtcbiAgICAgICAgICAgIH1cblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5pbnNlcnQgPSBcImhlYWRcIjtcbm9wdGlvbnMuc2luZ2xldG9uID0gZmFsc2U7XG5cbnZhciB1cGRhdGUgPSBhcGkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5tb2R1bGUuZXhwb3J0cyA9IGNvbnRlbnQubG9jYWxzIHx8IHt9OyIsInZhciBhcGkgPSByZXF1aXJlKFwiIS4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiKTtcbiAgICAgICAgICAgIHZhciBjb250ZW50ID0gcmVxdWlyZShcIiEhLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi9yZ2wtb3ZlcmlkZS5jc3NcIik7XG5cbiAgICAgICAgICAgIGNvbnRlbnQgPSBjb250ZW50Ll9fZXNNb2R1bGUgPyBjb250ZW50LmRlZmF1bHQgOiBjb250ZW50O1xuXG4gICAgICAgICAgICBpZiAodHlwZW9mIGNvbnRlbnQgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgIGNvbnRlbnQgPSBbW21vZHVsZS5pZCwgY29udGVudCwgJyddXTtcbiAgICAgICAgICAgIH1cblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5pbnNlcnQgPSBcImhlYWRcIjtcbm9wdGlvbnMuc2luZ2xldG9uID0gZmFsc2U7XG5cbnZhciB1cGRhdGUgPSBhcGkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuXG5tb2R1bGUuZXhwb3J0cyA9IGNvbnRlbnQubG9jYWxzIHx8IHt9OyIsImNvbnN0IGdldEl0ZW1TdHlsZSA9IChfaXNEcmFnZ2luZywgZHJhZ2dhYmxlU3R5bGUpID0+IHtcbiAgY29uc3Qge3RyYW5zZm9ybX0gPSBkcmFnZ2FibGVTdHlsZVxuICBsZXQgYWN0aXZlVHJhbnNmb3JtID0ge31cbiAgaWYgKHRyYW5zZm9ybSkge1xuICAgIGFjdGl2ZVRyYW5zZm9ybSA9IHtcbiAgICAgIHRyYW5zZm9ybTogYHRyYW5zbGF0ZSgwLCAke3RyYW5zZm9ybS5zdWJzdHJpbmcoXG4gICAgICAgIHRyYW5zZm9ybS5pbmRleE9mKCcsJykgKyAxLFxuICAgICAgICB0cmFuc2Zvcm0uaW5kZXhPZignKScpXG4gICAgICApfSlgXG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgdXNlclNlbGVjdDogJ25vbmUnLFxuICAgIC8vIGJhY2tncm91bmQ6IGlzRHJhZ2dpbmcgPyAnI2ZmZicgOiAnI2ZmZicsXG4gICAgYmFja2dyb3VuZDogJyNmZmYnLFxuICAgIG91dGxpbmU6ICdub25lJyxcbiAgICB3aWR0aDogJzEwMCUnLFxuICAgIGhlaWdodDogJzEwMCUnLFxuICAgIC4uLmRyYWdnYWJsZVN0eWxlLFxuICAgIC4uLmFjdGl2ZVRyYW5zZm9ybVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGdldEl0ZW1TdHlsZVxuIiwiY29uc3QgaXNFbXB0eUFycmF5ID0gKHZhbHVlKSA9PiB7XG4gIGlmICh2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gdW5kZWZpbmVkKSByZXR1cm4gdHJ1ZVxuICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgdmFsdWUuc3BsaWNlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgcmV0dXJuICF2YWx1ZS5sZW5ndGhcbiAgfVxuICByZXR1cm4gZmFsc2Vcbn1cblxuZXhwb3J0IGRlZmF1bHQgaXNFbXB0eUFycmF5XG4iXSwic291cmNlUm9vdCI6IiJ9